Godot APK analysis
==================

The resources/, sources/ and smali/ folders next to this one are the Android
wrapper: an activity that starts the engine, plus whatever ad and analytics SDKs
the developer linked in. None of the game is in them.

This godot/ folder is the game. Nothing from the uploaded APK was executed.

Project:  recovered into project/ — open it with Godot 4.7.2
Scripts:  231 decompiled .gd files, also copied flat into scripts/

Limitations
-----------
GDScript decompiles back to readable source, but comments and blank lines are
not in the bytecode and do not come back. Scripts written in C# or as a native
GDExtension are compiled code and are not recoverable this way. Content the game
downloads at runtime was never in the APK.
