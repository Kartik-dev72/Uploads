class_name SoulBurst
extends Node2D







const MAX_SOULS: = 40
const SPREAD_TIME: = 0.5
const MAX_GAP: = 0.05
const KICK: = Vector2(160.0, 320.0)
const PULL: = 3200.0
const TOP_SPEED: = 900.0

var _hud: HUD
var _player: Player
var _tex: Texture2D
var _souls: Array[Dictionary] = []
var _speed: = TOP_SPEED


static func spawn(parent: Node, at: Vector2, amount: int, hud: HUD) -> void :
	var b: = SoulBurst.new()
	b._hud = hud
	var n: = mini(amount, MAX_SOULS)
	var gap: = minf(SPREAD_TIME / n, MAX_GAP)
	b._speed = TOP_SPEED * (1.0 + n / 40.0)
	for i in n:
		var dir: = Vector2.RIGHT.rotated(randf() * TAU)
		b._souls.append({"pos": at + dir * randf_range(4.0, 14.0), "vel": dir * randf_range(KICK.x, KICK.y), 
			"wait": gap * i, "share": amount / n + (1 if i < amount % n else 0)})
	parent.add_child(b)

func _ready() -> void :
	Layers.put(self, Layers.PICKUPS + 1)
	_player = get_tree().get_first_node_in_group("player") as Player
	_tex = Game.theme.texture(Game.theme.pickups.get("coin", "coin"))

func _process(delta: float) -> void :
	if not is_instance_valid(_player):
		queue_free()
		return
	var target: = _player.global_position
	for i in range(_souls.size() - 1, -1, -1):
		var s: Dictionary = _souls[i]
		if s["wait"] > 0.0:
			s["wait"] -= delta
			continue
		var to: Vector2 = target - s["pos"]
		var dist: = to.length()
		if dist < _player.radius:
			_arrive(s)
			_souls.remove_at(i)
			continue
		s["vel"] = (s["vel"] as Vector2).move_toward(to / maxf(dist, 0.01) * _speed, PULL * delta)
		var step: Vector2 = s["vel"] * delta
		if step.dot(to) > 0.0 and step.length() >= dist - _player.radius:
			_arrive(s)
			_souls.remove_at(i)
			continue
		s["pos"] += step
	queue_redraw()
	if _souls.is_empty():
		queue_free()

func _arrive(s: Dictionary) -> void :
	if is_instance_valid(_hud):
		_hud.soul_arrived(int(s["share"]), _player.global_position, _souls.size())


func _exit_tree() -> void :
	if is_instance_valid(_hud):
		for s: Dictionary in _souls:
			_hud.soul_arrived(int(s["share"]), Vector2.INF, 0)

func _draw() -> void :
	var size: = _tex.get_size() * Pickup.SCALE
	for s: Dictionary in _souls:
		if s["wait"] <= 0.0:
			draw_texture_rect(_tex, Rect2(s["pos"] - global_position - size * 0.5, size), false)
