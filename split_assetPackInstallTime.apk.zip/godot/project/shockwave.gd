class_name Shockwave
extends Weapon







const ID: = "shockwave"
const COOLDOWN_TEXT: = "tolls %d%% more often"
const MAX_RADIUS: = 250.0
const MAX_REACH: = 380.0
const EDGE_DAMAGE: = 0.35
const WAVE_SPEED: = 950.0
const BAND: = 34.0
const PUSH: = 560.0
const MIN_COOLDOWN: = 11.0
const BASE: = {"damage": 50.0, "cooldown": 20.0, "area": 1.0, "force": 1.0}
const UPGRADES: = [
	{"damage": 25.0}, 
	{"area": 1.1}, 
	{"cooldown": 0.9}, 
	{"damage": 35.0}, 
	{"area": 1.1}, 
	{"cooldown": 0.9}, 
	{"damage": 50.0}, 
]


const HOLY: = {"damage": 60.0, "area": 1.1, "cooldown": 0.6, "force": 1.4}
const HOLY_MIN_COOLDOWN: = 7.0
const PULL_REACH: = 520.0

var damage: = 50.0
var cooldown: = 20.0
var area: = 1.0
var force: = 1.0
var _timer: = 4.0
var _waves: Array[Dictionary] = []

func _on_level() -> void :
	Layers.put(self, Layers.AROUND_PLAYER)

func _process(delta: float) -> void :
	_timer -= delta
	if _timer <= 0.0 and not enemies_on_screen().is_empty():
		_timer = maxf(cooldown_of(cooldown), HOLY_MIN_COOLDOWN if holy else MIN_COOLDOWN)
		_release()
		if holy:
			_gather()
	if _waves.is_empty():
		return
	for w in _waves:
		w["r"] += WAVE_SPEED * delta
		_hit_ring(w)
	_waves = _waves.filter( func(w: Dictionary) -> bool: return w["r"] < w["max_r"])
	queue_redraw()

func _release() -> void :
	_waves.append({"r": 20.0, "max_r": minf(area_of(MAX_RADIUS * area), MAX_REACH), "hit": {}, "origin": global_position})
	Game.sfx("explode")
	player.shake(5.0)


func _gather() -> void :
	var reach: = PULL_REACH * PULL_REACH
	for g: XPGem in get_tree().get_nodes_in_group("xp_vacuum"):
		if g.global_position.distance_squared_to(global_position) < reach:
			g.pull()
	for g: XPGem in get_tree().get_nodes_in_group("pullable_pickups"):
		if g is Pickup and (g as Pickup).kind == Pickup.Kind.COIN and g.global_position.distance_squared_to(global_position) < reach:
			g.pull()

func _hit_ring(w: Dictionary) -> void :
	var origin: Vector2 = w["origin"]
	var hit: Dictionary = w["hit"]
	for e: Enemy in Enemy.near(origin, float(w["r"]) + BAND):
		var id: = e.get_instance_id()
		if hit.has(id):
			continue
		var d: = origin.distance_to(e.global_position)
		if absf(d - float(w["r"])) < BAND + e.radius:
			hit[id] = true
			var falloff: = lerpf(1.0, EDGE_DAMAGE, clampf(float(w["r"]) / float(w["max_r"]), 0.0, 1.0))
			e.take_damage(power(damage) * falloff, 0.0)
			e.knock(origin.direction_to(e.global_position) * PUSH * force)
	if holy:
		return
	var r: = float(w["r"])
	for group in ["xp_vacuum", "pullable_pickups", "rare_pickups"]:
		for g: Node2D in get_tree().get_nodes_in_group(group):
			if not g.is_queued_for_deletion() and absf(origin.distance_to(g.global_position) - r) < BAND:
				RingFx.spawn(g.get_parent(), g.global_position, 18.0, color)
				g.queue_free()

func _draw() -> void :
	var hot: = color.lightened(0.5)
	for w in _waves:
		var o: = to_local(w["origin"])
		var k: = float(w["r"]) / float(w["max_r"])
		var fade: = 1.0 - k * k
		PixelFx.arc(self, o, w["r"], 0, TAU, Color(color, 0.25 * fade), BAND * 1.6)
		PixelFx.arc(self, o, w["r"], 0, TAU, Color(color, 0.8 * fade), 10.0 * fade + 2.0)
		PixelFx.arc(self, o, w["r"] - 8.0, 0, TAU, Color(hot, 0.9 * fade), 3.0)
		PixelFx.arc(self, o, w["r"] * 0.82, 0, TAU, Color(hot, 0.35 * fade), 2.0)
		if holy:
			PixelFx.arc(self, o, w["r"] + 12.0, 0, TAU, Color(1, 1, 1, 0.5 * fade), 3.0)
			for j in 3:
				var rr: float = float(w["r"]) - 26.0 * (j + 1)
				if rr <= 0.0:
					continue
				for seg in 12:
					var a0: = TAU * seg / 12.0 + j * 0.13
					PixelFx.arc(self, o, rr, a0, a0 + TAU / 20.0, Color(1, 1, 1, (0.55 - j * 0.15) * fade), 3.0)
			for n in 8:
				var d: = Vector2.RIGHT.rotated(TAU * n / 8.0 + float(w["r"]) * 0.002)
				var p: = o + d * float(w["r"])
				PixelFx.disc(self, p + Vector2(0, 4), 5.0, Color(1, 1, 1, 0.8 * fade))
				PixelFx.line(self, p + Vector2(4, 4), p + Vector2(4, -10), Color(1, 1, 1, 0.8 * fade), 2.0)
