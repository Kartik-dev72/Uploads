class_name HolyWater
extends Weapon




const ID: = "holy_water"
const COOLDOWN_TEXT: = "throws %d%% more often"
const POOL_RADIUS: = 60.0
const BASE: = {"damage": 8.0, "cooldown": 2.5, "count": 1, "area": 1.0, "duration": 2.5}
const UPGRADES: = [
	{"area": 1.2}, 
	{"damage": 4.0}, 
	{"duration": 1.3}, 
	{"count": 1}, 
	{"cooldown": 0.85}, 
	{"damage": 6.0}, 
	{"area": 1.2}, 
]



const HOLY: = {"damage": 4.0, "area": 1.1, "duration": 1.3}

var damage: = 8.0
var cooldown: = 2.5
var count: = 1
var area: = 1.0
var duration: = 2.5
var _timer: = 1.0
var _time: = 0.0

func _on_level() -> void :
	Layers.put(self, Layers.GROUND_EFFECTS)
	for v in PixelFx.POOL_VARIANTS:
		PixelFx.pool_frames(area_of(POOL_RADIUS * area), color, v)

func _process(delta: float) -> void :
	_time += delta
	_timer -= delta
	if _timer > 0.0:
		return
	_timer = cooldown_of(cooldown)
	if holy:
		_spring()
		return


	var inner: = visible_rect()
	inner = inner.grow_individual( - inner.size.x * 0.25, - inner.size.y * 0.25, - inner.size.x * 0.25, - inner.size.y * 0.25)
	var targets: = enemies_on_screen().filter( func(e: Enemy) -> bool: return inner.has_point(e.global_position))
	targets.shuffle()
	for i in amount_of(count):
		var at: = global_position + Vector2.RIGHT.rotated(randf() * TAU) * randf_range(60.0, 180.0)
		if i < targets.size():
			at = targets[i].global_position
		_splash(at)


func _splash(at: Vector2) -> void :
	var zone: = DamageZone.new()
	zone.radius = area_of(POOL_RADIUS * area)
	zone.damage = power(damage)
	zone.duration = duration_of(duration)
	zone.color = color
	zone.global_position = at
	var flask: = FlaskThrow.new()
	flask.texture = Game.theme.texture(icon())
	flask.from = global_position + Vector2(0, -30)
	flask.to = at
	flask.zone = zone
	flask.tint = color
	flask.add_to_group("win_clear")
	get_tree().current_scene.add_child(flask)


class FlaskThrow extends Node2D:
	const FLIGHT: = 0.42
	const HEIGHT: = 150.0
	var texture: Texture2D
	var from: = Vector2.ZERO
	var to: = Vector2.ZERO
	var zone: Node2D
	var tint: = Color.WHITE
	var _t: = 0.0
	var _shards: = 0.0

	func _ready() -> void :
		Layers.put(self, Layers.FLYING)
		global_position = from

	func _process(delta: float) -> void :
		if _shards > 0.0:
			_shards -= delta
			queue_redraw()
			if _shards <= 0.0:
				queue_free()
			return
		_t += delta / FLIGHT
		if _t >= 1.0:
			global_position = to
			get_parent().add_child(zone)
			Game.sfx("splash")
			_shards = 0.25
			queue_redraw()
			return
		global_position = from.lerp(to, _t) + Vector2(0, - sin(_t * PI) * HEIGHT)
		rotation = floorf(_t * 6.0) * PI / 2.0
		queue_redraw()

	func _draw() -> void :
		if _shards > 0.0:
			rotation = 0.0
			var k: = 1.0 - _shards / 0.25
			for i in 8:
				var d: = Vector2.RIGHT.rotated(i * TAU / 8.0 + 0.3) * (10.0 + 44.0 * k) + Vector2(0, 30.0 * k * k)
				PixelFx.dot(self, d, Color(tint.lightened(0.5) if i % 2 else Color(0.85, 0.95, 1), 1.0 - k), 2 if k < 0.5 else 1)
			return
		if texture:
			var size: = texture.get_size() * 3.0
			draw_texture_rect(texture, Rect2( - size * 0.5, size), false)
		else:
			PixelFx.disc(self, Vector2.ZERO, 10.0, tint)


func _spring() -> void :
	Game.sfx("splash", 0.8)
	var n: = amount_of(count)
	var turn: = randf() * TAU
	for i in n:
		var pool: = DamageZone.new()
		pool.radius = area_of(POOL_RADIUS * area)
		pool.damage = power(damage)
		pool.duration = duration_of(duration)
		pool.color = color
		pool.follow = player
		pool.global_position = global_position + Vector2.RIGHT.rotated(turn + TAU * i / n) * randf_range(70.0, 130.0)
		get_tree().current_scene.add_child(pool)
