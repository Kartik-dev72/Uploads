class_name Pickup
extends XPGem










enum Kind{COIN, HEART, BLESSING, VACUUM, PURGE, FREEZE, FEVER, LUCK}

const SCALE: = 3.0


const POUCH: = 3
const COFFER: = 18
const TROPHY_SCALE: = 4.0
const LITTLE_HEAL: = 0.35
const LITTLE_SCALE: = 0.6
const TROPHY_TILT: = -0.32

static var _heads: = {}

var kind: = Kind.COIN
var tier: = 0
var blessed: = false
var quiet: = false
var little: = false
var trophy: = {}
var _texture: Texture2D
var _pulse: = 0.0

func _init() -> void :
	mergeable = false
	vacuumable = false

static func spawn(parent: Node, pickup_kind: Kind, pos: Vector2, amount: = 1) -> Pickup:
	var p: = Pickup.new()
	p.kind = pickup_kind
	p.value = amount
	p.position = GameMap.reachable(pos)
	parent.add_child.call_deferred(p)
	return p



const LITTLE_MAX: = 10
static var _little_alive: = 0

static func reset_little_hearts() -> void :
	_little_alive = 0
var _uncounted: = false

static func little_heart(parent: Node, pos: Vector2) -> Pickup:
	if _little_alive >= LITTLE_MAX:
		return null
	_little_alive += 1
	var p: = Pickup.new()
	p.kind = Kind.HEART
	p.little = true
	p.position = GameMap.reachable(pos)
	parent.add_child.call_deferred(p)
	return p

func _ready() -> void :
	super ()
	var key: String = ["coin", "heart", "blessing", "vacuum", "purge", "freeze", "fever", "luck"][kind]
	if kind == Kind.COIN and value >= POUCH:
		key = "soul_coffer" if value >= COFFER else "soul_pouch"
	_texture = trophy_texture(trophy) if not trophy.is_empty() else Game.theme.texture(Game.theme.pickups.get(key, key))
	if kind == Kind.COIN or kind == Kind.HEART:
		add_to_group("pullable_pickups")
		if kind == Kind.COIN:
			add_to_group("soul_pickups")
	elif kind == Kind.VACUUM or kind == Kind.PURGE or kind == Kind.FREEZE or kind == Kind.FEVER or kind == Kind.LUCK:
		add_to_group("rare_pickups")
	if kind == Kind.BLESSING:
		magnetic = false
		add_to_group(OffscreenPointer.GROUP)
		if not quiet:
			Game.sfx("chest_spawn")

func _exit_tree() -> void :
	super ()
	if little and not _uncounted:
		_little_alive -= 1
		_uncounted = true

func _process(delta: float) -> void :
	super (delta)
	if _glows():
		_pulse += delta
		queue_redraw()

func _glows() -> bool:
	return kind == Kind.BLESSING or kind == Kind.VACUUM or kind == Kind.PURGE or kind == Kind.FREEZE\
	or kind == Kind.FEVER or kind == Kind.LUCK or (kind == Kind.COIN and value >= COFFER)


func pointer_texture() -> Texture2D:
	return _texture

func pointer_color() -> Color:
	return Game.theme.ui.get("holy", Color(1, 0.93, 0.55))



func _can_collect() -> bool:
	if kind != Kind.BLESSING:
		return true
	var screen: = get_tree().get_first_node_in_group("blessing_screen") as CanvasItem
	return screen == null or not screen.visible

func _collect() -> void :
	match kind:
		Kind.COIN:

			_player.add_coins(value, global_position, value >= POUCH)
			SoulFever.soul_taken(get_tree(), value)
			Game.sfx("coin" if value < POUCH else "jackpot")
			if value >= POUCH:
				Game.track("soul_bags")
		Kind.HEART:
			_player.heal(_player.heal_drop() * (LITTLE_HEAL if little else 1.0))
			_player.add_score(Game.SCORE["heart"])
			Game.track("hearts")
			Game.sfx("heal")
		Kind.BLESSING:
			_player.add_score(Game.SCORE["blessing"])
			if trophy.is_empty():
				Game.track("chests")
			var screen: = get_tree().get_first_node_in_group("blessing_screen")
			if screen:
				if trophy.is_empty():
					screen.open(tier, BlessingScreen.BIG_CHEST_LEVEL if blessed else 0)
				else:
					screen.open_trophy(trophy)
		Kind.VACUUM:
			Game.sfx("vacuum")
			Game.track("vacuums")
			_player.add_score(Game.SCORE["rare"])
			XPGem.vacuum_all(get_tree())
		Kind.PURGE:
			Game.sfx("purge")
			Game.track("purges")
			_player.add_score(Game.SCORE["rare"])
			HolyFlash.purge(_player)
		Kind.FREEZE:
			Game.track("freezes")
			_player.add_score(Game.SCORE["rare"])
			Freeze.start(get_tree().current_scene, _player)
		Kind.FEVER:
			Game.track("fevers")
			_player.add_score(Game.SCORE["rare"])
			SoulFever.start(get_tree().current_scene, _player)
		Kind.LUCK:
			Game.track("nails")
			_player.luck_found += 0.1
			_player.recalc_stats()
			Game.sfx("select", 1.4)
			FloatText.pop(self, "+10% LUCK", global_position + Vector2(0, -50), Color(0.85, 0.85, 0.95), 30, 1.2, 60.0)


static func trophy_texture(data: Dictionary) -> Texture2D:
	var sprite: = str(data.get("sprite", ""))
	var full: = Game.theme.texture(sprite)
	var r: Array = data.get("head", [0, 0, roundi(full.get_width()), ceili(full.get_height() * 0.6)])
	var key: = "%s|%s" % [sprite, r]
	if not _heads.has(key):
		var img: = full.get_image()
		var f: = PixelArt.factor_of(full, img)
		var rect: = Rect2i(r[0] * f, r[1] * f, r[2] * f, r[3] * f).intersection(Rect2i(Vector2i.ZERO, img.get_size()))
		var head: = ImageTexture.create_from_image(img.get_region(rect))
		if f > 1:
			head.set_size_override(rect.size / f)
		_heads[key] = head
	return _heads[key]



func _draw_trophy() -> void :
	var size: = _texture.get_size() * TROPHY_SCALE
	var pulse: = 0.5 + 0.5 * sin(_pulse * 3.0)
	var holy: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
	var blood: Color = Game.theme.ui["hp"]
	var w: = size.x
	draw_rect(Rect2( - w * 0.45, -360, w * 0.9, 360), Color(holy, 0.07 + 0.05 * pulse))
	draw_rect(Rect2( - w * 0.18, -360, w * 0.36, 360), Color(1, 1, 1, 0.07 + 0.07 * pulse))

	draw_set_transform(Vector2(0, size.y * 0.42), 0.0, Vector2(1, 0.38))
	draw_circle(Vector2.ZERO, w * 0.62, Color(blood.darkened(0.55), 0.85))
	draw_circle(Vector2( - w * 0.12, -4), w * 0.42, Color(blood.darkened(0.35), 0.8))
	draw_set_transform(Vector2.ZERO)
	var salt: = int(absf(position.x * 7.0 + position.y * 13.0))
	for i in 5:
		var a: = TAU * i / 5.0 + float(salt % 7)
		var d: = w * (0.6 + 0.1 * ((salt >> i) % 3))
		PixelFx.dot(self, Vector2(cos(a) * d, size.y * 0.42 + sin(a) * d * 0.38), Color(blood.darkened(0.45), 0.9), 3 + (salt >> i) % 3)
	draw_arc(Vector2(0, size.y * 0.1), w * (0.78 + 0.08 * pulse), 0, TAU, 40, Color(holy, 0.55), 3.0)

	draw_set_transform(Vector2(0, -4), TROPHY_TILT, Vector2.ONE)
	draw_rect(Rect2( - size.x * 0.4, size.y * 0.5 - 6, size.x * 0.8, 9), blood.darkened(0.25))
	draw_rect(Rect2( - size.x * 0.3, size.y * 0.5 - 4, size.x * 0.6, 4), blood.lightened(0.1))
	draw_texture_rect(_texture, Rect2( - size * 0.5, size), false)
	draw_set_transform(Vector2.ZERO)

	var ember: Color = Game.theme.ui.get("arena_fire", Color(1, 0.4, 0.08))
	for i in 4:
		var k: = fmod(_pulse * 0.45 + i * 0.25, 1.0)
		var x: = sin(i * 2.1 + _pulse * 1.5) * w * 0.3
		PixelFx.dot(self, Vector2(x, - size.y * 0.3 - k * 90.0), Color(ember.lightened(0.3), 1.0 - k), 2)

func _draw() -> void :
	if not trophy.is_empty():
		_draw_trophy()
		return
	var size: = _texture.get_size() * SCALE * (LITTLE_SCALE if little else 1.0)
	var pulse: = 0.5 + 0.5 * sin(_pulse * 4.0)
	match kind:
		Kind.BLESSING:

			var holy: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
			if blessed:
				size *= 1.4
				draw_rect(Rect2( - size.x * 0.6, -340, size.x * 1.2, 340), Color(holy, 0.08 + 0.06 * pulse))
				draw_arc(Vector2.ZERO, size.x * (1.05 + 0.12 * pulse), 0, TAU, 32, Color(holy, 0.6), 3.0)
			draw_rect(Rect2( - size.x * 0.35, -260, size.x * 0.7, 260), Color(holy, 0.12 + 0.08 * pulse))
			draw_rect(Rect2( - size.x * 0.15, -260, size.x * 0.3, 260), Color(1, 1, 1, 0.12 + 0.1 * pulse))
			draw_circle(Vector2.ZERO, size.x * (0.8 + 0.1 * pulse), Color(holy, 0.25))
		Kind.VACUUM:

			var xp: Color = Game.theme.ui["xp"]
			draw_circle(Vector2.ZERO, size.x * (0.85 + 0.15 * pulse), Color(xp, 0.18))
			var t: = fmod(_pulse, 1.0)
			draw_arc(Vector2.ZERO, size.x * (1.3 - 0.7 * t), 0, TAU, 24, Color(xp, 0.6 * sin(PI * t)), 2.0)
		Kind.PURGE:
			var holy: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
			draw_circle(Vector2.ZERO, size.y * (0.6 + 0.1 * pulse), Color(holy, 0.22 + 0.1 * pulse))
		Kind.FEVER, Kind.COIN:
			if kind == Kind.FEVER or value >= POUCH:
				var gold: = SoulFever.GOLD
				draw_circle(Vector2.ZERO, size.y * (0.6 + 0.1 * pulse), Color(gold, (0.2 + 0.1 * pulse) * (1.0 if value >= COFFER or kind == Kind.FEVER else 0.5)))
		Kind.LUCK:
			draw_circle(Vector2.ZERO, size.y * (0.55 + 0.1 * pulse), Color(1, 1, 1, 0.15 + 0.1 * pulse))
		Kind.FREEZE:
			var ice: = Freeze.ICE
			draw_circle(Vector2.ZERO, size.y * (0.6 + 0.1 * pulse), Color(ice, 0.2 + 0.1 * pulse))
			var t: = fmod(_pulse * 0.8, 1.0)
			draw_arc(Vector2.ZERO, size.y * (0.6 + 0.8 * t), 0, TAU, 24, Color(ice, 0.6 * (1.0 - t)), 2.0)
	draw_set_transform(Vector2(0, size.y * 0.5), 0.0, Vector2(1, 0.35))
	draw_circle(Vector2.ZERO, size.x * 0.45, Color(0, 0, 0, 0.25))
	draw_set_transform(Vector2.ZERO)
	draw_texture_rect(_texture, Rect2( - size * 0.5, size), false)
