class_name Winds
extends Weapon








const ID: = "winds"
const COOLDOWN_TEXT: = "blows %d%% more often"
const SPEED: = 520.0
const RANGE: = 360.0
const WIDTH: = 56.0
const PUSH: = 420.0
const BASE: = {"damage": 12.0, "cooldown": 2.4, "count": 4, "area": 1.0, "speed": 1.0, "force": 1.0}
const UPGRADES: = [
	{"damage": 5.0}, 
	{"force": 1.3}, 
	{"cooldown": 0.85}, 
	{"area": 1.25}, 
	{"damage": 7.0}, 
	{"speed": 1.25}, 
	{"damage": 9.0}, 
]


const HOLY: = {"count": 4, "damage": 10.0}
const SPIRAL: = 0.75

var damage: = 12.0
var cooldown: = 2.4
var count: = 4
var area: = 1.0
var speed: = 1.0
var force: = 1.0
var _timer: = 1.2
var _turn: = 0.0
var _gusts: Array[Dictionary] = []
var _time: = 0.0

func _on_level() -> void :
	Layers.put(self, Layers.FLYING)

func _process(delta: float) -> void :
	_time += delta
	_timer -= delta
	if _timer <= 0.0:
		_timer = cooldown_of(cooldown)
		_blow()
	if not _gusts.is_empty():
		_move_gusts(delta)
		queue_redraw()

func _blow() -> void :
	for i in count:
		var dir: = Vector2.RIGHT.rotated(_turn + TAU * i / count)
		_gusts.append({"pos": global_position + dir * 20.0, "dir": dir, "went": 0.0, "hit": {}, "back": false, 
			"spin": randf() * TAU})
	_turn = PI / 4.0 - _turn
	Game.sfx("dodge", randf_range(0.8, 0.95))

func _move_gusts(delta: float) -> void :
	var reach: = RANGE * speed
	var step: = SPEED * speed * delta
	var half: = WIDTH * area_of(area) * 0.5
	for g in _gusts:
		if g["back"]:
			var home: Vector2 = global_position - g["pos"]
			g["dir"] = (g["dir"] as Vector2).lerp(home.normalized().rotated(SPIRAL), minf(1.0, 6.0 * delta)).normalized()
			if home.length() < 40.0:
				g["went"] = INF
		g["pos"] += g["dir"] * step
		g["went"] += step
		g["spin"] += delta * 9.0
		var pos: Vector2 = g["pos"]
		var hit: Dictionary = g["hit"]
		for e: Enemy in Enemy.near(pos, half):
			var id: = e.get_instance_id()
			if hit.has(id) or pos.distance_squared_to(e.global_position) > pow(half + e.radius, 2):
				continue
			hit[id] = true
			var dmg: = power(damage)
			e.take_damage(dmg, 0.0)
			if e.is_dead():
				continue
			e.knock(g["dir"] * PUSH * force)
		if holy and not g["back"] and g["went"] >= reach:
			g["back"] = true
			hit.clear()
	_gusts = _gusts.filter( func(g: Dictionary) -> bool:
		return g["went"] < (reach * 3.0 if g["back"] else reach))



func _draw() -> void :
	var reach: = RANGE * speed
	var half: = WIDTH * area_of(area) * 0.5
	var hot: = color.lightened(0.5)
	for g in _gusts:
		var p: = to_local(g["pos"])
		var d: Vector2 = g["dir"]
		var side: = d.orthogonal()
		var ang: = d.angle()
		var spin: float = g["spin"]
		var a: = 1.0 if g["back"] else clampf((reach - float(g["went"])) / 90.0, 0.4, 1.0)
		for k in 3:
			var off: = side * (k - 1) * half * 0.6
			var pts: = PackedVector2Array()
			for i in 6:
				pts.append(p - d * (i * 16.0 + half * 0.4) + off + side * sin(spin * 0.7 + i * 0.9 + k * 2.1) * 5.0)
			PixelFx.polyline(self, pts, Color(color, 0.6 * a), 3.0)
		PixelFx.disc(self, p, half * 0.8, Color(color, 0.22 * a))
		PixelFx.arc(self, p - d * half * 0.7, half * 0.75, ang - 0.9, ang + 0.9, Color(color, 0.6 * a), 3.0)
		PixelFx.arc(self, p - d * half * 0.3, half * 0.95, ang - 1.1, ang + 1.1, Color(hot, 0.95 * a), 5.0)
		PixelFx.arc(self, p, half * 0.4, spin, spin + 2.4, Color(hot, 0.85 * a), 3.0)
		for i in 3:
			var q: = p + side * sin(spin + i * 1.7) * half * 0.8 + d * cos(spin * 1.3 + i) * 10.0
			PixelFx.dot(self, q, Color(hot, 0.9 * a), 1)
