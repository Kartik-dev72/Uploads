class_name Maw
extends Weapon










const ID: = "maw"
const COOLDOWN_TEXT: = "opens %d%% more often"
const REACH: = 420.0
const MIN_REACH: = 150.0
const CROWD: = 110.0
const RADIUS: = 170.0
const PULL: = 1900.0
const CHEW_TICK: = 0.4
const CHEW_SHARE: = 0.1
const OPEN_TIME: = 0.2
const CLOSE_TIME: = 0.3
const BURST: = 760.0
const HEART: = 0.3
const TAKE_MAX: = 10
const HOLY_CHEW: = 2.0
const BURST_REACH: = 1.25
const RISE_TIME: = 0.55
const BASE: = {"damage": 30.0, "cooldown": 6.5, "count": 1, "area": 1.0, "duration": 1.8}
const UPGRADES: = [
	{"damage": 12.0}, 
	{"area": 1.15}, 
	{"cooldown": 0.85}, 
	{"count": 1}, 
	{"damage": 18.0}, 
	{"duration": 1.3}, 
	{"damage": 25.0}, 
]
const HOLY: = {"damage": 40.0, "area": 1.2}

var damage: = 30.0
var cooldown: = 6.5
var count: = 1
var area: = 1.0
var duration: = 1.8
var _timer: = 2.0
var _maws: Array[Dictionary] = []
var _time: = 0.0

func _on_level() -> void :
	Layers.put(self, Layers.UNDERGROUND)

func _process(delta: float) -> void :
	_time += delta
	_timer -= delta
	if _timer <= 0.0:
		var spots: = _crowds(count)
		if spots.is_empty():
			_timer = 0.5
		else:
			_timer = cooldown_of(cooldown)
			for p in spots:
				_maws.append({"pos": p, "t": 0.0, "chew": CHEW_TICK, "shut": false, "taken": 0, "rises": []})
			Game.sfx("vacuum", 0.7)
	if _maws.is_empty():
		return
	var r: = RADIUS * area_of(area)
	for m in _maws:
		m["t"] += delta
		if holy:
			for rise: Dictionary in m["rises"]:
				rise["t"] += delta
			m["rises"] = m["rises"].filter( func(rise: Dictionary) -> bool: return rise["t"] < RISE_TIME)
		if m["t"] < duration_of(duration):
			_pull(m, r, delta)
		elif not m["shut"]:
			m["shut"] = true
			_snap(m, r)
	_maws = _maws.filter( func(m: Dictionary) -> bool: return m["t"] < duration_of(duration) + CLOSE_TIME or not m["rises"].is_empty())
	queue_redraw()


func _crowds(n: int) -> Array[Vector2]:
	var near: Array[Enemy] = []
	for e in enemies_on_screen():
		if e.targetable and e.global_position.distance_squared_to(global_position) < REACH * REACH:
			near.append(e)
	if near.size() > 60:
		near.shuffle()
		near = near.slice(0, 60)
	var scored: Array = []
	for a in near:
		var c: = 0
		var sum: = Vector2.ZERO
		for b in near:
			if a.global_position.distance_squared_to(b.global_position) < CROWD * CROWD:
				c += 1
				sum += b.global_position
		scored.append([c, sum / c])
	scored.sort_custom( func(x: Array, y: Array) -> bool: return x[0] > y[0])
	var out: Array[Vector2] = []
	for s in scored:
		var p: Vector2 = s[1]
		if p.distance_to(global_position) < MIN_REACH:
			continue
		if out.all( func(q: Vector2) -> bool: return q.distance_to(p) > RADIUS * 1.5):
			out.append(p)
			if out.size() >= n:
				break
	return out

func _pull(m: Dictionary, r: float, delta: float) -> void :
	var at: Vector2 = m["pos"]
	m["chew"] -= delta
	var chew: bool = m["chew"] <= 0.0
	if chew:
		m["chew"] += CHEW_TICK
	for e: Enemy in Enemy.near(at, r):
		var to: = at - e.global_position
		var d: = to.length()
		if d > r + e.radius:
			continue
		e.knock(to / maxf(d, 1.0) * PULL * delta * clampf(d / 50.0, 0.0, 1.0))
		if not chew:
			continue
		if holy and d < r * HEART + e.radius:
			if e.is_dead():
				continue

			if e.targetable and e.behavior != "still" and e.elite == "" and not e.is_boss and m["taken"] < TAKE_MAX:
				m["taken"] += 1
				m["rises"].append({"pos": e.global_position, "t": 0.0})
				e.hp = 0.0
				e.die()
			else:
				e.take_damage(power(damage) * CHEW_SHARE * HOLY_CHEW, 0.0)
		elif d < r * 0.35 + e.radius:
			e.take_damage(power(damage) * CHEW_SHARE, 0.0)

func _snap(m: Dictionary, r: float) -> void :
	var at: Vector2 = m["pos"]
	var reach: = r * (BURST_REACH if holy else 0.85)
	for e: Enemy in Enemy.near(at, reach):
		var d: = at.distance_to(e.global_position)
		if d > reach + e.radius:
			continue
		e.take_damage(power(damage), 0.0)
		if holy and not e.is_dead():
			e.knock((e.global_position - at).normalized() * BURST)
	Game.sfx("explode", 0.75 if not holy else 1.1)
	player.shake(3.0)
	if holy:
		RingFx.spawn(get_tree().current_scene, at, reach, color)



func _draw() -> void :
	var r: = RADIUS * area_of(area)
	var hot: = color.lightened(0.45)
	if holy:
		_draw_gate(r)
		return
	for m in _maws:
		var p: = to_local(m["pos"])
		var t: float = m["t"]
		var open: = clampf(t / OPEN_TIME, 0.0, 1.0)
		var closing: = clampf((t - duration_of(duration)) / CLOSE_TIME, 0.0, 1.0)
		var size: = open * (1.0 - closing)
		var fade: = 1.0 - closing

		PixelFx.arc(self, p, r, 0, TAU, Color(color, 0.12 * open * fade), 3.0)
		for i in 3:
			var a0: = _time * 2.6 + TAU * i / 3.0
			PixelFx.arc(self, p, r * 0.7 * size, a0, a0 + 1.4, Color(color, 0.3 * fade), 6.0)
			PixelFx.arc(self, p, r * 0.48 * size, a0 + 0.9, a0 + 2.1, Color(color, 0.45 * fade), 4.0)
		for i in 10:
			var k: = fposmod(_time * 0.9 + i * 0.37, 1.0)
			var a: = TAU * i / 10.0 + k * 2.0
			PixelFx.dot(self, p + Vector2.RIGHT.rotated(a) * r * (1.0 - k) * size, Color(hot, 0.7 * fade * (1.0 - k * 0.5)), 1)
		var hole: = r * 0.32 * size
		PixelFx.disc(self, p, hole + 8.0, Color(color.darkened(0.55), 0.85 * fade))
		PixelFx.disc(self, p, hole, Color(0.03, 0.0, 0.05, fade))
		for i in 10:
			var a: = TAU * i / 10.0 + 0.1 * sin(_time * 3.0)
			var d: = Vector2.RIGHT.rotated(a)
			var base: = p + d * (hole + 2.0)
			var side: = d.orthogonal() * hole * 0.1
			var tip: = p + d * (hole * 0.15 if closing > 0.0 else hole * 0.78)
			PixelFx.poly(self, PackedVector2Array([base + side, base - side, tip]), Color(0.78, 0.72, 0.62, 0.9 * fade))




func _draw_gate(r: float) -> void :
	var gold: = color
	var white: = Color(1, 1, 0.94)
	for m in _maws:
		var p: = to_local(m["pos"])
		var t: float = m["t"]
		var open: = clampf(t / OPEN_TIME, 0.0, 1.0)
		var closing: = clampf((t - duration_of(duration)) / CLOSE_TIME, 0.0, 1.0)
		var live: = t < duration_of(duration) + CLOSE_TIME
		if live:
			var fade: = 1.0 - closing
			PixelFx.arc(self, p, r, 0, TAU, Color(gold, 0.22 * open * fade), 3.0)
			PixelFx.arc(self, p, r * HEART, 0, TAU, Color(gold, 0.55 * open * fade), 4.0)
			for i in 3:
				var k: = fposmod(_time * 0.7 + i / 3.0, 1.0)
				PixelFx.arc(self, p, r * (1.0 - k * 0.8) * open, 0, TAU, Color(gold, 0.5 * k * fade), 3.0)
			for i in (8 if open > 0.2 else 0):
				var a: = - _time * 0.8 + TAU * i / 8.0
				var d: = Vector2.RIGHT.rotated(a)
				PixelFx.line(self, p + d * r * 0.16 * open, p + d * r * 0.9 * open, Color(gold, 0.55 * fade), 5.0)
				PixelFx.line(self, p + d * r * 0.16 * open, p + d * r * 0.6 * open, Color(white, 0.6 * fade), 2.0)
			for i in 12:
				var k: = fposmod(_time * 1.1 + i * 0.29, 1.0)
				var a: = TAU * i / 12.0 - k * 1.5
				PixelFx.dot(self, p + Vector2.RIGHT.rotated(a) * r * (1.0 - k) * open, Color(white, 0.9 * fade), 2)
			var heart: = r * (0.13 + 0.015 * sin(_time * 8.0)) * open
			PixelFx.disc(self, p, heart + 12.0, Color(gold, 0.6 * fade))
			PixelFx.disc(self, p, heart, Color(white, 0.95 * fade))
			if closing > 0.0:
				var reach: = r * BURST_REACH
				PixelFx.disc(self, p, heart + (reach - heart) * closing, Color(white, 0.35 * fade))
				PixelFx.arc(self, p, heart + (reach - heart) * closing, 0, TAU, Color(gold, 0.9 * fade), 6.0)
		for rise: Dictionary in m["rises"]:
			var k: float = rise["t"] / RISE_TIME
			var at: = to_local(rise["pos"])
			var w: = 14.0 * (1.0 - k * 0.6)
			var h: = 60.0 + 160.0 * k
			PixelFx.rect(self, Rect2(at.x - w * 0.5, at.y - h, w, h), Color(white, 0.55 * (1.0 - k)))
			PixelFx.rect(self, Rect2(at.x - w * 0.2, at.y - h, w * 0.4, h), Color(1, 1, 1, 0.8 * (1.0 - k)))
