class_name Familiar
extends Weapon




const ID: = "familiar"
const COOLDOWN_TEXT: = "spits fire %d%% faster"
const ORBIT: = 95.0
const BASE: = {"damage": 7.0, "cooldown": 1.0, "count": 1}


const UPGRADES: = [
	{"cooldown": 0.88}, 
	{"damage": 3.0}, 
	{"cooldown": 0.88}, 
	{"count": 1}, 
	{"damage": 4.0}, 
	{"cooldown": 0.88}, 
	{"damage": 6.0}, 
]




const HOLY: = {"damage": 8.0}
const RAISE_CHANCE: = 0.3
const RAISE_GAP: = 0.7
const MAX_GHOSTS: = 2
const GHOST_SHARE: = 0.6

var damage: = 7.0
var cooldown: = 1.0
var count: = 1
var _time: = 0.0
var _raise_ready: = 0.0
var _pets: Array[Dictionary] = []
var _sprite_frames: = {}
const PET_SCALE: = 2.0
const FLAP_RATE: = 9.0

func _on_level() -> void :
	Layers.put(self, Layers.FLYING)

func _process(delta: float) -> void :
	_time += delta
	var n: = count
	while _pets.size() < n:
		_pets.append({"pos": global_position, "timer": randf_range(0.2, cooldown_of(cooldown))})
	if _pets.size() > n:
		_pets.resize(n)
	for i in _pets.size():
		var pet: = _pets[i]
		var spot: = global_position + Vector2.RIGHT.rotated(_time * 0.9 + TAU * i / n) * ORBIT + Vector2(0, sin(_time * 3.0 + i) * 8.0 - 30.0)
		pet["pos"] = (pet["pos"] as Vector2).lerp(spot, 1.0 - exp(-7.0 * delta))
		pet["timer"] -= delta
		if pet["timer"] <= 0.0:
			var targets: = nearest_enemies_on_screen(1)
			if not targets.is_empty():
				pet["timer"] = cooldown_of(cooldown)
				pet["face"] = signf(targets[0].global_position.x - (pet["pos"] as Vector2).x)
				_shoot(pet["pos"], targets[0])
	queue_redraw()

func _shoot(from: Vector2, target: Enemy) -> void :
	var dir: = from.direction_to(target.global_position)

	var n: = 1 + player.extra_projectiles
	for k in n:
		var off: = (k - (n - 1) / 2.0) * 0.24
		var p: = fire_projectile(from, dir.rotated(off), 620.0, damage, 1, Projectile.Style.ORB, 0.65)
		if holy:
			p.on_hit = _maybe_raise


func _maybe_raise(e: Enemy) -> void :
	if not e.is_dead() or e.is_boss or e.elite == "champion" or e.behavior == "still" or not e.targetable:
		return
	if _time < _raise_ready or Ghost.alive.size() >= MAX_GHOSTS + count or randf() >= RAISE_CHANCE:
		return
	_raise_ready = _time + RAISE_GAP
	var g: = Ghost.new()
	g.raise(e, power(damage) * GHOST_SHARE)
	get_tree().current_scene.add_child(g)
	Game.sfx("holy", 1.6, -10.0)


func _draw_cherub(p: Vector2, i: int, frames: Array) -> void :
	if not frames.is_empty():
		_draw_pet_sprite(p, i, frames)
		return
	PixelFx.disc(self, p, 30.0, Color(color, 0.16))
	var flap: = sin(_time * 14.0 + i) * 0.5
	for side: float in [-1.0, 1.0]:
		var wing: = PackedVector2Array([p + Vector2(side * 8, 0), p + Vector2(side * 28, -14 + flap * 10), p + Vector2(side * 30, -2 + flap * 6), p + Vector2(side * 22, 8 + flap * 4)])
		PixelFx.poly(self, wing, Color(1, 1, 1, 0.95))
		PixelFx.polyline(self, PackedVector2Array([wing[0], wing[1], wing[2], wing[3]]), Color(color, 0.8), 1.5)
	PixelFx.disc(self, p + Vector2(0, 2), 14.0, Color(0.15, 0.1, 0.05, 0.7))
	PixelFx.disc(self, p, 12.0, Color(0.98, 0.82, 0.66))
	for k in 5:
		PixelFx.disc(self, p + Vector2(-8 + k * 4, -10 + absf(k - 2) * 1.5), 4.0, Color(0.98, 0.82, 0.38))
	PixelFx.disc(self, p + Vector2(-4, 0), 2.0, Color(0.1, 0.08, 0.15))
	PixelFx.disc(self, p + Vector2(4, 0), 2.0, Color(0.1, 0.08, 0.15))
	PixelFx.disc(self, p + Vector2(-7, 4), 2.5, Color(1, 0.55, 0.55, 0.6))
	PixelFx.disc(self, p + Vector2(7, 4), 2.5, Color(1, 0.55, 0.55, 0.6))
	draw_set_transform(p + Vector2(0, -21), 0.0, Vector2(1, 0.35))
	PixelFx.arc(self, Vector2.ZERO, 10.0, 0, TAU, Color(color.lightened(0.3), 1.0), 3.0)
	draw_set_transform(Vector2.ZERO)



func _pet_frames() -> Array:
	var key: String = Game.theme.weapon(ID).get("holy_pet_sprite" if holy else "pet_sprite", "")
	if key == "":
		return []
	if not _sprite_frames.has(key):
		_sprite_frames[key] = Game.theme.frames(key)
	return _sprite_frames[key]


func _draw_pet_sprite(p: Vector2, i: int, frames: Array) -> void :
	var tex: Texture2D = frames[int(_time * FLAP_RATE + i * 0.5) % frames.size()]
	var size: = tex.get_size() * PET_SCALE
	for k in 3:
		var w: = size.x * (0.35 - absf(k - 1) * 0.1)
		PixelFx.rect(self, Rect2(PixelFx.snap(p + Vector2( - w * 0.5, 30 + k * PixelFx.PIXEL)), Vector2(w, PixelFx.PIXEL)), Color(0, 0, 0, 0.22))
	var face: float = _pets[i].get("face", 1.0)
	draw_set_transform(PixelFx.snap(p), 0.0, Vector2(face if face != 0.0 else 1.0, 1.0))
	draw_texture_rect(tex, Rect2( - size * 0.5, size), false)
	draw_set_transform(Vector2.ZERO)


func _draw() -> void :
	var hot: = color.lightened(0.5)
	var dark: = color.darkened(0.5)
	var frames: = _pet_frames()
	for i in _pets.size():
		var p: = to_local(_pets[i]["pos"])
		if holy:
			_draw_cherub(p, i, frames)
			continue
		if not frames.is_empty():
			_draw_pet_sprite(p, i, frames)
			continue
		var flap: = sin(_time * 18.0 + i) * 0.5
		for side: float in [-1.0, 1.0]:
			var wing: = PackedVector2Array([p + Vector2(side * 6, -2), p + Vector2(side * 26, -16 + flap * 12), p + Vector2(side * 22, 6 + flap * 6)])
			PixelFx.poly(self, wing, Color(dark, 0.9))
			PixelFx.polyline(self, PackedVector2Array([wing[1], wing[0], wing[2]]), Color(color, 0.9), 2.0)
		PixelFx.disc(self, p + Vector2(0, 2), 14.0, Color(0.05, 0.02, 0.05, 0.8))
		PixelFx.disc(self, p, 12.0, color)
		PixelFx.disc(self, p + Vector2(-3, -3), 6.0, hot)
		PixelFx.poly(self, PackedVector2Array([p + Vector2(-9, -8), p + Vector2(-5, -20), p + Vector2(-2, -9)]), dark)
		PixelFx.poly(self, PackedVector2Array([p + Vector2(9, -8), p + Vector2(5, -20), p + Vector2(2, -9)]), dark)
		PixelFx.disc(self, p + Vector2(-4, -1), 3.0, Color.WHITE)
		PixelFx.disc(self, p + Vector2(4, -1), 3.0, Color.WHITE)
		PixelFx.disc(self, p + Vector2(-4, -1), 1.3, Color(0.05, 0, 0))
		PixelFx.disc(self, p + Vector2(4, -1), 1.3, Color(0.05, 0, 0))
