class_name RealmGoals
extends Node2D













const ARROW_AT: = 420.0
const ARROW_LEN: = 130.0
const ARROW_SHOW: = 1400.0
const DIRS: = {"up": Vector2.UP, "down": Vector2.DOWN, "left": Vector2.LEFT, "right": Vector2.RIGHT}

var map: GameMap
var _player: Player
var _sites: Array[GoalSite] = []
var _tier: = 0
var _font: Font

func _ready() -> void :
	add_to_group("realm_goals")
	Layers.put(self, Layers.GROUND_EFFECTS)
	_font = ThemeDB.fallback_font
	_player = get_tree().get_first_node_in_group("player") as Player
	_tier = Game.run_tier
	var looks: Array = Game.theme.level_looks
	var goals: Dictionary = (looks[_tier] as Dictionary).get("goals", {}) if _tier < looks.size() else {}
	var speed: = _player.base_speed if _player else 250.0
	for kind: String in ["hero", "item"]:
		var g: Dictionary = goals.get(kind, {})
		if g.is_empty() or is_done(kind, _tier):
			continue
		var dir: Vector2 = DIRS.get(str(g.get("dir", "up")), Vector2.UP)
		var site: = GoalSite.new()
		site.kind = GoalSite.Kind.HERO if kind == "hero" else GoalSite.Kind.ITEM
		site.what = str(g.get("survivor" if kind == "hero" else "item", ""))
		site.tier = _tier
		site.dir_name = str(g.get("dir", "up"))
		site.position = dir * float(g.get("minutes", 9.0)) * 60.0 * speed
		if map:
			site.position = map.clamp_band(site.position, 300.0)
		_sites.append(site)
		get_parent().add_child(site)

static func is_done(kind: String, tier: int) -> bool:
	return Game.progress.stats.get("goal_%s_%d" % [kind, tier], 0) > 0

func _process(_delta: float) -> void :
	_sites.assign(_sites.filter( func(s: Variant) -> bool: return is_instance_valid(s) and not (s as GoalSite).claimed))
	if _player == null or _sites.is_empty():
		if visible:
			visible = false
		return
	var near: = Game.goal_arrows and _player.global_position.length() < ARROW_SHOW + ARROW_AT
	if near or visible != near:
		visible = near
		queue_redraw()


func _draw() -> void :
	var holy: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
	var accent: Color = Game.theme.ui["accent"]
	var t: = Time.get_ticks_msec() / 1000.0
	for s in _sites:
		var dir: = s.position.normalized()
		var c: = holy if s.kind == GoalSite.Kind.HERO else accent
		var pulse: = 0.75 + 0.25 * sin(t * 3.0)
		var base: = dir * ARROW_AT
		var tip: = base + dir * ARROW_LEN
		var side: = dir.orthogonal()
		var shaft: = PackedVector2Array([base + side * 16.0, tip - dir * 50.0 + side * 16.0, tip - dir * 50.0 + side * 46.0, tip, 
			tip - dir * 50.0 - side * 46.0, tip - dir * 50.0 - side * 16.0, base - side * 16.0])
		draw_colored_polygon(shaft, Color(0, 0, 0, 0.45))
		var lit: = PackedVector2Array()
		for p in shaft:
			lit.append(p - Vector2(0, 4))
		draw_colored_polygon(lit, Color(c, 0.7 * pulse))
		var word: = "RESCUE" if s.kind == GoalSite.Kind.HERO else "TREASURE"
		var size: = 30
		var w: = _font.get_string_size(word, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
		var at: = base - dir * 40.0 + Vector2( - w * 0.5, size * 0.35)
		if absf(dir.x) > 0.5:
			at = base + dir * ARROW_LEN * 0.4 + Vector2( - w * 0.5, -40.0)
		draw_string_outline(_font, at, word, HORIZONTAL_ALIGNMENT_LEFT, -1, size, 8, Color(0, 0, 0, 0.85))
		draw_string(_font, at, word, HORIZONTAL_ALIGNMENT_LEFT, -1, size, Color(c, pulse))
