class_name LevelPips
extends Control









const PIP: = 12.0
const GAP: = 7.0
const GAP_MIN: = 5.0
const PIP_MIN: = 7.0
const MAX_WIDTH: = 92.0

var _pip: = PIP
var _gap: = GAP
var _cols: = 1
var _rows: = 1

var level: = 0
var top: = 1
var color: = Color(1, 0.6, 0.2)
var finished: = false
var pending: = false



func setup(lvl: int, max_level: int, fill: Color, done: = false, next: = false, max_width: = MAX_WIDTH) -> LevelPips:
	level = lvl
	pending = next
	set_process(next)
	top = maxi(max_level, 1)
	color = fill
	finished = done
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_layout(max_width)
	custom_minimum_size = Vector2(_cols * _pip + (_cols - 1) * _gap + 2.0, _rows * _pip + (_rows - 1) * _gap + 2.0)
	queue_redraw()
	return self


func _layout(max_width: float) -> void :
	_rows = 1
	_cols = top
	_pip = PIP
	_gap = GAP
	if _width() <= max_width:
		return
	_gap = GAP_MIN
	_pip = minf(PIP, floorf((max_width - (_cols - 1) * _gap) / _cols))
	if _pip >= PIP_MIN:
		return
	_rows = 2
	_cols = ceili(top / 2.0)
	_pip = minf(PIP, floorf((max_width - (_cols - 1) * _gap) / _cols))
	_pip = maxf(_pip, 4.0)

func _width() -> float:
	return _cols * _pip + (_cols - 1) * _gap

func _process(_delta: float) -> void :
	queue_redraw()

func _draw() -> void :
	var maxed: = finished or level >= top
	var lit: = color.lightened(0.25) if maxed else color
	var x: = (size.x - _width()) / 2.0
	var y: = (size.y - (_rows * _pip + (_rows - 1) * _gap)) / 2.0
	for i in top:
		var r: = Rect2(x + (i % _cols) * (_pip + _gap), y + floori(float(i) / _cols) * (_pip + _gap), _pip, _pip)
		draw_rect(r.grow(1.0), Color(0, 0, 0, 0.85))
		if i < level or finished:
			draw_rect(r, lit)
			draw_rect(Rect2(r.position, Vector2(_pip, 2.0)), Color(1, 1, 1, 0.35))
		elif pending and i == level:
			var beat: = 0.5 + 0.5 * sin(Time.get_ticks_msec() * 0.009)
			var hot: = Color.WHITE if i == top - 1 else color.lightened(0.45)
			draw_rect(r, Color(1, 1, 1, 0.08))
			draw_rect(r, Color(hot, 0.25 + 0.75 * beat))
		else:
			draw_rect(r, Color(color.darkened(0.55), 0.9))
			draw_rect(r.grow(-1.0), Color(0.05, 0.03, 0.03, 0.9))
