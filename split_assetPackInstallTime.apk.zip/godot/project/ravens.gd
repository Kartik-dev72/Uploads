class_name Ravens
extends Weapon









const ID: = "ravens"
const COOLDOWN_TEXT: = "drops %d%% more often"
const ORBIT: = 165.0
const ORBIT_SPEED: = 2.0
const FALL: = 0.18
const BLAST: = 48.0
const BURST_SHOW: = 0.35
const BIRD_SCALE: = 2.5
const DIVE_TIME: = 0.32
const DOVE_BLAST: = 78.0
const DIVE_EVERY: = 0.9




const BASE: = {"damage": 12.0, "cooldown": 0.3, "count": 1, "area": 1.0}
const UPGRADES: = [
	{"damage": 4.0}, 
	{"area": 1.15}, 
	{"count": 1}, 
	{"cooldown": 0.85}, 
	{"damage": 5.0}, 
	{"count": 1}, 
	{"damage": 6.0}, 
]
const HOLY: = {"damage": 6.0, "area": 1.1}

var damage: = 12.0
var cooldown: = 0.3
var count: = 1
var area: = 1.0
var _timer: = 0.4
var _angle: = 0.0
var _time: = 0.0
var _bombs: Array[Dictionary] = []
var _bursts: Array[Dictionary] = []
var _dives: Array[Dictionary] = []
var _next_dove: = 0
var _ground: Node2D

func _on_level() -> void :
	Layers.put(self, Layers.FLYING)
	if _ground == null:
		_ground = Layers.canvas(self, Layers.GROUND_EFFECTS, _draw_ground)
	while _dives.size() < count:
		_dives.append({"state": 0, "t": 0.0, "from": Vector2.ZERO, "to": Vector2.ZERO})

func _home(i: int) -> Vector2:
	return Vector2.RIGHT.rotated(_angle + TAU * i / count) * ORBIT * area_of(area)

func _process(delta: float) -> void :
	_time += delta
	_angle = fmod(_angle + ORBIT_SPEED * delta, TAU)
	_timer -= delta
	if holy:
		_step_doves(delta)
	elif _timer <= 0.0:
		_timer = cooldown_of(cooldown)
		for i in count:
			_bombs.append({"at": global_position + _home(i) + Vector2(randf_range(-10, 10), randf_range(-10, 10)), "t": 0.0})
	for b in _bombs:
		b["t"] += delta
		if b["t"] >= FALL:
			_burst(b["at"], BLAST * area_of(area), power(damage), false)
	_bombs = _bombs.filter( func(b: Dictionary) -> bool: return b["t"] < FALL)
	for b in _bursts:
		b["t"] += delta
	_bursts = _bursts.filter( func(b: Dictionary) -> bool: return b["t"] < BURST_SHOW)
	queue_redraw()

func _burst(at: Vector2, r: float, dmg: float, light: bool) -> void :
	for e: Enemy in Enemy.near(at, r):
		if at.distance_squared_to(e.global_position) < pow(r + e.radius * 0.6, 2):
			e.take_damage(dmg, 0.5)
	_bursts.append({"at": at, "t": 0.0, "r": r, "holy": light})
	Game.sfx("hit", randf_range(0.6, 0.8) if not light else 1.4)


func _step_doves(delta: float) -> void :
	if _timer <= 0.0:
		_timer = cooldown_of(DIVE_EVERY) / maxf(count, 1)
		var targets: = enemies_on_screen()
		if not targets.is_empty():
			for k in count:
				var i: = (_next_dove + k) % count
				var d: Dictionary = _dives[i]
				if d["state"] == 0:
					d["state"] = 1
					d["t"] = 0.0
					d["from"] = _home(i)
					d["to"] = (targets.pick_random() as Enemy).global_position
					_next_dove = i + 1
					break
	for i in count:
		var d: Dictionary = _dives[i]
		if d["state"] == 0:
			continue
		d["t"] += delta / DIVE_TIME
		if d["state"] == 1 and d["t"] >= 1.0:
			_burst(d["to"], DOVE_BLAST * area_of(area), power(damage) * 2.5, true)
			d["state"] = 2
			d["t"] = 0.0
		elif d["state"] == 2 and d["t"] >= 1.0:
			d["state"] = 0


func _bird(i: int) -> Array:
	var home: = _home(i)
	var dir: = Vector2.UP.rotated(_angle + TAU * i / count)
	if holy:
		var d: Dictionary = _dives[i]
		var k: = clampf(d["t"], 0.0, 1.0)
		var e: = k * k * (3.0 - 2.0 * k)
		if d["state"] == 1:
			var to: Vector2 = d["to"] - global_position
			return [(d["from"] as Vector2).lerp(to, e), to - (d["from"] as Vector2)]
		if d["state"] == 2:
			var from: Vector2 = d["to"] - global_position
			return [from.lerp(home, e), home - from]
	return [home, - dir]

func _draw() -> void :
	var sprite: = "dove" if holy else "raven"
	var frames: = Game.theme.frames(sprite)
	for i in count:
		var b: = _bird(i)
		var at: Vector2 = b[0]
		var dir: Vector2 = b[1]
		var tex: Texture2D = frames[int(_time * 9.0 + i * 3) % frames.size()]
		var size: = tex.get_size() * BIRD_SCALE
		draw_set_transform(at, dir.angle() + PI / 2.0)
		if holy:
			PixelFx.disc(self, Vector2.ZERO, size.x * 0.55, Color(color, 0.18))
		draw_texture_rect(tex, Rect2( - size / 2.0, size), false)
		draw_set_transform(Vector2.ZERO)
		if holy and _dives[i]["state"] != 0:
			PixelFx.line(self, at, at - dir.normalized() * 60.0, Color(color, 0.35), 6.0)
	for bomb in _bombs:
		var p: = to_local(bomb["at"]) + Vector2(0, -36.0 * (1.0 - bomb["t"] / FALL))
		PixelFx.rect(self, Rect2(PixelFx.snap(p) - Vector2(3, 5), Vector2(6, 10)), Color(0.12, 0.1, 0.1))
		PixelFx.rect(self, Rect2(PixelFx.snap(p) - Vector2(2, 4), Vector2(4, 8)), Color(0.92, 0.88, 0.78))


func _draw_ground() -> void :
	for b in _bursts:
		var at: = to_local(b["at"])
		var k: float = b["t"] / BURST_SHOW
		var r: float = b["r"]
		if b["holy"]:
			PixelFx.disc(_ground, at, r * (0.6 + 0.4 * k), Color(color, 0.35 * (1.0 - k)))
			PixelFx.arc(_ground, at, r * (0.5 + 0.6 * k), 0, TAU, Color(1, 1, 1, 0.8 * (1.0 - k)), 3.0)
			continue
		PixelFx.disc(_ground, at, r * (0.5 + 0.5 * k), Color(0.08, 0.06, 0.08, 0.45 * (1.0 - k)))
		PixelFx.disc(_ground, at, r * 0.4 * (1.0 - k), Color(color.lightened(0.3), 0.6 * (1.0 - k)))
		for j in 6:
			var d: = Vector2.RIGHT.rotated(j * TAU / 6.0 + float(b["r"]))
			PixelFx.rect(_ground, Rect2(PixelFx.snap(at + d * r * (0.2 + 0.8 * k)) - Vector2(2, 2), Vector2(4, 4)), Color(0.92, 0.88, 0.78, 1.0 - k))
