class_name Enemy
extends Node2D




signal died(enemy: Enemy)

const FLASH_TIME: = 0.08
const CRIT_MULT: = 2.0
const SWEEP_DESPAWN: = 900.0





const ELITE_BLESSING_CHANCE: = 0.25
const CHEST_RHYTHM: = 90.0
const CHEST_CHANCE_MIN: = 0.02
const CHEST_CHANCE_MAX: = 0.6
const COIN_TAPER_KILLS: = 2000.0
const HOP_RATE: = 1.6
const HOP_AIR: = 0.55
const SKITTER_SWAY: = 0.7
const HUNT_SPEED: = 0.92
const HUNT_ABILITY: = 1.7
const CENSER_BOSS: = 0.5
const FROZEN_TINT: = Color(0.55, 0.85, 1.3)
const DOOM_TINT: = Color(0.6, 0.85, 0.7)




const RELOCATE_MARGIN: = 220.0
const RELOCATE_AFTER: = 1.2
const RELOCATE_SPREAD: = 1.9
const CLIMB_SPEED: = 0.5
const CLIMB_LIFT: = 14.0
const LAVA_TICK: = 0.5



const ELITES: = {
	"swift": {"hp": 3.0, "scale": 1.25, "speed": 1.6}, 
	"brute": {"hp": 6.0, "scale": 1.5, "speed": 0.9}, 
	"volatile": {"hp": 3.5, "scale": 1.3, "speed": 1.0}, 
	"champion": {"hp": 6.0, "scale": 1.7, "speed": 0.95}, 
}


static var blasting: = false

@export var speed: = 120.0
@export var max_hp: = 10.0
@export var hits: = 1.0
@export var radius: = 20.0
@export var xp_value: = 1
@export var coin_chance: = 0.015

var hp: = max_hp
var targetable: = true
var sprite_name: = ""
var sprite_scale: = 3.0
var motion: = "walk"
var alpha: = 1.0
var tint: = Color.WHITE
var _climb: = 0.0
var _on_wall: = false



const CHECK_EVERY: = 3
var _check: = randi() % CHECK_EVERY
var _ground: = -1
var is_boss: = false
var coin_drops: = 0
var elite: = ""
var kind_id: = ""
var hp_share: = 1.0
var hunt: = false
var _censed: = 0.0
var _far_t: = 0.0
var _rage: = 0.0
var keep_near: Callable
var _thorn_t: = 0.0
var _walker: = true
var _lava_t: = 0.0



var behavior: = "chase"
var velocity: = Vector2.ZERO



var ability: = ""
var _data: = {}
var _hp_mult: = 1.0
var _speed_mult: = 1.0
var _slow_t: = 0.0
var _bind_t: = 0.0
var _knock: = Vector2.ZERO





const KB_TIME: = 0.12
var knockback: = 0.0
var _kb_t: = 0.0
var _kb_mul: = 0.0
var _ab_timer: = 2.0
var _ab_state: = 0
var _ab_dir: = Vector2.RIGHT
var _ab_left: = 0.0



const SHOT_WINDUP: = 0.5
const SHOT_WINDUP_BOSS: = 0.65
const MAX_SHOTS: = 12
var _windup: = 0.0
var _tell: Node2D



static var _bestiary: = {}
var _kill_stat: = ""

static func flush_bestiary() -> void :
	for stat: String in _bestiary:
		Game.track(stat, int(_bestiary[stat]))
	_bestiary.clear()

static var frozen: = false
var _was_frozen: = false
var _doom: = 0.0
var _doom_t: = 0.0

var _player: Player
var _map: GameMap
var _dead: = false
var _dmg_acc: = 0.0
var _next_number: = 0
var _flash: = 0.0
var _sprite: Sprite2D
var _frames: Array[Texture2D] = []
var _anim: = 0.0
var _gait: = 0.0
var _feet: = 0.0
var _lure: Ghost = null


var guard_center: = Vector2.ZERO
var guard_radius: = 200.0
var guard_angle: = 0.0
var guard_spin: = 0.25

func configure(data: Dictionary, hp_mult: = 1.0, speed_mult: = 1.0) -> void :
	sprite_name = data.get("sprite", sprite_name)
	if sprite_name == "@survivor":
		sprite_name = str(Game.survivor().get("sprite", "devil"))
	sprite_scale = data.get("scale", sprite_scale)
	speed = data.get("speed", speed) * speed_mult
	max_hp = data.get("hp", max_hp) * hp_mult
	hits = data.get("hits", hits)
	var base_hp: float = data.get("hp", 12.0)
	knockback = data.get("knockback", 1.0 if base_hp <= 14.0 else (0.8 if base_hp <= 30.0 else (0.3 if base_hp <= 70.0 else 0.0)))
	if data.get("boss", false):
		knockback = 0.0
	radius = data.get("radius", radius)
	xp_value = data.get("xp", xp_value)
	motion = data.get("motion", motion)
	alpha = data.get("alpha", alpha)
	tint = data.get("tint", tint)
	is_boss = data.get("boss", is_boss)
	coin_drops = data.get("coins", coin_drops)
	targetable = data.get("targetable", targetable)
	ability = data.get("ability", "")
	_data = data
	_hp_mult = hp_mult
	_speed_mult = speed_mult
	_ab_timer = randf_range(1.0, float(data.get("every", 3.5)))
	if motion == "still":
		behavior = "still"


func make_elite(kind: String) -> void :
	var spec: Dictionary = ELITES[kind]
	elite = kind
	max_hp *= spec["hp"]
	sprite_scale *= spec["scale"]
	radius *= spec["scale"]
	speed *= spec["speed"]
	xp_value = maxi(xp_value, 1) * 6
	coin_drops += 3 if kind == "champion" else 1
	knockback *= 0.0 if kind == "champion" else 0.1

func slow(seconds: float) -> void :
	_slow_t = maxf(_slow_t, seconds)

func bind(seconds: float) -> void :
	_bind_t = maxf(_bind_t, seconds)


func knock(velocity_push: Vector2) -> void :


	if behavior == "chase" and not frozen:
		_knock += velocity_push * (0.2 if is_boss else 1.0)

func _spd() -> float:
	var s: = speed
	if hunt and is_instance_valid(_player):
		s = maxf(s, _player.speed * HUNT_SPEED)
	s *= 1.0 - _censed
	if _bind_t > 0.0:
		return s * (0.45 if is_boss else 0.0)
	return s * (0.45 if _slow_t > 0.0 else 1.0)

func _ready() -> void :
	add_to_group("enemies")
	if elite != "":
		add_to_group("elites")
	hp = max_hp * hp_share
	_anim = randf() * TAU
	_gait = randf()
	_player = get_tree().get_first_node_in_group("player") as Player
	_map = get_tree().get_first_node_in_group("map") as GameMap
	_sprite = Sprite2D.new()
	_frames = Game.theme.frames(sprite_name, "prop_rim" if self is Breakable else "rim")
	_sprite.texture = _frames[0]
	_sprite.scale = Vector2.ONE * sprite_scale
	_sprite.self_modulate = Color(tint, tint.a * alpha)
	add_child(_sprite)
	_feet = _sprite.texture.get_height() * sprite_scale * 0.5
	if motion == "fly" or motion == "float":
		_feet += 10.0
	_walker = motion != "fly" and motion != "float" and not is_boss
	_add_shadow()
	if ability == "charge":
		_lane = Layers.canvas(self, Layers.WARNINGS, _draw_lane, false)
	if ability == "shoot":
		_tell = Layers.canvas(self, Layers.SHOTS, _draw_tell, false)
	Layers.put(self, Layers.FLYING if motion == "fly" or motion == "float" else Layers.BODIES)
	if behavior == "sweep":
		_point_along(velocity)

func _process(delta: float) -> void :
	_update_flash(delta)
	if _doom_t > 0.0:
		_doom_t -= delta
		if _doom_t <= 0.0 and _flash <= 0.0:
			_sprite.modulate = Color.WHITE
	if is_boss:
		_update_rage(delta)
	if not is_instance_valid(_player):
		return
	if frozen and behavior != "still":
		if _flash <= 0.0:
			_sprite.modulate = FROZEN_TINT
		_was_frozen = true
		_knock = Vector2.ZERO
		return
	if _was_frozen:
		_was_frozen = false
		if _flash <= 0.0:
			_sprite.modulate = DOOM_TINT if _doom_t > 0.0 else Color.WHITE
	if _bind_t > 0.0:
		_bind_t -= delta
	if _slow_t > 0.0:
		_slow_t -= delta
	if elite != "" or hunt:
		queue_redraw()
	var to_player: = _player.global_position - global_position
	var dist: = to_player.length()
	_check -= 1
	var recheck: = _check <= 0
	if recheck:
		_check = CHECK_EVERY
	_animate(delta, dist < Game.offscreen_distance() + radius * 2.0, recheck)
	var touching: = dist <= radius + _player.radius
	_censed = 0.0
	if _player.censer_slow > 0.0 and dist <= Player.CENSER_RADIUS + radius:
		_censed = _player.censer_slow * (CENSER_BOSS if is_boss else 1.0)
	var from_x: = global_position.x
	match behavior:
		"sweep":
			global_position += velocity * delta
			_point_along(velocity)

			var gone: = maxf(SWEEP_DESPAWN, Game.offscreen_distance() + 100.0)
			if to_player.dot(velocity) < 0.0 and to_player.length_squared() > gone * gone:
				queue_free()
				return
		"still":
			pass
		"guard":
			guard_angle += guard_spin * delta
			global_position = guard_center + Vector2.RIGHT.rotated(guard_angle) * guard_radius
			_face(to_player.x)
		_:
			_check_left_behind(delta, dist)
			var wade: = _terrain(delta) if _walker and _map and _map.has_terrain else 1.0
			if _kb_t > 0.0:
				_kb_t -= delta
				_step( - to_player.normalized() * _spd() * _kb_mul * wade * delta)
			elif not _run_ability(delta, to_player):
				if recheck:
					_lure = _find_lure(dist)
				if is_instance_valid(_lure) and not _lure.is_fading():
					var to_ghost: = _lure.global_position - global_position
					if to_ghost.length() > radius + _lure.radius:
						_step(_chase_dir(to_ghost) * _spd() * _gait_mult() * wade * delta)
				elif not touching:
					_step(_chase_dir(to_player) * _spd() * _gait_mult() * wade * delta)



			var moved: = global_position.x - from_x
			if _kb_t > 0.0:
				_face(to_player.x)
			elif absf(moved) > _spd() * delta * 0.3:
				_face(moved)
			elif absf(moved) < 0.01 and absf(to_player.x) > 4.0:
				_face(to_player.x)
			if _knock.length_squared() > 4.0:
				_step(_knock * delta)
				_knock *= maxf(0.0, 1.0 - 7.0 * delta)
			else:
				_knock = Vector2.ZERO
	if touching and _ab_state != 1 and hits > 0.0:
		_player.touch(hits * delta, self, hits)
		if _player.thorns > 0.0:
			_thorn_t += delta
			if _thorn_t >= Player.THORN_TICK:
				_thorn_t -= Player.THORN_TICK
				_player.thorn_hit(self)
	elif _thorn_t > 0.0:
		_thorn_t = 0.0



func _terrain(delta: float) -> float:
	if _ground < 0 or _check == CHECK_EVERY:
		_ground = _map.ground_at(global_position)
	var g: = _ground
	if g == GameMap.Ground.CURRENT:
		_step(_map.flow_at(global_position) * delta)
	elif g == GameMap.Ground.LAVA:
		_lava_t += delta
		if _lava_t >= LAVA_TICK:
			_lava_t = 0.0
			var share: = _map.burn() * LAVA_TICK * (0.1 if elite == "champion" else (0.25 if elite != "" else 1.0))
			take_damage(max_hp * share, 0.0)
	return _map.ground_speed(g)


func _check_left_behind(delta: float, dist: float) -> void :
	if dist < Game.offscreen_distance() + RELOCATE_MARGIN or _ab_state != 0:
		_far_t = 0.0
		return
	_far_t += delta
	if _far_t < RELOCATE_AFTER or (keep_near.is_valid() and not keep_near.call()):
		return
	_far_t = 0.0
	var ahead: = _player.facing if _player.moving else (global_position - _player.global_position).normalized()
	var pos: = _player.global_position + ahead.rotated(randf_range( - RELOCATE_SPREAD, RELOCATE_SPREAD)) * Game.offscreen_distance()
	if _map and _map.band_axis != "" and not _map.in_band(pos, radius + 40.0):
		var along: = Vector2(signf(ahead.x) if absf(ahead.x) > 0.01 else 1.0, 0.0) if _map.band_axis == "x" else Vector2(0.0, signf(ahead.y) if absf(ahead.y) > 0.01 else 1.0)
		pos = _player.global_position + along * Game.offscreen_distance()
	global_position = _map.push_out(pos, radius) if _map else pos
	_knock = Vector2.ZERO



func _find_lure(dist_to_player: float) -> Ghost:
	if Ghost.alive.is_empty() or is_boss or hunt:
		return null
	var best: Ghost = null
	var best_d: = minf(Ghost.LURE, dist_to_player)
	for g: Ghost in Ghost.alive:
		if g.is_fading():
			continue
		var d: = g.global_position.distance_to(global_position)
		if d < best_d:
			best_d = d
			best = g
	return best


func _chase_dir(to_player: Vector2) -> Vector2:
	var dir: = to_player.normalized()
	if motion == "skitter":
		dir = dir.rotated(sin(_anim * 7.0 + _gait * TAU) * SKITTER_SWAY)
	return dir


func _gait_mult() -> float:
	if motion != "hop":
		return 1.0
	var p: = fmod(_anim * HOP_RATE + _gait, 1.0)
	return 0.0 if p > HOP_AIR else PI / (2.0 * HOP_AIR) * sin(PI * p / HOP_AIR)

func _face(dx: float) -> void :
	if dx != 0.0:
		_sprite.flip_h = dx < 0.0



func _point_along(v: Vector2) -> void :
	if v.length_squared() < 1.0:
		return
	_sprite.flip_h = v.x < -0.01
	var a: = atan2(v.y, absf(v.x))
	if motion != "float":
		a = clampf(a, -0.5, 0.5)
	_sprite.rotation = - a if _sprite.flip_h else a




func _step(motion: Vector2) -> void :
	if not _map:
		global_position += motion
	elif not _walker:
		global_position = _map.move(global_position, motion, radius, false, true, true)
	else:
		if _on_wall:
			motion *= CLIMB_SPEED
		global_position = _map.move(global_position, motion, radius, true, false, true)


func _run_ability(delta: float, to_player: Vector2) -> bool:
	match ability:
		"charge":
			return _charge(delta, to_player)
		"shoot":
			return _shoot(delta, to_player)
	return false

func _charge(delta: float, to_player: Vector2) -> bool:
	match _ab_state:
		0:
			_ab_timer -= delta * (HUNT_ABILITY if hunt else 1.0)
			if _ab_timer <= 0.0 and to_player.length() < float(_data.get("range", 450.0)):
				_ab_state = 1
				_ab_left = _data.get("windup", 0.7)
				_ab_dir = _charge_aim(to_player)
				queue_redraw()
				_redraw_lane()
		1:
			_ab_left -= delta
			_sprite.modulate = Color(1.6, 0.8, 0.8) if int(_ab_left * 14.0) % 2 == 0 else Color.WHITE
			if _ab_left > float(_data.get("windup", 0.7)) * 0.35:
				_ab_dir = _ab_dir.lerp(_charge_aim(to_player), 4.0 * delta).normalized()
			queue_redraw()
			_redraw_lane()
			if _ab_left <= 0.0:
				_ab_state = 2
				_ab_left = _data.get("dash_time", 0.5)
				_redraw_lane()
				_sprite.modulate = Color.WHITE
			return true
		2:
			_ab_left -= delta
			_step(_ab_dir * float(_data.get("dash_speed", 520.0)) * delta)
			if _ab_left <= 0.0:
				_ab_state = 0
				_ab_timer = float(_data.get("every", 3.5)) * randf_range(0.8, 1.2)
				queue_redraw()
			return true
	return false



func _charge_aim(to_player: Vector2) -> Vector2:
	var lead: = float(_data.get("lead", 0.0))
	if lead <= 0.0 or not _player.moving:
		return to_player.normalized()
	var eta: = to_player.length() / maxf(float(_data.get("dash_speed", 520.0)), 1.0) + float(_data.get("windup", 0.7)) * 0.35
	return (to_player + _player.facing * _player.speed * eta * lead).normalized()

func _shoot(delta: float, to_player: Vector2) -> bool:
	var dist: = to_player.length()
	if _windup > 0.0:
		_windup -= delta
		_tell.queue_redraw()
		if _windup <= 0.0:
			_fire_volley(to_player)
		return true
	_ab_timer -= delta * (HUNT_ABILITY if hunt else 1.0)
	if _ab_timer <= 0.0 and dist < float(_data.get("range", 560.0)):
		_ab_timer = float(_data.get("every", 2.4)) * randf_range(0.85, 1.15)
		if is_boss or (_on_screen() and EnemyShot.live < MAX_SHOTS):
			_windup = SHOT_WINDUP_BOSS if is_boss else SHOT_WINDUP
			_tell.queue_redraw()

	var hold: float = _data.get("hold", 320.0)
	if dist > hold + 40.0:
		_step(to_player.normalized() * _spd() * delta)
	elif dist < hold - 80.0:
		_step( - to_player.normalized() * _spd() * 0.7 * delta)
	return true

func _fire_volley(to_player: Vector2) -> void :
	var count: int = _data.get("shots", 1)
	var spread: float = _data.get("spread", 0.0)
	for i in count:
		var off: = 0.0 if count == 1 else lerpf( - spread, spread, float(i) / (count - 1))
		EnemyShot.fire(get_tree().current_scene, global_position + _tell_offset(), to_player.normalized().rotated(off), 
			_data.get("shot_speed", 240.0), 1.0, _shot_color(), is_boss)

func _shot_color() -> Color:
	return _data.get("shot_color", Game.theme.ui["death"])


func _on_screen() -> bool:
	var view: = get_canvas_transform().affine_inverse() * get_viewport_rect()
	return view.grow(-30.0).has_point(global_position)


func _tell_offset() -> Vector2:
	return Vector2(0, - _feet * 0.5)



func _draw_tell() -> void :
	if _windup <= 0.0 or _dead:
		return
	var full: = SHOT_WINDUP_BOSS if is_boss else SHOT_WINDUP
	var k: = clampf(1.0 - _windup / full, 0.0, 1.0)
	var c: = _shot_color()
	var at: = _tell_offset()
	var r: = EnemyShot.RADIUS * (1.4 if is_boss else 1.0)
	var late: = k > 0.6 and int(_windup * 20.0) % 2 == 0
	PixelFx.disc(_tell, at, r * (1.2 + 1.4 * k), Color(0, 0, 0, 0.4 * k))
	PixelFx.arc(_tell, at, r * (3.6 - 2.0 * k), 0.0, TAU, Color(Color.WHITE if late else c, 0.35 + 0.6 * k), PixelFx.PIXEL * 1.5)
	for i in 4:
		var a: = TAU * i / 4.0 + k * 2.0
		PixelFx.dot(_tell, at + Vector2.RIGHT.rotated(a) * r * (3.2 - 2.4 * k), Color(c.lightened(0.4), k), 2)
	PixelFx.disc(_tell, at, r * (0.4 + 0.8 * k), c)
	PixelFx.disc(_tell, at, r * 0.45 * k, Color.WHITE)

func _animate(delta: float, on_screen: = true, recheck: = true) -> void :
	_anim += delta
	if _walker and _map:
		if recheck:
			_on_wall = _map.on_obstacle(global_position, radius)
		if _on_wall or _climb > 0.0:
			_climb = move_toward(_climb, 1.0 if _on_wall else 0.0, delta * 6.0)
			_sprite.offset.y = - CLIMB_LIFT * _climb / maxf(sprite_scale, 0.01)
	if not on_screen:
		return
	var animated: = _frames.size() > 1
	if motion == "gallop" and animated:
		if _ab_state == 1:
			_sprite.texture = _frames[mini(2, _frames.size() - 1)]
			_sprite.position.x = sin(_anim * 70.0) * 1.5
			return
		_sprite.position.x = 0.0
		_gait += delta * clampf(_spd() * (2.0 if _ab_state == 2 else 1.0) / 60.0, 1.5, 5.0)
		_sprite.texture = _frames[int(_gait * _frames.size()) % _frames.size()]
		return
	if motion == "hop":
		var p: = fmod(_anim * HOP_RATE + _gait, 1.0)
		var air: = p < HOP_AIR
		if animated:
			_sprite.texture = _frames[1 if air else 0]
		_sprite.position.y = - sin(PI * p / HOP_AIR) * 14.0 if air else 0.0
		return
	if animated:
		var cycle: = 14.0 if motion == "fly" else (6.0 if motion == "float" else (16.0 if motion == "skitter" else 8.0))
		_sprite.texture = _frames[int(_anim * cycle / TAU * _frames.size()) % _frames.size()]
	match motion:
		"fly":
			_sprite.position.y = sin(_anim * 14.0) * 4.0
			if not animated:
				_sprite.scale.y = sprite_scale * (1.0 + 0.15 * sin(_anim * 14.0))
		"float":
			_sprite.position.y = sin(_anim * 3.0) * 6.0
		"still":
			pass
		_:
			_sprite.position.y = - absf(sin(_anim * 8.0)) * (1.5 if animated else 3.0)
			_sprite.rotation = sin(_anim * 8.0) * (0.02 if animated else 0.06)


func _update_rage(delta: float) -> void :
	var was: = _rage
	_rage = move_toward(_rage, 1.0 if hunt else 0.0, delta * 3.0)
	if _rage <= 0.0 and was <= 0.0:
		return
	if _flash <= 0.0 and _ab_state != 1:
		var beat: = 0.5 + 0.5 * sin(Time.get_ticks_msec() * 0.014)
		_sprite.modulate = Color.WHITE.lerp(Color(1.6, 0.5, 0.4), _rage * (0.55 + 0.45 * beat))
	queue_redraw()

func _update_flash(delta: float) -> void :
	if _flash <= 0.0:
		return
	_flash -= delta
	_sprite.modulate = Color(10, 10, 10) if _flash > 0.0 else (DOOM_TINT if _doom_t > 0.0 else Color.WHITE)



func mark_doom(share: float, time: float) -> void :
	_doom = maxf(share, _doom) if _doom_t > 0.0 else share
	_doom_t = time
	if _flash <= 0.0:
		_sprite.modulate = DOOM_TINT

func is_dead() -> bool:
	return _dead






const GRID_CELL: = 128.0
const GRID_BIG: = 64.0
const GRID_SLACK: = 40.0
static var _grid: = {}
static var _grid_big: Array = []
static var _grid_frame: = -1

static func _rebuild_grid() -> void :
	_grid_frame = Engine.get_process_frames()
	_grid.clear()
	_grid_big.clear()
	var tree: = Engine.get_main_loop() as SceneTree
	for e: Enemy in tree.get_nodes_in_group("enemies"):
		if e.radius > GRID_BIG:
			_grid_big.append(e)
			continue
		var cell: = Vector2i((e.global_position / GRID_CELL).floor())
		var list: Variant = _grid.get(cell)
		if list == null:
			_grid[cell] = [e]
		else:
			(list as Array).append(e)


static func near(center: Vector2, reach: float) -> Array:
	return in_rect(Rect2(center - Vector2(reach, reach), Vector2(reach, reach) * 2.0))


static func in_rect(rect: Rect2) -> Array:
	if _grid_frame != Engine.get_process_frames():
		_rebuild_grid()
	rect = rect.grow(GRID_BIG + GRID_SLACK)
	var lo: = Vector2i((rect.position / GRID_CELL).floor())
	var hi: = Vector2i((rect.end / GRID_CELL).floor())
	var out: Array = []
	if (hi.x - lo.x + 1) * (hi.y - lo.y + 1) > _grid.size():
		for cell: Vector2i in _grid:
			if cell.x >= lo.x and cell.x <= hi.x and cell.y >= lo.y and cell.y <= hi.y:
				for e: Enemy in _grid[cell]:
					if not e._dead:
						out.append(e)
	else:
		for cx in range(lo.x, hi.x + 1):
			for cy in range(lo.y, hi.y + 1):
				var list: Variant = _grid.get(Vector2i(cx, cy))
				if list != null:
					for e: Enemy in list:
						if not e._dead:
							out.append(e)
	for e: Enemy in _grid_big:
		if not e._dead:
			out.append(e)
	return out



func take_damage(amount: float, kb: = 1.0, crit_bonus: = 0.0) -> bool:
	if _dead:
		return false
	if _doom_t > 0.0:
		amount *= 1.0 + _doom
	var crit: = is_instance_valid(_player) and behavior != "still" and randf() < _player.crit_chance + crit_bonus
	if crit:
		amount *= CRIT_MULT
		_player.shake(2.5)
	hp -= amount
	if hp > 0.0 and knockback > 0.0 and kb > 0.0 and behavior == "chase" and _ab_state == 0:
		_kb_mul = knockback * kb
		_kb_t = KB_TIME
	_show_damage(amount, crit)
	Game.sfx("hit")
	_flash = FLASH_TIME
	_sprite.modulate = Color(10, 10, 10)
	if is_boss or elite != "":
		queue_redraw()
	if hp <= 0.0:
		die()
	return crit



const NUMBER_GAP: = 320

func _show_damage(amount: float, crit: bool) -> void :
	if behavior == "still" or Game.damage_numbers == 0:
		return
	_dmg_acc += amount
	var now: = Time.get_ticks_msec()
	var killing: = hp <= 0.0
	if now < _next_number and not crit and not killing:
		return
	if Game.damage_numbers == 1 and not crit and not killing:
		_dmg_acc = 0.0
		return
	if not crit and not killing and FloatText.soft_full():
		return
	_next_number = now + NUMBER_GAP
	var shown: = _dmg_acc
	_dmg_acc = 0.0
	var size: = int(clampf(15.0 + sqrt(shown) * 1.8, 15.0, 34.0))
	var color: = Color.WHITE
	if shown >= 150.0:
		color = Color(1, 0.35, 0.2)
	elif shown >= 40.0:
		color = Color(1, 0.7, 0.2)
	var text: = str(int(round(shown)))
	var life: = 0.6
	var kick: = 1.4
	if crit:
		size = int(size * 1.3)
		color = Color(1, 0.9, 0.2)
		text += "!"
		life = 0.8
		kick = 1.6
	elif killing:
		size = int(size * 1.15)
	var top: = _feet + 8.0
	FloatText.pop(self, text, global_position + Vector2(randf_range(-14.0, 14.0), - top), color, size, life, 
		70.0 if not crit else 95.0, kick, not (crit or killing))

func die() -> void :
	_dead = true
	remove_from_group("enemies")
	Game.sfx("break" if behavior == "still" else "kill")
	died.emit(self)
	if is_instance_valid(_player):
		if behavior == "still":
			_player.add_score(_score_value(), global_position)
		else:
			_player.register_kill(_score_value(), global_position)
			if _kill_stat == "":
				_kill_stat = "kill_" + str(_data.get("name", sprite_name))
			_bestiary[_kill_stat] = int(_bestiary.get(_kill_stat, 0)) + 1
			if elite != "":
				_bestiary["elite_" + elite] = int(_bestiary.get("elite_" + elite, 0)) + 1
	var scene: = get_tree().current_scene
	if ability == "split":
		_split()
	DeathFx.spawn(scene, global_position + _sprite.position, Game.theme.texture(sprite_name), sprite_scale, _sprite.flip_h, radius, _feet - _sprite.position.y)
	var xp_drop: = xp_value
	var extra_coins: = 0
	if elite != "":
		Game.track("elites")
		if is_instance_valid(_player):
			xp_drop = int(xp_value * (1.0 + _player.elite_bonus))
			extra_coins = 1 if randf() < _player.elite_bonus / 2.0 else 0
		if elite == "volatile":
			_burst_shots(scene)
	var blessed: = is_boss or elite == "champion"
	if is_boss:
		Game.track("bosses")
	if xp_drop > 0:
		XPGem.drop(scene, global_position, xp_drop)


	var taper: = 1.0 + (_player.kills / COIN_TAPER_KILLS if is_instance_valid(_player) else 0.0)
	if randf() < coin_chance / taper or (SoulFever.active and randf() < SoulFever.DROP_CHANCE / taper and get_tree().get_node_count_in_group("soul_pickups") < 150):
		Pickup.spawn(scene, Pickup.Kind.COIN, global_position + Vector2(12, 0))
	for i in coin_drops + extra_coins:
		Pickup.spawn(scene, Pickup.Kind.COIN, global_position + Vector2(randf_range( - radius, radius), randf_range( - radius, radius)))
	var chest: = is_boss or elite == "champion" or (elite != "" and randf() < elite_chest_chance())
	if chest:
		if is_instance_valid(_player):
			_player.last_chest_at = _player.survived
		var c: = Pickup.spawn(scene, Pickup.Kind.BLESSING, global_position)
		c.blessed = blessed
		if is_boss:
			c.trophy = _data
	if is_boss:
		_harvest()
	elif is_instance_valid(_player) and behavior != "still" and not blasting and _player.blast_chance > 0.0\
	and randf() < _player.blast_chance:
		_player.blast.call_deferred(global_position)
	queue_free()



func burn_to_ash() -> void :
	if _dead:
		return
	_dead = true
	remove_from_group("enemies")
	DeathFx.spawn(get_tree().current_scene, global_position + _sprite.position, Game.theme.texture(sprite_name), sprite_scale, _sprite.flip_h, radius, _feet - _sprite.position.y)
	queue_free()


func elite_chest_chance() -> float:
	if not is_instance_valid(_player):
		return ELITE_BLESSING_CHANCE
	var since: = _player.survived - _player.last_chest_at
	return clampf(ELITE_BLESSING_CHANCE * since / CHEST_RHYTHM, CHEST_CHANCE_MIN, CHEST_CHANCE_MAX)


func _burst_shots(scene: Node) -> void :
	var tint: Color = Game.theme.elite_colors.get("volatile", Game.theme.ui["warning"])
	for i in 10:
		EnemyShot.fire(scene, global_position, Vector2.RIGHT.rotated(TAU * i / 10.0), 230.0, 1.0, tint)


func _harvest() -> void :
	FloatText.pop(self, "SOUL HARVEST", global_position + Vector2(0, -120), Game.theme.ui["xp"], 46, 1.8, 50.0, 2.0)
	Game.sfx("vacuum")
	var tree: = get_tree()
	tree.create_timer(0.4).timeout.connect( func() -> void : XPGem.vacuum_all(tree, true))


func _split() -> void :
	var into: Dictionary = Game.theme.enemies.get(_data.get("into", ""), {})
	var parent: = get_parent()
	if into.is_empty() or parent == null:
		return
	var scene: PackedScene = load("res://enemy.tscn")
	var count: = int(_data.get("count", 3))
	var cap: Variant = parent.get("max_enemies")
	if cap != null:
		count = mini(count, maxi(0, int(cap) - parent.get_child_count()))
	for i in count:
		var kid: = scene.instantiate() as Enemy
		kid.configure(into, _hp_mult, _speed_mult)
		kid.global_position = global_position + Vector2.RIGHT.rotated(TAU * i / _data.get("count", 3) + randf()) * radius
		parent.add_child.call_deferred(kid)

func _score_value() -> int:
	if behavior == "still":
		return Game.SCORE["statue"]
	return Game.SCORE["kill"] * maxi(1, xp_value) + (Game.SCORE["boss"] if is_boss else 0)




static var _shadow_tex: Texture2D

func _add_shadow() -> void :
	if _shadow_tex == null:
		var img: = Image.create_empty(64, 64, false, Image.FORMAT_RGBA8)
		for y in 64:
			for x in 64:
				if Vector2(x - 31.5, y - 31.5).length() < 32.0:
					img.set_pixel(x, y, Color.WHITE)
		_shadow_tex = ImageTexture.create_from_image(img)
	var shadow: = Sprite2D.new()
	shadow.texture = _shadow_tex
	shadow.modulate = Color(0, 0, 0, 0.25)
	shadow.position = Vector2(0, _feet)
	shadow.scale = Vector2(1.0, 0.35) * radius * 0.9 * 2.0 / 64.0
	Layers.put(shadow, Layers.GROUND_EFFECTS)
	add_child(shadow)
	move_child(shadow, 0)



var _lane: Node2D

func _redraw_lane() -> void :
	if _lane:
		_lane.queue_redraw()

func _draw_lane() -> void :
	if _ab_state != 1:
		return
	var warn: Color = Game.theme.ui["warning"]
	var reach: = float(_data.get("dash_speed", 520.0)) * float(_data.get("dash_time", 0.5))
	var k: = 1.0 - _ab_left / float(_data.get("windup", 0.7))
	var side: = _ab_dir.orthogonal() * radius
	var lane: = PackedVector2Array([side, _ab_dir * reach + side, _ab_dir * reach - side, - side])
	_lane.draw_colored_polygon(lane, Color(0, 0, 0, 0.35))
	_lane.draw_colored_polygon(lane, Color(warn, 0.18 + 0.32 * k))
	_lane.draw_line(side, _ab_dir * reach + side, Color(warn, 0.7), 3.0)
	_lane.draw_line( - side, _ab_dir * reach - side, Color(warn, 0.7), 3.0)

func _draw() -> void :
	if _rage > 0.0:
		var hp_color: Color = Game.theme.ui["hp"]
		var ms: = Time.get_ticks_msec()
		var beat: = 0.5 + 0.5 * sin(ms * 0.012)
		PixelFx.disc(self, Vector2.ZERO, radius * (1.5 + 0.15 * beat), Color(hp_color, 0.22 * _rage))
		draw_arc(Vector2.ZERO, radius * 1.15 + 8.0, 0, TAU, 40, Color(hp_color, (0.35 + 0.4 * beat) * _rage), 5.0)
		draw_arc(Vector2.ZERO, radius * 1.15 + 16.0, 0, TAU, 40, Color(hp_color, 0.15 * beat * _rage), 8.0)
		for i in 10:
			var life: = fmod(ms * 0.0011 + i * 0.37, 1.0)
			var x: = sin(i * 12.9898) * radius * 0.9
			var p: = Vector2(x + sin(ms * 0.004 + i) * 6.0, - _feet * 0.4 - life * radius * 2.2)
			PixelFx.dot(self, p, Color(hp_color.lightened(0.3 * (1.0 - life)), (1.0 - life) * _rage), 4 if life < 0.5 else 2)
	if elite != "":
		var c: Color = Game.theme.elite_colors.get(elite, Color(1, 0.85, 0.2))
		var pulse: = 0.5 + 0.5 * sin(Time.get_ticks_msec() * 0.008)
		var r: = radius * 1.25 + 6.0
		draw_arc(Vector2.ZERO, r, 0, TAU, 32, Color(c, 0.35 + 0.35 * pulse), 4.0)
		draw_arc(Vector2.ZERO, r + 5.0, 0, TAU, 32, Color(c, 0.18), 6.0)
		for i in 3:
			var a: = Time.get_ticks_msec() * 0.003 + TAU * i / 3.0
			draw_circle(Vector2.RIGHT.rotated(a) * (r + 3.0), 4.0, c.lightened(0.4))
	if is_boss or elite != "":
		var w: = radius * 2.4
		var top_left: = Vector2( - w / 2, - _feet - 22)
		draw_rect(Rect2(top_left, Vector2(w, 10)), Color(0, 0, 0, 0.6))
		draw_rect(Rect2(top_left, Vector2(w * clampf(hp / max_hp, 0, 1), 10)), Game.theme.ui["hp"])
