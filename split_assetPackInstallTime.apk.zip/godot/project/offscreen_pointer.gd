class_name OffscreenPointer
extends Control





const GROUP: = "offscreen_pointer"
const MARGIN: = 44.0
const TOP_MARGIN: = 240.0
const ARROW: = 26.0
const ICON_SCALE: = 2.5
const LABEL_SIZE: = 24

var _player: Node2D
var _time: = 0.0
var _holy: Color

func _ready() -> void :
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_player = get_tree().get_first_node_in_group("player") as Node2D
	_holy = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))

func _process(delta: float) -> void :
	_time += delta
	queue_redraw()

func _draw() -> void :
	if not is_instance_valid(_player):
		return
	var view: = get_viewport_rect()
	var to_screen: = get_viewport().get_canvas_transform()
	var top: = TOP_MARGIN + Game.safe_top()
	var inner: = Rect2(view.position + Vector2(MARGIN, top), view.size - Vector2(MARGIN * 2, top + MARGIN))
	var from: = to_screen * _player.global_position
	var bob: = sin(_time * 6.0) * 6.0
	for node: Node in get_tree().get_nodes_in_group(GROUP):
		var target: = node as Node2D
		if target == null or (node.has_method("pointer_hidden") and node.pointer_hidden()):
			continue
		var at: = to_screen * target.global_position
		if view.grow(-16).has_point(at):
			continue
		var dir: = (at - from).normalized()
		var pos: = _edge_point(inner, from, dir) + dir * bob
		_draw_arrow(pos, dir, node.pointer_color() if node.has_method("pointer_color") else _holy)
		var icon_at: = pos - dir * ARROW
		if node.has_method("pointer_texture"):
			var tex: Texture2D = node.pointer_texture()
			var scale_by: float = node.pointer_scale() if node.has_method("pointer_scale") else ICON_SCALE
			var size: = tex.get_size() * scale_by
			icon_at = pos - dir * (ARROW + size.x * 0.6)
			draw_texture_rect(tex, Rect2(icon_at - size * 0.5, size), false)
		if node.has_method("pointer_label"):
			var text: String = node.pointer_label()
			var font: = ThemeDB.fallback_font
			var w: = font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, LABEL_SIZE).x
			var spot: = icon_at - dir * 40.0 + Vector2( - w * 0.5, LABEL_SIZE * 0.35)
			if absf(dir.x) > absf(dir.y):
				spot = Vector2(pos.x - w * 0.5, pos.y - 46.0)
			spot.x = clampf(spot.x, 8.0, view.size.x - w - 8.0)
			draw_string_outline(font, spot, text, HORIZONTAL_ALIGNMENT_LEFT, -1, LABEL_SIZE, 6, Color(0, 0, 0, 0.9))
			draw_string(font, spot, text, HORIZONTAL_ALIGNMENT_LEFT, -1, LABEL_SIZE, Color.WHITE)


func _edge_point(rect: Rect2, from: Vector2, dir: Vector2) -> Vector2:
	var t: = INF
	if dir.x > 0.001:
		t = minf(t, (rect.end.x - from.x) / dir.x)
	elif dir.x < -0.001:
		t = minf(t, (rect.position.x - from.x) / dir.x)
	if dir.y > 0.001:
		t = minf(t, (rect.end.y - from.y) / dir.y)
	elif dir.y < -0.001:
		t = minf(t, (rect.position.y - from.y) / dir.y)
	return from + dir * maxf(t, 0.0)

func _draw_arrow(pos: Vector2, dir: Vector2, tint: Color) -> void :
	var side: = dir.orthogonal()
	var pulse: = 0.5 + 0.5 * sin(_time * 5.0)
	draw_circle(pos - dir * ARROW * 0.6, ARROW * (1.5 + 0.2 * pulse), Color(tint, 0.18 + 0.12 * pulse))
	var tip: = pos + dir * ARROW
	var back: = pos - dir * ARROW * 0.5
	var outline: = PackedVector2Array([tip + dir * 5, back + side * (ARROW + 5) - dir * 3, back - side * (ARROW + 5) - dir * 3])
	draw_colored_polygon(outline, Color(0, 0, 0, 0.75))
	draw_colored_polygon(PackedVector2Array([tip, back + side * ARROW, back - side * ARROW]), tint.lerp(Color.WHITE, 0.3 * pulse))
