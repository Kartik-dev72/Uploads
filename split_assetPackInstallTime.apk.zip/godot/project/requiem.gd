class_name Requiem
extends Weapon











const ID: = "requiem"
const COOLDOWN_TEXT: = "sings %d%% more often"
const WIDTH: = 64.0



const TICK: = 0.5
const FADE: = 0.25
const BASE: = {"damage": 8.0, "cooldown": 3.0, "count": 1, "area": 1.0, "duration": 1.4}
const UPGRADES: = [
	{"damage": 3.0}, 
	{"area": 1.2}, 
	{"duration": 1.25}, 
	{"damage": 3.0}, 
	{"count": 1}, 
	{"area": 1.2}, 
	{"damage": 5.0}, 
]
const HOLY: = {"damage": 6.0}

var damage: = 8.0
var cooldown: = 3.0
var count: = 1
var area: = 1.0
var duration: = 1.4
var _timer: = 0.8
var _hymns: Array[Dictionary] = []
var _time: = 0.0

func _on_level() -> void :
	Layers.put(self, Layers.PLAYER_EFFECTS)

func _process(delta: float) -> void :
	_time += delta
	_timer -= delta
	if _timer <= 0.0:
		_timer = cooldown_of(cooldown)
		var w: = WIDTH * area_of(area)
		for i in count:
			_hymns.append({"x": (i - (count - 1) * 0.5) * w, "t": 0.0, "life": duration_of(duration), "tick": 0.0})
		Game.sfx("holy" if holy else "reap", 0.55 if not holy else 0.8)
	if _hymns.is_empty():
		return
	for h in _hymns:
		h["t"] += delta
		h["tick"] -= delta
		if h["tick"] <= 0.0 and h["t"] >= FADE * 0.5:
			h["tick"] += TICK
			_sing(float(h["x"]))
	_hymns = _hymns.filter( func(h: Dictionary) -> bool: return h["t"] < h["life"])
	queue_redraw()


func _sing(offset: float) -> void :
	var view: = visible_rect().grow(40)
	var half: = WIDTH * area_of(area) * 0.5
	var x: = global_position.x + offset
	var hit: = {}
	for e: Enemy in Enemy.in_rect(Rect2(x - half - 40, view.position.y, half * 2 + 80, view.size.y)):
		if absf(e.global_position.x - x) <= half + e.radius * 0.6:
			hit[e] = true
	if holy:
		var y: = global_position.y + offset
		for e: Enemy in Enemy.in_rect(Rect2(view.position.x, y - half - 40, view.size.x, half * 2 + 80)):
			if absf(e.global_position.y - y) <= half + e.radius * 0.6:
				hit[e] = true
	for e: Enemy in hit:
		if not e.is_dead():
			e.take_damage(power(damage), 0.0)



func _draw() -> void :
	var view: = visible_rect().grow(60)
	var top: = view.position.y - global_position.y
	var bottom: = view.end.y - global_position.y
	var left: = view.position.x - global_position.x
	var right: = view.end.x - global_position.x
	var half: = WIDTH * area_of(area) * 0.5
	for h in _hymns:
		var t: float = h["t"]
		var life: float = h["life"]
		var a: = minf(1.0, t / FADE) * minf(1.0, (life - t) / FADE)
		var x: float = h["x"]
		_band(Rect2(x - half, top, half * 2.0, bottom - top), a, true, t)
		if holy:
			_band(Rect2(left, x - half, right - left, half * 2.0), a, false, t)

func _band(r: Rect2, a: float, vertical: bool, t: float) -> void :
	var hot: = color.lightened(0.6)
	PixelFx.rect(self, r, Color(color, 0.16 * a))
	var inner: = r.grow_individual( - r.size.x * 0.3, 0, - r.size.x * 0.3, 0) if vertical else r.grow_individual(0, - r.size.y * 0.3, 0, - r.size.y * 0.3)
	PixelFx.rect(self, inner, Color(hot, 0.14 * a))
	var thick: = PixelFx.PIXEL
	if vertical:
		PixelFx.rect(self, Rect2(r.position.x, r.position.y, thick, r.size.y), Color(hot, 0.7 * a))
		PixelFx.rect(self, Rect2(r.end.x - thick, r.position.y, thick, r.size.y), Color(hot, 0.7 * a))
		for k in 7:
			var y: = r.position.y + fmod(t * 520.0 + k * r.size.y / 7.0, r.size.y)
			PixelFx.rect(self, Rect2(r.position.x + thick, y, r.size.x - thick * 2.0, thick), Color(hot, 0.35 * a))
		for k in 5:
			var y: = r.position.y + fmod(t * 160.0 + k * 233.0, r.size.y)
			var x: = r.get_center().x + sin(t * 3.0 + k * 1.9) * r.size.x * 0.25
			_note(Vector2(x, y), Color(Color.WHITE if holy else hot, 0.8 * a))
	else:
		PixelFx.rect(self, Rect2(r.position.x, r.position.y, r.size.x, thick), Color(hot, 0.7 * a))
		PixelFx.rect(self, Rect2(r.position.x, r.end.y - thick, r.size.x, thick), Color(hot, 0.7 * a))
		for k in 7:
			var x: = r.position.x + fmod(t * 520.0 + k * r.size.x / 7.0, r.size.x)
			PixelFx.rect(self, Rect2(x, r.position.y + thick, thick, r.size.y - thick * 2.0), Color(hot, 0.35 * a))


func _note(at: Vector2, c: Color) -> void :
	var p: = PixelFx.PIXEL
	var o: = PixelFx.snap(at)
	PixelFx.rect(self, Rect2(o, Vector2(p * 3, p * 2)), c)
	PixelFx.rect(self, Rect2(o + Vector2(p * 2, - p * 5), Vector2(p, p * 5)), c)
	PixelFx.rect(self, Rect2(o + Vector2(p * 3, - p * 5), Vector2(p * 2, p)), c)
