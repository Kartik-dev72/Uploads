extends RefCounted







var _unit_id: = ""
var _ad: RewardedAd
var _loading: = false
var _sdk_ready: = false

func start(unit_id: String) -> void :
	_unit_id = unit_id
	_request_consent()

func is_ready() -> bool:
	return _ad != null


func privacy_options_required() -> bool:
	return UserMessagingPlatform.consent_information.get_privacy_options_requirement_status() == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED

func show_privacy_options(done: Callable) -> void :
	UserMessagingPlatform.show_privacy_options_form( func(_error: FormError) -> void : done.call())

func _request_consent() -> void :
	var info: = UserMessagingPlatform.consent_information
	info.update(ConsentRequestParameters.new(), func() -> void :
		if info.get_consent_status() == ConsentInformation.ConsentStatus.REQUIRED and info.get_is_consent_form_available():
			_show_consent_form()
		else:
			_init_sdk(), 
	func(_error: FormError) -> void : _init_sdk())

func _show_consent_form() -> void :
	UserMessagingPlatform.load_consent_form( func(form: ConsentForm) -> void :
		form.show( func(_error: FormError) -> void : _init_sdk()), 
	func(_error: FormError) -> void : _init_sdk())

func _init_sdk() -> void :
	if _sdk_ready:
		return
	_sdk_ready = true
	var config: = RequestConfiguration.new()
	config.max_ad_content_rating = RequestConfiguration.MAX_AD_CONTENT_RATING_T
	MobileAds.set_request_configuration(config)
	var listener: = OnInitializationCompleteListener.new()
	listener.on_initialization_complete = func(_status: InitializationStatus) -> void : _load()
	MobileAds.initialize(listener)


func _load() -> void :
	if _loading or _ad != null or not _sdk_ready:
		return
	_loading = true
	var on_load: = RewardedAdLoadCallback.new()
	on_load.on_ad_failed_to_load = func(error: LoadAdError) -> void :
		_loading = false
		push_warning("Rewarded ad failed to load: %s" % error.message)
		_retry_later()
	on_load.on_ad_loaded = func(ad: RewardedAd) -> void :
		_loading = false
		_retry_wait = RETRY_FIRST
		_ad = ad
	RewardedAdLoader.new().load(_unit_id, AdRequest.new(), on_load)




const RETRY_FIRST: = 20.0
const RETRY_MAX: = 180.0
var _retry_wait: = RETRY_FIRST

func _retry_later() -> void :
	var tree: = Engine.get_main_loop() as SceneTree
	if tree == null:
		return
	tree.create_timer(_retry_wait, true).timeout.connect(_load)
	_retry_wait = minf(_retry_wait * 2.0, RETRY_MAX)

func show(done: Callable) -> void :
	var ad: = _ad
	_ad = null
	if ad == null:
		done.call(false)
		return
	var state: = {"earned": false}
	var content: = FullScreenContentCallback.new()
	content.on_ad_dismissed_full_screen_content = func() -> void :
		ad.destroy()
		_load()
		done.call(state["earned"])
	content.on_ad_failed_to_show_full_screen_content = func(_error: AdError) -> void :
		ad.destroy()
		_load()
		done.call(false)
	ad.full_screen_content_callback = content
	var listener: = OnUserEarnedRewardListener.new()
	listener.on_user_earned_reward = func(_item: RewardedItem) -> void :
		state["earned"] = true
	ad.show(listener)
