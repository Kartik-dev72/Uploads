class_name Toast
extends CanvasLayer









const SHOW_TIME: = 2.8



const MAX_AT_ONCE: = 2
const HOLD_GROUPS: = ["blessing_screen"]

var _box: VBoxContainer
var _queue: Array[Array] = []

func _ready() -> void :
	layer = 100
	process_mode = Node.PROCESS_MODE_ALWAYS
	_box = VBoxContainer.new()
	_box.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	_box.offset_top = 300.0
	_box.offset_left = 60.0
	_box.offset_right = -60.0
	_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_box.add_theme_constant_override("separation", 10)
	add_child(_box)

func push(title: String, subtitle: = "", color: = Color(1, 0.85, 0.3), icon: = "", reward: = "", sound: = "") -> void :
	_queue.append([title, subtitle, color, icon, reward, sound])

func _process(_delta: float) -> void :
	if _queue.is_empty() or _shown() >= MAX_AT_ONCE or _held():
		return
	var t: Array = _queue.pop_front()
	_show(t[0], t[1], t[2], t[3], t[4])
	if t[5] != "":
		Game.sfx(t[5])

func _shown() -> int:
	return _box.get_children().filter( func(c: Node) -> bool: return not c.is_queued_for_deletion()).size()


func _held() -> bool:
	var tree: = get_tree()
	var lus: = tree.current_scene.get_node_or_null("UI/LevelUpScreen") as CanvasItem if tree.current_scene else null
	if lus and lus.visible:
		return true
	for g: String in HOLD_GROUPS:
		for n: Node in tree.get_nodes_in_group(g):
			if (n as CanvasItem).visible:
				return true
	return false

func _show(title: String, subtitle: String, color: Color, icon: String, reward: = "") -> void :
	var panel: = PanelContainer.new()
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style: = StyleBoxFlat.new()
	style.bg_color = Color(0.05, 0.02, 0.04, 0.92)
	style.border_color = color
	style.set_border_width_all(3)
	style.set_corner_radius_all(12)
	style.set_content_margin_all(12)
	style.shadow_color = Color(color, 0.35)
	style.shadow_size = 10
	panel.add_theme_stylebox_override("panel", style)
	var col: = VBoxContainer.new()
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	if icon != "":
		var row: = HBoxContainer.new()
		row.add_theme_constant_override("separation", 14)
		row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		panel.add_child(row)
		row.add_child(_icon(icon, color))
		row.add_child(col)
	else:
		panel.add_child(col)
	var t: = Label.new()
	t.text = title
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER if icon == "" else HORIZONTAL_ALIGNMENT_LEFT
	t.add_theme_font_size_override("font_size", 32 if icon == "" else 28)
	t.add_theme_color_override("font_color", color)
	t.add_theme_color_override("font_outline_color", Color.BLACK)
	t.add_theme_constant_override("outline_size", 8)
	col.add_child(t)
	if subtitle != "":
		var s: = Label.new()
		s.text = subtitle
		s.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER if icon == "" else HORIZONTAL_ALIGNMENT_LEFT
		s.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		s.add_theme_font_size_override("font_size", 22)
		s.add_theme_color_override("font_color", Color(1, 1, 1, 0.85))
		col.add_child(s)
	if reward != "":
		var r: = Label.new()
		r.text = reward
		r.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER if icon == "" else HORIZONTAL_ALIGNMENT_LEFT
		r.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		r.add_theme_font_size_override("font_size", 24)
		r.add_theme_color_override("font_color", Game.theme.ui["accent"])
		r.add_theme_color_override("font_outline_color", Color.BLACK)
		r.add_theme_constant_override("outline_size", 6)
		col.add_child(r)
	_box.add_child(panel)
	panel.modulate.a = 0.0
	panel.pivot_offset = Vector2(300, 40)
	var tw: = panel.create_tween()
	tw.tween_property(panel, "modulate:a", 1.0, 0.2)
	if reward != "":
		panel.scale = Vector2.ONE * 1.25
		tw.parallel().tween_property(panel, "scale", Vector2.ONE, 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_interval(SHOW_TIME + (1.0 if reward != "" else 0.0))
	tw.tween_property(panel, "modulate:a", 0.0, 0.4)
	tw.tween_callback(panel.queue_free)


func _icon(sprite: String, color: Color) -> Control:
	var box: = Control.new()
	box.custom_minimum_size = Vector2(84, 84)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var tex: = Game.theme.texture(sprite)
	box.draw.connect( func() -> void :
		var c: = box.size / 2.0
		box.draw_circle(c, 40.0, Color(color, 0.22))
		box.draw_arc(c, 40.0, 0.0, TAU, 32, Color(color, 0.8), 2.0)
		var fit: = minf(60.0 / tex.get_width(), 60.0 / tex.get_height())
		var sz: = tex.get_size() * fit
		box.draw_texture_rect(tex, Rect2(c - sz / 2.0, sz), false))
	box.pivot_offset = Vector2(42, 42)
	box.scale = Vector2.ZERO
	var tw: = box.create_tween()
	tw.tween_interval(0.15)
	tw.tween_property(box, "scale", Vector2.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	return box
