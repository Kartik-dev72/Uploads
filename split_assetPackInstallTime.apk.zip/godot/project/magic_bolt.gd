class_name MagicBolt
extends Weapon

const ID: = "magic_bolt"
const COOLDOWN_TEXT: = "casts %d%% faster"
const BASE: = {"damage": 10.0, "cooldown": 0.7, "count": 1, "pierce": 1}
const UPGRADES: = [
	{"damage": 4.0}, 
	{"cooldown": 0.88}, 
	{"damage": 5.0}, 
	{"count": 1}, 
	{"cooldown": 0.88}, 
	{"pierce": 1, "count": 1}, 
	{"damage": 13.0}, 
]

const HOLY: = {"damage": 3.0, "pierce": 1, "cooldown": 0.18}
const HOLY_MIN_COOLDOWN: = 0.12

var cooldown: = 0.7
var damage: = 10.0
var count: = 1
var pierce: = 1
var _timer: = 0.0
var _shot: = 0

func _process(delta: float) -> void :
	_timer -= delta
	if _timer > 0.0:
		return
	var n: = amount_of(count)
	var targets: = nearest_enemies_on_screen(n)
	if targets.is_empty():
		return
	_timer = maxf(cooldown_of(cooldown), HOLY_MIN_COOLDOWN) if holy else cooldown_of(cooldown)
	if holy:
		_shot += 1
		var target: = targets[_shot % targets.size()]
		var dir: = global_position.direction_to(target.global_position).rotated(randf_range(-0.08, 0.08))
		fire_projectile(global_position, dir, 760.0, damage, pierce, Projectile.Style.ORB, 1.25)
		return
	for i in n:
		var target: = targets[i % targets.size()]
		fire_projectile(global_position, global_position.direction_to(target.global_position), 700.0, damage, pierce, Projectile.Style.ORB)
