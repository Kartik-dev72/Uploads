class_name SigilMine
extends Node2D



const ARM_TIME: = 0.5
const LIFETIME: = 15.0
const TRIGGER: = 62.0

var damage: = 28.0
var radius: = 115.0
var color: = Color.WHITE
var holy: = false
var _time: = 0.0

func _ready() -> void :
	add_to_group("sigil_mines")
	Layers.put(self, Layers.GROUND_EFFECTS)

func _process(delta: float) -> void :
	_time += delta
	if _time >= LIFETIME:
		queue_free()
		return
	queue_redraw()
	if _time < ARM_TIME:
		return
	for e: Enemy in Enemy.near(global_position, TRIGGER):
		if e.targetable and global_position.distance_squared_to(e.global_position) < pow(TRIGGER + e.radius, 2):
			_explode()
			return

func _explode() -> void :
	remove_from_group("sigil_mines")
	for e: Enemy in Enemy.near(global_position, radius):
		if global_position.distance_squared_to(e.global_position) < pow(radius + e.radius, 2):
			e.take_damage(damage)
	RingFx.spawn(get_tree().current_scene, global_position, radius, color)
	Game.sfx("explode")
	var player: = get_tree().get_first_node_in_group("player") as Player
	if player:
		player.shake(3.0)
	queue_free()


func _draw() -> void :
	var armed: = _time >= ARM_TIME
	var left: = LIFETIME - _time
	var fade: = 1.0 if left > 2.0 else (0.4 + 0.6 * absf(sin(_time * 10.0)))
	var a: = (0.9 if armed else 0.4) * fade
	var pulse: = 0.5 + 0.5 * sin(_time * 6.0)
	var r: = TRIGGER * 0.8
	var hot: = color.lightened(0.5)
	PixelFx.disc(self, Vector2.ZERO, r * 1.15, Color(0, 0, 0, 0.3 * fade))
	PixelFx.arc(self, Vector2.ZERO, r, 0, TAU, Color(color, a), 3.0)
	PixelFx.arc(self, Vector2.ZERO, r * 0.78, 0, TAU, Color(color, a * 0.5), 2.0)
	for k in 2:
		var pts: = PackedVector2Array()
		for i in 3:
			pts.append(Vector2.RIGHT.rotated(_time * 0.7 * (1.0 if k == 0 else -1.0) + TAU * i / 3.0 + k * PI / 3.0) * r * 0.9)
		pts.append(pts[0])
		PixelFx.polyline(self, pts, Color(hot, a * 0.8), 2.0)
	PixelFx.disc(self, Vector2.ZERO, 6.0 + 3.0 * pulse * (1.0 if armed else 0.0), Color(hot, a))
	if holy:
		PixelFx.arc(self, Vector2.ZERO, r * 1.3, 0, TAU, Color(1, 1, 1, 0.35 * a), 2.0)
