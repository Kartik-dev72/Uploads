class_name DevilTip
extends Control









const DIM: = 0.6
const FADE_TIME: = 0.2
const DEVIL_AT: = 0.1
const LINE_AT: = 0.45
const TYPE_SPEED: = 0.035
const LINE_GAP: = 0.25
const SLAM_TIME: = 0.35
const HINT_DELAY: = 0.4
const TAP_DELAY: = 0.9
const FACE_SCALE: = 8.0
const FACE_TOP: = 230.0
const TEXT_WIDTH: = 660.0
const HINT_WIDTH: = 600.0

var _tip: Dictionary
var _t: = 0.0
var _laughed: = false
var _last_tap: = -1.0
var _starts: Array[float] = []
var _slam_at: = 0.0
var _hint_at: = 0.0
var _on_close: = Callable()



static func show_tip(host: Node, tip: Dictionary, on_close: = Callable()) -> void :
	var node: = DevilTip.new()
	node._tip = tip
	node._on_close = on_close
	host.add_child(node)

func _ready() -> void :
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_to_group("pause_screen")
	get_tree().paused = true
	var lines: Array = _tip.get("lines", [])
	var at: = LINE_AT
	for i in lines.size():
		_starts.append(at)
		if i < lines.size() - 1:
			at += str(lines[i]).length() * TYPE_SPEED + LINE_GAP
	_slam_at = at
	_hint_at = _slam_at + SLAM_TIME + HINT_DELAY

func _process(delta: float) -> void :
	_t += delta
	if not _laughed and _t >= DEVIL_AT:
		_laughed = true
		Game.sfx("laugh")
	queue_redraw()

func _gui_input(event: InputEvent) -> void :
	var tapped: bool = (event is InputEventScreenTouch and event.pressed) or (event is InputEventMouseButton and event.pressed)
	if not tapped:
		return
	accept_event()
	var now: = Time.get_ticks_msec() / 1000.0
	if now - _last_tap < 0.2:
		return
	_last_tap = now
	if _t < _hint_at:
		_t = _hint_at
	elif _t >= _hint_at + TAP_DELAY:
		_close()

func _unhandled_input(event: InputEvent) -> void :
	if event.is_action_pressed("ui_accept") and _t >= _hint_at + TAP_DELAY:
		_close()

func _close() -> void :
	Game.sfx("select")
	remove_from_group("pause_screen")
	hide()
	queue_free()
	LevelUpScreen.resume_if_clear(get_tree())
	if _on_close.is_valid():
		_on_close.call()

func _draw() -> void :
	var view: = get_viewport_rect().size
	var fade: = clampf(_t / FADE_TIME, 0.0, 1.0)
	draw_rect(Rect2(Vector2.ZERO, view), Color(0, 0, 0, float(_tip.get("dim", DIM)) * fade))
	var slam: = _t - _slam_at
	var shake: = Vector2.ZERO
	if slam >= 0.0 and slam < SLAM_TIME:
		shake = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * 12.0 * (1.0 - slam / SLAM_TIME)
	draw_set_transform(Vector2((view.x - 720.0) / 2.0, Game.design_offset()) + shake)
	var rise: = clampf((_t - DEVIL_AT) / 0.3, 0.0, 1.0)
	var accent: Color = Game.theme.ui["accent"]
	for i in 5:
		draw_circle(Vector2(360, 380), 300.0 - i * 50.0, Color(accent.darkened(0.35), (0.04 + 0.02 * i) * rise))
	_draw_devil(rise)
	var font: = ThemeDB.fallback_font
	var lines: Array = _tip.get("lines", [])
	var y: = 720.0
	for i in lines.size():
		var line: = str(lines[i])
		if i == lines.size() - 1:
			if slam >= 0.0:
				_draw_slam(font, line, str(_tip.get("shake", "")), Vector2(360, y + 30.0), slam)
			break
		if _t >= _starts[i]:
			var size: = _fit(font, line, 44)
			var shown: = line.left(int((_t - _starts[i]) / TYPE_SPEED) + 1)
			var x: = 360.0 - font.get_string_size(line, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x / 2.0
			draw_string_outline(font, Vector2(x, y), shown, HORIZONTAL_ALIGNMENT_LEFT, -1, size, 10, Color(0.1, 0, 0))
			draw_string(font, Vector2(x, y), shown, HORIZONTAL_ALIGNMENT_LEFT, -1, size, Color(1, 0.9, 0.85))
		y += 64.0
	var hint: = str(_tip.get("hint", ""))
	if hint != "" and _t >= _hint_at:
		var a: = clampf((_t - _hint_at) / 0.3, 0.0, 1.0)
		var hy: = y + 130.0
		var hint_size: = _fit(font, hint, 28, 1.0, HINT_WIDTH)
		draw_rect(Rect2(40, hy - 44, 640, 64), Color(0, 0, 0, 0.55 * a))
		draw_string_outline(font, Vector2(40, hy), hint, HORIZONTAL_ALIGNMENT_CENTER, 640, hint_size, 7, Color(0, 0, 0, a))
		draw_string(font, Vector2(40, hy), hint, HORIZONTAL_ALIGNMENT_CENTER, 640, hint_size, Color(1, 1, 1, a))
	if _t >= _hint_at + TAP_DELAY:
		var a: = 0.35 + 0.15 * sin(_t * 4.0)
		draw_string(font, Vector2(0, 1140), "tap to continue", HORIZONTAL_ALIGNMENT_CENTER, 720, 26, Color(1, 1, 1, a))
	draw_set_transform(Vector2.ZERO)


func _draw_devil(rise: float) -> void :
	var key: = Game.theme.taunt_sprite
	if rise <= 0.0 or not Game.theme.sprites.has(key):
		return
	var tex: = Game.theme.texture(key)
	var size: = tex.get_size() * FACE_SCALE
	var bob: = - absf(sin((_t - DEVIL_AT) * 18.0)) * 12.0 * maxf(0.0, 1.0 - (_t - DEVIL_AT) / 2.5)
	var pos: = Vector2(360.0 - size.x / 2.0, FACE_TOP + (1.0 - rise) * 100.0 + bob)
	draw_texture_rect(tex, Rect2(pos + Vector2(8, 10), size), false, Color(0, 0, 0, 0.45 * rise))
	draw_texture_rect(tex, Rect2(pos, size), false, Color(1, 1, 1, rise))


func _draw_slam(font: Font, line: String, word: String, center: Vector2, slam: float) -> void :
	var size: = _fit(font, line, 60, 1.25)
	var punch: = 1.0 + 1.2 * maxf(0.0, 1.0 - slam / 0.14)
	var at: = line.find(word) if word != "" else -1
	var total: = font.get_string_size(line, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	var x: = - total / 2.0
	var hot: = Color(1, 0.12, 0.08).lerp(Color(1, 0.8, 0.2), 0.5 + 0.5 * sin(_t * 12.0))
	var base: = Transform2D(0.0, Vector2.ONE, 0.0, Vector2((get_viewport_rect().size.x - 720.0) / 2.0, Game.design_offset()))\
	* Transform2D(0.0, Vector2.ONE * punch, 0.0, center)
	for i in line.length():
		var c: = line[i]
		var w: = font.get_string_size(c, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
		var in_word: = at >= 0 and i >= at and i < at + word.length()
		var off: = Vector2(x, 0)
		var angle: = 0.0
		if in_word:
			var k: = i - at
			off += Vector2(randf_range(-2, 2), sin(_t * 15.0 + k * 1.1) * 7.0)
			angle = sin(_t * 11.0 + k * 1.7) * 0.12
		draw_set_transform_matrix(base * Transform2D(angle, Vector2.ONE, 0.0, off + Vector2(w / 2.0, 0)))
		draw_string_outline(font, Vector2( - w / 2.0, 0), c, HORIZONTAL_ALIGNMENT_LEFT, -1, size, 12, Color(0.15, 0, 0))
		draw_string(font, Vector2( - w / 2.0, 0), c, HORIZONTAL_ALIGNMENT_LEFT, -1, size, hot if in_word else Color.WHITE)
		x += w
	draw_set_transform(Vector2((get_viewport_rect().size.x - 720.0) / 2.0, Game.design_offset()))

func _fit(font: Font, text: String, wanted: int, slack: = 1.0, width: = TEXT_WIDTH) -> int:
	var w: = font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, wanted).x * slack
	return wanted if w <= width else int(wanted * width / w)
