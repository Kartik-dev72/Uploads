class_name GoalSite
extends Node2D







enum Kind{HERO, ITEM}

const GUARD_AT: = 1500.0
const GUARDS: = 20
const GUARD_RING: = 200.0
const GUARD_SPIN: = 0.3
const GUARD_HP: = 3.0
const CLAIM: = 60.0
const PX_PER_METER: = 25.0
const ALREADY_SOULS: = 300

var kind: = Kind.HERO
var what: = ""
var tier: = 0
var dir_name: = ""
var claimed: = false
var _player: Player
var _guarded: = false
var _t: = 0.0
var _check: = 0.0

func _ready() -> void :
	Layers.put(self, Layers.BODIES)
	add_to_group(OffscreenPointer.GROUP)
	_player = get_tree().get_first_node_in_group("player") as Player




const FACE_SHARE: = 0.55
const FACE_SCALE: = 3.0

static var _faces: = {}

func pointer_texture() -> Texture2D:
	if kind == Kind.ITEM:
		return Game.theme.texture(str(Game.item_info(what).get("icon", "")))
	return face_of(what)



static func face_of(survivor_id: String) -> Texture2D:
	if _faces.has(survivor_id):
		return _faces[survivor_id]
	var full: = Game.theme.texture(str(Game.theme.survivor(survivor_id).get("sprite", "")))
	if full == null:
		return null
	var img: = full.get_image()
	if img.is_compressed():
		img.decompress()
	var used: = img.get_used_rect()
	var tall: = roundi(used.size.y * FACE_SHARE)
	var head: = img.get_region(Rect2i(used.position, Vector2i(used.size.x, tall)))
	var trim: = head.get_used_rect()
	var tex: = ImageTexture.create_from_image(head.get_region(trim))
	var f: = PixelArt.factor_of(full, img)
	if f > 1:
		tex.set_size_override(trim.size / f)
	_faces[survivor_id] = tex
	return tex

func pointer_hidden() -> bool:
	return not Game.goal_arrows

func pointer_scale() -> float:
	return FACE_SCALE if kind == Kind.HERO else 2.0

func pointer_color() -> Color:
	return Game.theme.ui.get("holy", Color(1, 0.93, 0.55)) if kind == Kind.HERO else Game.theme.ui["accent"]

func pointer_label() -> String:
	var m: = 0.0
	if is_instance_valid(_player):
		m = _player.global_position.distance_to(global_position) / PX_PER_METER
	return "%s  %s m" % ["RESCUE" if kind == Kind.HERO else "TREASURE", HUD.format_score(int(m))]

func _process(delta: float) -> void :
	_t += delta
	if claimed or not is_instance_valid(_player):
		return
	var d: = _player.global_position.distance_to(global_position)
	if d < 1400.0:
		queue_redraw()
	_check -= delta
	if _check > 0.0:
		return
	_check = 0.1
	if not _guarded and d < GUARD_AT:
		_guarded = true
		_spawn_guards()
	if d < CLAIM + _player.radius:
		_claim()

func _spawn_guards() -> void :
	var spawner: = get_parent().get_node_or_null("Spawner") as Spawner
	if spawner == null:
		return
	var t: = _player.survived
	for i in GUARDS:
		var row: Dictionary = spawner._pick_row(t * spawner._pace)
		var data: Dictionary = Game.theme.enemies.get(str(row.get("enemy", "")), {})
		if data.is_empty() or data.get("boss", false):
			continue
		var e: = (Spawner.ENEMY.instantiate()) as Enemy
		e.configure(data, spawner.hp_mult(t) * GUARD_HP, 1.0)
		e.kind_id = str(row["enemy"])
		e.behavior = "guard"
		e.guard_center = global_position
		e.guard_radius = GUARD_RING
		e.guard_angle = TAU * i / GUARDS
		e.guard_spin = GUARD_SPIN
		e.global_position = global_position + Vector2.RIGHT.rotated(e.guard_angle) * GUARD_RING
		spawner.add_child(e)

func _claim() -> void :
	claimed = true
	remove_from_group(OffscreenPointer.GROUP)
	var holy: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
	Game.sfx("jackpot")
	_player.shake(10.0)
	RingFx.spawn(get_parent(), global_position, 260.0, holy)
	if kind == Kind.HERO:
		Game.track("goal_hero_%d" % tier)
		var s: = Game.theme.survivor(what)
		if Game.rescue_survivor(what):
			var ui: = get_tree().current_scene.find_child("UI", true, false)
			if ui:
				RescueReveal.play(ui, s)
			else:
				Game.announce("SOUL RESCUED", "%s the %s is free" % [s.get("name", what), s.get("title", "")], 
					"Pick them in the Survivors tab", holy, str(s.get("sprite", "")))
		else:
			_player.add_coins(ALREADY_SOULS, global_position, true)
			Game.toast("%s THANKS YOU" % str(s.get("name", what)).to_upper(), "Already free: +%d %s" % [ALREADY_SOULS, Game.theme.currency], holy)
	else:
		Game.track("goal_item_%d" % tier)
		_give_item()
		var info: = Game.item_info(what)
		Game.toast("TREASURE FOUND", "%s: yours now, and in every run" % info.get("name", what), Game.theme.ui["accent"], str(info.get("icon", "")))
		Game.track("found_" + what)
	queue_free()



func _give_item() -> void :
	if Game.WEAPONS.has(what):
		for c in _player.get_children():
			if c is Weapon and str(Weapon.info(c.get_script(), "ID")) == what:
				if not (c as Weapon).is_maxed():
					(c as Weapon).level_up()
				return
		_player.add_child((Game.WEAPONS[what] as Script).new())
	elif Game.PASSIVES.has(what):
		if int(_player.passives.get(what, 0)) < int(Game.PASSIVES[what]["max"]):
			_player.add_passive(what)

func _draw() -> void :
	var holy: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
	var glow: = 0.5 + 0.5 * sin(_t * 2.0)

	draw_rect(Rect2(-34, -420, 68, 420), Color(holy, 0.07 + 0.04 * glow))
	draw_rect(Rect2(-12, -420, 24, 420), Color(1, 1, 1, 0.06 + 0.04 * glow))
	draw_set_transform(Vector2(0, 6), 0.0, Vector2(1, 0.4))
	draw_circle(Vector2.ZERO, 90.0, Color(0, 0, 0, 0.3))
	draw_arc(Vector2.ZERO, 92.0, 0, TAU, 48, Color(holy, 0.35 + 0.2 * glow), 4.0)
	draw_set_transform(Vector2.ZERO)
	if kind == Kind.HERO:
		_draw_stake()
	else:
		_draw_altar()


func _draw_stake() -> void :
	var wood: = Color(0.36, 0.22, 0.12)
	var dark: = Color(0.16, 0.09, 0.05)
	for i in 7:
		var a: = - PI * 0.5 + (i - 3) * 0.32
		var from: = Vector2(cos(a + PI * 0.5) * 70.0 * ((i - 3) / 3.0), 0)
		var to: = from + Vector2( - from.x * 0.6, -34.0)
		draw_line(from + Vector2(0, 2), to + Vector2(0, 2), dark, 14.0)
		draw_line(from, to, wood.lightened(0.08 * (i % 3)), 10.0)
	draw_rect(Rect2(-7, -190, 14, 196), dark)
	draw_rect(Rect2(-5, -190, 6, 196), wood)
	var s: = Game.theme.survivor(what)
	var tex: = Game.theme.texture(str(s.get("sprite", "")))
	if tex:
		var size: = tex.get_size() * 3.0
		var at: = Vector2( - size.x * 0.5, -44.0 - size.y)
		var sway: = sin(_t * 1.6) * 0.03
		draw_set_transform(Vector2(0, -44), sway, Vector2.ONE)
		draw_texture_rect(tex, Rect2(at - Vector2(0, -44), size), false)
		draw_set_transform(Vector2.ZERO)
		var rope: = Color(0.72, 0.6, 0.38)
		for k in 3:
			var y: = -44.0 - size.y * (0.3 + 0.22 * k)
			draw_line(Vector2( - size.x * 0.32, y), Vector2(size.x * 0.32, y + 4.0), Color(0.1, 0.07, 0.04), 5.0)
			draw_line(Vector2( - size.x * 0.32, y - 1.0), Vector2(size.x * 0.32, y + 3.0), rope, 3.0)


func _draw_altar() -> void :
	var stone: = Color(0.42, 0.4, 0.44)
	var dark: = Color(0.16, 0.15, 0.18)
	draw_rect(Rect2(-46, -50, 92, 52), dark)
	draw_rect(Rect2(-42, -48, 84, 46), stone)
	draw_rect(Rect2(-56, -62, 112, 16), dark)
	draw_rect(Rect2(-52, -60, 104, 10), stone.lightened(0.15))
	var info: = Game.item_info(what)
	var tex: = Game.theme.texture(str(info.get("icon", "")))
	if tex:
		var bob: = sin(_t * 2.2) * 8.0
		var c: = Vector2(0, -120 + bob)
		draw_circle(c, 46.0, Color(Game.theme.ui["accent"], 0.18))
		draw_circle(c, 30.0, Color(1, 1, 1, 0.12))
		var size: = tex.get_size() * 3.5
		draw_set_transform(c, 0.0, Vector2(cos(_t * 1.5), 1.0))
		draw_texture_rect(tex, Rect2( - size * 0.5, size), false)
		draw_set_transform(Vector2.ZERO)
