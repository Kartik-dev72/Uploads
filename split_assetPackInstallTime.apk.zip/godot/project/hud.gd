class_name HUD
extends Control






const SLOT_SIZE: = 52.0
const ROW_WIDTH: = 284.0
const ROW_GAP: = 6.0
const ICON_MARGIN: = 6.0
const SCORE_TOP: = 140.0
const SCORE_FONT: = 56
const MINUTE_FONT: = 24


const TEXT_BOTTOM: = SCORE_TOP + SCORE_FONT + 10 + MINUTE_FONT + 10
const SCORE_COUNT_SPEED: = 14.0
const SOUL_FLIGHT: = 0.55
const MAX_FLYING_SOULS: = 30



@onready var xp_bar: ProgressBar = $XPBar
@onready var level_label: Label = $LevelLabel
@onready var time_label: Label = $TimeLabel
@onready var coin_icon: TextureRect = $CoinRow / CoinIcon
@onready var coin_label: Label = $CoinRow / CoinLabel
@onready var weapon_slots: HBoxContainer = $WeaponSlots
@onready var passive_slots: HBoxContainer = $PassiveSlots

var _player: Player
var _weapon_icons: Array[TextureRect] = []
var _passive_icons: Array[TextureRect] = []
var _slots_shown: Array = []
var _score_label: Label
var _score_shown: = 0.0
var _score_pop: Tween
var _score_flash: = 0.0
var _next_milestone: = 10000
var _coins_in_flight: = 0
var _flying_souls: = 0
var _coin_pop: Tween

func _ready() -> void :
	_player = get_tree().get_first_node_in_group("player") as Player
	offset_top += Game.safe_top()
	var t: = Game.theme
	coin_icon.texture = t.texture(t.pickups["coin"])
	(xp_bar.get_theme_stylebox("fill") as StyleBoxFlat).bg_color = t.ui["xp"]


	_weapon_icons = _build_slots(weapon_slots, Game.MAX_WEAPONS + Game.TROPHY_SLOTS + FOUND_SLOTS, t.ui["accent"])
	_passive_icons = _build_slots(passive_slots, Game.MAX_PASSIVES + Game.TROPHY_SLOTS + FOUND_SLOTS, t.ui["xp"])
	_fit_row(_weapon_icons, Game.MAX_WEAPONS, Game.MAX_WEAPONS)
	_fit_row(_passive_icons, Game.MAX_PASSIVES, Game.MAX_PASSIVES)
	_build_score()
	if _player:
		_score_shown = _player.score
		_score_label.text = format_score(_player.score)
		_next_milestone = (_player.score / 10000 + 1) * 10000
		_player.scored.connect(_on_scored)
		_player.minute_survived.connect(_on_minute)
		_player.coins_gained.connect(_on_coins_gained)
		_player.leveled_up.connect(_on_level_up)

var _pending_bump: = 0.0

func _process(delta: float) -> void :
	if not is_instance_valid(_player):
		return
	if _pending_bump > 0.0:
		_bump_score(_pending_bump)
		_pending_bump = 0.0
	xp_bar.max_value = _player.xp_to_next
	xp_bar.value = _player.xp
	level_label.text = "Lv %d" % _player.level
	var secs: = int(_player.survived)
	time_label.text = "%02d:%02d" % [secs / 60, secs % 60]
	coin_label.text = str(_player.coins - _coins_in_flight)
	_score_shown = minf(_score_shown + maxf(1.0, (_player.score - _score_shown) * SCORE_COUNT_SPEED * delta), _player.score)
	_score_label.text = format_score(int(_score_shown))
	_update_flash(delta)
	_update_slots()

func _update_slots() -> void :
	var weapons: Array[Node] = _player.get_children().filter( func(c: Node) -> bool: return c is Weapon)
	var states: Array = []
	for w: Weapon in weapons:
		states.append([w.get_script(), _weapon_state(w)])
	for id: String in _player.passives:
		states.append([id, "maxed" if _player.passives[id] >= Game.PASSIVES[id]["max"] else ""])
	if states == _slots_shown:
		return
	_slots_shown = states
	for i in _weapon_icons.size():
		var w: Weapon = weapons[i] if i < weapons.size() else null
		_set_icon(_weapon_icons[i], w.icon() if w else "")
		_style_slot(_weapon_icons[i], _weapon_state(w) if w else "", Game.theme.ui["accent"])
	_fit_row(_weapon_icons, weapons.size(), Game.MAX_WEAPONS)
	_fit_row(_passive_icons, _player.passives.size(), Game.MAX_PASSIVES)
	var passive_ids: Array = _player.passives.keys()
	for i in _passive_icons.size():
		var id: String = passive_ids[i] if i < passive_ids.size() else ""
		_set_icon(_passive_icons[i], Game.theme.passive(id).get("icon", "") if id != "" else "")
		var maxed: bool = id != "" and _player.passives[id] >= Game.PASSIVES[id]["max"]
		_style_slot(_passive_icons[i], "maxed" if maxed else "", Game.theme.ui["xp"])


func _weapon_state(w: Weapon) -> String:
	if w.holy:
		return "holy"
	return "maxed" if w.is_maxed() else ""



func _style_slot(icon: TextureRect, state: String, row_color: Color) -> void :
	var style: = (icon.get_parent() as Panel).get_theme_stylebox("panel") as StyleBoxFlat
	var holy_color: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
	match state:
		"holy":
			style.border_color = Color.WHITE
			style.bg_color = Color(holy_color.darkened(0.5), 0.85)
		"maxed":
			style.border_color = Color(1, 0.5, 0.12)
			style.bg_color = Color(0.5, 0.16, 0.03, 0.6)
		_:
			style.border_color = Color(row_color, 0.7)
			style.bg_color = Color(0, 0, 0, 0.35)
	style.set_border_width_all(2 if state == "" else 3)



static func text_bottom() -> float:
	return Game.safe_top() + TEXT_BOTTOM

static func format_score(n: int) -> String:
	var digits: = str(absi(n))
	var out: = ""
	for i in digits.length():
		if i > 0 and (digits.length() - i) % 3 == 0:
			out += ","
		out += digits[i]
	return ("-" if n < 0 else "") + out

func _build_score() -> void :
	_score_label = Label.new()
	_score_label.text = "0"
	_score_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_score_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_score_label.position = Vector2(-200, SCORE_TOP)
	_score_label.size = Vector2(400, SCORE_FONT + 12)
	_score_label.pivot_offset = _score_label.size / 2.0
	_score_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_score_label.add_theme_font_size_override("font_size", SCORE_FONT)
	_score_label.add_theme_color_override("font_color", Game.theme.ui["accent"])
	_score_label.add_theme_color_override("font_outline_color", Color.BLACK)
	_score_label.add_theme_constant_override("outline_size", 12)
	add_child(_score_label)




func _on_scored(points: int) -> void :
	if points < Game.SCORE["kill"]:
		return
	var bump: = clampf(1.18 + points / 2000.0, 1.18, 1.65)
	_score_flash = maxf(_score_flash, clampf(0.35 + points / 800.0, 0.35, 0.8))
	if _player.score >= _next_milestone:
		_next_milestone = (_player.score / 10000 + 1) * 10000
		bump = 1.85
		_score_flash = 1.0
		_popup_milestone()
	_pending_bump = maxf(_pending_bump, bump)

func _bump_score(bump: float) -> void :
	if _score_pop:
		_score_pop.kill()

	_score_label.scale = Vector2(bump * 0.92, bump * 1.1)
	_score_label.rotation = randf_range(-0.07, 0.07) * minf(bump - 1.0, 0.6) / 0.3
	_score_pop = create_tween().set_parallel()
	_score_pop.tween_property(_score_label, "scale", Vector2.ONE, 0.35).set_trans(Tween.TRANS_ELASTIC).set_ease(Tween.EASE_OUT)
	_score_pop.tween_property(_score_label, "rotation", 0.0, 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _on_coins_gained(amount: int, at: Vector2, bag: bool) -> void :
	if at == Vector2.INF:
		_bump_coins()
		return
	if bag:
		_coins_in_flight += amount
		SoulBurst.spawn(get_tree().current_scene, at, amount, self)
		return
	if _flying_souls >= MAX_FLYING_SOULS:
		_bump_coins()
		return
	_fly_soul(amount, at)



func soul_arrived(share: int, at: Vector2, left: int) -> void :
	if at == Vector2.INF:
		_coins_in_flight -= share
		_bump_coins()
		return
	_fly_soul(share, at, 1.0, true, SOUL_FLIGHT * clampf(1.0 - left / 50.0, 0.55, 1.0))



func _fly_soul(amount: int, at: Vector2, bump: = 1.0, held: = false, flight: = SOUL_FLIGHT) -> void :
	var from: = get_viewport().get_canvas_transform() * at
	var soul: = TextureRect.new()
	soul.texture = coin_icon.texture
	soul.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	soul.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	soul.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	soul.size = coin_icon.size * 1.3
	soul.pivot_offset = soul.size / 2.0
	soul.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(soul)
	if not held:
		_coins_in_flight += amount
	_flying_souls += 1

	var side: = signf(randf() - 0.5)
	var bend: = Vector2(side * randf_range(60.0, 140.0), - randf_range(60.0, 140.0))
	var tw: = create_tween().set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	tw.tween_method(_move_soul.bind(soul, from, bend, side), 0.0, 1.0, flight).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
	tw.tween_callback( func() -> void :
		_coins_in_flight -= amount
		_flying_souls -= 1
		soul.queue_free()
		_bump_coins(bump))

func _move_soul(t: float, soul: TextureRect, from: Vector2, bend: Vector2, side: float) -> void :
	var to: = coin_icon.global_position + coin_icon.size / 2.0
	var mid: = from.lerp(to, 0.45) + bend
	var p: = from.lerp(mid, t).lerp(mid.lerp(to, t), t)
	soul.position = p - soul.pivot_offset
	soul.scale = Vector2.ONE * (1.25 - 0.55 * t)
	soul.rotation = sin(t * PI) * side * 0.5

func _bump_coins(strength: = 1.0) -> void :
	if _coin_pop:
		_coin_pop.kill()
	for c: Control in [coin_icon, coin_label]:
		c.pivot_offset = c.size / 2.0
		c.scale = Vector2.ONE * (1.0 + 0.4 * strength)
	coin_label.modulate = Color(1, 1, 0.6)
	_coin_pop = create_tween().set_parallel()
	for c: Control in [coin_icon, coin_label]:
		_coin_pop.tween_property(c, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_coin_pop.tween_property(coin_label, "modulate", Color.WHITE, 0.3)

func _popup_milestone() -> void :
	_popup_note("PASSED %s!" % format_score(_next_milestone - 10000), SCORE_TOP - 44, 30)


func _on_minute(minutes: int, points: int) -> void :
	_popup_note("%d MIN SURVIVED  +%s" % [minutes, format_score(points)], SCORE_TOP + SCORE_FONT + 10, MINUTE_FONT)


func _popup_note(text: String, y: float, font_size: int) -> void :
	var l: = Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", Color.WHITE)
	l.add_theme_color_override("font_outline_color", Game.theme.ui["accent"].darkened(0.4))
	l.add_theme_constant_override("outline_size", 10)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.set_anchors_preset(Control.PRESET_CENTER_TOP)
	l.position = Vector2(-200, y)
	l.size = Vector2(400, font_size + 10)
	l.pivot_offset = Vector2(200, (font_size + 10) / 2.0)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.scale = Vector2.ONE * 1.8
	add_child(l)
	var tw: = create_tween().set_parallel()
	tw.tween_property(l, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(l, "modulate:a", 0.0, 0.6).set_delay(0.9)
	tw.tween_property(l, "position:y", l.position.y - 20.0, 1.5)
	tw.chain().tween_callback(l.queue_free)

func _on_level_up(lvl: int) -> void :
	level_label.text = "Lv %d" % lvl
	level_label.pivot_offset = Vector2(0, level_label.size.y / 2.0)
	level_label.scale = Vector2.ONE * 1.7
	level_label.modulate = Color(1, 1, 0.5)

	var tw: = create_tween().set_parallel().set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	tw.tween_property(level_label, "scale", Vector2.ONE, 0.4).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(level_label, "modulate", Color.WHITE, 0.6)


func _update_flash(delta: float) -> void :
	_score_flash = maxf(_score_flash - delta * 2.5, 0.0)
	_score_label.add_theme_color_override("font_color", Game.theme.ui["accent"].lerp(Color.WHITE, _score_flash))



const FOUND_SLOTS: = 2
func _fit_row(icons: Array[TextureRect], held: int, base: int) -> void :
	var shown: = clampi(held, base, icons.size())
	var size: = minf(SLOT_SIZE, floorf((ROW_WIDTH - ROW_GAP * (shown - 1)) / shown))
	for i in icons.size():
		var slot: = icons[i].get_parent() as Panel
		slot.visible = i < shown
		slot.custom_minimum_size = Vector2(size, size)

func _set_icon(rect: TextureRect, sprite: String) -> void :
	rect.texture = Game.theme.texture(sprite) if sprite != "" else null


func _build_slots(box: HBoxContainer, count: int, color: Color) -> Array[TextureRect]:
	var icons: Array[TextureRect] = []
	for i in count:
		var slot: = Panel.new()
		slot.custom_minimum_size = Vector2(SLOT_SIZE, SLOT_SIZE)
		slot.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var style: = StyleBoxFlat.new()
		style.bg_color = Color(0, 0, 0, 0.35)
		style.border_color = Color(color, 0.7)
		style.set_border_width_all(2)
		style.set_corner_radius_all(6)
		slot.add_theme_stylebox_override("panel", style)
		var icon: = TextureRect.new()
		icon.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT, Control.PRESET_MODE_MINSIZE, int(ICON_MARGIN))
		icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
		slot.add_child(icon)
		box.add_child(slot)
		icons.append(icon)
	return icons
