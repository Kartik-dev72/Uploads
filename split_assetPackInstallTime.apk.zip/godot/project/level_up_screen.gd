class_name LevelUpScreen
extends Control













const CHOICES: = 3
const CARD_HEIGHT: = 172
const CARD_HEIGHT_FOUR: = 146
const INPUT_DELAY: = 0.4
const ICON_SIZE: = 96
const PARTNER_ICON: = 46
const AD_REROLLS: = 3
const MAXED_COINS: = 3
const HOLD_TIME: = 0.7
const WARM_FRAMES: = 3

@onready var _options: VBoxContainer = $VBox / Options

var _player: Player
var _pending: = 0
var _reroll: Button
var _exile: Button
var _skip: Button
var _exile_mode: = false
var _ad_rerolls_used: = 0
var _ad_busy: = false
var _shown: Array[String] = []
var _maxed_mode: = false
var _hold_card: Button
var _hold_kind: = ""
var _hold_t: = 0.0
var _hold_bar: ColorRect

func _ready() -> void :
	hide()
	add_to_group("pause_screen")
	$VBox / Title.add_theme_color_override("font_color", Game.theme.ui["accent"])
	_player = get_tree().get_first_node_in_group("player") as Player
	_player.leveled_up.connect(_on_leveled_up)
	_reroll = Button.new()
	_reroll.custom_minimum_size = Vector2(0, 90)
	_reroll.add_theme_font_size_override("font_size", 30)
	for state: String in ["normal", "hover", "pressed", "disabled", "focus"]:
		var style: = _card_style(state, false)
		style.border_color = Color.WHITE if state != "disabled" else Color(1, 1, 1, 0.25)
		_reroll.add_theme_stylebox_override(state, style)
	_reroll.pressed.connect(_on_reroll)
	_reroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_exile = Button.new()
	_exile.custom_minimum_size = Vector2(0, 90)
	_exile.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_exile.add_theme_font_size_override("font_size", 30)
	for state: String in ["normal", "hover", "pressed", "disabled", "focus"]:
		var style: = _card_style(state, false)
		style.border_color = Color(1, 0.4, 0.35) if state != "disabled" else Color(1, 1, 1, 0.25)
		_exile.add_theme_stylebox_override(state, style)
	_exile.pressed.connect(_on_exile)
	_skip = Button.new()
	_skip.custom_minimum_size = Vector2(0, 90)
	_skip.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_skip.add_theme_font_size_override("font_size", 30)
	for state: String in ["normal", "hover", "pressed", "disabled", "focus"]:
		var style: = _card_style(state, false)
		style.border_color = Color(1, 1, 1, 0.55) if state != "disabled" else Color(1, 1, 1, 0.25)
		_skip.add_theme_stylebox_override(state, style)
	_skip.pressed.connect(_on_skip)
	var buttons: = HBoxContainer.new()
	buttons.add_theme_constant_override("separation", 16)
	buttons.add_child(_reroll)
	buttons.add_child(_skip)
	buttons.add_child(_exile)
	$VBox.add_child(buttons)
	_warm_up.call_deferred()





func _warm_up() -> void :
	for script: Script in Game.WEAPONS.values():
		Game.theme.texture(str(Weapon.theme_info(script).get("icon", "")))
	for id: String in Game.PASSIVES:
		Game.theme.texture(str(Game.theme.passive(id).get("icon", "")))
	var ghost: = Control.new()
	ghost.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.modulate.a = 0.004
	var title: = $VBox / Title.duplicate() as Label
	title.text = "LEVEL UP! EXILE WHICH? 0123456789"
	ghost.add_child(title)
	var box: = VBoxContainer.new()
	box.position = Vector2(60, 300)
	box.size = Vector2(600, 600)
	ghost.add_child(box)
	for choice in _roll_choices():
		var card: = describe(choice)
		card["text"] += " abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 %+-→()."
		box.add_child(_make_card(card))
	get_parent().add_child(ghost)
	for i in WARM_FRAMES:
		await get_tree().process_frame
	ghost.queue_free()

func _on_leveled_up(_new_level: int) -> void :
	_pending += 1
	if not visible:
		_show_choices()

func _on_reroll() -> void :
	if _player.rerolls > 0:
		_player.rerolls -= 1
		Game.sfx("reroll")
		_show_choices(true)
	elif _can_ad_reroll() and not _ad_busy:
		_ad_busy = true
		_reroll.disabled = true
		Ads.show_rewarded( func(earned: bool) -> void :
			_ad_busy = false
			if earned and visible:
				_ad_rerolls_used += 1
				Game.sfx("reroll")
				_show_choices(true)
			else:
				_reroll.disabled = false)


func _can_ad_reroll() -> bool:
	return _ad_rerolls_used < AD_REROLLS and Ads.can_show() and not Game.dev_mode

func _reroll_text() -> String:
	if _player.rerolls > 0 or not _can_ad_reroll():
		return "Reroll  (%d)" % _player.rerolls
	return "Reroll  (video)"




const SKIP_XP: = 0.2

func _on_skip() -> void :
	if _player.skips <= 0 or _maxed_mode:
		return
	_player.skips -= 1
	_player.xp += maxf(_player.xp_to_next - _player.xp, 0.0) * SKIP_XP
	Game.sfx("click")
	_pending -= 1
	if _pending > 0:
		_show_choices()
	else:
		_close()

func _on_exile() -> void :
	if _player.exiles <= 0:
		return
	_exile_mode = not _exile_mode
	Game.sfx("click")
	_update_buttons()

func _update_buttons() -> void :
	if _maxed_mode:
		return
	$VBox / Title.text = "EXILE WHICH?" if _exile_mode else "LEVEL UP!"
	_exile.visible = Game.upgrade_level("exile") > 0
	_skip.visible = not _exile_mode
	_skip.text = "Skip  (%d)" % _player.skips
	_exile.text = "Cancel" if _exile_mode else "Exile  (%d)" % _player.exiles


func _key(choice: Dictionary) -> String:
	return choice["passive"] if choice.has("passive") else str(Weapon.info(choice["weapon"], "ID"))


func _show_choices(reroll: = false) -> void :
	var avoid: Array[String] = []
	if reroll:
		avoid = _shown.duplicate()
	var choices: = _roll_choices(avoid)
	_shown.assign(choices.map(_key))
	if choices.is_empty():

		if _player.maxed_auto != "":
			_take_maxed(_player.maxed_auto, _pending)
			_close()
		else:
			_show_maxed()
		return
	_maxed_mode = false
	_reroll.visible = true
	_exile_mode = false
	for child in _options.get_children():
		child.queue_free()
	var buttons: Array[Button] = []
	for choice in choices:
		var button: = _make_card(describe(choice), CARD_HEIGHT if choices.size() <= CHOICES else CARD_HEIGHT_FOUR)
		button.pressed.connect(_pick.bind(choice))
		_options.add_child(button)
		buttons.append(button)
	_reroll.text = _reroll_text()
	_reroll.disabled = true
	_exile.disabled = true
	_skip.disabled = true
	_update_buttons()
	if not visible:
		Game.sfx("level_up")
	show()
	get_tree().paused = true
	await get_tree().create_timer(INPUT_DELAY).timeout
	for button in buttons:
		if is_instance_valid(button):
			button.disabled = false
	_reroll.disabled = _player.rerolls <= 0 and not _can_ad_reroll()
	_exile.disabled = _player.exiles <= 0 and not _exile_mode
	_skip.disabled = _player.skips <= 0


func _show_maxed() -> void :
	_maxed_mode = true
	_exile_mode = false
	_hold_card = null
	for child in _options.get_children():
		child.queue_free()
	var cur: = Game.theme.currency
	var cards: = [
		["souls", {"name": "+%d %s" % [MAXED_COINS, cur], "icon": Game.theme.pickups.get("coin", "coin"), 
			"text": "Tap to take. Hold to always take %s" % cur}], 
		["heal", {"name": "Heal %d HP" % roundi(_player.heal_drop()), "icon": Game.theme.pickups.get("heart", "heart"), 
			"text": "Tap to take. Hold to always heal"}], 
	]
	var buttons: Array[Button] = []
	for entry: Array in cards:
		var card: Dictionary = entry[1]
		card.merge({"tag": "MAXED", "new": false, "passive": entry[0] == "heal"})
		var button: = _make_card(card)
		var kind: String = entry[0]
		button.pressed.connect(_pick_maxed.bind(kind))
		button.button_down.connect(_start_hold.bind(button, kind))
		button.button_up.connect(_end_hold)
		_options.add_child(button)
		buttons.append(button)
	$VBox / Title.text = "ALL MAXED OUT"
	_reroll.visible = false
	_exile.visible = false
	_skip.visible = false
	if not visible:
		Game.sfx("level_up")
	show()
	get_tree().paused = true
	await get_tree().create_timer(INPUT_DELAY).timeout
	for button in buttons:
		if is_instance_valid(button):
			button.disabled = false

func _start_hold(button: Button, kind: String) -> void :
	_hold_card = button
	_hold_kind = kind
	_hold_t = 0.0
	if not is_instance_valid(_hold_bar):
		_hold_bar = ColorRect.new()
		_hold_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if _hold_bar.get_parent():
		_hold_bar.get_parent().remove_child(_hold_bar)
	_hold_bar.color = Color(Game.theme.ui["xp"] if kind == "heal" else Game.theme.ui["accent"], 0.35)
	_hold_bar.position = Vector2.ZERO
	_hold_bar.size = Vector2(0, button.size.y)
	button.add_child(_hold_bar)
	button.move_child(_hold_bar, 0)


func _process(delta: float) -> void :
	if _hold_card == null:
		return
	if not is_instance_valid(_hold_card) or not visible:
		_end_hold()
		return
	_hold_t += delta
	_hold_bar.size = Vector2(_hold_card.size.x * minf(_hold_t / HOLD_TIME, 1.0), _hold_card.size.y)
	if _hold_t < HOLD_TIME:
		return
	_hold_card = null
	_player.maxed_auto = _hold_kind
	Game.toast("ALWAYS " + ("HEAL" if _hold_kind == "heal" else Game.theme.currency.to_upper()), 
		"Maxed level-ups now pick this on their own", Color(1, 0.85, 0.3))
	_take_maxed(_hold_kind, _pending)
	_close()


func _end_hold() -> void :
	_hold_card = null
	if is_instance_valid(_hold_bar):
		_hold_bar.size.x = 0.0


func _pick_maxed(kind: String) -> void :
	if not visible or not _maxed_mode:
		return
	_hold_card = null
	_take_maxed(kind, 1)
	_pending -= 1
	if _pending > 0:
		_show_choices()
	else:
		_close()

func _take_maxed(kind: String, times: int) -> void :
	for i in times:
		if kind == "heal":
			_player.heal(_player.heal_drop())
		else:
			_player.add_coins(MAXED_COINS)
	Game.sfx("heal" if kind == "heal" else "coin")

func _close() -> void :
	_pending = 0
	_maxed_mode = false
	hide()
	resume_if_clear(get_tree())


func _make_card(card: Dictionary, height: = CARD_HEIGHT) -> Button:
	var button: = Button.new()
	button.alignment = HORIZONTAL_ALIGNMENT_LEFT
	button.custom_minimum_size = Vector2(0, height)
	_add_card_content(button, card)
	button.disabled = true
	for state: String in ["normal", "hover", "pressed", "disabled", "focus"]:
		button.add_theme_stylebox_override(state, _card_style(state, card["passive"]))
	return button


func describe(choice: Dictionary) -> Dictionary:
	if choice.has("passive"):
		var id: String = choice["passive"]
		var info: = Game.theme.passive(id)
		var next: int = _player.passives.get(id, 0) + 1
		var tag: = "NEW" if next == 1 else "Lv %d" % next
		return {"title": "%s  (%s)" % [info.get("name", id), tag], "name": info.get("name", id), "tag": tag, 
			"new": next == 1, "text": Game.passive_text(id, next), "icon": info.get("icon", ""), "passive": true, 
			"level": next, "top": int(Game.PASSIVES[id]["max"]), "partner_icon": _partner_hint(choice) if next == 1 else ""}
	var weapon_script: Script = choice["weapon"]
	var info: = Weapon.theme_info(weapon_script)
	var owned: = owned_weapon(weapon_script)
	if owned == null:
		return {"title": "%s  (NEW)" % info.get("name", "?"), "name": info.get("name", "?"), "tag": "NEW", 
			"new": true, "text": info.get("description", ""), "icon": info.get("icon", ""), "passive": false, 
			"level": 1, "top": Weapon.max_level(weapon_script), "partner_icon": _partner_hint(choice)}
	var next: = owned.level + 1
	return {"title": "%s  Lv %d" % [info.get("name", "?"), next], "name": info.get("name", "?"), "tag": "Lv %d" % next, 
		"new": false, "text": Weapon.upgrade_text(weapon_script, next), "icon": info.get("icon", ""), "passive": false, 
		"level": next, "top": Weapon.max_level(weapon_script), "partner_icon": ""}






func _partner_hint(choice: Dictionary) -> String:
	var stats: Dictionary = Game.progress.stats
	if choice.has("weapon"):
		var wid: = str(Weapon.info(choice["weapon"], "ID"))
		var pid: = Weapon.partner_of(choice["weapon"])
		var owned: = owned_weapon(choice["weapon"])
		if pid != "" and _player.passives.has(pid) and int(stats.get("holy_" + wid, 0)) > 0 and not (owned and owned.holy):
			return str(Game.theme.passive(pid).get("icon", ""))
		return ""
	var id: String = choice["passive"]
	for c in _player.get_children():
		if not (c is Weapon) or (c as Weapon).holy or Weapon.partner_of(c.get_script()) != id:
			continue
		if int(stats.get("holy_" + str(Weapon.info(c.get_script(), "ID")), 0)) > 0:
			return str(Weapon.theme_info(c.get_script()).get("icon", ""))
	return ""

func _pick(choice: Dictionary) -> void :
	if _exile_mode:
		_player.exiled.append(_key(choice))
		_player.exiles -= 1
		Game.sfx("purge", 1.3)
		_show_choices()
		return
	Game.sfx("select")
	apply(choice)
	_pending -= 1
	if _pending > 0:
		_show_choices()
	else:
		hide()
		resume_if_clear(get_tree())


func apply(choice: Dictionary) -> void :
	if choice.has("passive"):
		_player.add_passive(choice["passive"])
	else:
		var weapon_script: Script = choice["weapon"]
		var owned: = owned_weapon(weapon_script)
		if owned:
			owned.level_up()
		else:
			_player.add_child(weapon_script.new())





static func resume_if_clear(tree: SceneTree, grace: = true, from_pause: = false) -> void :
	var blocked: = tree.get_nodes_in_group("pause_screen").any( func(n: CanvasItem) -> bool: return n.visible)
	if blocked or not tree.paused:
		tree.paused = blocked
		return
	var player: = tree.get_first_node_in_group("player") as Player
	tree.paused = false
	if grace and player and not player.is_dead():
		player.begin_grace(from_pause)



func _roll_choices(avoid: Array[String] = []) -> Array[Dictionary]:
	var owned_weapons: = _player.get_children().filter( func(c: Node) -> bool: return c is Weapon).size()
	var candidates: Array[Dictionary] = []
	for weapon_script: Script in Game.WEAPONS.values():
		var wid: = str(Weapon.info(weapon_script, "ID"))
		var owned: = owned_weapon(weapon_script)
		if _player.exiled.has(wid) or (owned == null and not Game.is_item_in_run(wid)):
			continue
		if owned:
			if owned.level < Weapon.max_level(weapon_script):
				candidates.append({"weapon": weapon_script})
		elif owned_weapons < Game.MAX_WEAPONS:
			candidates.append({"weapon": weapon_script})
	for id: String in Game.PASSIVES:

		if _player.exiled.has(id) or ( not _player.passives.has(id) and not Game.is_item_in_run(id)):
			continue
		var lvl: int = _player.passives.get(id, 0)
		if lvl > 0:
			if lvl < Game.PASSIVES[id]["max"]:
				candidates.append({"passive": id})
		elif _player.passives.size() < Game.MAX_PASSIVES:
			candidates.append({"passive": id})






	var fresh: = candidates.filter( func(c: Dictionary) -> bool: return not avoid.has(_key(c)))
	var picked: Array[Dictionary] = []
	var count: = card_count()
	var left: = func() -> Array:
		var pool: = fresh.filter( func(c: Dictionary) -> bool: return not picked.has(c))
		return pool if not pool.is_empty() else candidates.filter( func(c: Dictionary) -> bool: return not picked.has(c))
	for i in EXISTING_ROLLS:
		if picked.size() >= count:
			break
		var owned: = _roll_existing(left.call())
		if not owned.is_empty():
			picked.append(owned)
	while picked.size() < count:
		var pool: Array = left.call()
		if pool.is_empty():
			break
		if _player.level <= EARLY_WEAPONS and owned_weapons < Game.MAX_WEAPONS:
			var weapons: = pool.filter( func(c: Dictionary) -> bool: return c.has("weapon"))
			if not weapons.is_empty():
				pool = weapons
		picked.append(_weighted(pool))
	_ensure_new_item(picked, left.call(), owned_weapons)
	return picked

const NEARLY_FULL: = 2




func _ensure_new_item(picked: Array[Dictionary], rest: Array, owned_weapons: int) -> void :
	var weapons_free: = Game.MAX_WEAPONS - owned_weapons
	var passives_free: = Game.MAX_PASSIVES - _player.passives.size()
	var tight_weapons: = weapons_free > 0 and weapons_free <= NEARLY_FULL
	var tight_passives: = passives_free > 0 and passives_free <= NEARLY_FULL
	if not (tight_weapons or tight_passives) or picked.is_empty():
		return
	var is_new: = func(c: Dictionary) -> bool:
		return (c.has("weapon") and owned_weapon(c["weapon"]) == null) or (c.has("passive") and not _player.passives.has(c["passive"]))
	var fills_tight: = func(c: Dictionary) -> bool:
		return is_new.call(c) and ((c.has("weapon") and tight_weapons) or (c.has("passive") and tight_passives))
	if picked.any(fills_tight):
		return
	var pool: = rest.filter(fills_tight)
	if pool.is_empty():
		if picked.any(is_new):
			return
		pool = rest.filter(is_new)
	if pool.is_empty():
		return
	var at: = picked.size() - 1
	while at > 0 and is_new.call(picked[at]):
		at -= 1
	picked[at] = _weighted(pool)

const EXISTING_ROLLS: = 2
const EXISTING_BASE: = 0.3
const FIRST_ITEM_SHARE: = 0.5
const LEVEL_GATE: = 2.5
const EARLY_WEAPONS: = 3



func existing_chance() -> float:
	var share: = EXISTING_BASE * (2.0 if _player.level % 2 == 0 else 1.0)
	return clampf(1.0 + share - 1.0 / maxf(_player.luck, 0.01), 0.0, 1.0)




func _roll_existing(pool: Array) -> Dictionary:
	if randf() > existing_chance():
		return {}
	var owned: Array[Dictionary] = []
	for c in _player.get_children():
		if c is Weapon:
			var choice: = {"weapon": c.get_script()}
			if pool.has(choice):
				owned.append(choice)
	for id: String in _player.passives:
		var choice: = {"passive": id}
		if pool.has(choice):
			owned.append(choice)
	while not owned.is_empty():
		var c: Dictionary = owned[0] if randf() < FIRST_ITEM_SHARE else owned.pick_random()
		if (_item_level(c) + 1) * LEVEL_GATE <= _player.level:
			return c
		owned.erase(c)
	return {}

func _item_level(choice: Dictionary) -> int:
	if choice.has("passive"):
		return int(_player.passives.get(choice["passive"], 0))
	var w: = owned_weapon(choice["weapon"])
	return w.level if w else 0



const RARITY: = {
	"tear": 80, "duration": 100, 
	"magic_bolt": 100, "throwing_knife": 100, "whip": 100, "battle_axe": 100, "holy_water": 100, "aura": 70, 
	"boomerang": 80, "lightning": 80, "spirit_orbs": 80, "familiar": 80, "shockwave": 60, "sigil": 50, 
	"might": 100, "armor": 100, "area": 100, "magnet": 100, "luck": 100, "max_hp": 90, "regen": 90, 
	"growth": 70, "bounty": 70, "cooldown": 50, "amount": 50, "speed": 50, "curse": 40, "relic": 40, 


	"requiem": 50, "ravens": 50, "nails": 40, "bulwark": 60, 
	"sodom": 80, 
}

const PARTNER_BOOST: = 2.0



func _weighted(pool: Array) -> Dictionary:
	var partners: = _partners()
	var weights: Array[float] = []
	var total: = 0.0
	for c: Dictionary in pool:
		var key: = _key(c)
		var w: = float(RARITY.get(key, 100)) * (PARTNER_BOOST if partners.has(key) else 1.0)
		weights.append(w)
		total += w
	var roll: = randf() * total
	for i in pool.size():
		roll -= weights[i]
		if roll <= 0.0:
			return pool[i]
	return pool[-1]


func _partners() -> Dictionary:
	var out: = {}
	for c in _player.get_children():
		if c is Weapon:
			var p: = Weapon.partner_of(c.get_script())
			if p != "":
				out[p] = true
	for wid: String in Game.EVOLUTIONS:
		if _player.passives.has(Game.EVOLUTIONS[wid]):
			out[wid] = true
	return out


func card_count() -> int:
	return CHOICES + (1 if randf() < 1.0 - 1.0 / maxf(_player.luck, 1.0) else 0)

func owned_weapon(weapon_script: Script) -> Weapon:
	for child in _player.get_children():
		if child.get_script() == weapon_script:
			return child as Weapon
	return null


func _add_card_content(button: Button, card: Dictionary) -> void :
	var margin: = MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for side: String in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 16)
	button.add_child(margin)


	var base_height: = button.custom_minimum_size.y
	margin.minimum_size_changed.connect( func() -> void :
		button.custom_minimum_size.y = maxf(base_height, margin.get_combined_minimum_size().y))
	var row: = HBoxContainer.new()
	row.add_theme_constant_override("separation", 20)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.add_child(row)
	var icon: = TextureRect.new()
	icon.texture = Game.theme.texture(card["icon"])
	icon.custom_minimum_size = Vector2(ICON_SIZE, ICON_SIZE)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var partner: = str(card.get("partner_icon", ""))
	if partner == "":
		row.add_child(icon)
	else:
		row.add_child(_icon_with_partner(icon, partner, button.custom_minimum_size.y))
	var texts: = VBoxContainer.new()
	texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	texts.alignment = BoxContainer.ALIGNMENT_CENTER
	texts.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(texts)

	var title_row: = HBoxContainer.new()
	title_row.add_theme_constant_override("separation", 14)
	title_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	texts.add_child(title_row)
	var title: = Label.new()
	title.text = card["name"]
	title.add_theme_font_size_override("font_size", 30)
	title.add_theme_color_override("font_color", Color.WHITE)
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	title_row.add_child(title)
	var tag: = Label.new()
	tag.text = card["tag"]
	tag.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	tag.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if card["new"]:
		var badge_color: Color = Game.theme.ui.get("warning", Color(1, 0.85, 0.2))
		var badge: = StyleBoxFlat.new()
		badge.bg_color = badge_color
		badge.set_corner_radius_all(8)
		badge.content_margin_left = 10
		badge.content_margin_right = 10
		badge.content_margin_top = 2
		badge.content_margin_bottom = 2
		tag.add_theme_stylebox_override("normal", badge)
		tag.add_theme_font_size_override("font_size", 24)
		tag.add_theme_color_override("font_color", Color(0.1, 0.03, 0.03))
	else:
		tag.add_theme_font_size_override("font_size", 26)
		tag.add_theme_color_override("font_color", Color(1, 1, 1, 0.6))
	title_row.add_child(tag)
	if card.has("top"):
		var accent: Color = Game.theme.ui["xp"] if card["passive"] else Game.theme.ui["accent"]
		var pips: = LevelPips.new().setup(int(card["level"]) - 1, int(card["top"]), accent, false, true, 260.0)
		pips.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
		texts.add_child(pips)
	var desc: = Label.new()
	desc.text = card["text"]
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc.add_theme_font_size_override("font_size", 24)
	desc.add_theme_color_override("font_color", Game.theme.ui["accent"])
	desc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	texts.add_child(desc)


func _icon_with_partner(icon: TextureRect, partner: String, card_height: float) -> Control:
	var small: = PARTNER_ICON
	var main: = minf(ICON_SIZE, card_height - 32.0 - small + 10.0)
	icon.custom_minimum_size = Vector2(main, main)
	var col: = VBoxContainer.new()
	col.add_theme_constant_override("separation", -10)
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	col.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	col.custom_minimum_size.x = ICON_SIZE
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_child(icon)
	var gold: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
	var tex: = Game.theme.texture(partner)
	var badge: = Control.new()
	badge.custom_minimum_size = Vector2(ICON_SIZE, small)
	badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	badge.draw.connect( func() -> void :
		var r: = Rect2(Vector2((badge.size.x - small) / 2.0, 0), Vector2(small, small))
		var beat: = 0.5 + 0.5 * sin(Time.get_ticks_msec() * 0.006)
		badge.draw_rect(r.grow(5), Color(gold, 0.12 + 0.12 * beat))
		badge.draw_rect(r, Color(0.06, 0.04, 0.02, 0.9))
		badge.draw_rect(r, Color(gold, 0.65 + 0.35 * beat), false, 2.0)
		badge.draw_texture_rect(tex, r.grow(-4), false))
	badge.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	var pulse: = Timer.new()
	pulse.wait_time = 0.08
	pulse.process_mode = Node.PROCESS_MODE_ALWAYS
	pulse.timeout.connect(badge.queue_redraw)
	badge.add_child(pulse)
	pulse.autostart = true
	col.add_child(badge)
	return col


func _card_style(state: String, passive: bool) -> StyleBoxFlat:
	var style: = StyleBoxFlat.new()
	var accent: Color = Game.theme.ui["xp"] if passive else Game.theme.ui["accent"]
	var panel: Color = Game.theme.ui["panel"]
	style.bg_color = panel if state != "pressed" else panel.lightened(0.15)
	style.border_color = accent if state != "disabled" else accent.darkened(0.5)
	style.set_border_width_all(3)
	style.set_corner_radius_all(12)
	style.set_content_margin_all(16)
	if state == "focus":
		style.draw_center = false
	return style
