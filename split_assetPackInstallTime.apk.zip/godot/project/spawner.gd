class_name Spawner
extends Node2D











const ENEMY: = preload("res://enemy.tscn")
const WARNING_TIME: = 1.3
const BANNER_TIME: = 3.0
const BANNER_SIZE: = 64
const BANNER_MARGIN: = 40.0
const BANNER_GAP: = 16.0
const SWARM_SPACING: = 40.0
const SWARM_WIDTH: = 340.0



@export var base_rate: = 0.9
@export var rate_per_minute: = 1.25
@export var rate_per_level: = 0.05
@export var min_alive: = 10
@export var min_alive_per_minute: = 18.0
@export var intro_swarm_at: = 30.0
@export var intro_swarm_size: = 0.6




@export var hp_growth: = 0.4
@export var hp_growth_sq: = 0.12
@export var hp_per_level: = 0.025
@export var speed_growth: = 0.02



const CURVE_LENGTH: = 600.0
@export var boss_spawn_scale: = 0.35
@export var spawn_distance: = 800.0
@export var max_enemies: = 260
@export var elite_start: = 120.0
@export var elite_chance_start: = 0.008
@export var elite_chance_end: = 0.03
@export var max_elites: = 4

const DESIGN_LENGTH: = 900.0

var _timer: = 0.0
var _player: Player
var _swarm_timers: = {}
var _intro_done: = false
var _warnings: Array[Dictionary] = []
var _next_boss: = -1.0
var _boss_round: = 0
var _arena: BossArena
var _banner: = ""
var _banner_sub: = ""
var _banner_time: = 0.0
var _overlay: Node2D

var auto_spawn: = true
var director: EventDirector
var _pace: = 1.0
var _tier: = {}

func _ready() -> void :
	_player = get_tree().get_first_node_in_group("player") as Player
	_pace = DESIGN_LENGTH / maxf(Game.theme.win_time, 60.0)
	_tier = Game.tier_info(Game.run_tier)
	_next_boss = _boss_due(0)
	_overlay = Node2D.new()
	Layers.put(_overlay, Layers.BANNERS)
	_overlay.draw.connect(_draw_overlay)
	add_child(_overlay)
	if Game.dev_mode:
		auto_spawn = false
		_next_boss = INF
	else:
		director = EventDirector.new()
		director.setup(self)
		get_parent().add_child.call_deferred(director)

func _process(delta: float) -> void :
	if not is_instance_valid(_player):
		return
	var t: = _player.survived
	var pt: = t * _pace
	var fighting_boss: = fighting()
	var rate: = base_rate + rate_per_minute * pt / 60.0 + rate_per_level * (_player.level - 1)
	rate *= float(_tier["rate"]) * (1.0 + 0.2 * _player.curse) * _player.spawn_mult * (director.rate_mult if director else 1.0)
	if fighting_boss:
		rate *= boss_spawn_scale
	_timer += delta * rate if auto_spawn else 0.0
	while _timer >= 1.0:
		_timer -= 1.0
		spawn(t)
	if not fighting_boss and auto_spawn:
		var crowd: = mini(min_alive + int(min_alive_per_minute * pt / 60.0), max_enemies / 2)
		for i in 3:
			if _crowd() < crowd:
				spawn(t)
	_update_swarms(pt, delta)
	_update_boss(t)
	if _banner_time > 0.0:
		_banner_time -= delta
	_overlay.queue_redraw()





const SAVED_MONSTERS: = 300

func save_state() -> Dictionary:
	var round_index: = _boss_round
	var next: = _next_boss
	var d: = {"intro_done": _intro_done, "swarm_timers": _swarm_timers.duplicate()}
	if fighting():
		var arena: = _arena.save_state()
		if arena.is_empty():
			next = maxf(_boss_due(_boss_round), _player.survived + 20.0)
		else:
			d["arena"] = arena
	d["boss_round"] = round_index
	d["next_boss"] = next
	var monsters: = []
	for c in get_children():
		var e: = c as Enemy
		if e == null or e.is_dead() or e.kind_id == "" or e.is_boss or e.behavior != "chase":
			continue
		monsters.append([e.kind_id, e.global_position - _player.global_position, e.hp / maxf(e.max_hp, 0.001), e.elite])
		if monsters.size() >= SAVED_MONSTERS:
			break
	d["monsters"] = monsters
	return d

func load_state(d: Dictionary, now: float) -> void :
	_boss_round = int(d["boss_round"])
	_next_boss = float(d["next_boss"])
	if _next_boss < 0.0 or (is_inf(_next_boss) and not d.has("arena")):
		_next_boss = now + RunSave.BOSS_RESTART
	_intro_done = bool(d["intro_done"])
	_swarm_timers = (d["swarm_timers"] as Dictionary).duplicate()
	_restore_world.call_deferred(d, now)


func _restore_world(d: Dictionary, now: float) -> void :
	var bosses: Array = Game.theme.bosses
	if d.has("arena") and not bosses.is_empty() and _boss_round > 0:
		var a: Dictionary = d["arena"]
		var index: = _boss_round - 1
		_next_boss = INF
		_arena = BossArena.new()
		_arena.setup(bosses[index % bosses.size()], a["center"], float(a["hp_mult"]), float(a["speed_mult"]))
		_arena.resume = a
		_arena.finished.connect(_on_boss_finished)
		add_child(_arena)
	for m: Array in d.get("monsters", []):
		var data: Dictionary = Game.theme.enemies.get(str(m[0]), {})
		if data.is_empty() or _crowd() >= max_enemies:
			continue
		var enemy: = ENEMY.instantiate() as Enemy
		enemy.configure(data, hp_mult(now), speed_mult(now))
		enemy.kind_id = str(m[0])
		if str(m[3]) != "":
			enemy.make_elite(str(m[3]))
		enemy.hp_share = clampf(float(m[2]), 0.05, 1.0)
		enemy.global_position = _player.global_position + (m[1] as Vector2)
		add_child(enemy)



func _crowd() -> int:
	return get_child_count() - 1 - (1 if is_instance_valid(_arena) else 0)


func fighting() -> bool:
	return is_instance_valid(_arena)





func stop_for_win() -> void :
	set_process(false)
	_banner_time = 0.0
	_overlay.hide()

func show_banner(text: String, sub: = "") -> void :
	_banner = text
	_banner_sub = sub
	_banner_time = BANNER_TIME + (1.0 if sub != "" else 0.0)



func time_growth(t: float) -> float:
	var m: = curve_minutes(t)
	return 1.0 + hp_growth * m + hp_growth_sq * m * m



func hp_mult(t: float) -> float:
	var m: = curve_minutes(t)
	return (1.0 + hp_growth * m + hp_growth_sq * m * m) * (1.0 + hp_per_level * (_player.level - 1))\
	* float(_tier["hp"]) * (1.0 + 0.1 * _player.curse)





func boss_hp_mult(t: float) -> float:
	var m: = curve_minutes(t)
	return (1.0 + hp_growth * m + hp_growth_sq * m * m) * float(_tier.get("boss_hp", _tier["hp"])) * (1.0 + 0.1 * _player.curse)


func speed_mult(t: = 0.0) -> float:
	return float(_tier["speed"]) * (1.0 + speed_growth * curve_minutes(t))


static func curve_minutes(t: float) -> float:
	return t / 60.0 * CURVE_LENGTH / maxf(Game.theme.win_time, 60.0)


func elite_chance(pt: float) -> float:
	if pt < elite_start:
		return 0.0
	var k: = clampf((pt - elite_start) / (DESIGN_LENGTH - elite_start), 0.0, 1.0)
	return lerpf(elite_chance_start, elite_chance_end, k) * float(_tier["elite"])

func spawn(t: float) -> void :
	var pt: = t * _pace
	var row: = _pick_row(pt)
	if row.is_empty():
		return
	var data: Dictionary = Game.theme.enemies.get(row["enemy"], {})
	if data.is_empty():
		push_warning("spawn_table names unknown enemy '%s'" % row["enemy"])
		return
	var dist: = maxf(spawn_distance, Game.offscreen_distance())
	var center: = GameMap.current.ring_point(_player.global_position, dist) if GameMap.current else _player.global_position + Vector2.RIGHT.rotated(randf() * TAU) * dist
	for i in row.get("group", 1):
		if _crowd() >= max_enemies:
			return
		var enemy: = ENEMY.instantiate() as Enemy
		enemy.configure(data, hp_mult(t), speed_mult(t))
		enemy.kind_id = row["enemy"]
		if not data.get("boss", false) and data.get("motion", "walk") != "still" and randf() < elite_chance(pt)\
		and get_tree().get_node_count_in_group("elites") < max_elites:
			enemy.make_elite(["swift", "brute", "volatile"].pick_random())
		enemy.global_position = GameMap.reachable(center + Vector2(randf_range(-40, 40), randf_range(-40, 40)))
		add_child(enemy)


func _pick_row(t: float) -> Dictionary:
	var active: Array[Dictionary] = []
	var total: = 0.0
	for row: Dictionary in Game.theme.spawn_table:
		if t >= row.get("from", 0.0) and t < row.get("until", INF):
			active.append(row)
			total += row.get("weight", 1.0)
	var roll: = randf() * total
	for row in active:
		roll -= row.get("weight", 1.0)
		if roll <= 0.0:
			return row
	return {} if active.is_empty() else active[-1]



func _update_swarms(t: float, delta: float) -> void :
	var swarms: Array = Game.theme.swarms
	if not _intro_done and auto_spawn and t >= intro_swarm_at:
		_intro_done = true
		_intro_swarm(swarms)
	for i in swarms.size():
		var s: Dictionary = swarms[i]
		if t < s.get("from", 0.0) or not auto_spawn:
			continue
		var left: float = _swarm_timers.get(i, 0.0) - delta
		if left <= 0.0:
			left = s.get("every", 30.0) * randf_range(0.8, 1.2)
			_warn_swarm(s)
		_swarm_timers[i] = left
	for w in _warnings:
		w["time"] -= delta
		if w["time"] <= 0.0:
			_launch_swarm(w)
	_warnings = _warnings.filter( func(w: Dictionary) -> bool: return w["time"] > 0.0)



func _intro_swarm(swarms: Array) -> void :
	var first: = -1
	for i in swarms.size():
		if first < 0 or swarms[i].get("from", 0.0) < swarms[first].get("from", 0.0):
			first = i
	if first < 0 or swarms[first].get("from", 0.0) <= intro_swarm_at:
		return
	var s: Dictionary = swarms[first].duplicate()
	var count: Array = s.get("count", [24, 36])
	s["count"] = [maxi(1, int(count[0] * intro_swarm_size)), maxi(1, int(count[1] * intro_swarm_size))]
	_warn_swarm(s)
	_swarm_timers[first] = maxf(0.0, intro_swarm_at + s.get("every", 30.0) - s.get("from", 0.0))

func _warn_swarm(s: Dictionary) -> void :

	var dirs: = [Vector2.RIGHT, Vector2.LEFT, Vector2.RIGHT, Vector2.LEFT, Vector2.DOWN, Vector2.UP]
	_warnings.append({"swarm": s, "dir": dirs.pick_random(), "lane": _player.global_position, "time": WARNING_TIME})
	Game.sfx("swarm")

func _launch_swarm(w: Dictionary) -> void :
	var s: Dictionary = w["swarm"]
	var data: Dictionary = Game.theme.enemies.get(s.get("enemy", ""), {})
	if data.is_empty():
		push_warning("swarm names unknown enemy '%s'" % s.get("enemy", ""))
		return
	data = data.duplicate()
	for key: String in ["xp", "hp", "tint", "scale"]:
		if s.has(key):
			data[key] = s[key]
	var dir: Vector2 = w["dir"]
	var side: = dir.orthogonal()
	var view: = _view_rect()
	var half: float = absf(dir.x) * view.size.x * 0.5 + absf(dir.y) * view.size.y * 0.5
	var lane: Vector2 = w["lane"]

	var start: = dir * (view.get_center().dot(dir) - half - 80.0) + side * lane.dot(side)
	var count_range: Array = s.get("count", [24, 36])
	var count: = randi_range(count_range[0], count_range[1])
	var speed: float = s.get("speed", 380.0)
	var t: = _player.survived


	var lanes: = maxi(1, int(SWARM_WIDTH / SWARM_SPACING))
	for k in count:
		var col: = k % lanes
		var row: = k / lanes
		var across: = (col - (lanes - 1) / 2.0 + randf_range(-0.4, 0.4) + (row % 2) * 0.5) * SWARM_SPACING
		var back: = (row + randf_range(-0.3, 0.3)) * SWARM_SPACING * 0.9
		var enemy: = ENEMY.instantiate() as Enemy
		enemy.configure(data, hp_mult(t), speed_mult())
		enemy.behavior = "sweep"
		enemy.velocity = dir * speed * randf_range(0.9, 1.1)
		enemy.global_position = start + side * across - dir * back
		add_child(enemy)




func start_boss_now() -> void :
	if not is_instance_valid(_arena):
		_next_boss = 0.0
		_update_boss(_player.survived)



func _boss_due(round_index: int) -> float:
	var bosses: Array = Game.theme.bosses
	if bosses.is_empty():
		return INF
	if round_index < bosses.size():
		return float(bosses[round_index].get("at", Game.theme.boss_first + round_index * Game.theme.boss_every))
	var last: float = bosses[-1].get("at", Game.theme.boss_first + (bosses.size() - 1) * Game.theme.boss_every)
	return last + (round_index - bosses.size() + 1) * Game.theme.boss_every

func _update_boss(t: float) -> void :
	var bosses: Array = Game.theme.bosses
	if bosses.is_empty() or is_instance_valid(_arena) or t < _next_boss:
		return
	var b: Dictionary = bosses[_boss_round % bosses.size()]
	var loop: = _boss_round / bosses.size()
	_boss_round += 1
	_next_boss = INF
	_arena = BossArena.new()
	var center: = _player.global_position
	if GameMap.current:
		center = GameMap.current.clamp_band(center, float(b.get("radius", 500.0)) + 60.0)
	_arena.setup(b, center, boss_hp_mult(t) * (1.0 + loop), speed_mult())
	_arena.finished.connect(_on_boss_finished)
	add_child(_arena)
	show_banner(_arena.boss_name().to_upper())
	Game.sfx("boss_spawn")
	_player.shake(12.0)
	if not Game.dev_mode and Game.progress.stats.get("trophies", 0) == 0:
		get_tree().create_timer(BANNER_TIME + 0.2, false).timeout.connect( func() -> void :
			Game.toast("SLAY IT FOR ITS HEAD", "Its trophy gives you free upgrades for what you own", Game.theme.ui.get("holy", Color(1, 0.93, 0.55))))

func _on_boss_finished() -> void :
	if is_instance_valid(_player):
		_next_boss = maxf(_boss_due(_boss_round), _player.survived + 20.0)
	else:
		_next_boss = INF



func _view_rect() -> Rect2:
	return get_canvas_transform().affine_inverse() * get_viewport_rect()

func _draw_overlay() -> void :
	var o: = _overlay
	var view: = _view_rect()
	var warn: Color = Game.theme.ui["warning"]
	var blink: = 0.55 + 0.45 * sin(Time.get_ticks_msec() * 0.02)
	for w in _warnings:
		var dir: Vector2 = w["dir"]
		var side: = dir.orthogonal()
		var half: float = absf(dir.x) * view.size.x * 0.5 + absf(dir.y) * view.size.y * 0.5
		var lane: Vector2 = w["lane"]
		var tip: = dir * (view.get_center().dot(dir) - half + 70.0) + side * lane.dot(side)
		tip = tip.clamp(view.position + Vector2(40, 200), view.end - Vector2(40, 40))
		for j in 3:

			o.draw_set_transform(to_local(tip + dir * (j * 18.0 - 36.0)))
			var c: = Color(warn, blink * (0.5 + 0.25 * j))
			o.draw_colored_polygon(PackedVector2Array([dir * 14.0, - dir * 10.0 + side * 22.0, - dir * 2.0]), c)
			o.draw_colored_polygon(PackedVector2Array([dir * 14.0, - dir * 2.0, - dir * 10.0 - side * 22.0]), c)
		o.draw_set_transform(Vector2.ZERO)
	var font: = ThemeDB.fallback_font

	var top: = to_local(Vector2(view.position.x, view.position.y + HUD.text_bottom() + BANNER_GAP))
	if _banner_time > 0.0:
		var a: = clampf(_banner_time, 0.0, 1.0)
		var width: = view.size.x - BANNER_MARGIN
		var lines: = _banner_lines(font, _banner, width)
		var size: = _fit_size(font, lines, BANNER_SIZE, width)
		var pos: = top + Vector2(0, font.get_ascent(size))
		for i in lines.size():
			var line_pos: = pos + Vector2(0, i * size * 0.95)
			o.draw_string_outline(font, line_pos, lines[i], HORIZONTAL_ALIGNMENT_CENTER, view.size.x, size, 14, Color(0, 0, 0, a))
			o.draw_string(font, line_pos, lines[i], HORIZONTAL_ALIGNMENT_CENTER, view.size.x, size, Color(warn, a))
		if _banner_sub != "":
			var sub_pos: = pos + Vector2(0, 50 + (lines.size() - 1) * size * 0.95)
			var sub_size: = _fit_size(font, [_banner_sub], 30, width)
			o.draw_string_outline(font, sub_pos, _banner_sub, HORIZONTAL_ALIGNMENT_CENTER, view.size.x, sub_size, 9, Color(0, 0, 0, a))
			o.draw_string(font, sub_pos, _banner_sub, HORIZONTAL_ALIGNMENT_CENTER, view.size.x, sub_size, Color(1, 1, 1, a))
	elif director and director.status() != "":
		var line: = director.status()
		var size: = _fit_size(font, [line], 30, view.size.x - BANNER_MARGIN)
		var pos: = top + Vector2(0, font.get_ascent(size))
		o.draw_string_outline(font, pos, line, HORIZONTAL_ALIGNMENT_CENTER, view.size.x, size, 9, Color(0, 0, 0, 0.85))
		o.draw_string(font, pos, line, HORIZONTAL_ALIGNMENT_CENTER, view.size.x, size, Color(warn.lightened(0.3), 0.95))



func _banner_lines(font: Font, text: String, width: float) -> Array[String]:
	if font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, BANNER_SIZE).x <= width or not " " in text:
		return [text]
	var mid: = text.length() / 2
	var best: = -1
	for i in text.length():
		if text[i] == " " and (best < 0 or absi(i - mid) < absi(best - mid)):
			best = i
	return [text.left(best), text.substr(best + 1)]


func _fit_size(font: Font, lines: Array, wanted: int, width: float) -> int:
	var size: = wanted
	for line in lines:
		var w: = font.get_string_size(str(line), HORIZONTAL_ALIGNMENT_LEFT, -1, wanted).x
		if w > width:
			size = mini(size, int(wanted * width / w))
	return size
