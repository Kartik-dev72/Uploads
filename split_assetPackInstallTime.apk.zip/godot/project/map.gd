class_name GameMap
extends Node2D




























enum Ground{LAND, PATH, BRIDGE, LAVA, CURRENT, DEEP, VOID, ICE}

const CHUNK_SIZE: = 640
const KEEP_X: = 1
const KEEP_Y: = 2
const OBSTACLE_GAP: = 110.0
const START_CLEAR: = 420.0
const START_SAFE: = 200.0
const OBSTACLE_KEEP: = 4
const PLOT_MARGIN: = 120.0
const GATE: = 120.0
const BRIDGE_HALF_W: = 46.0

@export var map_seed: = 0

static var current: GameMap

var ground_noise: = FastNoiseLite.new()
var path_noise: = FastNoiseLite.new()
var accent_noise: = FastNoiseLite.new()
var pool_noise: = FastNoiseLite.new()
var cell_noise: = FastNoiseLite.new()
var river_width: = 0.045
var river_kind: = ""
var pool_kind: = ""
var pool_above: = 1.0
var has_terrain: = false
var band_axis: = ""
var band_half: = 0.0
var _river: = {}
var _pools: = {}
var _plots: = {}
var _bridges_on: = false
var _chunks: = {}
var _obstacles: = {}
var _bridges: = {}
var _jobs: = {}
var _first_frame: = true
var _first_jobs: Array[MapChunk] = []

func _enter_tree() -> void :
	add_to_group("map")
	current = self


func _ready() -> void :
	if int(Game.resume.get("map_seed", 0)) != 0:
		map_seed = int(Game.resume["map_seed"])
	Layers.put(self, Layers.MAP)
	configure()
	add_child(Gloom.new())
	if not Game.dev_mode:
		var shrines: = Shrines.new()
		shrines.map = self
		get_parent().add_child.call_deferred(shrines)
	if band_axis != "":
		var edge: = BandEdge.new()
		edge.map = self
		add_child(edge)
	if not Game.dev_mode:
		var goals: = RealmGoals.new()
		goals.map = self
		get_parent().add_child.call_deferred(goals)
	if has_terrain:
		var fx: = TerrainFx.new()
		fx.map = self
		add_child(fx)



func configure() -> void :
	var t: Dictionary = Game.theme.terrain
	_river = t.get("river", {})
	_pools = t.get("pools", {})
	_plots = t.get("plots", {})
	river_kind = _river.get("kind", "")
	river_width = _river.get("width", 0.045)
	_bridges_on = _river.get("bridges", false)
	pool_kind = _pools.get("kind", "")
	pool_above = _pools.get("above", 1.0)
	has_terrain = river_kind != "" or pool_kind != ""
	var band: Dictionary = t.get("band", {})
	band_axis = str(band.get("axis", ""))
	band_half = float(band.get("half", 0.0))
	if map_seed == 0:
		map_seed = randi()
	_seed_noise()
	for i in 200:
		if _start_is_clear():
			break
		map_seed += 7919
		_seed_noise()



static var _previews: = {}
static var _preview_jobs: = {}

static func preview(level: int, texels: = 64) -> ImageTexture:
	var key: = Vector2i(level, texels)
	if not _previews.has(key):
		if not _preview_jobs.has(key):
			_preview_jobs[key] = _start_preview(level, texels)
		WorkerThreadPool.wait_for_task_completion(_preview_jobs[key][0])
		_previews[key] = _finish_preview(_preview_jobs[key], texels)
		_preview_jobs.erase(key)
	return _previews[key]


static func preview_async(level: int, texels: = 64) -> ImageTexture:
	var key: = Vector2i(level, texels)
	if _previews.has(key):
		return _previews[key]
	if not _preview_jobs.has(key):
		_preview_jobs[key] = _start_preview(level, texels)
		return null
	if not WorkerThreadPool.is_task_completed(_preview_jobs[key][0]):
		return null
	return preview(level, texels)



static func _start_preview(level: int, texels: int) -> Array:
	var theme: = Game.theme
	theme.apply_level(level)
	var m: = GameMap.new()
	m.map_seed = 2024 + level * 31
	m.configure()
	var span: = texels * GroundPainter.SUB
	var best: = Vector2.ZERO
	var best_score: = INF
	for wx in 4:
		for wy in 4:
			var at: = Vector2(wx, wy) * float(CHUNK_SIZE - span) / 3.0
			var wet: = 0
			for k in 36:
				if m.ground_at(at + Vector2(k % 6 + 0.5, k / 6 + 0.5) * span / 6.0) != Ground.LAND:
					wet += 1
			var score: = absf(wet / 36.0 - 0.35)
			if score < best_score:
				best_score = score
				best = at
	var near: = []
	for x in range(-1, 2):
		for y in range(-1, 2):
			near.append_array(m.bridges_in(Vector2i(x, y)))
	var painter: = GroundPainter.new(m, Vector2.ZERO, near)
	theme.apply_level(Game.tier)
	return [WorkerThreadPool.add_task(painter.paint, false, "preview"), painter, m, Vector2i(best / GroundPainter.SUB)]

static func _finish_preview(job: Array, texels: int) -> ImageTexture:
	var painter: GroundPainter = job[1]
	var img: = painter.image.get_region(Rect2i(job[3], Vector2i(texels, texels)))
	(job[2] as GameMap).free()
	return ImageTexture.create_from_image(img)

func _seed_noise() -> void :


	_bridges.clear()
	_obstacles.clear()
	ground_noise.seed = map_seed
	ground_noise.frequency = 0.004
	accent_noise.seed = map_seed + 2
	accent_noise.frequency = 0.0028
	path_noise.seed = map_seed + 1

	var rng: = RandomNumberGenerator.new()
	rng.seed = map_seed
	path_noise.offset = Vector3(rng.randf_range(-5000.0, 5000.0), rng.randf_range(-5000.0, 5000.0), 0.0)
	pool_noise.offset = Vector3(rng.randf_range(-5000.0, 5000.0), rng.randf_range(-5000.0, 5000.0), 0.0)
	path_noise.noise_type = FastNoiseLite.TYPE_PERLIN
	path_noise.frequency = _river.get("freq", 0.0012)
	path_noise.fractal_octaves = _river.get("octaves", 5)
	pool_noise.seed = map_seed + 5
	pool_noise.frequency = _pools.get("freq", 0.003)
	pool_noise.fractal_octaves = _pools.get("octaves", 5)
	cell_noise.seed = map_seed + 9
	cell_noise.noise_type = FastNoiseLite.TYPE_CELLULAR
	cell_noise.cellular_return_type = FastNoiseLite.RETURN_DISTANCE2_SUB
	cell_noise.fractal_type = FastNoiseLite.FRACTAL_NONE
	cell_noise.frequency = Game.theme.map.get("cell_freq", 0.012)

func _start_is_clear() -> bool:
	for k in 13:
		var p: = Vector2.ZERO if k == 0 else Vector2.RIGHT.rotated(k * TAU / 6.0) * (START_SAFE if k > 6 else START_SAFE * 0.5)
		var g: = ground_at(p)
		if g != Ground.LAND and g != Ground.PATH:
			return false
	return true

func _process(_delta: float) -> void :
	var cam: = get_viewport().get_camera_2d()
	if not cam:
		return
	var center: = Vector2i((cam.get_screen_center_position() / CHUNK_SIZE).floor())
	for x in range(center.x - KEEP_X, center.x + KEEP_X + 1):
		for y in range(center.y - KEEP_Y, center.y + KEEP_Y + 1):
			var coord: = Vector2i(x, y)
			if not _chunks.has(coord):
				var chunk: = MapChunk.new()
				chunk.setup(self, coord)
				add_child(chunk)
				_chunks[coord] = chunk
				_paint(chunk, coord)
	if _first_frame:
		for chunk: MapChunk in _first_jobs:
			var job: Array = _jobs[chunk]
			WorkerThreadPool.wait_for_task_completion(job[0])
			chunk.set_ground((job[1] as GroundPainter).image)
			_jobs.erase(chunk)
		_first_jobs.clear()
	_first_frame = false
	_collect_paint()
	for coord: Vector2i in _chunks.keys():
		if absi(coord.x - center.x) > KEEP_X + 1 or absi(coord.y - center.y) > KEEP_Y + 1:
			_chunks[coord].queue_free()
			_chunks.erase(coord)
	for coord: Vector2i in _obstacles.keys():
		if (absi(coord.x - center.x) > OBSTACLE_KEEP or absi(coord.y - center.y) > OBSTACLE_KEEP):
			_obstacles.erase(coord)
			_bridges.erase(coord)



func _paint(chunk: MapChunk, coord: Vector2i) -> void :
	var near: = []
	for x in range(coord.x - 1, coord.x + 2):
		for y in range(coord.y - 1, coord.y + 2):
			near.append_array(bridges_in(Vector2i(x, y)))
	var painter: = GroundPainter.new(self, chunk.position, near)
	var cam: = get_viewport().get_camera_2d()
	var view: = Rect2(cam.get_screen_center_position() - Game.view_size() / 2.0, Game.view_size()) if cam else Rect2()
	_jobs[chunk] = [WorkerThreadPool.add_task(painter.paint, false, "ground"), painter]
	if _first_frame and view.intersects(Rect2(chunk.position, Vector2.ONE * CHUNK_SIZE)):
		_first_jobs.append(chunk)



func collect_paint() -> bool:
	_collect_paint()
	return not _jobs.is_empty()

func _collect_paint() -> void :
	for chunk: Variant in _jobs.keys():
		var job: Array = _jobs[chunk]
		if not WorkerThreadPool.is_task_completed(job[0]):
			continue
		WorkerThreadPool.wait_for_task_completion(job[0])
		if is_instance_valid(chunk):
			(chunk as MapChunk).set_ground((job[1] as GroundPainter).image)
		_jobs.erase(chunk)

func _exit_tree() -> void :
	for chunk: Variant in _jobs.keys():
		WorkerThreadPool.wait_for_task_completion(_jobs[chunk][0])
	_jobs.clear()
	if current == self:
		current = null




func ground_at(p: Vector2) -> int:
	if river_width > 0.0 and absf(path_noise.get_noise_2dv(p)) < river_width:
		if river_kind == "":
			return Ground.PATH
		if _bridges_on and on_bridge(p):
			return Ground.BRIDGE
		return Ground.LAVA if river_kind == "lava" else Ground.CURRENT
	if pool_kind != "" and pool_noise.get_noise_2dv(p) > pool_above:
		return _pool_ground()
	return Ground.LAND

func _pool_ground() -> int:
	match pool_kind:
		"void":
			return Ground.VOID
		"ice":
			return Ground.ICE
	return Ground.DEEP


func classify(p: Vector2, pn: float, bridges: Array) -> int:
	if river_width > 0.0 and absf(pn) < river_width:
		if river_kind == "":
			return Ground.PATH
		if _bridges_on and _on_any(p, bridges):
			return Ground.BRIDGE
		return Ground.LAVA if river_kind == "lava" else Ground.CURRENT
	if pool_kind != "" and pool_noise.get_noise_2dv(p) > pool_above:
		return _pool_ground()
	return Ground.LAND

func solid_at(p: Vector2) -> bool:
	return pool_kind == "void" and pool_noise.get_noise_2dv(p) > pool_above\
	and not (river_width > 0.0 and absf(path_noise.get_noise_2dv(p)) < river_width)


func ground_speed(g: int) -> float:
	match g:
		Ground.LAVA, Ground.CURRENT:
			return _river.get("slow", 1.0)
		Ground.DEEP:
			return _pools.get("slow", 1.0)
	return 1.0


func flow_at(p: Vector2) -> Vector2:
	if river_kind != "current":
		return Vector2.ZERO
	var n: = path_noise.get_noise_2dv(p)
	if absf(n) >= river_width:
		return Vector2.ZERO
	var g: = _gradient(p)
	if g == Vector2.ZERO:
		return Vector2.ZERO
	var core: = 1.0 - absf(n) / river_width
	return g.orthogonal().normalized() * float(_river.get("flow", 150.0)) * (0.45 + 0.55 * core)


func scorch() -> float:
	return _river.get("scorch", 0.0) if river_kind == "lava" else 0.0

func burn() -> float:
	return _river.get("burn", 0.0) if river_kind == "lava" else 0.0

func _gradient(p: Vector2) -> Vector2:
	const E: = 3.0
	return Vector2(path_noise.get_noise_2d(p.x + E, p.y) - path_noise.get_noise_2d(p.x - E, p.y), 
		path_noise.get_noise_2d(p.x, p.y + E) - path_noise.get_noise_2d(p.x, p.y - E)) / (2.0 * E)



func on_bridge(p: Vector2) -> bool:
	var c: = Vector2i((p / CHUNK_SIZE).floor())
	for x in range(c.x - 1, c.x + 2):
		for y in range(c.y - 1, c.y + 2):
			if _on_any(p, bridges_in(Vector2i(x, y))):
				return true
	return false

static func _on_any(p: Vector2, bridges: Array) -> bool:
	for b: Dictionary in bridges:
		var d: Vector2 = p - b["pos"]
		var dir: Vector2 = b["dir"]
		if absf(d.dot(dir)) < b["half_len"] and absf(d.dot(dir.orthogonal())) < BRIDGE_HALF_W:
			return true
	return false

func bridges_in(coord: Vector2i) -> Array:
	if not _bridges_on:
		return []
	if not _bridges.has(coord):
		_bridges[coord] = _make_bridges(coord) + _spine_bridges(coord)
	return _bridges[coord]





const SPINE_STEP: = 8.0
const SPINE_SWAY: = 0.45
const SPINE_SPAN: = 420.0

func spine_point(along: float) -> Vector2:
	var across: = band_half * SPINE_SWAY * (0.65 * sin(along * 0.0011 + map_seed % 97) + 0.35 * sin(along * 0.0029 + map_seed % 53))
	return Vector2(across, along) if band_axis == "y" else Vector2(along, across)

func _spine_bridges(coord: Vector2i) -> Array:
	if band_axis == "" or river_kind == "":
		return []
	var origin: = Vector2(coord * CHUNK_SIZE)
	var lo: = origin.y if band_axis == "y" else origin.x
	var chunk: = Rect2(origin, Vector2.ONE * CHUNK_SIZE)
	var out: = []
	var start: = INF
	var along: = lo - 2.0 * CHUNK_SIZE
	while along <= lo + 3.0 * CHUNK_SIZE:
		var p: = spine_point(along)
		var wet: = absf(path_noise.get_noise_2dv(p)) < river_width
		if wet and start == INF:
			start = along
		elif not wet and start != INF:


			var spans: = ceili((along - start + SPINE_STEP) / SPINE_SPAN)
			for k in spans:
				var a: = spine_point(lerpf(start - SPINE_STEP, along, float(k) / spans))
				var b: = spine_point(lerpf(start - SPINE_STEP, along, float(k + 1) / spans))
				var mid: = (a + b) / 2.0
				if chunk.has_point(mid):
					out.append({"pos": mid, "dir": (b - a).normalized(), "half_len": a.distance_to(b) / 2.0 + 40.0})
			start = INF
		along += SPINE_STEP
	return out



func _make_bridges(coord: Vector2i) -> Array:
	var origin: = Vector2(coord * CHUNK_SIZE)
	var best: = Vector2.INF
	var best_n: = INF
	for i in 6:
		for j in 6:
			var p: = origin + Vector2(90.0 + i * 92.0, 90.0 + j * 92.0)
			var n: = absf(path_noise.get_noise_2dv(p))
			if n < best_n:
				best_n = n
				best = p
	if best_n > river_width * 2.5:
		return []
	var p: = best
	for k in 5:
		var g: = _gradient(p)
		if g.length_squared() < 1e-12:
			return []
		p -= path_noise.get_noise_2dv(p) * g / g.length_squared()
	var local: = p - origin
	if local.x < 60.0 or local.y < 60.0 or local.x > CHUNK_SIZE - 60.0 or local.y > CHUNK_SIZE - 60.0:
		return []
	var gr: = _gradient(p)
	var half: = river_width / maxf(gr.length(), 1e-06)
	if half > 260.0:
		return []
	return [{"pos": p, "dir": gr.normalized(), "half_len": half + 40.0}]



func obstacles_in(coord: Vector2i) -> Array:
	if not _obstacles.has(coord):
		_obstacles[coord] = _make_obstacles(coord)
	return _obstacles[coord]

func _make_obstacles(coord: Vector2i) -> Array:
	var kinds: Array = Game.theme.map_obstacles
	var rng: = RandomNumberGenerator.new()
	rng.seed = hash(Vector3i(coord.x, coord.y, map_seed + 7))
	var origin: = Vector2(coord * CHUNK_SIZE)
	var list: = []
	if not _plots.is_empty():
		list.append_array(_make_plot(origin, rng))
	if kinds.is_empty():
		return list
	for i in rng.randi_range(2, 4):
		var kind: Dictionary = pick_weighted(kinds, rng)
		var r: float = kind["radius"]


		var margin: = r + OBSTACLE_GAP / 2.0
		var pos: = origin + Vector2(rng.randf_range(margin, CHUNK_SIZE - margin), rng.randf_range(margin, CHUNK_SIZE - margin))
		if pos.length() < START_CLEAR + r or not _dry(pos, r):
			continue
		var ok: = true
		for o: Dictionary in list:
			if distance_to(o, pos) < r + o["r"] + OBSTACLE_GAP:
				ok = false
				break
		if ok:
			list.append({"pos": pos, "r": r, "sprite": kind["sprite"], "scale": kind["scale"]})
	return list


func _make_plot(origin: Vector2, rng: RandomNumberGenerator) -> Array:
	if rng.randf() > float(_plots.get("chance", 0.5)):
		return []
	var size: = Vector2(rng.randf_range(300.0, 400.0), rng.randf_range(250.0, 340.0))
	var lo: = origin + Vector2.ONE * PLOT_MARGIN
	var span: = Vector2.ONE * (CHUNK_SIZE - 2.0 * PLOT_MARGIN) - size
	var rect: = Rect2(lo + Vector2(rng.randf() * span.x, rng.randf() * span.y), size)
	var nearest: = Vector2(clampf(0.0, rect.position.x, rect.end.x), clampf(0.0, rect.position.y, rect.end.y))
	if nearest.length() < START_CLEAR:
		return []
	for k in 16:
		var p: = rect.position + rect.size * Vector2(float(k % 4) / 3.0, float(k / 4) / 3.0)
		if not _dry(p, 30.0):
			return []
	var styles: Array = _plots.get("walls", [])
	if styles.is_empty():
		return []
	var style: Dictionary = pick_weighted(styles, rng)
	var corners: = [rect.position, Vector2(rect.end.x, rect.position.y), rect.end, Vector2(rect.position.x, rect.end.y)]

	var sides: Array[int] = []
	for s in 4:
		var roll: = rng.randf()
		sides.append(0 if roll < 0.22 else (2 if roll > 0.85 else 1))
	while sides.count(0) > 2:
		sides[sides.find(0)] = 1
	var list: = []
	var thick: float = style.get("thick", 10.0)
	for s in 4:
		var a: Vector2 = corners[s]
		var b: Vector2 = corners[(s + 1) % 4]
		if sides[s] == 2:
			continue
		if sides[s] == 0:
			list.append(_wall(a, b, thick, style))
			continue
		var len: = a.distance_to(b)
		var mid: = rng.randf_range(0.3, 0.7) * len
		var dir: = (b - a) / len
		list.append(_wall(a, a + dir * (mid - GATE / 2.0), thick, style))
		list.append(_wall(a + dir * (mid + GATE / 2.0), b, thick, style))
	var inside: Array = _plots.get("inside", [])
	if not inside.is_empty():
		var inner: = rect.grow(-70.0)
		var y: = inner.position.y
		while y <= inner.end.y:
			var x: = inner.position.x + rng.randf_range(0.0, 30.0)
			while x <= inner.end.x:
				if rng.randf() < 0.55:
					var kind: Dictionary = pick_weighted(inside, rng)
					list.append({"pos": Vector2(x, y), "r": kind["radius"], "sprite": kind["sprite"], "scale": kind["scale"]})
				x += rng.randf_range(80.0, 100.0)
			y += rng.randf_range(80.0, 95.0)
	return list

func _wall(a: Vector2, b: Vector2, thick: float, style: Dictionary) -> Dictionary:
	if a.y > b.y or (a.y == b.y and a.x > b.x):
		var c: = a
		a = b
		b = c
	return {"pos": a, "b": b, "r": thick, "wall": style}


func _dry(p: Vector2, r: float) -> bool:
	if ground_at(p) != Ground.LAND:
		return false
	for k in 6:
		if ground_at(p + Vector2.RIGHT.rotated(k * TAU / 6.0) * (r + 12.0)) != Ground.LAND:
			return false
	return true


static func nearest_point(o: Dictionary, p: Vector2) -> Vector2:
	if not o.has("b"):
		return o["pos"]
	return Geometry2D.get_closest_point_to_segment(p, o["pos"], o["b"])

static func distance_to(o: Dictionary, p: Vector2) -> float:
	return p.distance_to(nearest_point(o, p))


static func pick_weighted(entries: Array, rng: RandomNumberGenerator) -> Dictionary:
	var total: = 0.0
	for e: Dictionary in entries:
		total += e.get("weight", 1.0)
	var roll: = rng.randf() * total
	for e: Dictionary in entries:
		roll -= e.get("weight", 1.0)
		if roll <= 0.0:
			return e
	return entries.back()



func on_obstacle(pos: Vector2, radius: float) -> bool:
	for o: Dictionary in obstacles_near(pos, radius):
		if distance_to(o, pos) < float(o["r"]) + radius * 0.4:
			return true
	return false


func obstacles_near(pos: Vector2, reach: float) -> Array:
	var lo: = Vector2i(((pos - Vector2.ONE * reach) / CHUNK_SIZE).floor())
	var hi: = Vector2i(((pos + Vector2.ONE * reach) / CHUNK_SIZE).floor())
	if lo == hi:
		return obstacles_in(lo)
	var out: = []
	for x in range(lo.x, hi.x + 1):
		for y in range(lo.y, hi.y + 1):
			out.append_array(obstacles_in(Vector2i(x, y)))
	return out






func move(pos: Vector2, motion: Vector2, radius: float, steer: = false, flier: = false, through: = false) -> Vector2:
	return clamp_band(_move(pos, motion, radius, steer, flier, through), radius)




func clamp_band(p: Vector2, margin: = 0.0) -> Vector2:
	var lim: = maxf(band_half - margin, 0.0)
	if band_axis == "x":
		p.y = clampf(p.y, - lim, lim)
	elif band_axis == "y":
		p.x = clampf(p.x, - lim, lim)
	return p

func in_band(p: Vector2, margin: = 0.0) -> bool:
	return clamp_band(p, margin) == p



func ring_point(from: Vector2, dist: float, margin: = 60.0) -> Vector2:
	var p: = from + Vector2.RIGHT.rotated(randf() * TAU) * dist
	if band_axis == "" or in_band(p, margin):
		return p
	var lim: = band_half - margin
	var across: = randf_range( - lim, lim)
	var side: = 1.0 if randf() < 0.5 else -1.0
	if band_axis == "x":
		var dy: = across - from.y
		return Vector2(from.x + side * sqrt(maxf(dist * dist - dy * dy, dist * dist * 0.36)), across)
	var dx: = across - from.x
	return Vector2(across, from.y + side * sqrt(maxf(dist * dist - dx * dx, dist * dist * 0.36)))

func _move(pos: Vector2, motion: Vector2, radius: float, steer: = false, flier: = false, through: = false) -> Vector2:
	var out: = pos + motion if through else _move_obstacles(pos, motion, radius, steer)
	if flier or pool_kind != "void" or motion == Vector2.ZERO or not _blocked(out, motion, radius) or solid_at(pos):
		return out
	var turns: = [0.7, -0.7, 1.45, -1.45] if steer else [0.6, -0.6, 1.2, -1.2]
	for a: float in turns:
		var m: = motion.rotated(a) * (1.0 if steer else cos(a))
		var p: = pos + m if through else _move_obstacles(pos, m, radius, steer)
		if not _blocked(p, m, radius):
			return p
	return pos

func _blocked(p: Vector2, motion: Vector2, radius: float) -> bool:
	return solid_at(p) or solid_at(p + motion.normalized() * radius * 0.7)

func _move_obstacles(pos: Vector2, motion: Vector2, radius: float, steer: bool) -> Vector2:
	var near: = obstacles_near(pos, radius + motion.length())
	if near.is_empty():
		return pos + motion
	if steer:
		for o: Dictionary in near:
			var c: = nearest_point(o, pos + motion)
			var min_d: float = o["r"] + radius
			if (pos + motion).distance_squared_to(c) < min_d * min_d:
				var tangent: = (pos - nearest_point(o, pos)).orthogonal().normalized()
				if motion.dot(tangent) < 0.0:
					tangent = - tangent
				motion = tangent * motion.length()
				break
	return _push_out(pos + motion, radius, near)


func push_out(pos: Vector2, radius: float) -> Vector2:
	pos = clamp_band(pos, radius)
	pos = _push_out(pos, radius, obstacles_near(pos, radius))
	if pool_kind == "void" and solid_at(pos):
		var open: = nearest_open(pos)
		pos = _push_out(open, radius, obstacles_near(open, radius))
	return pos


static func reachable(pos: Vector2) -> Vector2:
	if current and current.band_axis != "":
		pos = current.clamp_band(pos, 30.0)
	if current and current.pool_kind == "void":
		return current.nearest_open(pos)
	return pos


func nearest_open(pos: Vector2) -> Vector2:
	if not solid_at(pos):
		return pos
	for ring in range(1, 22):
		var d: = ring * 24.0
		for k in 8:
			var p: = pos + Vector2.RIGHT.rotated((k + 0.5 * (ring % 2)) * TAU / 8.0) * d
			if not solid_at(p) and not solid_at(p + (p - pos).normalized() * 30.0):
				return p
	return pos

func _push_out(pos: Vector2, radius: float, near: Array) -> Vector2:
	for o: Dictionary in near:
		var c: = nearest_point(o, pos)
		var min_d: float = o["r"] + radius
		var away: = pos - c
		if away.length_squared() < min_d * min_d:
			pos = c + (away.normalized() if away != Vector2.ZERO else Vector2.RIGHT) * min_d
	return pos
