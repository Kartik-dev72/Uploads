class_name Freeze
extends Node







const TIME: = 10.0
const ICE: = Color(0.62, 0.9, 1.0)
const TINT: = 0.13

var _left: = 0.0
var _tint: ColorRect
var _flash: = 1.0
var _length: = TIME
var _banner: Control

static func start(parent: Node, player: Node2D) -> void :
	var running: = parent.get_tree().get_first_node_in_group("freeze") as Freeze
	if running and running._left > 0.0:
		running._left += TIME
		running._length = running._left
	else:
		var f: = Freeze.new()
		f._left = TIME
		parent.add_child(f)
	Enemy.frozen = true
	Game.sfx("barrier", 0.6)

func _ready() -> void :
	add_to_group("freeze")
	_tint = ColorRect.new()
	_tint.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_tint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_tint.color = Color(ICE, TINT)

	var ui: = get_parent().get_node_or_null("UI")
	if ui:
		ui.add_child(_tint)
		ui.move_child(_tint, 0)
		_banner = Control.new()
		_banner.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_banner.draw.connect(_draw_banner)
		ui.add_child(_banner)
		var hud: = ui.get_node_or_null("HUD")
		if hud:
			ui.move_child(_banner, hud.get_index())
		get_tree().process_frame.connect(_hide_when_paused)
	else:
		var layer: = CanvasLayer.new()
		add_child(layer)
		layer.add_child(_tint)


func _hide_when_paused() -> void :
	if is_instance_valid(_banner):
		_banner.visible = not get_tree().paused

func _process(delta: float) -> void :
	_left -= delta
	_flash = maxf(_flash - delta * 3.0, 0.0)
	var thaw: = clampf(_left, 0.0, 1.0)
	_tint.color = Color(ICE.lerp(Color.WHITE, _flash), TINT * thaw + 0.3 * _flash)
	if is_instance_valid(_banner):
		_banner.queue_redraw()
	if _left <= 0.0:
		queue_free()


func _draw_banner() -> void :
	var view: = _banner.size
	var fade: = clampf(_left, 0.0, 1.0)
	var font: = ThemeDB.fallback_font
	var w: = 300.0
	var top: = HUD.text_bottom() + 70.0 + (104.0 if SoulFever.active else 0.0)
	var box: = Rect2((view.x - w) / 2.0, top, w, 58.0)
	_banner.draw_rect(box, Color(0.02, 0.06, 0.1, 0.8 * fade))
	_banner.draw_rect(box, Color(ICE, 0.8 * fade), false, 3.0)
	var title: = "FROZEN"
	_banner.draw_string_outline(font, Vector2(box.position.x + 16.0, top + 32.0), title, HORIZONTAL_ALIGNMENT_LEFT, -1, 28, 6, Color(0, 0, 0, fade))
	_banner.draw_string(font, Vector2(box.position.x + 16.0, top + 32.0), title, HORIZONTAL_ALIGNMENT_LEFT, -1, 28, Color(ICE.lightened(0.3), fade))
	var secs: = "%.1f s" % maxf(_left, 0.0)
	_banner.draw_string(font, Vector2(box.end.x - 70.0, top + 32.0), secs, HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color(1, 1, 1, 0.75 * fade))
	var bar: = Rect2(box.position.x + 16.0, top + 42.0, w - 32.0, 7.0)
	_banner.draw_rect(bar, Color(0, 0, 0, 0.7 * fade))
	_banner.draw_rect(Rect2(bar.position, Vector2(bar.size.x * clampf(_left / maxf(_length, 0.01), 0.0, 1.0), bar.size.y)), Color(ICE, fade))


func _exit_tree() -> void :
	if get_tree().process_frame.is_connected(_hide_when_paused):
		get_tree().process_frame.disconnect(_hide_when_paused)
	remove_from_group("freeze")
	Enemy.frozen = get_tree().get_first_node_in_group("freeze") != null
	if is_instance_valid(_tint):
		_tint.queue_free()
	if is_instance_valid(_banner):
		_banner.queue_free()
