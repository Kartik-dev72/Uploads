class_name TearOfCocytus
extends Weapon










const ID: = "tear"
const COOLDOWN_TEXT: = "weeps %d%% more often"
const BASE: = {"damage": 10.0, "cooldown": 3.0, "count": 1, "pierce": 999, "duration": 2.25, "speed": 1.0}
const UPGRADES: = [
	{"damage": 5.0}, 
	{"duration": 1.25}, 
	{"cooldown": 0.85}, 
	{"count": 1}, 
	{"damage": 5.0}, 
	{"duration": 1.2}, 
	{"damage": 8.0}, 
]
const HOLY: = {"damage": 6.0, "count": 1}
const SPEED: = 520.0
const BURST_RADIUS: = 90.0
const RETALIATE_GAP: = 0.4

var cooldown: = 3.0
var damage: = 10.0
var count: = 1
var pierce: = 999
var duration: = 2.25
var speed: = 1.0
var _timer: = 0.5
var _tears: Array = []
var _retaliate_t: = 0.0

func _ready() -> void :
	super._ready()
	player.hit_taken.connect(_on_hit_taken)

func _on_hit_taken() -> void :
	if not holy or _retaliate_t > 0.0:
		return
	var live: Array = []
	for t: Variant in _tears:
		if is_instance_valid(t) and not (t as Node).is_queued_for_deletion():
			live.append(t)
	_tears = live
	if _tears.is_empty():
		return
	_retaliate_t = RETALIATE_GAP
	for t: Variant in _tears:
		(t as Projectile).burst(player.retaliation)
	Game.sfx("barrier", 1.3)

func _process(delta: float) -> void :
	_retaliate_t -= delta
	_timer -= delta
	if _timer > 0.0:
		return
	_timer = cooldown_of(cooldown)
	var n: = amount_of(count)
	var dir: = player.facing if player.facing != Vector2.ZERO else Vector2.RIGHT
	for i in n:

		var d: = dir.rotated((i - (n - 1) / 2.0) * 0.35)
		var p: = fire_projectile(global_position, d, SPEED * speed, damage, pierce, Projectile.Style.TEAR)
		p.motion = Projectile.Motion.BOUNCE
		p.lifetime = duration_of(duration)
		if holy:
			p.bounce_burst = BURST_RADIUS
			_tears.append(p)
	Game.sfx("barrier", 1.6)
