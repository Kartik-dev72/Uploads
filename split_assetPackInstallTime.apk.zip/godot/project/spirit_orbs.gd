class_name SpiritOrbs
extends Weapon

const ID: = "spirit_orbs"
const ORBIT_RADIUS: = 110.0
const ORB_RADIUS: = 14.0
const GLOW: = 5.0
const SPIN_SPEED: = 3.0
const HIT_COOLDOWN: = 0.35


const BASE: = {"damage": 12.0, "count": 1, "spin": 1.0, "area": 1.0}
const UPGRADES: = [
	{"count": 1}, 
	{"damage": 4.0}, 
	{"area": 1.15}, 
	{"count": 1}, 
	{"spin": 1.2}, 
	{"damage": 5.0}, 
	{"count": 1}, 
]


const HOLY: = {"damage": 10.0, "spin": 1.2, "area": 1.15}
const HUNT_EVERY: = 1.2
const HUNT_TIME: = 0.55
const HUNT_RANGE: = 380.0
const PUSH: = 220.0

var damage: = 10.0
var count: = 1
var spin: = 1.0
var area: = 1.0
var _angle: = 0.0
var _time: = 0.0
var _orbs: = 1
var _size: = 1.0


var _next_hit: Array[Dictionary] = []
var _offsets: Array[Vector2] = []
var _hunt_t: Array[float] = []
var _hunt_wait: Array[float] = []
var _hunt_at: Array[Vector2] = []

func _on_level() -> void :
	Layers.put(self, Layers.PLAYER_EFFECTS)

func _process(delta: float) -> void :
	_time += delta
	_orbs = count
	_size = area_of(area)
	while _next_hit.size() < _orbs:
		_next_hit.append({})
	var prev_angle: = _angle
	_angle = fmod(_angle + SPIN_SPEED * spin * delta, TAU)
	queue_redraw()
	var prev: = _offsets.duplicate()
	_update_offsets(delta)
	while prev.size() < _orbs:
		prev.append(_offsets[prev.size()])

	var orbit: = ORBIT_RADIUS * _size
	var far: = HUNT_RANGE + orbit if holy else 0.0
	for e: Enemy in Enemy.near(global_position, (far if holy else orbit) + (ORB_RADIUS + GLOW) * _size):
		var to_enemy: = e.global_position - global_position
		var reach: = (ORB_RADIUS + GLOW) * _size + e.radius

		if (absf(to_enemy.length() - orbit) > reach) if not holy else (to_enemy.length() > far + reach):
			continue
		var id: = e.get_instance_id()
		for i in _orbs:
			if _time < _next_hit[i].get(id, 0.0):
				continue


			var closest: = Geometry2D.get_closest_point_to_segment(to_enemy, prev[i], _offsets[i])
			if closest.distance_squared_to(to_enemy) < reach * reach:
				_next_hit[i][id] = _time + HIT_COOLDOWN
				e.take_damage(power(damage))
				if e.is_dead():
					break
				e.knock(to_enemy.normalized() * PUSH)

	for hits in _next_hit:
		if hits.size() > 200:
			for id: int in hits.keys():
				if hits[id] < _time:
					hits.erase(id)


func _update_offsets(delta: float) -> void :
	while _hunt_t.size() < _orbs:
		_hunt_t.append(-1.0)
		_hunt_wait.append(HUNT_EVERY * (_hunt_t.size() - 1) / maxf(_orbs, 1))
		_hunt_at.append(Vector2.ZERO)
	_offsets.resize(_orbs)
	for i in _orbs:
		var on_orbit: = _orb_offset(_angle, i)
		_offsets[i] = on_orbit
		if not holy:
			continue
		if _hunt_t[i] < 0.0:
			_hunt_wait[i] -= delta
			if _hunt_wait[i] <= 0.0:
				var target: = _dive_target(global_position + on_orbit)
				_hunt_wait[i] = HUNT_EVERY
				if target != null:
					_hunt_t[i] = 0.0
					_hunt_at[i] = target.global_position
			continue
		_hunt_t[i] += delta
		if _hunt_t[i] >= HUNT_TIME:
			_hunt_t[i] = -1.0
			continue
		var k: = sin(PI * _hunt_t[i] / HUNT_TIME)
		_offsets[i] = on_orbit.lerp(_hunt_at[i] - global_position, k)

func _dive_target(from: Vector2) -> Enemy:
	var best: Enemy = null
	var best_d: = HUNT_RANGE * HUNT_RANGE
	for e: Enemy in Enemy.near(from, HUNT_RANGE):
		if not e.targetable:
			continue
		var d: = from.distance_squared_to(e.global_position)
		if d < best_d:
			best_d = d
			best = e
	return best

func _orb_offset(angle: float, i: int) -> Vector2:
	return Vector2.RIGHT.rotated(angle + TAU * i / _orbs) * ORBIT_RADIUS * _size



func _draw() -> void :
	var r: = ORB_RADIUS * _size
	var step: = 0.07 / maxf(_size, 0.5)
	for i in _orbs:
		var flick: = 1.0 + 0.12 * sin(_time * 18.0 + i * 2.1)
		for k in range(8, 0, -1):
			if holy:
				break
			var f: = k / 8.0
			var p: = _orb_offset(_angle - step * k * spin, i)
			p += Vector2(0, sin(_time * 6.0 + k + i) * 2.0)
			PixelFx.disc(self, p, r * (1.0 - f * 0.75), Color(color, 0.35 * (1.0 - f)))
		var pos: = _offsets[i] if i < _offsets.size() else _orb_offset(_angle, i)
		if holy:
			_draw_redeemed(pos, r, i)
			continue

		draw_set_transform(PixelFx.snap(pos), 0.0, Vector2.ONE * 1.5 * _size * flick)
		PixelFx.draw_sprite(self, "soul", color, int(_time * 8.0 + i))
		draw_set_transform(Vector2.ZERO)


func _draw_redeemed(pos: Vector2, r: float, i: int) -> void :
	var diving: = i < _hunt_t.size() and _hunt_t[i] >= 0.0
	var bob: = sin(_time * 5.0 + i * 1.7) * 2.0
	var p: = pos + Vector2(0, bob)
	PixelFx.disc(self, p, r * (2.6 if diving else 2.0), Color(color, 0.18))
	var beat: = sin(_time * 14.0 + i)
	for side: float in [-1.0, 1.0]:
		var base: = p + Vector2(side * r * 0.6, 0)
		PixelFx.poly(self, PackedVector2Array([base, base + Vector2(side * r * 1.4, - r * (0.6 + 0.4 * beat)), base + Vector2(side * r * 0.9, r * 0.5)]), Color(1, 1, 1, 0.85))
	PixelFx.poly(self, PackedVector2Array([p + Vector2( - r * 0.8, 0), p + Vector2(0, r * 1.7 + sin(_time * 9.0 + i) * 2.0), p + Vector2(r * 0.8, 0)]), Color(1, 1, 1, 0.9))
	PixelFx.disc(self, p, r * 0.85, Color.WHITE)
	PixelFx.disc(self, p + Vector2( - r * 0.3, - r * 0.15), r * 0.12, Color(0.1, 0.1, 0.18))
	PixelFx.disc(self, p + Vector2(r * 0.3, - r * 0.15), r * 0.12, Color(0.1, 0.1, 0.18))
	PixelFx.disc(self, p + Vector2(0, r * 0.3), r * (0.15 + 0.08 * absf(sin(_time * 7.0 + i))), Color(0.1, 0.1, 0.18))
	PixelFx.arc(self, p + Vector2(0, - r * 1.2), r * 0.6, 0, TAU, Color(color.lightened(0.3), 0.95), 2.5)
