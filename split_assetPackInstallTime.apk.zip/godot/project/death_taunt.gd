class_name DeathTaunt
extends Control









enum State{GLOAT, HEADER, REWIND}

const DIM: = 0.72
const BLUR: = 4.0
const FADE_TIME: = 0.22
const DEVIL_AT: = 0.15
const LINE1_AT: = 0.5
const TYPE_SPEED: = 0.04
const LINE2_AT: = 1.6
const SETTLED: = LINE2_AT + 0.35
const HINT_AT: = SETTLED + 0.8
const DURATION: = 5.5
const HA_LOOP: = 1.5
const SHRINK_TIME: = 0.4
const REWIND_TIME: = 1.3
const FACE_SCALE: = 11.0
const FACE_TOP: = 250.0
const LINE2_Y: = 920.0
const LINE2_HEADER_Y: = 730.0
const SCENE_TOP: = 230.0
const HEADER_SCALE: = 0.4
const TEXT_WIDTH: = 660.0
const HAS: = [Vector2(-250, 300), Vector2(240, 250), Vector2(-210, 470), Vector2(265, 430), Vector2(-150, 180), Vector2(170, 560)]
const BLUR_SHADER: = "\nshader_type canvas_item;\nuniform sampler2D screen_tex : hint_screen_texture, filter_linear;\nuniform float radius = 0.0;\nvoid fragment() {\n\tvec4 sum = vec4(0.0);\n\tfloat total = 0.0;\n\tfor (int x = -2; x <= 2; x++) {\n\t\tfor (int y = -2; y <= 2; y++) {\n\t\t\tfloat w = exp(-float(x * x + y * y) / 4.0);\n\t\t\tsum += texture(screen_tex, SCREEN_UV + vec2(float(x), float(y)) * SCREEN_PIXEL_SIZE * radius) * w;\n\t\t\ttotal += w;\n\t\t}\n\t}\n\tCOLOR = sum / total;\n}\n"

















static var _deck: Array = []
static var _deck_last: Variant = null

var _taunt: Dictionary
var _done: Callable
var _state: = State.GLOAT
var _t: = 0.0
var _k: = 0.0
var _laughed: = false
var _last_tap: = -1.0
var _blur: ColorRect
var _rewind_rate: = 1.0


static func play(host: Node, taunt: Dictionary, done: Callable) -> void :
	var node: = DeathTaunt.new()
	node._taunt = taunt
	node._done = done
	host.add_child(node)



static func next_taunt(taunts: Array) -> Dictionary:
	if _deck.is_empty():
		_deck = taunts.duplicate()
		_deck.shuffle()
	var pick: = _deck.size() - 1
	if _deck_last != null:
		for i in range(_deck.size() - 1, -1, -1):
			if _punchline(_deck[i]) != _punchline(_deck_last):
				pick = i
				break
	_deck_last = _deck.pop_at(pick)
	return _deck_last

static func _punchline(taunt: Variant) -> String:
	var lines: Array = (taunt as Dictionary).get("lines", [])
	return str(lines.back()) if not lines.is_empty() else ""

func _ready() -> void :
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_to_group("pause_screen")
	add_to_group("death_taunt")
	get_tree().paused = true
	var shader: = Shader.new()
	shader.code = BLUR_SHADER
	var mat: = ShaderMaterial.new()
	mat.shader = shader
	_blur = ColorRect.new()
	_blur.material = mat
	_blur.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_blur.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	get_parent().add_child.call_deferred(_blur)
	get_parent().move_child.call_deferred(_blur, get_index())

func _exit_tree() -> void :
	if is_instance_valid(_blur):
		_blur.queue_free()

func _process(delta: float) -> void :
	match _state:
		State.GLOAT:
			_t += delta
			if not _laughed and _t >= DEVIL_AT:
				_laughed = true
				Game.sfx("laugh")
			if _t >= DURATION:
				_to_header()
		State.HEADER:
			_t += delta
			_k = minf(_k + delta / SHRINK_TIME, 1.0)
		State.REWIND:
			_k = maxf(_k - delta / 0.25, 0.0)
			_t -= delta * _rewind_rate
			if _t <= 0.0:
				_end_rewind()
	if is_instance_valid(_blur):
		(_blur.material as ShaderMaterial).set_shader_parameter("radius", BLUR * _fade())
	queue_redraw()

func _fade() -> float:
	return clampf(maxf(_t, 0.0) / FADE_TIME, 0.0, 1.0)


func _gui_input(event: InputEvent) -> void :
	var tapped: bool = (event is InputEventScreenTouch and event.pressed) or (event is InputEventMouseButton and event.pressed)
	if not tapped or _state != State.GLOAT:
		return
	accept_event()
	var now: = Time.get_ticks_msec() / 1000.0
	if now - _last_tap < 0.2:
		return
	_last_tap = now
	if _t < SETTLED:
		_t = SETTLED
	elif _t >= HINT_AT:
		_to_header()


func _to_header() -> void :
	_state = State.HEADER
	remove_from_group("pause_screen")
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	var screen: = get_tree().get_first_node_in_group("game_over_screen") as Control
	if screen and screen.get_parent() == get_parent() and screen.get_index() < get_index():
		var i: = screen.get_index()
		get_parent().move_child(_blur, i)
		get_parent().move_child(self, i + 1)
	var done: = _done
	_done = Callable()
	if done.is_valid():
		done.call()


func header_bottom() -> float:
	return _header_origin().y + (LINE2_HEADER_Y + 30.0) * HEADER_SCALE

func _header_origin() -> Vector2:
	var view: = get_viewport_rect().size
	return Vector2(view.x / 2.0, Game.safe_top() + 8.0) - Vector2(360.0, SCENE_TOP) * HEADER_SCALE



func rewind(then: Callable) -> void :
	_done = then
	_state = State.REWIND
	add_to_group("pause_screen")
	var screen: = get_tree().get_first_node_in_group("game_over_screen") as Control
	if screen:
		screen.hide()
	get_tree().paused = true
	_t = minf(_t, SETTLED + 0.6)
	_rewind_rate = _t / REWIND_TIME
	Game.sfx("rewind")

func _end_rewind() -> void :
	remove_from_group("pause_screen")
	remove_from_group("death_taunt")
	hide()
	queue_free()
	var then: = _done
	_done = Callable()
	if then.is_valid():
		then.call()

func _draw() -> void :
	var view: = get_viewport_rect().size
	var t: = maxf(_t, 0.0)
	draw_rect(Rect2(Vector2.ZERO, view), Color(0, 0, 0, DIM * _fade()))
	var slam: = t - LINE2_AT
	var shake: = Vector2.ZERO
	if slam >= 0.0 and slam < 0.35:
		shake = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * 16.0 * (1.0 - slam / 0.35)
	if _state == State.REWIND:
		shake.x += randf_range(-7, 7)
	var e: = ease(_k, -2.0)
	var origin: = Vector2((view.x - 720.0) / 2.0, Game.design_offset()).lerp(_header_origin(), e) + shake
	var scale: = lerpf(1.0, HEADER_SCALE, e)
	var base: = Transform2D(0.0, Vector2.ONE * scale, 0.0, origin)
	draw_set_transform_matrix(base)
	var accent: Color = Game.theme.ui["accent"]
	var rise: = clampf((t - DEVIL_AT) / 0.3, 0.0, 1.0)
	for i in 6:
		draw_circle(Vector2(360, 450), 380.0 - i * 55.0, Color(accent.darkened(0.35), (0.04 + 0.02 * i) * rise))
	_draw_devil(rise)
	_draw_has(1.0 - e)
	var font: = ThemeDB.fallback_font
	var lines: Array = _taunt.get("lines", [])
	if lines.size() > 0 and t >= LINE1_AT and e < 1.0:
		var first: String = lines[0]
		var shown: = first.left(int((t - LINE1_AT) / TYPE_SPEED) + 1)
		var size: = _fit(font, first, 54)
		var x: = 360.0 - font.get_string_size(first, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x / 2.0
		draw_string_outline(font, Vector2(x, 790), shown, HORIZONTAL_ALIGNMENT_LEFT, -1, size, 12, Color(0.1, 0, 0, 1.0 - e))
		draw_string(font, Vector2(x, 790), shown, HORIZONTAL_ALIGNMENT_LEFT, -1, size, Color(1, 0.9, 0.85, 1.0 - e))
	if lines.size() > 1 and slam >= 0.0:
		_draw_punchline(font, lines[1], str(_taunt.get("shake", "")), base, lerpf(LINE2_Y, LINE2_HEADER_Y, e), slam)
	draw_set_transform_matrix(base)
	if _state == State.GLOAT and t >= HINT_AT:
		var a: = clampf((t - HINT_AT) / 0.4, 0.0, 1.0) * (0.35 + 0.15 * sin(t * 4.0))
		draw_string(font, Vector2(0, 1060), "tap to continue", HORIZONTAL_ALIGNMENT_CENTER, 720, 26, Color(1, 1, 1, a))
	draw_set_transform(Vector2.ZERO)
	if _state == State.REWIND:
		_draw_tape(view, font)


func _draw_tape(view: Vector2, font: Font) -> void :
	for y in range(0, int(view.y), 6):
		draw_rect(Rect2(0, y, view.x, 2), Color(0, 0, 0, 0.18))
	for i in 3:
		var y: = randf() * view.y
		var h: = randf_range(6.0, 26.0)
		draw_rect(Rect2(0, y, view.x, h), Color(1, 1, 1, randf_range(0.05, 0.14)))
		for k in 10:
			draw_rect(Rect2(randf() * view.x, y + randf() * h, randf_range(10, 60), 2), Color(1, 1, 1, randf_range(0.2, 0.5)))
	if fmod(Time.get_ticks_msec() / 1000.0, 0.5) < 0.32:
		var p: = Vector2(36, Game.safe_top() + 70)
		draw_string_outline(font, p, "<< REWIND", HORIZONTAL_ALIGNMENT_LEFT, -1, 44, 10, Color(0, 0, 0, 0.8))
		draw_string(font, p, "<< REWIND", HORIZONTAL_ALIGNMENT_LEFT, -1, 44, Color.WHITE)


func _draw_devil(rise: float) -> void :
	var key: = Game.theme.taunt_sprite
	if rise <= 0.0 or not Game.theme.sprites.has(key):
		return
	var tex: = Game.theme.texture(key)
	var size: = tex.get_size() * FACE_SCALE
	var bob: = - absf(sin((_t - DEVIL_AT) * 20.0)) * 16.0
	var pos: = Vector2(360.0 - size.x / 2.0, FACE_TOP + (1.0 - rise) * 120.0 + bob)
	var tint: = Color(1, 1, 1, rise)
	draw_texture_rect(tex, Rect2(pos + Vector2(10, 14), size), false, Color(0, 0, 0, 0.45 * rise))
	draw_texture_rect(tex, Rect2(pos, size), false, tint)
	var glow: = (0.55 + 0.45 * sin(_t * 9.0)) * rise
	for cx: float in [9.5, tex.get_width() - 9.5]:
		var c: = pos + Vector2(cx, 13.5) * FACE_SCALE
		draw_circle(c, 42.0, Color(1, 0.3, 0.1, 0.14 * glow))
		draw_circle(c, 22.0, Color(1, 0.75, 0.25, 0.22 * glow))


func _draw_has(alpha: float) -> void :
	if alpha <= 0.0:
		return
	var font: = ThemeDB.fallback_font
	for k in HAS.size():
		var age: = _t - (DEVIL_AT + 0.1 + k * 0.2)
		if age < 0.0:
			continue
		age = fmod(age, HA_LOOP * 2.0)
		if age > 0.9:
			continue
		var a: = (1.0 - age / 0.9) * alpha
		var p: Vector2 = Vector2(300, 0) + HAS[k] + Vector2(0, - age * 60.0)
		var size: = 40 + (k % 3) * 6
		draw_string_outline(font, p, "HA!", HORIZONTAL_ALIGNMENT_CENTER, 120, size, 8, Color(0.1, 0, 0, a))
		draw_string(font, p, "HA!", HORIZONTAL_ALIGNMENT_CENTER, 120, size, Color(1, 0.55, 0.2, a))


func _draw_punchline(font: Font, line: String, word: String, scene: Transform2D, y: float, slam: float) -> void :
	var size: = _fit(font, line, 66, 1.3)
	var big: = int(size * 1.3)
	var at: = line.find(word) if word != "" else -1
	var widths: Array[float] = []
	var total: = 0.0
	for i in line.length():
		var w: = font.get_string_size(line[i], HORIZONTAL_ALIGNMENT_LEFT, -1, big if _in_word(i, at, word) else size).x
		widths.append(w)
		total += w
	var punch: = 1.0 + 1.4 * maxf(0.0, 1.0 - slam / 0.14)
	var base: = scene * Transform2D(0.0, Vector2.ONE * punch, 0.0, Vector2(360, y))
	var x: = - total / 2.0
	var hot: = Color(1, 0.12, 0.08).lerp(Color(1, 0.8, 0.2), 0.5 + 0.5 * sin(_t * 12.0))
	for i in line.length():
		var c: = line[i]
		var in_word: = _in_word(i, at, word)
		var fs: = big if in_word else size
		var pos: = Vector2(x, 0)
		var angle: = 0.0
		var scale: = 1.0
		if in_word:
			var k: = i - at
			pos += Vector2(randf_range(-2.5, 2.5), sin(_t * 15.0 + k * 1.1) * 9.0 + randf_range(-2.5, 2.5))
			angle = sin(_t * 11.0 + k * 1.7) * 0.14
			scale = 1.0 + 0.08 * sin(_t * 9.0 + k * 0.8)
		draw_set_transform_matrix(base * Transform2D(angle, Vector2.ONE * scale, 0.0, pos + Vector2(widths[i] / 2.0, 0)))
		var p: = Vector2( - widths[i] / 2.0, 0)
		draw_string_outline(font, p, c, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, 14, Color(0.15, 0, 0))
		draw_string(font, p, c, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, hot if in_word else Color.WHITE)
		x += widths[i]

func _in_word(i: int, at: int, word: String) -> bool:
	return at >= 0 and i >= at and i < at + word.length()



func _fit(font: Font, text: String, wanted: int, slack: = 1.0) -> int:
	var w: = font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, wanted).x * slack
	return wanted if w <= TEXT_WIDTH else int(wanted * TEXT_WIDTH / w)
