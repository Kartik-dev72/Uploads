class_name Weapon
extends Node2D






















const PROJECTILE: = preload("res://projectile.tscn")
const NEAR_TARGET_RANGE: = 220.0
const MULTIPLIED_STATS: = ["cooldown", "area", "spin", "speed", "duration", "force"]

var level: = 1
var holy: = false
var player: Player
var color: = Color.WHITE

func _ready() -> void :
	player = get_parent() as Player
	_apply_level()
	_report_level()
	var held: = player.get_children().filter( func(c: Node) -> bool: return c is Weapon).size()
	Game.track_max("weapons_held", held)

func level_up() -> void :
	level += 1
	_apply_level()
	_report_level()
	if is_maxed():
		_report_maxed()

func is_maxed() -> bool:
	return level >= max_level(get_script())


static func partner_of(weapon_script: Script) -> String:
	return Game.EVOLUTIONS.get(str(info(weapon_script, "ID")), "")


func can_turn_holy() -> bool:
	var partner: = partner_of(get_script())
	return is_maxed() and not holy and partner != "" and player.passives.has(partner)

func make_holy() -> void :
	holy = true
	_apply_level()
	Game.track("holy_" + str(info(get_script(), "ID")))
	Game.track("holys")


func _report_level() -> void :
	Game.track_max("wlvl_" + str(info(get_script(), "ID")), level)


func _report_maxed() -> void :
	var n: = 0
	for c in player.get_children():
		if c is Weapon and (c as Weapon).is_maxed():
			n += 1
	Game.track_max("maxed_weapons", n)


func _apply_level() -> void :
	var t: = theme_info(get_script())
	color = t.get("holy_color", Color(1, 0.95, 0.6)) if holy else t.get("color", Color.WHITE)
	var stats: = stats_at(get_script(), level, holy)
	for key: String in stats:
		set(key, stats[key])
	_on_level()


func _on_level() -> void :
	pass

static func info(weapon_script: Script, key: String) -> Variant:
	return weapon_script.get_script_constant_map().get(key)

static func max_level(weapon_script: Script) -> int:
	return (info(weapon_script, "UPGRADES") as Array).size() + 1

static func stats_at(weapon_script: Script, lvl: int, is_holy: = false) -> Dictionary:
	var stats: Dictionary = (info(weapon_script, "BASE") as Dictionary).duplicate()
	var upgrades: Array = info(weapon_script, "UPGRADES").duplicate()
	if is_holy:
		upgrades.append(info(weapon_script, "HOLY"))
		lvl = upgrades.size() + 1
	for i in mini(lvl - 1, upgrades.size()):
		var up: Dictionary = upgrades[i]
		for key: String in up:
			stats[key] = stats[key] * up[key] if key in MULTIPLIED_STATS else stats[key] + up[key]
	return stats


static func upgrade_text(weapon_script: Script, lvl: int) -> String:
	if lvl < 2 or lvl > max_level(weapon_script):
		return ""
	return _describe_diff(weapon_script, stats_at(weapon_script, lvl - 1), stats_at(weapon_script, lvl))



static func holy_text(weapon_script: Script) -> String:
	var text: String = theme_info(weapon_script).get("holy_text", "")
	if text != "":
		return text
	var top: = max_level(weapon_script)
	return _describe_diff(weapon_script, stats_at(weapon_script, top), stats_at(weapon_script, top, true))






const BIG_STEP: = 0.3
const BIG_DAMAGE: = 0.5

static func _describe_diff(weapon_script: Script, before: Dictionary, after: Dictionary) -> String:
	var unit: String = theme_info(weapon_script).get("unit", "projectile")
	var parts: PackedStringArray = []
	for key: String in after:
		var a: float = before.get(key, 0.0)
		var b: float = after[key]
		if is_equal_approx(a, b):
			continue
		var change: = absf(b / a - 1.0) if a != 0.0 else 1.0
		if key == "cooldown":
			change = absf(a / b - 1.0)
		var big: = change >= BIG_STEP - 0.001
		match key:
			"damage": parts.append("much more damage" if change >= BIG_DAMAGE - 0.001 else "more damage")
			"count":
				var n: = int(b - a)
				if info(weapon_script, "COUNT_TEXT"):
					parts.append(str(info(weapon_script, "COUNT_TEXT")))
				else:
					parts.append("+1 %s" % unit if n == 1 else "+%d %s" % [n, _plural(unit)])
			"pierce": parts.append("pierces %d → %d" % [int(a), int(b)])
			"cooldown":
				var fmt: String = info(weapon_script, "COOLDOWN_TEXT") if info(weapon_script, "COOLDOWN_TEXT") else "attacks %d%% faster"
				parts.append(fmt.replace("%d%% ", "a lot " if big else ""))
			"area": parts.append("much bigger" if big else "bigger")
			"spin": parts.append("spins a lot faster" if big else "spins faster")
			"speed": parts.append("flies a lot faster and farther" if big else "flies faster and farther")
			"duration":
				if b > a:
					parts.append("lasts a lot longer" if big else "lasts longer")
				else:
					parts.append("lasts shorter")
			"force": parts.append(("pushes a lot harder" if big else "pushes harder") if b > a else "pushes softer")
			"doom": parts.append("doomed demons take even more damage")
			_: parts.append("more %s" % key)
	var text: = ", ".join(parts)
	return text.left(1).to_upper() + text.substr(1)


static func _plural(word: String) -> String:
	if word.ends_with("fe"):
		return word.left(-2) + "ves"
	for end: String in ["s", "sh", "ch", "x", "z"]:
		if word.ends_with(end):
			return word + "es"
	return word + "s"


static func theme_info(weapon_script: Script) -> Dictionary:
	return Game.theme.weapon(info(weapon_script, "ID"))


func icon() -> String:
	var t: = theme_info(get_script())
	return str(t.get("holy_icon", t.get("icon", ""))) if holy else str(t.get("icon", ""))


func power(base: float) -> float:
	return base * player.might


func cooldown_of(base: float) -> float:
	return base * player.cooldown_mult


func area_of(base: float) -> float:
	return base * player.area


func duration_of(base: float) -> float:
	return base * player.duration


func amount_of(base: int) -> int:
	return base + player.extra_projectiles


func visible_rect() -> Rect2:
	return (get_canvas_transform().affine_inverse() * get_viewport_rect()).grow(-10)



func enemies_on_screen() -> Array[Enemy]:
	var view: = visible_rect()
	var near: = NEAR_TARGET_RANGE * NEAR_TARGET_RANGE
	var origin: = global_position
	var found: Array[Enemy] = []
	for e: Enemy in Enemy.in_rect(view):
		if not view.has_point(e.global_position):
			continue
		if e.targetable or origin.distance_squared_to(e.global_position) < near:
			found.append(e)
	return found


func nearest_enemies_on_screen(count: int) -> Array[Enemy]:
	var found: = enemies_on_screen()
	var origin: = global_position
	found.sort_custom( func(a: Enemy, b: Enemy) -> bool:
		if a.is_boss != b.is_boss:
			return a.is_boss
		return origin.distance_squared_to(a.global_position) < origin.distance_squared_to(b.global_position))
	return found.slice(0, count)

func fire_projectile(from: Vector2, dir: Vector2, speed: float, damage: float, pierce: int, style: Projectile.Style, size: = 1.0) -> Projectile:
	var p: = PROJECTILE.instantiate() as Projectile
	p.global_position = from
	p.direction = dir
	p.speed = speed
	p.damage = power(damage)
	p.pierce = pierce
	p.style = style
	p.color = color
	p.size = area_of(size)
	p.holy = holy
	get_tree().current_scene.add_child(p)
	return p
