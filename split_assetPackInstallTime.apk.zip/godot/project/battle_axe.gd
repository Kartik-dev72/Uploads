class_name BattleAxe
extends Weapon



const ID: = "battle_axe"
const COOLDOWN_TEXT: = "throws %d%% faster"
const BASE: = {"damage": 20.0, "cooldown": 1.4, "count": 1, "pierce": 3, "area": 1.0}
const UPGRADES: = [
	{"damage": 8.0}, 
	{"area": 1.15}, 
	{"pierce": 2}, 
	{"count": 1}, 
	{"count": 1}, 
	{"area": 1.2}, 
	{"damage": 20.0}, 
]




const HOLY: = {"damage": 6.0, "area": 1.1, "cooldown": 1.6}
const SPIRAL_BASE: = 4
const SPIRAL_PER: = 2
const SPIRAL_SPEED: = 480.0
const SPIRAL_TURN: = 2.4

var damage: = 20.0
var cooldown: = 1.4
var count: = 1
var pierce: = 3
var area: = 1.0
var _timer: = 0.0
var _turn_dir: = 1.0

func _process(delta: float) -> void :
	_timer -= delta
	if _timer > 0.0:
		return
	_timer = cooldown_of(cooldown)
	if holy:
		_spiral()
		return
	var n: = amount_of(count)
	var front: = signf(player.facing.x) if absf(player.facing.x) > 0.1 else 1.0
	for i in n:

		var side: = front if i % 2 == 0 else - front
		var dir: = Vector2(side * (0.25 + 0.15 * (i / 2) + randf() * 0.1), -1.0).normalized()
		var p: = fire_projectile(global_position, dir, 900.0, damage, pierce, Projectile.Style.AXE, area)
		p.motion = Projectile.Motion.ARC
		p.radius = 12.0
		p.lifetime = 2.0


func _spiral() -> void :
	var ring: = SPIRAL_BASE + SPIRAL_PER * amount_of(count)
	var start: = randf() * TAU
	_turn_dir = - _turn_dir
	for i in ring:
		var dir: = Vector2.RIGHT.rotated(start + TAU * i / ring)
		var p: = fire_projectile(global_position, dir, SPIRAL_SPEED, damage, 100000, Projectile.Style.AXE, area)
		p.motion = Projectile.Motion.SPIRAL
		p.turn = SPIRAL_TURN * _turn_dir
		p.radius = 14.0
		p.lifetime = 2.4
