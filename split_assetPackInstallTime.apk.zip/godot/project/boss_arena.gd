class_name BossArena
extends Node2D
















signal finished

const ENEMY: = preload("res://enemy.tscn")
const RISE_TIME: = 0.8
const DOUSE_TIME: = 0.6
const ESCAPE_WARN: = 10.0
const ESCAPE_TIME: = 0.6
const BAND: = 14.0
const BURN_GAP: = 0.4
const FULL_PX: = 4.0
const HALF_PX: = 2.5
const SMOKE_LIFE: = 0.9
const DEFAULT_FIRE: = Color(1, 0.4, 0.08)





const RISE_PURGE: = false
const PULL_SPEED: = 160.0
const HUNT_DELAY: = 1.5
const SNAP_SLACK: = 60.0

var _data: Dictionary
var _hp_mult: = 1.0
var _speed_mult: = 1.0
var _center: = Vector2.ZERO
var _start_radius: = 500.0
var _time_limit: = 120.0
var _spacing: = 24.0
var _burn: = 10.0
var _burn_out: = 20.0
var _radius: = 500.0
var _time: = 0.0
var _over_at: = -1.0
var _boss: Enemy
var _outside: = 0.0
var _hunt_told: = false
var _overlay: Node2D
var _angles: PackedFloat32Array = []
var _lit: PackedInt32Array = []
var _shown: PackedFloat32Array = []
var _touching: = {}
var _since_burn: = 99.0
var _smoke: Array = []
var _player: Player
var _fire: = DEFAULT_FIRE
var _frames: Array = []
var _half_frames: Array = []
var resume: = {}

func setup(data: Dictionary, center: Vector2, hp_mult: float, speed_mult: float) -> void :
	_data = data
	_center = center
	_hp_mult = hp_mult
	_speed_mult = speed_mult
	_start_radius = data.get("radius", _start_radius)
	_time_limit = data.get("time_limit", _time_limit)
	_spacing = data.get("spacing", _spacing)
	_burn = data.get("burn", _burn)
	_burn_out = data.get("burn_out", _burn_out)
	_radius = _start_radius


func save_state() -> Dictionary:
	if _over_at >= 0.0 or not is_instance_valid(_boss) or _boss.is_dead():
		return {}
	return {"center": _center, "hp_mult": _hp_mult, "speed_mult": _speed_mult, "time": _time, 
		"offset": _angles[0] if not _angles.is_empty() else 0.0, "lit": Array(_lit), 
		"boss_pos": _boss.global_position, "boss_hp": _boss.hp / maxf(_boss.max_hp, 0.001), 
		"outside": _outside, "hunt_told": _hunt_told}

func boss_name() -> String:
	return Game.theme.enemies.get(_data.get("boss", ""), {}).get("name", "")

func _ready() -> void :
	process_priority = 10
	Layers.put(self, Layers.BODIES)
	_player = get_tree().get_first_node_in_group("player") as Player
	_fire = Game.theme.ui.get("arena_fire", DEFAULT_FIRE)
	_overlay = Node2D.new()
	Layers.put(_overlay, Layers.ARENA_ARROWS)
	_overlay.draw.connect(_draw_way_back)
	add_child(_overlay)
	_frames = PixelFx.tinted("flame", _fire)
	_half_frames = PixelFx.tinted("flame", _fire.darkened(0.3).lerp(Color(0.85, 0.1, 0.05), 0.3))
	var n: = ceili(TAU * _start_radius / _spacing)
	var offset: = float(resume.get("offset", randf() * TAU))
	var saved_lit: Array = resume.get("lit", [])
	for i in n:
		_angles.append(offset + TAU * i / n)
		_lit.append(int(saved_lit[i]) if i < saved_lit.size() else 2)
		_shown.append(_lit[i] * 0.5 if not resume.is_empty() else 0.0)
	if resume.is_empty():
		Game.sfx("fire_rise")
	else:
		_time = maxf(float(resume.get("time", 0.0)), RISE_TIME)
		_outside = float(resume.get("outside", 0.0))
		_hunt_told = bool(resume.get("hunt_told", false))
	var enemies: Dictionary = Game.theme.enemies
	var boss_data: Dictionary = enemies.get(_data.get("boss", ""), {})
	if boss_data.is_empty():
		push_warning("boss entry names unknown enemy '%s'" % _data.get("boss", ""))
		_end()
		return
	_boss = ENEMY.instantiate() as Enemy
	_boss.configure(boss_data, _hp_mult, _speed_mult)
	_boss.global_position = _center + Vector2.RIGHT.rotated(randf() * TAU) * _start_radius * 0.6
	if not resume.is_empty():
		_boss.global_position = resume.get("boss_pos", _boss.global_position)
		_boss.hp_share = clampf(float(resume.get("boss_hp", 1.0)), 0.01, 1.0)
	_boss.died.connect(_on_boss_died)
	_boss.keep_near = func() -> bool: return _over_at < 0.0 and is_instance_valid(_player) and _player.global_position.distance_to(_center) > _radius
	add_child(_boss)
	_clear_stage.call_deferred()


func _clear_stage() -> void :
	if not RISE_PURGE:
		return
	for e: Enemy in get_tree().get_nodes_in_group("enemies"):
		if e == _boss or e.is_boss or not e.targetable or e.elite == "champion" or e.behavior == "sweep":
			continue
		if e.global_position.distance_squared_to(_center) <= _start_radius * _start_radius:
			e.burn_to_ash()
	RingFx.spawn(get_parent(), _center, _start_radius, _fire)
	Game.sfx("explode", 0.8)

func _process(delta: float) -> void :
	_time += delta
	_since_burn += delta
	_age_smoke(delta)
	queue_redraw()
	_overlay.queue_redraw()
	if _over_at >= 0.0:
		return
	var rise: = clampf(_time / RISE_TIME, 0.0, 1.0)
	for i in _lit.size():
		_shown[i] = move_toward(_shown[i], _lit[i] * 0.5 * rise, delta * 3.0)
	_keep_boss_inside(delta)
	_update_hunt(delta)
	_burn_player()
	if _time >= _time_limit:
		_escape()

func _flame_pos(i: int) -> Vector2:
	return _center + Vector2.RIGHT.rotated(_angles[i]) * _radius





func _burn_player() -> void :
	if not is_instance_valid(_player):
		return
	var off: = _player.global_position - _center
	var now: = {}
	if absf(off.length() - _radius) < BAND + _player.radius * 0.5:
		var ang: = off.angle()
		var reach: = (_player.radius * 0.7 + _spacing * 0.5) / maxf(_radius, 1.0)
		for i in _angles.size():
			if absf(angle_difference(ang, _angles[i])) <= reach:
				now[i] = true
	var entering: = _touching.is_empty() and not now.is_empty()
	var strongest: = 0
	for i: int in now:
		if not _touching.has(i) and _lit[i] > 0:
			strongest = maxi(strongest, _lit[i])
			_lit[i] -= 1
			_smoke.append([_flame_pos(i), 0.0, _lit[i] == 0])
	_touching = now
	if strongest == 0:
		return
	Game.sfx("fire_out" if strongest == 1 else "fire_hiss")
	if entering and _since_burn >= BURN_GAP:
		_since_burn = 0.0
		_player.take_hit((_burn if strongest == 2 else _burn_out) / Player.HIT_DAMAGE, false)

func _age_smoke(delta: float) -> void :
	for j in range(_smoke.size() - 1, -1, -1):
		_smoke[j][1] += delta
		if _smoke[j][1] >= SMOKE_LIFE:
			_smoke.remove_at(j)




func _keep_boss_inside(delta: float) -> void :
	if not is_instance_valid(_boss) or _boss.is_dead() or not is_instance_valid(_player):
		return
	if _player.global_position.distance_to(_center) > _radius:
		return
	var limit: = maxf(_radius - _boss.radius - 20.0, 0.0)
	var off: = _boss.global_position - _center
	if off.length() <= limit:
		return
	if off.length() <= limit + SNAP_SLACK:
		_boss.global_position = _center + off.limit_length(limit)
	else:
		_boss.global_position = _center + off.limit_length(off.length() - PULL_SPEED * delta)



func _update_hunt(delta: float) -> void :
	if not is_instance_valid(_boss) or _boss.is_dead() or not is_instance_valid(_player):
		return
	if _player.global_position.distance_to(_center) > _radius + BAND:
		_outside += delta
	else:
		_outside = 0.0
	var hunting: = _outside >= HUNT_DELAY
	if hunting and not _boss.hunt and not _hunt_told:
		_hunt_told = true
		var tip: Dictionary = Game.theme.devil_tips.get("arena_escape", {})
		var ui: = get_tree().get_first_node_in_group("blessing_screen")
		if not tip.is_empty() and not Game.dev_mode and Game.progress.stats.get("arena_tip", 0) == 0 and ui:
			Game.track("arena_tip")
			DevilTip.show_tip(ui.get_parent(), tip)
		var spawner: = get_parent()
		if spawner.has_method("show_banner"):
			spawner.show_banner("%s IS ENRAGED" % boss_name().to_upper(), "Get back in the ring!")
		Game.sfx("boss_spawn")
	_boss.hunt = hunting


func _escape() -> void :
	var spawner: = get_parent()
	if spawner.has_method("show_banner"):
		spawner.show_banner("%s ESCAPED" % boss_name().to_upper())
	if is_instance_valid(_boss) and not _boss.is_dead():
		_boss.hunt = false
		_boss.remove_from_group("enemies")
		_boss.set_process(false)
		var fade: = _boss.create_tween()
		fade.tween_property(_boss, "modulate:a", 0.0, ESCAPE_TIME)
		fade.tween_callback(_boss.queue_free)
	_douse()
	get_tree().create_timer(maxf(DOUSE_TIME, ESCAPE_TIME) + 0.1).timeout.connect(_end)

func _douse() -> void :
	_over_at = _time
	Game.sfx("fire_out")

func _on_boss_died(_enemy: Enemy) -> void :
	if _over_at >= 0.0:
		return
	Game.sfx("boss_die")
	_douse()
	get_tree().create_timer(DOUSE_TIME + 0.1).timeout.connect(_end)


func douse_for_win() -> void :
	if _over_at >= 0.0:
		return
	_douse()
	get_tree().create_timer(DOUSE_TIME + 0.1).timeout.connect(_end)

func _end() -> void :
	finished.emit()
	queue_free()


func _draw_way_back() -> void :
	if _over_at >= 0.0 or not is_instance_valid(_player) or _outside <= 0.0:
		return
	var to_center: = _center - _player.global_position
	var gap: = to_center.length() - _radius
	if gap <= BAND:
		return
	var dir: = to_center.normalized()
	var side: = dir.orthogonal()
	var beat: = 0.5 + 0.5 * sin(_time * 8.0)
	var c: = Color(_fire.lightened(0.25), 0.55 + 0.4 * beat)
	var base: = _overlay.to_local(_player.global_position) + dir * (95.0 + 10.0 * beat)
	for j in 2:
		var tip: = base + dir * (j * 26.0)
		var col: = Color(c, c.a * (0.6 + 0.4 * j))
		PixelFx.poly(_overlay, PackedVector2Array([tip + dir * 18.0, tip - dir * 8.0 + side * 22.0, tip - dir * 2.0]), Color(0, 0, 0, 0.5))
		PixelFx.poly(_overlay, PackedVector2Array([tip + dir * 16.0, tip - dir * 8.0 + side * 20.0, tip]), col)
		PixelFx.poly(_overlay, PackedVector2Array([tip + dir * 16.0, tip, tip - dir * 8.0 - side * 20.0]), col)

func _draw() -> void :
	var fade: = 1.0
	if _over_at >= 0.0:
		fade = 1.0 - clampf((_time - _over_at) / DOUSE_TIME, 0.0, 1.0)
	var flicker: = 1.0
	if _over_at < 0.0 and _time > _time_limit - ESCAPE_WARN:
		flicker = 0.45 + 0.55 * absf(sin(_time * 8.0))
	var glow: = Color(_fire.darkened(0.2), 0.4 * fade * flicker)
	var scorch: = Color(0.08, 0.06, 0.06, 0.55 * fade)
	for i in _angles.size():
		var p: = to_local(_flame_pos(i))
		var s: = _shown[i] * fade
		if _lit[i] == 0 and s < 0.05:

			PixelFx.dot(self, p, scorch, 4)
			if fmod(_time * 0.7 + i * 0.37, 1.0) < 0.25:
				PixelFx.dot(self, p + Vector2(-2, -2), Color(_fire, 0.6 * fade))
			continue
		var half: = s <= 0.55
		var px: = (HALF_PX if half else FULL_PX) * clampf(s / (0.5 if half else 1.0), 0.0, 1.0)
		if px < 0.3:
			continue
		var frames: = _half_frames if half else _frames
		var tex: Texture2D = frames[int(_time * 9.0 + i * 1.7) % frames.size()]
		var tall: = 0.8 + 0.45 * absf(sin(i * 12.9898))
		var sway: = tall * (0.88 + 0.12 * sin(_time * 11.0 + i * 2.3))
		var size: = tex.get_size() * px * Vector2(1.0, sway)
		PixelFx.dot(self, p, glow, 12 if not half else 6)
		PixelFx.dot(self, p, Color(_fire.lightened(0.3), glow.a * 1.4), 5 if not half else 3)
		draw_texture_rect(tex, Rect2(PixelFx.snap(p - Vector2(size.x * 0.5, size.y * 0.85)), size), false, 
			Color(1, 1, 1, (0.75 if half else 1.0) * flicker))
		if half:
			var rise: = fmod(_time * 26.0 + i * 13.0, 36.0)
			PixelFx.dot(self, p + Vector2(sin(_time * 3.0 + i) * 3.0, - size.y * 0.6 - rise), Color(0.35, 0.33, 0.33, 0.5 * (1.0 - rise / 36.0) * fade), 2)

	for puff: Array in _smoke:
		var t: float = puff[1] / SMOKE_LIFE
		var big: bool = puff[2]
		var base: = to_local(puff[0])
		for k in (7 if big else 4):
			var a: = k * 2.4
			var d: = Vector2(cos(a) * (6.0 + 18.0 * t), -12.0 - 50.0 * t - k * 4.0)
			var col: = Color(0.55, 0.52, 0.5, (0.7 if big else 0.5) * (1.0 - t))
			PixelFx.dot(self, base + d, col, 3 if big else 2)
		if t < 0.4:
			for k in 3:
				PixelFx.dot(self, base + Vector2((k - 1) * 9.0, -20.0 - 60.0 * t - k * 6.0), Color(_fire.lightened(0.4), 1.0 - t / 0.4))
