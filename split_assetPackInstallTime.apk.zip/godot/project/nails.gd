class_name Nails
extends Weapon






const ID: = "nails"
const COOLDOWN_TEXT: = "fires %d%% faster"
const SPEED: = 950.0
const SPREAD: = 0.09
const GAP: = 0.045
const CROSS_LEN: = 64.0
const CROSS_SHARE: = 0.6
const CROSS_SHOW: = 0.25
const BASE: = {"damage": 6.0, "cooldown": 1.25, "count": 3, "pierce": 1}
const UPGRADES: = [
	{"damage": 3.0}, 
	{"count": 1}, 
	{"cooldown": 0.85}, 
	{"pierce": 1}, 
	{"damage": 3.0}, 
	{"count": 1}, 
	{"damage": 4.0}, 
]
const HOLY: = {"damage": 4.0, "pierce": 1}

var damage: = 6.0
var cooldown: = 1.25
var count: = 3
var pierce: = 1
var _timer: = 0.5
var _queue: Array[float] = []
var _gap: = 0.0
var _crosses: Array[Dictionary] = []

func _on_level() -> void :
	Layers.put(self, Layers.FLYING)

func _process(delta: float) -> void :
	_timer -= delta
	if _timer <= 0.0:
		var targets: = enemies_on_screen()
		if not targets.is_empty():
			_timer = cooldown_of(cooldown)
			var aim: = global_position.direction_to((targets.pick_random() as Enemy).global_position).angle()
			var n: = amount_of(count)
			for i in n:
				_queue.append(aim + (i - (n - 1) / 2.0) * SPREAD)
			_gap = 0.0
	if not _queue.is_empty():
		_gap -= delta
		if _gap <= 0.0:
			_fire(_queue.pop_front())
			_gap = GAP
	if not _crosses.is_empty():
		for c in _crosses:
			c["t"] += delta
		_crosses = _crosses.filter( func(c: Dictionary) -> bool: return c["t"] < CROSS_SHOW)
		queue_redraw()

func _fire(angle: float) -> void :
	var p: = fire_projectile(global_position, Vector2.RIGHT.rotated(angle), SPEED, damage, pierce, Projectile.Style.NAIL)
	p.lifetime = 1.1
	p.radius = 6.0
	if holy:
		p.on_hit = _cross
	Game.sfx("dodge", randf_range(1.5, 1.7))



func _cross(struck: Enemy) -> void :
	var at: = struck.global_position
	var arm: = CROSS_LEN * player.area
	var half: = 14.0
	var turn: = randf() * PI * 0.5
	var dirs: = [Vector2.RIGHT.rotated(turn), Vector2.DOWN.rotated(turn)]
	for e: Enemy in Enemy.near(at, arm + half):
		if e == struck:
			continue
		var to: = e.global_position - at
		for d: Vector2 in dirs:
			if absf(to.dot(d)) <= arm and absf(to.dot(d.orthogonal())) <= half + e.radius * 0.5:
				e.take_damage(power(damage) * CROSS_SHARE, 0.0)
				break
	_crosses.append({"at": at, "t": 0.0, "angle": turn})

func _draw() -> void :
	var arm: = CROSS_LEN * player.area
	for c in _crosses:
		var k: float = c["t"] / CROSS_SHOW
		var at: = to_local(c["at"])
		var d: = Vector2.RIGHT.rotated(c["angle"])
		var reach: = arm * minf(1.0, k * 3.0)
		for v: Vector2 in [d, d.orthogonal()]:
			PixelFx.line(self, at - v * reach, at + v * reach, Color(color, 0.5 * (1.0 - k)), 12.0)
			PixelFx.line(self, at - v * reach, at + v * reach, Color(1, 1, 1, 0.9 * (1.0 - k)), 4.0)
