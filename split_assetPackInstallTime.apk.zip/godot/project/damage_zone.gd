class_name DamageZone
extends Node2D




const TICK: = 0.4
const GROW_TIME: = 0.15



const FOLLOW_SPEED: = 110.0
const GROW_EVERY: = 140.0
const GROW_STEP: = 1.12
const GROW_STEPS: = 4

var radius: = 60.0
var damage: = 6.0
var duration: = 2.5
var color: = Color.WHITE
var _player: Player
var _time: = 0.0
var _tick: = 0.0
var _drops: = PackedVector2Array()
var _frames: Array = []
var _baked: = false
var _variant: = 0
var follow: Node2D = null
var _moved: = 0.0
var _steps: = 0

func _ready() -> void :
	Layers.put(self, Layers.GROUND_EFFECTS)
	_player = get_tree().get_first_node_in_group("player") as Player
	_tick = randf() * 0.1
	_variant = randi() % PixelFx.POOL_VARIANTS
	for i in 7:
		_drops.append(Vector2.RIGHT.rotated(randf() * TAU) * randf_range(1.0, 1.5))

func _process(delta: float) -> void :
	_time += delta
	if _time >= duration:
		queue_free()
		return
	queue_redraw()
	if is_instance_valid(follow):
		_follow(delta)
	_tick -= delta
	if _tick > 0.0:
		return
	_tick = TICK
	for e: Enemy in Enemy.near(global_position, radius):
		var reach: = radius + e.radius * 0.5
		if global_position.distance_squared_to(e.global_position) < reach * reach:
			e.take_damage(damage, 0.0)

func _follow(delta: float) -> void :
	var to: = follow.global_position - global_position
	if to.length() < radius * 0.4:
		return
	var step: = minf(FOLLOW_SPEED * delta, to.length())
	global_position += to.normalized() * step
	_moved += step
	if _moved >= GROW_EVERY and _steps < GROW_STEPS:
		_moved -= GROW_EVERY
		_steps += 1
		radius *= GROW_STEP
		_baked = false




func _draw() -> void :
	var grow: = clampf(_time / GROW_TIME, 0.0, 1.0)
	var fade: = clampf((duration - _time) / 0.3, 0.0, 1.0)
	var hot: = color.lightened(0.55)
	if _time < 0.3:
		var t: = _time / 0.3
		for d: Vector2 in _drops:
			PixelFx.dot(self, d * radius * (0.6 + 0.5 * t), Color(hot, 1.0 - t), 2 if t < 0.5 else 1)
	if not _baked:
		_frames = PixelFx.pool_frames(radius, color, _variant)
		_baked = not _frames.is_empty() and _frames[0].get_width() * PixelFx.PIXEL == PixelFx.pool_size(radius)
	if not _frames.is_empty():
		var tex: Texture2D = _frames[int(_time * 2.5) % _frames.size()]
		var size: = Vector2.ONE * PixelFx.pool_size(radius) * (0.5 + 0.5 * grow)
		draw_texture_rect(tex, Rect2(PixelFx.snap( - size * 0.5), size), false, Color(1, 1, 1, fade))
	if grow < 1.0:
		return

	for i in 6:
		var life: = fmod(_time * 0.9 + i * 0.37, 1.0)
		var a: = i * 2.399 + floorf(_time * 0.9 + i * 0.37) * 1.3
		var p: = Vector2.RIGHT.rotated(a) * radius * (0.12 + 0.5 * fmod(i * 0.618, 1.0))
		if life < 0.45:
			PixelFx.dot(self, p, Color(hot, fade))
		elif life < 0.8:
			PixelFx.dot(self, p, Color(hot, fade), 2)
			PixelFx.dot(self, p + Vector2( - PixelFx.PIXEL, - PixelFx.PIXEL) * 0.5, Color(1, 1, 1, 0.8 * fade))
		else:
			var spread: = PixelFx.PIXEL * (1.5 + 6.0 * (life - 0.8))
			for k in 4:
				PixelFx.dot(self, p + Vector2.RIGHT.rotated(k * PI / 2 + 0.785) * spread, Color(hot, (1.0 - life) * 5.0 * fade))
