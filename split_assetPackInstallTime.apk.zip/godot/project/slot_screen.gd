class_name SlotScreen
extends Control

















const UNROLL: = 0.45
const BOON_STOP: = 1.15
const PRICE_STOP: = 1.75
const RESULT_DELAY: = 0.25
const SIGN_TIME: = 1.0
const WALK_TIME: = 0.45


const FACE_POS: = Vector2(360, 76)
const FACE_SCALE: = 14.0
const PAPER: = Rect2(78, 548, 564, 436)
const BOON_Y: = 634.0
const PRICE_Y: = 810.0
const LAWYER_POS: = Vector2(66, 420)
const LAWYER_SCALE: = 6.0
const PAPER_PX: = 4
const CLAW_SCALE: = 5.0
const WATCH_SCALE: = 6.0
const BUBBLE: = Rect2(404, 92, 296, 0)
const BUBBLE_FONT: = 25
const TYPE_SPEED: = 0.035
const PARCH: = Color(0.92, 0.83, 0.63)
const INK: = Color(0.28, 0.14, 0.08)
const BLOOD: = Color(0.72, 0.04, 0.06)

var _player: Player
var _boons: Array = []
var _prices: Array = []
var _boon: = ""
var _price: = ""
var _voided: = false
var _rerolled: = false
var _t: = 0.0
var _void_t: = -1.0
var _end_t: = -1.0
var _signed: = false
var _result_shown: = false
var _boon_landed: = false
var _price_landed: = false
var _boon_roll: = Vector2.ZERO
var _price_roll: = Vector2.ZERO
var _flash: = 0.0
var _flash_color: = Color.WHITE
var _shake: = Vector2.ZERO
var _particles: Array[Dictionary] = []
var _ember_clock: = 0.0
var _box: VBoxContainer
var _busy: = false
var _oy: = 0.0

var _paper_tex: Texture2D
var _shade_tex: Texture2D
var _height: = PackedFloat32Array()
var _warp: = PackedFloat32Array()
var _drips: Array[Vector2] = []

var _wait: = 0.0
var _act: = ""
var _act_t: = 0.0
var _act_len: = 0.0
var _next_act: = 1.0
var _last_mood: = ""
var _line: = ""
var _decks: = {}
var _blink_in: = 2.0
var _blink: = 0.0
var _drool_t: = -1.0

func _ready() -> void :
	hide()
	add_to_group("slot_screen")
	add_to_group("pause_screen")
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_STOP
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	set_anchors_preset(Control.PRESET_FULL_RECT)
	_player = get_tree().get_first_node_in_group("player") as Player
	_box = VBoxContainer.new()
	_box.size = Vector2(640, 260)
	_box.add_theme_constant_override("separation", 12)
	add_child(_box)


func open() -> void :
	_oy = Game.design_offset()
	_box.position = Vector2(40, 1000 + _oy)
	_boons = Game.PACTS.keys()
	_prices = Game.PRICES.keys()
	_voided = false
	_rerolled = false
	_busy = false
	_particles.clear()
	_drips.clear()
	_decks.clear()
	_last_mood = ""
	_bake_paper()
	_roll("")
	Game.sfx("chest_spawn")
	show()
	get_tree().paused = true


func _roll(exclude_boon: String) -> void :
	_boon = _boons.filter( func(id: String) -> bool: return id != exclude_boon).pick_random()
	_price = Game.roll_pact_price(_boon)
	_boon_roll = _reel(_boons, _boon, 8.0)
	_price_roll = _reel(_prices, _price, 11.0)
	_t = 0.0
	_void_t = -1.0
	_end_t = -1.0
	_signed = false
	_result_shown = false
	_boon_landed = false
	_price_landed = false
	_act = ""
	_line = ""
	_wait = 0.0
	_next_act = 1.0
	_clear_box()
	Game.sfx("slot_spin")


func _reel(list: Array, id: String, travel: float) -> Vector2:
	var n: = list.size()
	var start: = randf() * n
	var idx: = list.find(id)
	return Vector2(start, idx + n * ceilf((start + travel + randf() * 3.0 - idx) / n))


func _rolling_id(list: Array, roll: Vector2, stop: float) -> String:
	var k: = clampf((_t - UNROLL) / (stop - UNROLL), 0.0, 1.0)
	var p: = lerpf(roll.x, roll.y, 1.0 - pow(1.0 - k, 3.0))
	return list[posmod(floori(p + 0.001), list.size())]

func _clear_box() -> void :
	for c in _box.get_children():
		_box.remove_child(c)
		c.queue_free()

func _gui_input(event: InputEvent) -> void :
	if event is InputEventMouseButton and event.pressed and not _result_shown and _t > 0.3:
		_t = maxf(_t, PRICE_STOP)

func _process(delta: float) -> void :
	if not visible:
		return
	_t += delta
	_flash = maxf(_flash - delta * 2.0, 0.0)
	_shake = _shake.move_toward(Vector2.ZERO, 110.0 * delta)
	if not _boon_landed and _t >= BOON_STOP:
		_boon_landed = true
		_land(BOON_Y)
	if not _price_landed and _t >= PRICE_STOP:
		_price_landed = true
		_land(PRICE_Y)
		_start_act("lick")
	_update_blink(delta)
	if _act != "":
		_act_t += delta
		if _act_t >= _act_len:
			_act = ""
			_next_act = _wait + randf_range(1.0, 2.2)
	if _result_shown and _end_t < 0.0 and (_void_t < 0.0 or _void_t > 2.4):
		_act_update(delta)
	if _drool_t >= 0.0:
		_drool_t += delta
		if _drool_t >= 1.3:
			_drool_t = -1.0
			_drips.append(Vector2(_mouth_corner().x + randf_range(-6, 6), PAPER.position.y + randf_range(60.0, 160.0)))
	if _price_landed and not _result_shown and _t >= PRICE_STOP + RESULT_DELAY and _end_t < 0.0:
		_show_buttons()
	if _void_t >= 0.0:
		var before: = _void_t
		_void_t += delta
		if before < 0.55 and _void_t >= 0.55:
			_shake = Vector2(randf_range(-1, 1), 1).normalized() * 16.0
			_flash = 0.35
			_flash_color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
			_burst(Vector2(360, PRICE_Y + 50), 34, BLOOD, 520.0)
			Game.sfx("explode", 1.35)
		if before < 1.2 and _void_t >= 1.2 and _end_t < 0.0:
			_show_buttons()
	if _end_t >= 0.0:
		var before: = _end_t
		_end_t += delta
		if _signed and before < 0.55 and _end_t >= 0.55:
			_flash = 0.9
			_flash_color = BLOOD.lightened(0.2)
			_shake = Vector2(randf_range(-1, 1), randf_range(-1, 1)).normalized() * 12.0
			_burst(PAPER.get_center(), 70, Color(1, 0.45, 0.1), 900.0)
			Game.sfx("jackpot")
		if _end_t >= (SIGN_TIME if _signed else WALK_TIME):
			_close()
			return

	_ember_clock += delta
	while _ember_clock > 0.05:
		_ember_clock -= 0.05
		var life: = randf_range(1.2, 2.6)
		_particles.append({"pos": Vector2(randf() * 720.0, 1300.0), "vel": Vector2(randf_range(-20, 20), randf_range(-260, -120)), 
			"life": life, "max": life, "color": Color(1, randf_range(0.3, 0.6), 0.1), "size": randf_range(2.0, 4.5), "g": -40.0})
	for p in _particles:
		p["life"] -= delta
		p["vel"] = (p["vel"] as Vector2) * (1.0 - 1.2 * delta) + Vector2(0, p["g"]) * delta
		p["pos"] = (p["pos"] as Vector2) + (p["vel"] as Vector2) * delta
	_particles = _particles.filter( func(p: Dictionary) -> bool: return p["life"] > 0.0)
	queue_redraw()

func _land(row_y: float) -> void :
	Game.sfx("slot_stop", 1.0 if row_y == BOON_Y else 0.8)
	_shake = Vector2(randf_range(-1, 1), randf_range(-1, 1)).normalized() * 7.0
	_burst(Vector2(146, row_y + 46), 12, Game.theme.ui["accent"])

func _burst(at: Vector2, count: int, tint: Color, speed: = 420.0) -> void :
	for i in count:
		var life: = randf_range(0.5, 1.2)
		_particles.append({"pos": at, "vel": Vector2.RIGHT.rotated(randf() * TAU) * randf_range(100.0, speed), 
			"life": life, "max": life, "color": tint if randf() < 0.7 else Color(1, 0.85, 0.4), "size": randf_range(3.0, 7.0), "g": 500.0})



func _show_buttons() -> void :
	_result_shown = true
	_clear_box()
	var words: Dictionary = Game.theme.pact_words
	var sign: = _button(words["sign"], BLOOD.lightened(0.25), _sign, 92, 38)
	(sign.get_theme_stylebox("normal") as StyleBoxFlat).bg_color = BLOOD.darkened(0.45)
	_box.add_child(sign)
	if Ads.can_show() and not _voided:
		var row: = HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		var holy: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
		var lawyer: = _button(words["lawyer"] + "\n(watch a video)", holy, _hire_lawyer, 88, 27)
		lawyer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(lawyer)
		if not _rerolled:
			var reroll: = _button(words["reroll"] + "\n(watch a video)", Color(1, 1, 1, 0.7), _reroll, 88, 27)
			reroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			row.add_child(reroll)
		_box.add_child(row)
	var walk: = _button(words["walk"], Color(1, 1, 1, 0.0), _walk_away, 56, 28)
	walk.add_theme_color_override("font_color", Color(1, 1, 1, 0.6))
	_box.add_child(walk)
	for c in _box.get_children():
		c.modulate.a = 0.0
		c.create_tween().tween_property(c, "modulate:a", 1.0, 0.2)

func _button(label: String, border: Color, action: Callable, height: float, font_size: int) -> Button:
	var b: = Button.new()
	b.text = label
	b.custom_minimum_size = Vector2(0, height)
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", font_size)
	var panel: Color = Game.theme.ui["panel"]
	for state: String in ["normal", "hover", "pressed", "disabled"]:
		var style: = StyleBoxFlat.new()
		style.bg_color = panel if state != "pressed" else panel.lightened(0.15)
		if border.a == 0.0:
			style.bg_color = Color(0, 0, 0, 0)
		style.border_color = border
		style.set_border_width_all(3)
		style.set_corner_radius_all(12)
		b.add_theme_stylebox_override(state, style)
	b.pressed.connect( func() -> void :
		Game.sfx("click")
		action.call())
	return b

func _sign() -> void :
	if _busy or _end_t >= 0.0:
		return
	Game.sfx("select")
	_signed = true
	_end_t = 0.0
	_act = ""
	_clear_box()

func _walk_away() -> void :
	if _busy or _end_t >= 0.0:
		return
	_signed = false
	_end_t = 0.0
	_act = ""
	_clear_box()

func _close() -> void :
	hide()
	if _signed:
		_player.set_pact(_boon, "" if _voided else _price)
	LevelUpScreen.resume_if_clear(get_tree())

func _hire_lawyer() -> void :
	if _busy:
		return
	_busy = true
	Ads.show_rewarded( func(earned: bool) -> void :
		_busy = false
		if earned and visible:
			_voided = true
			_void_t = 0.0
			_act = ""
			_clear_box()
			Game.sfx("chest_spawn", 1.3))

func _reroll() -> void :
	if _busy:
		return
	_busy = true
	Ads.show_rewarded( func(earned: bool) -> void :
		_busy = false
		if earned and visible:
			_rerolled = true
			_roll(_boon))



func _update_blink(delta: float) -> void :
	if _blink > 0.0:
		_blink -= delta
		return
	_blink_in -= delta
	if _blink_in <= 0.0:
		_blink = 0.13
		_blink_in = randf_range(1.8, 4.5) if randf() > 0.2 else 0.25



func _act_update(delta: float) -> void :
	_wait += delta
	if _act == "" and _wait >= _next_act:
		_start_act(_pick_act())

func _pick_act() -> String:
	var options: Array
	if _voided:
		options = ["indecisive", "watch", "drum", "slow"]
	elif _wait < 7.0:
		options = ["greedy", "scared", "greedy", "drum", "lick"]
	elif _wait < 15.0:
		options = ["slow", "bored", "yawn", "watch", "drum"]
	else:
		options = ["indecisive", "slow", "watch", "yawn", "scared", "drum", "indecisive"]
	options = options.filter( func(o: String) -> bool: return o != _last_mood)
	var pick: String = options.pick_random()
	_last_mood = pick
	return pick


func _start_act(kind: String) -> void :
	_act_t = 0.0
	_line = ""
	match kind:
		"yawn":
			_act = "yawn"
			_act_len = 1.9
		"watch":
			_act = "watch"
			_act_len = 3.0
			_line = _next_line("watch")
		"drum":
			_act = "drum"
			_act_len = 1.8
		"lick":
			_act = "lick"
			_act_len = 1.4
			_drool_t = 0.0
		_:
			_line = _next_line(kind)
			if _line == "":
				return
			_act = "talk"
			_act_len = 0.4 + _line.length() * TYPE_SPEED + 1.7
			if kind == "greedy" or kind == "scared":
				Game.sfx("laugh", 1.45, -14.0)


func _next_line(mood: String) -> String:
	var lines: Array = Game.theme.pact_taunts.get(mood, [])
	if lines.is_empty():
		return ""
	var deck: Array = _decks.get(mood, [])
	if deck.is_empty():
		deck = lines.duplicate()
		deck.shuffle()
	var line: String = deck.pop_back()
	_decks[mood] = deck
	return line


func _watch_raise() -> float:
	if _act != "watch":
		return 0.0
	var up: = clampf(_act_t / 0.35, 0.0, 1.0)
	var down: = clampf((_act_len - _act_t) / 0.35, 0.0, 1.0)
	var k: = minf(up, down)
	return k * k * (3.0 - 2.0 * k)


func _mouth_corner() -> Vector2:
	var tex: = Game.theme.texture("pact_devil")
	var size: = tex.get_size() * FACE_SCALE
	return FACE_POS + Vector2( - size.x / 2.0, _devil_bob(false, false)) + Vector2(21.5, 27.5) * FACE_SCALE





func _bake_paper() -> void :
	var w: = int(PAPER.size.x) / PAPER_PX
	var h: = int(PAPER.size.y) / PAPER_PX
	var creases: = FastNoiseLite.new()
	creases.seed = randi()
	creases.noise_type = FastNoiseLite.TYPE_CELLULAR
	creases.cellular_return_type = FastNoiseLite.RETURN_DISTANCE2_SUB
	creases.frequency = 0.05
	var bulge: = FastNoiseLite.new()
	bulge.seed = randi()
	bulge.frequency = 0.035
	var grain: = FastNoiseLite.new()
	grain.seed = randi()
	grain.frequency = 0.12

	_height.resize(w * h)
	_warp.resize(w * h)
	var sum: = 0.0
	for y in h:
		for x in w:
			var v: = creases.get_noise_2d(x, y * 1.3) * 0.9 + bulge.get_noise_2d(x, y) * 0.7
			_height[y * w + x] = v
			_warp[y * w + x] = bulge.get_noise_2d(x, y) * 2.2
			sum += v
	var mean: = sum / (w * h)
	var sq: = 0.0
	for i in _height.size():
		_height[i] -= mean
		sq += _height[i] * _height[i]
	var sd: = maxf(sqrt(sq / _height.size()), 0.0001)
	for i in _height.size():
		_height[i] /= sd

	var left: = PackedInt32Array()
	var right: = PackedInt32Array()
	left.resize(h)
	right.resize(h)
	var l: = 2
	var r: = 2
	for y in h:
		l = clampi(l + randi_range(-1, 1), 0, 4)
		r = clampi(r + randi_range(-1, 1), 0, 4)
		left[y] = l
		right[y] = r
	for side: PackedInt32Array in [left, right]:
		for n in randi_range(2, 3):
			var y0: = randi_range(8, h - 9)
			var depth: = randi_range(5, 9)
			var half: = randi_range(2, 5)
			for y in range(y0 - half, y0 + half + 1):
				side[y] = maxi(side[y], roundi(depth * (1.0 - absf(y - y0) / float(half + 1))))

	var light: = PackedFloat32Array()
	light.resize(w * h)
	for y in h:
		for x in w:
			var hx: = _height[y * w + mini(x + 1, w - 1)] - _height[y * w + maxi(x - 1, 0)]
			var hy: = _height[mini(y + 1, h - 1) * w + x] - _height[maxi(y - 1, 0) * w + x]
			light[y * w + x] = - hx * 0.8 - hy * 0.6
	var sorted: = light.duplicate()
	sorted.sort()
	var t_deep: = sorted[int(sorted.size() * 0.08)]
	var t_dark: = sorted[int(sorted.size() * 0.26)]
	var t_lit: = sorted[int(sorted.size() * 0.86)]
	var paper: = Image.create_empty(w, h, false, Image.FORMAT_RGBA8)
	var shade: = Image.create_empty(w, h, false, Image.FORMAT_RGBA8)
	var stains: Array = []
	for i in 3:
		stains.append([Vector2(randf_range(10, w - 10), randf_range(8, h - 8)), randf_range(4.0, 9.0)])
	var crisp: = Color(0.36, 0.18, 0.07)
	var burnt: = Color(0.55, 0.32, 0.13)
	var singe: = Color(0.76, 0.58, 0.34)
	for y in h:
		for x in w:
			var edge: = mini(x - left[y], w - 1 - right[y] - x)
			if edge < 0:
				continue
			var c: = PARCH
			var g: = grain.get_noise_2d(x, y)
			if g > 0.25:
				c = PARCH.lightened(0.05)
			elif g < -0.3:
				c = PARCH.darkened(0.07)
			for s: Array in stains:
				var d: = Vector2(x, y).distance_to(s[0])
				if absf(d - s[1]) < 0.8:
					c = c.lerp(Color(0.62, 0.38, 0.22), 0.35)
				elif d < s[1]:
					c = c.lerp(Color(0.7, 0.52, 0.3), 0.08)
			if edge == 0:
				c = crisp
			elif edge == 1:
				c = burnt
			elif edge == 2:
				c = singe
			paper.set_pixel(x, y, c)
			var lv: = light[y * w + x]
			var sc: = Color(0, 0, 0, 0)
			if lv <= t_deep:
				sc = Color(0.28, 0.13, 0.04, 0.34)
			elif lv <= t_dark:
				sc = Color(0.28, 0.13, 0.04, 0.17)
			elif lv >= t_lit:
				sc = Color(1, 0.97, 0.88, 0.15)
			if edge >= 0 and edge < 3:
				sc.a *= 0.5
			shade.set_pixel(x, y, sc)
	_paper_tex = ImageTexture.create_from_image(paper)
	_shade_tex = ImageTexture.create_from_image(shade)


func _crumple(p: Vector2) -> float:
	var w: = int(PAPER.size.x) / PAPER_PX
	var h: = int(PAPER.size.y) / PAPER_PX
	var x: = int((p.x - PAPER.position.x) / PAPER_PX)
	var y: = int((p.y - PAPER.position.y) / PAPER_PX)
	if x < 0 or y < 0 or x >= w or y >= h or _warp.is_empty():
		return 0.0
	return _warp[y * w + x]




func _ink(text: String, pos: Vector2, font_size: int, color: Color, width: = -1.0, align: = HORIZONTAL_ALIGNMENT_LEFT) -> void :
	var font: = ThemeDB.fallback_font
	var x: = pos.x
	if width > 0.0 and align != HORIZONTAL_ALIGNMENT_LEFT:
		var tw: = font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
		x += (width - tw) * (0.5 if align == HORIZONTAL_ALIGNMENT_CENTER else 1.0)
	var base: = Vector2(0, _oy) + _shake
	for i in text.length():
		var ch: = text.unicode_at(i)
		var cw: = font.get_char_size(ch, font_size).x
		var mid: = Vector2(x + cw / 2.0, pos.y - font_size * 0.3)
		var hgt: = _crumple(mid)
		var slope: = (_crumple(mid + Vector2(12, 0)) - _crumple(mid - Vector2(12, 0))) / 24.0
		var at: = Vector2(x, pos.y + hgt * 3.0)
		draw_set_transform_matrix(Transform2D(clampf(slope * 3.0, -0.06, 0.06), base + at))
		var a: = color.a * (0.86 + 0.14 * sin(i * 2.3 + pos.y))
		draw_char(font, Vector2(1, 1), String.chr(ch), font_size, Color(color.darkened(0.4), a * 0.22))
		draw_char(font, Vector2.ZERO, String.chr(ch), font_size, Color(color, a))
		x += cw
	draw_set_transform(base)


func _wrap(text: String, width: float, font_size: int, max_lines: = 2) -> PackedStringArray:
	var font: = ThemeDB.fallback_font
	var out: = PackedStringArray()
	var line: = ""
	for word in text.split(" "):
		var test: = word if line == "" else line + " " + word
		if line != "" and font.get_string_size(test, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x > width and out.size() < max_lines - 1:
			out.append(line)
			line = word
		else:
			line = test
	if line != "":
		out.append(line)
	return out



func _draw() -> void :
	var view: = get_viewport_rect().size
	draw_rect(Rect2(Vector2.ZERO, view), Color(0.05, 0.0, 0.01, 0.9))
	draw_set_transform(Vector2(0, _oy) + _shake)
	var accent: Color = Game.theme.ui["accent"]

	for i in 6:
		draw_circle(Vector2(360, 330), 420.0 - i * 60.0, Color(accent.darkened(0.3), 0.05 + 0.02 * i))
	_draw_devil()
	_draw_watch_arm()
	_draw_paper()
	_draw_claws()
	_draw_drool()
	_draw_lawyer()
	_draw_bubble()
	draw_set_transform(Vector2(0, _oy))
	var font: = ThemeDB.fallback_font
	var pulse: = 0.5 + 0.5 * sin(_t * 5.0)
	var title: String = Game.theme.pact_title
	draw_string_outline(font, Vector2(0, 62), title, HORIZONTAL_ALIGNMENT_CENTER, 720, 50 + int(4 * pulse), 14, Color(0.15, 0.0, 0.0))
	draw_string(font, Vector2(0, 62), title, HORIZONTAL_ALIGNMENT_CENTER, 720, 50 + int(4 * pulse), accent.lerp(Color.WHITE, 0.35 * pulse))
	if not _result_shown and _t > 0.3 and _t < PRICE_STOP:
		draw_string(font, Vector2(0, 1030), "tap to skip", HORIZONTAL_ALIGNMENT_CENTER, 720, 24, Color(1, 1, 1, 0.45))
	for p in _particles:
		var a: float = p["life"] / p["max"]
		draw_circle(p["pos"], p["size"] * (0.4 + 0.6 * a), Color(p["color"], a))
	draw_set_transform(Vector2.ZERO)
	if _flash > 0.0:
		draw_rect(Rect2(Vector2.ZERO, view), Color(_flash_color, minf(_flash, 1.0) * 0.7))


func _draw_devil() -> void :
	if not Game.theme.sprites.has("pact_devil"):
		return
	var mad: = (_void_t >= 0.6) or (_end_t >= 0.0 and not _signed)
	var laugh: = _signed and _end_t >= 0.0 and not _voided
	var face: = "pact_devil_mad" if mad else _face()
	if not Game.theme.sprites.has(face):
		face = "pact_devil"
	var tex: = Game.theme.texture(face)
	var bob: = _devil_bob(mad, laugh)
	var size: = tex.get_size() * FACE_SCALE
	var stretch: = 1.0
	if _act == "yawn":
		stretch = 1.0 + 0.07 * sin(PI * clampf(_act_t / _act_len, 0.0, 1.0))
	var pos: = FACE_POS + Vector2( - size.x / 2.0, bob - size.y * (stretch - 1.0) * 0.5)
	var rect: = Rect2(pos, Vector2(size.x, size.y * stretch))
	draw_texture_rect(tex, Rect2(rect.position + Vector2(10, 14), rect.size), false, Color(0, 0, 0, 0.45))
	draw_texture_rect(tex, rect, false)
	if face.contains("blink") or face == "pact_devil_yawn":
		return

	var glow: = (0.55 + 0.45 * sin(_t * 4.0)) * (0.45 if face == "pact_devil_bored" else 1.0)
	var eye_color: = Color(1, 0.3, 0.1) if mad else Color(1, 0.85, 0.3)
	for cx: float in [9.5, tex.get_width() - 9.5]:
		var c: = pos + Vector2(cx, 13.5) * FACE_SCALE
		draw_circle(c, 46.0, Color(eye_color, 0.12 * glow))
		draw_circle(c, 26.0, Color(eye_color, 0.18 * glow))


func _face() -> String:
	if _signed and _end_t >= 0.0:
		return "pact_devil"
	var blink: = _blink > 0.0
	match _act:
		"yawn":
			return "pact_devil_yawn"
		"lick":
			return "pact_devil_lick"
		"watch":
			return "pact_devil_look" if _watch_raise() > 0.6 else ("pact_devil_blink" if blink else "pact_devil")
		"talk":
			var talking: = _act_t < 0.3 + _line.length() * TYPE_SPEED
			if talking and fmod(_act_t, 0.16) < 0.08:
				return "pact_devil_talk"
	if _result_shown and _wait > 7.0 and (_act == "" or _act == "drum"):
		return "pact_devil_bored_blink" if blink else "pact_devil_bored"
	return "pact_devil_blink" if blink else "pact_devil"

func _devil_bob(mad: bool, laugh: bool) -> float:
	if laugh:
		return - absf(sin(_end_t * 22.0)) * 14.0
	return sin(_t * 1.8) * 6.0 + (sin(_t * 40.0) * 2.5 if mad else 0.0)



func _draw_claws() -> void :
	if not Game.theme.sprites.has("pact_claw"):
		return
	var claw: = Game.theme.texture(_claw_frame(0))
	var cs: = claw.get_size() * CLAW_SCALE
	var y: = PAPER.position.y - cs.y * 0.52 + sin(_t * 1.8) * 2.0
	var lift: = _watch_raise()
	if lift < 0.05:
		draw_texture_rect(claw, Rect2(Vector2(PAPER.position.x - 30, y), cs), false)
	var right: = Game.theme.texture(_claw_frame(2))
	draw_set_transform(Vector2(PAPER.end.x + 30, _oy + y) + _shake, 0.0, Vector2(-1, 1))
	draw_texture_rect(right, Rect2(Vector2.ZERO, cs), false)
	draw_set_transform(Vector2(0, _oy) + _shake)


func _claw_frame(offset: int) -> String:
	if _act != "drum" or not Game.theme.sprites.has("pact_claw/2"):
		return "pact_claw"
	var beat: = (int(_act_t * 9.0) + offset) % 4
	return ["pact_claw", "pact_claw/2", "pact_claw", "pact_claw/3"][beat]


func _draw_watch_arm() -> void :
	var k: = _watch_raise()
	if k <= 0.0 or not Game.theme.sprites.has("pact_watch"):
		return
	var tex: = Game.theme.texture("pact_watch")
	var size: = tex.get_size() * WATCH_SCALE
	var low: = Vector2(PAPER.position.x + 70, PAPER.position.y + 140)
	var high: = Vector2(190, 300)
	var tap: = 0.0
	if _act_t > 0.9 and _act_t < 1.7:
		tap = absf(sin((_act_t - 0.9) * TAU * 2.5)) * 10.0
		if fmod(_act_t - 0.9, 0.4) < 0.02:
			Game.sfx("click", 2.2, -6.0)
	var at: = low.lerp(high, k) + Vector2(0, tap)
	draw_set_transform(at + Vector2(0, _oy) + _shake, 0.35 * k, Vector2.ONE)
	draw_texture_rect(tex, Rect2( - size.x / 2.0, 0, size.x, size.y), false)
	draw_set_transform(Vector2(0, _oy) + _shake)


func _draw_drool() -> void :
	if _drool_t < 0.0:
		return
	var spit: = Color(0.85, 0.95, 1.0, 0.95)
	var at: = _mouth_corner()
	if _drool_t < 0.7:
		var k: = _drool_t / 0.7
		draw_line(at, at + Vector2(0, 30.0 * k), Color(spit, 0.7), 4.0)
		draw_circle(at + Vector2(0, 30.0 * k), 4.0 + 5.0 * k, spit)
		draw_circle(at + Vector2(-2, 28.0 * k), 2.0, Color.WHITE)
	else:
		var f: = _drool_t - 0.7
		var y: = at.y + 30.0 + 900.0 * f * f
		draw_circle(Vector2(at.x, y), 8.0, spit)
		draw_circle(Vector2(at.x - 2, y - 2), 2.5, Color.WHITE)



func _draw_bubble() -> void :
	if _line == "" or (_act != "talk" and _act != "watch"):
		return
	var start: = 0.15 if _act == "talk" else 0.6
	var t: = _act_t - start
	if t < 0.0 or _act_t > _act_len - 0.1:
		return
	var font: = ThemeDB.fallback_font
	var lines: = _wrap(_line, BUBBLE.size.x - 32.0, BUBBLE_FONT, 3)
	var box: = Rect2(BUBBLE.position, Vector2(BUBBLE.size.x, 26.0 + lines.size() * 30.0))
	var pop: = minf(t / 0.12, 1.0)
	draw_set_transform(box.get_center() + Vector2(0, _oy) + _shake, 0.0, Vector2.ONE * (0.7 + 0.3 * pop))
	var local: = Rect2( - box.size / 2.0, box.size)
	var paper: = Color(0.97, 0.93, 0.84)
	var mouth: = (Vector2(372, 378) - box.get_center()) / (0.7 + 0.3 * pop)
	var tail: = PackedVector2Array([local.position + Vector2(24, local.size.y - 2), local.position + Vector2(66, local.size.y - 2), mouth])
	draw_colored_polygon(PackedVector2Array([tail[0] + Vector2(-5, 0), tail[1] + Vector2(5, 0), tail[2] + Vector2(-6, 7)]), Color(0.1, 0.03, 0.03))
	draw_rect(local.grow(4), Color(0.1, 0.03, 0.03))
	draw_rect(local, paper)
	draw_colored_polygon(tail, paper)
	draw_rect(Rect2(local.position + Vector2(4, 4), Vector2(local.size.x - 8, 4)), Color(1, 1, 1, 0.6))
	var shown: = int(t / TYPE_SPEED)
	var count: = 0
	for i in lines.size():
		var part: = lines[i]
		var typed: = clampi(shown - count, 0, part.length())
		count += part.length() + 1
		draw_string(font, local.position + Vector2(16, 34 + i * 30), part.substr(0, typed), HORIZONTAL_ALIGNMENT_LEFT, -1, BUBBLE_FONT, INK)
	draw_set_transform(Vector2(0, _oy) + _shake)

func _draw_paper() -> void :
	var k: = clampf(_t / UNROLL, 0.0, 1.0)
	k = 1.0 - pow(1.0 - k, 3.0)
	var r: = PAPER
	r.size.y = maxf(r.size.y * k, 4.0)

	var src: = Rect2(Vector2.ZERO, _paper_tex.get_size() * Vector2(1.0, r.size.y / PAPER.size.y))
	draw_texture_rect_region(_paper_tex, r, src)
	for d in _drips:
		draw_circle(d, 9.0, Color(0.6, 0.45, 0.25, 0.25))
		draw_circle(d + Vector2(-2, -2), 5.0, Color(0.55, 0.4, 0.22, 0.25))
	if k < 1.0:
		draw_texture_rect_region(_shade_tex, r, src)
		_draw_rod(r.position.y)
		_draw_rod(r.end.y)
		return
	var words: Dictionary = Game.theme.pact_words
	var x: = r.position.x
	var w: = r.size.x
	_ink(words["header"], Vector2(x, r.position.y + 42), 30, BLOOD.darkened(0.2), w, HORIZONTAL_ALIGNMENT_CENTER)
	draw_line(Vector2(x + 120, r.position.y + 54), Vector2(r.end.x - 120, r.position.y + 54), Color(INK, 0.5), 2.0)
	_ink(words["receives"] + ":", Vector2(x, r.position.y + 78), 21, Color(INK, 0.8), w, HORIZONTAL_ALIGNMENT_CENTER)

	var boon: = _boon if _boon_landed else _rolling_id(_boons, _boon_roll, BOON_STOP)
	var info: Dictionary = Game.theme.pact(boon)
	_draw_term(BOON_Y, Game.theme.texture(info["icon"]), info["name"], Game.pact_text(boon), BLOOD.darkened(0.15), _boon_landed)

	var ex_y: = PRICE_Y - 30.0
	draw_line(Vector2(x + 40, ex_y - 8), Vector2(x + 180, ex_y - 8), Color(INK, 0.5), 2.0)
	draw_line(Vector2(r.end.x - 180, ex_y - 8), Vector2(r.end.x - 40, ex_y - 8), Color(INK, 0.5), 2.0)
	_ink(words["exchange"], Vector2(x, ex_y), 26, INK, w, HORIZONTAL_ALIGNMENT_CENTER)

	if _t >= BOON_STOP - 0.1:
		var price: = _price if _price_landed else _rolling_id(_prices, _price_roll, PRICE_STOP)
		var pinfo: Dictionary = Game.theme.pact_price(price)
		_draw_term(PRICE_Y, Game.theme.price_icon(price), pinfo["name"], Game.pact_text(price), Color(0.3, 0.1, 0.32), _price_landed)
	if _void_t >= 0.0:
		_draw_void()
	_draw_signature(r)

	draw_texture_rect(_shade_tex, r, false)
	_draw_rod(r.position.y)
	_draw_rod(r.end.y)

func _draw_rod(y: float) -> void :
	var wood: = Color(0.3, 0.15, 0.09)
	var rod: = Rect2(PAPER.position.x - 18, y - 12, PAPER.size.x + 36, 24)
	draw_rect(rod.grow(3), Color(0.08, 0.03, 0.02))
	draw_rect(rod, wood)
	draw_rect(Rect2(rod.position + Vector2(0, 4), Vector2(rod.size.x, 5)), Color(1, 1, 1, 0.12))
	var gold: = Color(0.95, 0.72, 0.25)
	for ex: float in [rod.position.x - 6, rod.end.x + 6]:
		draw_circle(Vector2(ex, y), 17.0, Color(0.08, 0.03, 0.02))
		draw_circle(Vector2(ex, y), 14.0, gold)
		draw_circle(Vector2(ex - 4, y - 4), 5.0, Color(1, 0.95, 0.7))


func _draw_term(y: float, icon: Texture2D, title: String, text: String, color: Color, landed: bool) -> void :
	var font: = ThemeDB.fallback_font
	var a: = 1.0 if landed else 0.55
	var fit: = minf(78.0 / icon.get_width(), 78.0 / icon.get_height())
	var isz: = icon.get_size() * fit
	var ic: = Vector2(PAPER.position.x + 76, y + 46)
	draw_circle(ic, 50.0, Color(0.55, 0.36, 0.16, 0.18))
	draw_arc(ic, 50.0, 0.0, TAU, 40, Color(INK, 0.35), 2.0)
	draw_texture_rect(icon, Rect2(ic - isz / 2.0, isz), false, Color(1, 1, 1, a))
	var tx: = PAPER.position.x + 144
	var tw: = PAPER.end.x - tx - 24
	_ink(title.to_upper(), Vector2(tx, y + 36), 32, Color(color, a))
	var lines: = _wrap(text, tw, 24)
	for i in lines.size():
		_ink(lines[i], Vector2(tx, y + 72 + i * 28), 24, Color(INK, a))


func _draw_void() -> void :
	var r: = Rect2(PAPER.position.x + 22, PRICE_Y - 4, PAPER.size.x - 44, 112)
	var t: = _void_t - 0.55
	if t < 0.0:
		return
	var font: = ThemeDB.fallback_font

	var s: = clampf(t / 0.15, 0.0, 1.0)
	var x0: = PAPER.position.x + 140
	for ly: float in [PRICE_Y + 25, PRICE_Y + 64]:
		draw_line(Vector2(x0, ly), Vector2(lerpf(x0, r.end.x - 16, s), ly + 3), Color(BLOOD, 0.9), 5.0)

	var c1: = clampf((t - 0.1) / 0.12, 0.0, 1.0)
	var c2: = clampf((t - 0.22) / 0.12, 0.0, 1.0)
	for o in 3:
		var off: = Vector2(o * 2.0 - 2.0, o * 1.5)
		if c1 > 0.0:
			draw_line(r.position + off, r.position.lerp(r.end, c1) + off, Color(BLOOD, 0.55), 12.0)
		if c2 > 0.0:
			var a: = Vector2(r.end.x, r.position.y)
			var b: = Vector2(r.position.x, r.end.y)
			draw_line(a + off, a.lerp(b, c2) + off, Color(BLOOD, 0.55), 12.0)

	var k: = clampf(t / 0.12, 0.0, 1.0)
	var scale: = lerpf(2.6, 1.0, k * k)
	var center: = r.get_center() + Vector2(70, 6)
	draw_set_transform(center + Vector2(0, _oy) + _shake, -0.22, Vector2.ONE * scale)
	var ink: = Color(0.85, 0.06, 0.08, 0.35 + 0.55 * k)
	var box: = Rect2(-130, -52, 260, 104)
	draw_rect(box, ink, false, 7.0)
	draw_rect(box.grow(-12), ink, false, 3.0)
	var word: String = Game.theme.pact_words["void"]
	draw_string(font, Vector2(-130, 26), word, HORIZONTAL_ALIGNMENT_CENTER, 260, 78, ink)
	draw_set_transform(Vector2(0, _oy) + _shake)


func _draw_signature(r: Rect2) -> void :
	var font: = ThemeDB.fallback_font
	var y: = r.end.y - 44
	var x0: = r.position.x + 70
	_ink("X", Vector2(r.position.x + 36, y), 30, INK)
	draw_line(Vector2(x0, y + 4), Vector2(x0 + 270, y + 4), Color(INK, 0.6), 2.0)

	var seal: = Vector2(r.end.x - 74, y - 10)
	for i in 10:
		draw_circle(seal + Vector2.RIGHT.rotated(TAU * i / 10.0) * 30.0, 9.0, BLOOD.darkened(0.25))
	draw_circle(seal, 32.0, BLOOD.darkened(0.25))
	draw_circle(seal, 24.0, BLOOD)
	draw_colored_polygon(PackedVector2Array([seal + Vector2(-13, -4), seal + Vector2(-19, -20), seal + Vector2(-5, -10)]), BLOOD.darkened(0.45))
	draw_colored_polygon(PackedVector2Array([seal + Vector2(13, -4), seal + Vector2(19, -20), seal + Vector2(5, -10)]), BLOOD.darkened(0.45))
	draw_circle(seal + Vector2(0, 4), 10.0, BLOOD.darkened(0.45))
	if not _signed or _end_t < 0.0:
		return
	var who: = signature_name()
	var font_size: = 44
	var room: = 250.0
	var width: = font.get_string_size(who, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
	if width > room:
		font_size = int(font_size * room / width)
		width = font.get_string_size(who, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
	var k: = clampf(_end_t / 0.45, 0.0, 1.0)
	var shown: = k * who.length()
	var base: = Vector2(0, _oy) + _shake
	var pen: = Vector2(x0 + 12, y + 1)
	for i in who.length():
		if i >= shown:
			break
		var ch: = who.unicode_at(i)
		var wobble: = sin(i * 2.7) * 3.0
		var a: = clampf(shown - i, 0.0, 1.0)

		draw_set_transform_matrix(Transform2D(sin(i * 1.9) * 0.05, Vector2.ONE, -0.32, base + pen + Vector2(0, wobble)))
		draw_char(font, Vector2(2, 2), String.chr(ch), font_size, Color(BLOOD.darkened(0.6), 0.5 * a))
		draw_char(font, Vector2.ZERO, String.chr(ch), font_size, Color(BLOOD, a))
		if i % 3 == 1 and shown >= who.length():
			var drip: = minf((_end_t - 0.45) * 40.0, 10.0 + (i % 2) * 8.0)
			if drip > 0.0:
				var at: = Vector2(font.get_char_size(ch, font_size).x * 0.5, 2)
				draw_line(at, at + Vector2(0, drip), BLOOD, 3.0)
				draw_circle(at + Vector2(0, drip), 2.5, BLOOD)
		pen.x += font.get_char_size(ch, font_size).x
	draw_set_transform(base)
	if k >= 1.0:
		var u: = clampf((_end_t - 0.45) / 0.15, 0.0, 1.0)
		var from: = Vector2(x0 + 4, y + 10)
		draw_line(from, from + Vector2((width + 24) * u, -6 * u), BLOOD, 3.0)


static func signature_name() -> String:
	var full: = str(Game.survivor().get("name", "")).strip_edges()
	var words: = full.split(" ", false)
	return words[-1] if words.size() > 0 else "X"


func _draw_lawyer() -> void :
	if _void_t < 0.0 or not Game.theme.sprites.has("pact_lawyer"):
		return
	var tex: = Game.theme.texture("pact_lawyer")
	var k: = clampf(_void_t / 0.45, 0.0, 1.0)
	var pos: = LAWYER_POS.lerp(Vector2(-140, LAWYER_POS.y - 200), pow(1.0 - k, 2.0)) + Vector2(0, sin(_t * 3.0) * 6.0)
	var holy: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
	draw_circle(pos, 82.0, Color(holy, 0.12))
	draw_circle(pos, 58.0, Color(holy, 0.16))
	var size: = tex.get_size() * LAWYER_SCALE
	draw_texture_rect(tex, Rect2(pos - size / 2.0, size), false)

	var bc: = pos + Vector2(size.x * 0.5 - 6, size.y * 0.12)
	draw_rect(Rect2(bc + Vector2(-2, -2), Vector2(42, 32)), Color(0.08, 0.04, 0.02))
	draw_rect(Rect2(bc, Vector2(38, 28)), Color(0.45, 0.26, 0.12))
	draw_rect(Rect2(bc + Vector2(12, -8), Vector2(14, 8)), Color(0.08, 0.04, 0.02), false, 3.0)
	draw_rect(Rect2(bc + Vector2(16, 10), Vector2(6, 6)), Color(0.95, 0.75, 0.3))

	if _void_t > 0.35 and _void_t < 2.2:
		var font: = ThemeDB.fallback_font
		var word: String = Game.theme.pact_words["objection"]
		var pop: = minf((_void_t - 0.35) / 0.1, 1.0)
		var bubble: = Rect2(pos + Vector2(-50, -146), Vector2(230, 58))
		draw_set_transform(bubble.get_center() + Vector2(0, _oy) + _shake, -0.06, Vector2.ONE * (0.6 + 0.4 * pop))
		var local: = Rect2( - bubble.size / 2.0, bubble.size)
		draw_colored_polygon(PackedVector2Array([Vector2(-60, 24), Vector2(-30, 24), Vector2(-80, 56)]), Color.WHITE)
		draw_rect(local.grow(3), Color(0.1, 0.05, 0.05))
		draw_rect(local, Color.WHITE)
		draw_string(font, Vector2(local.position.x, 12), word, HORIZONTAL_ALIGNMENT_CENTER, local.size.x, 34, BLOOD)
		draw_set_transform(Vector2(0, _oy) + _shake)
