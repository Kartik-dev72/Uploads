class_name PixelArt
extends RefCounted













static func build(rows: Array, palette: Dictionary, crop: = Rect2i(), factor: = 1) -> ImageTexture:
	if factor > 1:
		var lo: = crop if crop.has_area() else used_rect(rows)
		var hi: = rows
		var f: = 1
		while f < factor:
			hi = scale2x(hi)
			f *= 2
		rows = _thin_outline(hi, rows, factor)
		crop = Rect2i(lo.position * factor, lo.size * factor)
	var w: = 1
	for row: String in rows:
		w = maxi(w, row.length())
	var img: = Image.create_empty(w, maxi(rows.size(), 1), false, Image.FORMAT_RGBA8)
	for y in rows.size():
		var row: String = rows[y]
		for x in row.length():
			var ch: = row[x]
			if ch == "." or ch == " ":
				continue
			img.set_pixel(x, y, palette.get(ch, Color.MAGENTA))
	var used: = crop if crop.has_area() else img.get_used_rect()
	if used.has_area():
		img = img.get_region(used)
	if factor > 1:
		_light(img)
	var tex: = ImageTexture.create_from_image(img)
	if factor > 1:
		tex.set_size_override(img.get_size() / factor)
	return tex





const LIGHT: = 0.16
const SHADE: = 0.2

static func _light(img: Image) -> void :
	var w: = img.get_width()
	var h: = img.get_height()
	var src: = img.duplicate() as Image
	var area: = {}
	for y in h:
		for x in w:
			var c: = src.get_pixel(x, y)
			if c.a > 0.5:
				area[c] = area.get(c, 0) + 1
	for y in h:
		for x in w:
			var c: = src.get_pixel(x, y)
			if c.a < 0.5:
				continue
			var l: = c.get_luminance()
			if l < 0.1 or l > 0.85 or area[c] < 10:
				continue
			var up: = y == 0 or src.get_pixel(x, y - 1) != c
			var left: = x == 0 or src.get_pixel(x - 1, y) != c
			var down: = y == h - 1 or src.get_pixel(x, y + 1) != c
			var right: = x == w - 1 or src.get_pixel(x + 1, y) != c
			var k: = (int(up) + int(left)) - (int(down) + int(right))
			if k > 0:
				img.set_pixel(x, y, c.lightened(LIGHT * k))
			elif k < 0:
				img.set_pixel(x, y, c.darkened(SHADE * - k))


static func factor_of(tex: Texture2D, img: Image) -> int:
	return maxi(1, roundi(float(img.get_width()) / maxf(tex.get_width(), 1.0)))



static func scale2x(rows: Array) -> Array:
	var w: = 0
	for row: String in rows:
		w = maxi(w, row.length())
	var g: Array[PackedStringArray] = []
	for row: String in rows:
		var cells: = PackedStringArray()
		for x in w:
			var ch: = row[x] if x < row.length() else "."
			cells.append("." if ch == " " else ch)
		g.append(cells)
	var h: = g.size()
	var out: Array = []
	for y in h:
		var top: = PackedStringArray()
		var bottom: = PackedStringArray()
		for x in w:
			var p: = g[y][x]
			var a: = g[y - 1][x] if y > 0 else "."
			var b: = g[y][x + 1] if x < w - 1 else "."
			var c: = g[y][x - 1] if x > 0 else "."
			var d: = g[y + 1][x] if y < h - 1 else "."
			top.append(a if c == a and c != d and a != b else p)
			top.append(b if a == b and a != c and b != d else p)
			bottom.append(c if d == c and d != b and c != a else p)
			bottom.append(d if b == d and b != a and d != c else p)
		out.append("".join(top))
		out.append("".join(bottom))
	return out





static func _thin_outline(hi: Array, lo: Array, factor: int) -> Array:
	var h: = hi.size()
	var w: int = (hi[0] as String).length() if h > 0 else 0
	var g: Array[PackedStringArray] = []
	for row: String in hi:
		var cells: = PackedStringArray()
		for x in w:
			cells.append(row[x] if x < row.length() else ".")
		g.append(cells)
	var edge: = func(x: int, y: int) -> bool:
		var lx: = x / factor
		var ly: = y / factor
		var row: String = lo[ly] if ly < lo.size() else ""
		if lx >= row.length() or row[lx] != "K":
			return false
		for dv: Vector2i in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			var nx: = lx + dv.x
			var ny: = ly + dv.y
			if ny < 0 or ny >= lo.size() or nx < 0:
				return true
			var nrow: String = lo[ny]
			if nx >= nrow.length() or nrow[nx] == "." or nrow[nx] == " ":
				return true
		return false
	var out: = g.duplicate(true)
	for y in h:
		for x in w:
			if g[y][x] != "K" or not edge.call(x, y):
				continue
			var open: = false
			for dy in range(-1, 2):
				for dx in range(-1, 2):
					var nx: = x + dx
					var ny: = y + dy
					if nx < 0 or ny < 0 or nx >= w or ny >= h or g[ny][nx] == ".":
						open = true
			if open:
				continue
			for dv: Vector2i in [Vector2i(0, -1), Vector2i(0, 1), Vector2i(-1, 0), Vector2i(1, 0)]:
				var nx: = x + dv.x
				var ny: = y + dv.y
				if nx >= 0 and ny >= 0 and nx < w and ny < h and g[ny][nx] != "K" and g[ny][nx] != ".":
					var cells: PackedStringArray = out[y]
					cells[x] = g[ny][nx]
					out[y] = cells
					break
	var rows: Array = []
	for cells: PackedStringArray in out:
		rows.append("".join(cells))
	return rows


static func used_rect(rows: Array) -> Rect2i:
	var r: = Rect2i()
	for y in rows.size():
		var row: String = rows[y]
		for x in row.length():
			if row[x] != "." and row[x] != " ":
				r = Rect2i(x, y, 1, 1) if not r.has_area() else r.expand(Vector2i(x, y)).expand(Vector2i(x + 1, y + 1))
	return r





static func with_rim(tex: Texture2D, rim: Color) -> ImageTexture:
	var src: = tex.get_image()
	var f: = factor_of(tex, src)
	var w: = src.get_width()
	var h: = src.get_height()

	var img: = Image.create_empty(w + 2 * f, h + 2 * f, false, Image.FORMAT_RGBA8)
	img.blit_rect(src, Rect2i(0, 0, w, h), Vector2i(f, f))
	var body: = img.duplicate() as Image
	if f > 1:
		_round_halo(img, body, f, rim)
		var fine: = ImageTexture.create_from_image(img)
		fine.set_size_override(Vector2i(roundi(tex.get_width()) + 2, roundi(tex.get_height()) + 2))
		return fine
	var dirs: Array[Vector2i] = [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
	for y in h + 2 * f:
		for x in w + 2 * f:
			if body.get_pixel(x, y).a > 0.0:
				continue
			var solid: = 0
			var thick: = false
			for d in dirs:
				var n: = Vector2i(x, y) + d
				if _solid_at(body, n):
					solid += 1
					thick = thick or not _is_thin(body, n)
			if solid > 0 and thick:
				img.set_pixel(x, y, rim)
	var out: = ImageTexture.create_from_image(img)
	if f > 1:
		out.set_size_override(Vector2i(roundi(tex.get_width()) + 2, roundi(tex.get_height()) + 2))
	return out

static func _round_halo(img: Image, body: Image, r: int, rim: Color) -> void :
	var w: = img.get_width()
	var h: = img.get_height()
	var offsets: Array[Vector2i] = []
	for dy in range( - r, r + 1):
		for dx in range( - r, r + 1):
			if (dx != 0 or dy != 0) and dx * dx + dy * dy <= maxf(2.0, r * r * 0.6):
				offsets.append(Vector2i(dx, dy))
	for y in h:
		for x in w:
			if body.get_pixel(x, y).a > 0.0:
				continue
			for o in offsets:
				if _solid_at(body, Vector2i(x, y) + o):
					img.set_pixel(x, y, rim)
					break

static func _solid_at(img: Image, p: Vector2i) -> bool:
	return p.x >= 0 and p.y >= 0 and p.x < img.get_width() and p.y < img.get_height() and img.get_pixel(p.x, p.y).a > 0.5

static func _is_thin(img: Image, p: Vector2i) -> bool:
	return ( not _solid_at(img, p + Vector2i(1, 0)) and not _solid_at(img, p + Vector2i(-1, 0))) or ( not _solid_at(img, p + Vector2i(0, 1)) and not _solid_at(img, p + Vector2i(0, -1)))
