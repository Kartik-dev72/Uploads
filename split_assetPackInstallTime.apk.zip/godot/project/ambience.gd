class_name Ambience
extends Control





func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	var t: = Game.theme
	var vignette: = TextureRect.new()
	var grad: = Gradient.new()
	grad.offsets = PackedFloat32Array([0.45, 1.0])
	grad.colors = PackedColorArray([Color(0, 0, 0, 0), t.ui.get("vignette", Color(0, 0, 0, 0.6))])
	var tex: = GradientTexture2D.new()
	tex.gradient = grad
	tex.fill = GradientTexture2D.FILL_RADIAL
	tex.fill_from = Vector2(0.5, 0.5)
	tex.fill_to = Vector2(1.0, 0.85)
	tex.width = 128
	tex.height = 128
	vignette.texture = tex
	vignette.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vignette.stretch_mode = TextureRect.STRETCH_SCALE
	vignette.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(vignette)
	if t.ambient.has("color"):
		add_child(_embers(t.ambient["color"]))

func _embers(color: Color) -> CPUParticles2D:
	var p: = CPUParticles2D.new()
	p.position = Vector2(360, 1320)
	p.amount = 30
	p.lifetime = 8.0
	p.preprocess = 8.0
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	p.emission_rect_extents = Vector2(400, 10)
	p.direction = Vector2(0.15, -1)
	p.spread = 20.0
	p.initial_velocity_min = 90.0
	p.initial_velocity_max = 190.0
	p.gravity = Vector2.ZERO
	p.scale_amount_min = 2.0
	p.scale_amount_max = 5.0
	p.tangential_accel_min = -30.0
	p.tangential_accel_max = 30.0
	var ramp: = Gradient.new()
	ramp.offsets = PackedFloat32Array([0.0, 0.15, 0.7, 1.0])
	ramp.colors = PackedColorArray([Color(color, 0.0), Color(color.lightened(0.3), 0.8), Color(color.darkened(0.2), 0.45), Color(color.darkened(0.6), 0.0)])
	p.color_ramp = ramp
	return p
