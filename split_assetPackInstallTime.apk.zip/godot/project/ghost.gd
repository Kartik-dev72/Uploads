class_name Ghost
extends Node2D








const LIFE: = 7.0
const TOUCH_DRAIN: = 0.4
const LURE: = 230.0
const HIT_EVERY: = 0.4
const SEEK_EVERY: = 0.3
const SEEK_RANGE: = 420.0
const FADE: = 0.4
const TINT: = Color(0.62, 0.9, 1.0)

static var alive: Array[Ghost] = []

var damage: = 10.0
var speed: = 120.0
var radius: = 20.0
var _life: = LIFE
var _max_life: = LIFE
var _frames: Array[Texture2D] = []
var _scale: = 3.0
var _offset: = Vector2.ZERO
var _flip: = false
var _t: = 0.0
var _hit: = 0.0
var _seek: = 0.0
var _target: Enemy


func raise(e: Enemy, hit_damage: float) -> void :
	global_position = e.global_position
	damage = hit_damage
	speed = maxf(e.speed, 90.0) * 1.1
	radius = e.radius
	_frames = e._frames.duplicate()
	_scale = e.sprite_scale
	_offset = e._sprite.position
	_flip = e._sprite.flip_h
	if e.elite != "":
		_max_life = LIFE * 1.5
	_life = _max_life

func _ready() -> void :
	Layers.put(self, Layers.FLYING)
	var glow: = CanvasItemMaterial.new()
	glow.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	material = glow
	alive.append(self)
	_t = randf() * 3.0

func _exit_tree() -> void :
	alive.erase(self)

func is_fading() -> bool:
	return _life <= 0.0

func _process(delta: float) -> void :
	_t += delta
	queue_redraw()
	if _life <= 0.0:
		_life -= delta
		if _life <= - FADE:
			queue_free()
		return
	_seek -= delta
	if _seek <= 0.0 or not is_instance_valid(_target) or _target.is_dead():
		_seek = SEEK_EVERY
		_target = _nearest()
	if is_instance_valid(_target):
		var to: = _target.global_position - global_position
		if to.length() > radius * 0.5:
			global_position += to.normalized() * minf(speed * delta, to.length())
			_flip = to.x < 0.0
	var touching: Array[Enemy] = []
	for e: Enemy in Enemy.near(global_position, radius + 40.0):
		if e.targetable and e.global_position.distance_to(global_position) < radius + e.radius:
			touching.append(e)
	_life -= delta * (1.0 + TOUCH_DRAIN * touching.size())
	_hit -= delta
	if _hit <= 0.0 and not touching.is_empty():
		_hit = HIT_EVERY
		for e in touching:
			e.take_damage(damage, 0.5)
	if _life <= 0.0:
		_life = 0.0

func _nearest() -> Enemy:
	var best: Enemy = null
	var best_d: = SEEK_RANGE * SEEK_RANGE
	for e: Enemy in Enemy.near(global_position, SEEK_RANGE):
		if not e.targetable or e.is_dead():
			continue
		var d: = e.global_position.distance_squared_to(global_position)
		if d < best_d:
			best_d = d
			best = e
	return best



func _draw() -> void :
	if _frames.is_empty():
		return
	var k: = clampf(_life / _max_life, 0.0, 1.0)
	var a: = (0.55 + 0.4 * k) if _life > 0.0 else 0.55 * clampf(1.0 + _life / FADE, 0.0, 1.0)
	var bob: = Vector2(0, sin(_t * 4.0) * 4.0 - 6.0)
	var tex: Texture2D = _frames[int(_t * 6.0) % _frames.size()]
	var size: = tex.get_size() * _scale
	for i in 4:
		var p: = _offset + bob + Vector2(sin(_t * 5.0 + i) * 5.0, size.y * 0.3 + i * 9.0)
		PixelFx.disc(self, p, size.x * (0.22 - i * 0.04), Color(TINT, a * (0.4 - i * 0.09)))
	draw_set_transform(PixelFx.snap(_offset + bob), 0.0, Vector2(-1.0 if _flip else 1.0, 1.0))
	var gray: = Color(0.75, 0.95, 1.0, a)
	draw_texture_rect(tex, Rect2( - size * 0.5, size), false, Color(gray.r * 0.45, gray.g * 0.75, gray.b, a))
	draw_texture_rect(tex, Rect2( - size * 0.5, size), false, Color(0.2, 0.35, 0.5, a * 0.8))
	draw_set_transform(Vector2.ZERO)
