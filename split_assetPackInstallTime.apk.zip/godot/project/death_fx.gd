class_name DeathFx
extends Node2D









const LIFE: = 0.75
const POP_TIME: = 0.06
const GRAVITY: = 1500.0
const BOUNCE: = 0.35
const MAX_CHUNKS: = 3
const MAX_ALIVE: = 15
const MAX_FADES: = 80
const FADE_LIFE: = 0.25

static var _alive: = 0
static var _fading: = 0
const MAX_PER_FRAME: = 6
static var _frame: = -1
static var _made: = 0
static var _chunk_cache: = {}

var _fade: = false
var _texture: Texture2D
var _scale: = 3.0
var _flip: = false
var _color: = Color.WHITE
var _size: = 20.0
var _floor: = 0.0
var _time: = 0.0
var _src: Array[Rect2] = []
var _pos: = PackedVector2Array()
var _vel: = PackedVector2Array()
var _angle: = PackedFloat32Array()
var _spin: = PackedFloat32Array()
var _embers: = PackedVector2Array()


static func spawn(parent: Node, pos: Vector2, texture: Texture2D, scale_: float, flip: bool, size: float, floor_y: = -1.0) -> void :
	if parent == null or texture == null:
		return
	if Engine.get_process_frames() != _frame:
		_frame = Engine.get_process_frames()
		_made = 0
	if _made >= MAX_PER_FRAME:
		return
	_made += 1
	var fade: = _alive >= MAX_ALIVE
	if fade and _fading >= MAX_FADES:
		return
	var fx: = DeathFx.new()
	fx._fade = fade
	fx._texture = texture
	fx._scale = scale_
	fx._flip = flip
	fx._size = size
	fx._floor = floor_y if floor_y >= 0.0 else texture.get_height() * scale_ * 0.5
	fx._color = Game.theme.ui.get("death", Color(1, 1, 1))
	fx.position = pos
	parent.add_child(fx)

func _enter_tree() -> void :
	if _fade:
		_fading += 1
	else:
		_alive += 1

func _exit_tree() -> void :
	if _fade:
		_fading -= 1
	else:
		_alive -= 1

func _ready() -> void :
	Layers.put(self, Layers.GROUND_EFFECTS)
	if _fade:
		return
	var half: = _texture.get_size() * 0.5
	var power: = sqrt(_size / 20.0)
	for src: Rect2 in _chunks_of(_texture):
		var p: = (src.get_center() - half) * _scale
		if _flip:
			p.x = - p.x
		var out: = p.normalized() if p.length() > 1.0 else Vector2.RIGHT.rotated(randf() * TAU)
		_src.append(src)
		_pos.append(p)
		_vel.append(out * randf_range(60.0, 150.0) * power + Vector2(randf_range(-30, 30), - randf_range(160.0, 300.0) * power))
		_angle.append(0.0)
		_spin.append(randf_range(-12.0, 12.0))
	for i in 5:
		_embers.append(Vector2.RIGHT.rotated(TAU * i / 5.0 + randf_range(-0.5, 0.5)) * randf_range(0.6, 1.2))

func _process(delta: float) -> void :
	_time += delta
	if _time >= (FADE_LIFE if _fade else LIFE):
		queue_free()
		return
	if _time > POP_TIME:
		for i in _pos.size():
			var v: = _vel[i]
			v.y += GRAVITY * delta
			var p: = _pos[i] + v * delta
			if p.y > _floor and v.y > 0.0:
				p.y = _floor
				v = Vector2(v.x * 0.6, - v.y * BOUNCE)
				_spin[i] *= 0.5
			_pos[i] = p
			_vel[i] = v
			_angle[i] += _spin[i] * delta
	queue_redraw()

func _draw() -> void :
	if _fade:
		var k: = _time / FADE_LIFE
		draw_set_transform(Vector2.ZERO, 0.0, Vector2( - _scale if _flip else _scale, _scale) * (1.0 - 0.2 * k))
		draw_texture(_texture, - _texture.get_size() * 0.5, Color(10, 10, 10, 1.0 - k))
		draw_set_transform(Vector2.ZERO)
		return
	var t: = _time / LIFE
	var hot: = _color.lightened(0.5)

	draw_set_transform(Vector2(0, _floor), 0.0, Vector2(1, 0.35))
	draw_circle(Vector2.ZERO, _size * 0.9, Color(0, 0, 0, 0.25 * (1.0 - t)))
	var spread: = 1.0 - pow(1.0 - t, 3.0)
	draw_arc(Vector2.ZERO, _size * (0.5 + 1.3 * spread), 0, TAU, 24, Color(hot, 0.7 * (1.0 - t)), 4.0 * (1.0 - t) + 1.0)
	if _time < POP_TIME:
		var pop: = 1.0 + 0.25 * _time / POP_TIME
		draw_set_transform(Vector2.ZERO, 0.0, Vector2( - _scale if _flip else _scale, _scale) * pop)
		draw_texture(_texture, - _texture.get_size() * 0.5, Color(10, 10, 10))
		draw_set_transform(Vector2.ZERO)
		draw_circle(Vector2.ZERO, _size * 1.1, Color(hot, 0.45))
		return

	var k: = (_time - POP_TIME) / (LIFE - POP_TIME)
	var tint: = Color(4, 4, 4).lerp(Color.WHITE, k / 0.15) if k < 0.15 else Color.WHITE.lerp(_color * 1.6, (k - 0.15) / 0.5)
	tint.a = 1.0 - smoothstep(0.5, 1.0, k)
	var s: = _scale * (1.0 - 0.3 * k)
	for i in _pos.size():
		var src: = _src[i]
		draw_set_transform(_pos[i], _angle[i], Vector2( - s if _flip else s, s))
		draw_texture_rect_region(_texture, Rect2( - src.size * 0.5, src.size), src, tint)
	draw_set_transform(Vector2.ZERO)
	for d: Vector2 in _embers:
		var p: = d * _size * (0.3 + 1.2 * k) + Vector2(0, -50.0 * k)
		var e: = 4.0 * (1.0 - k) + 1.0
		draw_rect(Rect2(p - Vector2.ONE * e * 0.5, Vector2.ONE * e), Color(hot if d.x > 0.0 else _color, 1.0 - k))


static func _chunks_of(texture: Texture2D) -> Array[Rect2]:
	if _chunk_cache.has(texture):
		return _chunk_cache[texture]
	var chunks: Array[Rect2] = []
	var img: = texture.get_image()
	var f: = PixelArt.factor_of(texture, img)
	var w: = img.get_width()
	var h: = img.get_height()
	var step: = maxi(1, ceili(maxf(w, h) / float(MAX_CHUNKS)))
	for y in range(0, h, step):
		for x in range(0, w, step):
			var r: = Rect2i(x, y, mini(step, w - x), mini(step, h - y))
			if not img.get_region(r).is_invisible():
				chunks.append(Rect2(Vector2(r.position) / f, Vector2(r.size) / f))
	_chunk_cache[texture] = chunks
	return chunks
