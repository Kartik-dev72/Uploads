class_name PixelFx
extends RefCounted








const PIXEL: = 1.0
const SPRITE_PX: = 2.0
const ART_FACTOR: = 2
const DOT: = 2.0
const POOL_VARIANTS: = 3
const POOL_FRAMES: = 2

static var _pools: = {}
static var _pool_tasks: = {}
static var _pool_images: = {}
static var _pool_lock: = Mutex.new()
static var _tinted: = {}






const GRIDS: = {
	"fireball": [
		"........&rrK....", 
		".....&.&rRRRKK..", 
		"..&..&rRRHHHRRK.", 
		".&&.&rRHHCCCHRRK", 
		"&r&&rRRHCCCCCHRK", 
		".&&.&rRHHCCCHRRK", 
		"..&..&rRRHHHRRK.", 
		".....&.&rRRRKK..", 
		"........&rrK....", 
	], 
	"fireball/2": [
		".......&rrK.....", 
		"....&..&rRRRKK..", 
		".&...&rRRHHHRRK.", 
		"&&.&&rRHHCCCHRRK", 
		".&&&rRRHCCCCCHRK", 
		"..&.&rRHHCCCHRRK", 
		"...&.&rRRHHHRRK.", 
		"....&..&rRRRKK..", 
		".......&rrK.....", 
	], 
	"dagger": [
		"......KK............", 
		".....KYK.KKKKKKKK...", 
		"KKK.KKYKKWWWWWWWWKK.", 
		"KYnnnnYKGGGGGGGGGGGK", 
		"KKK.KKYKKggggggggKK.", 
		".....KYK.KKKKKKKK...", 
		"......KK............", 
	], 
	"wheel": [
		"....K.K.K....", 
		"..K.KHKHK.K..", 
		".KHKRRRRRKHK.", 
		"..KRr&&&rRK..", 
		"KHKr&KKK&rKHK", 
		".KRr&KHK&rRK.", 
		"KHR&&KCK&&RHK", 
		".KRr&KHK&rRK.", 
		"KHKr&KKK&rKHK", 
		"..KRr&&&rRK..", 
		".KHKRRRRRKHK.", 
		"..K.KHKHK.K..", 
		"....K.K.K....", 
	], 
	"wheel/2": [
		"....K.K.K....", 
		"..K.KCKCK.K..", 
		".KCKRRRRRKCK.", 
		"..KRr&&&rRK..", 
		"KCKr&KKK&rKCK", 
		".KRr&KHK&rRK.", 
		"KCR&&KCK&&RCK", 
		".KRr&KHK&rRK.", 
		"KCKr&KKK&rKCK", 
		"..KRr&&&rRK..", 
		".KCKRRRRRKCK.", 
		"..K.KCKCK.K..", 
		"....K.K.K....", 
	], 
	"flame": [
		"....&....", 
		"...&R&...", 
		"...&R&...", 
		"..&RHR&..", 
		"..&RHR&..", 
		".&RHHHR&.", 
		".&RHCHR&.", 
		"&RHHCHHR&", 
		"&RHCCCHR&", 
		"&RHCCCHR&", 
		".&RHHHR&.", 
		"..&RRR&..", 
		"...&&&...", 
	], 
	"flame/2": [
		"...&.....", 
		"..&R&....", 
		"..&R&....", 
		"..&RH&...", 
		".&RHR&...", 
		".&RHHR&..", 
		".&RHCHR&.", 
		"&RHHCHHR&", 
		"&RHCCCHR&", 
		"&RHCCCHR&", 
		".&RHHHR&.", 
		"..&RRR&..", 
		"...&&&...", 
	], 
	"flame/3": [
		".....&...", 
		"....&R&..", 
		"....&R&..", 
		"...&HR&..", 
		"...&RHR&.", 
		"..&RHHR&.", 
		".&RHCHR&.", 
		"&RHHCHHR&", 
		"&RHCCCHR&", 
		"&RHCCCHR&", 
		".&RHHHR&.", 
		"..&RRR&..", 
		"...&&&...", 
	], 
	"soul": [
		".....&.....", 
		"....&R&....", 
		"...&RH&.&..", 
		"..&RHHR&R&.", 
		".&RHHCHHR&.", 
		"&RHCCCCCHR&", 
		"&RHCKCKCHR&", 
		"&RHCKCKCHR&", 
		"&RHCCCCCHR&", 
		".&RHCKCHR&.", 
		"..&RHHHR&..", 
		"...&RRR&...", 
		"....&&&....", 
	], 
	"soul/2": [
		"......&....", 
		".&...&R&...", 
		"&R&.&RH&...", 
		".&R&RHHR&..", 
		".&RHHCHHR&.", 
		"&RHCCCCCHR&", 
		"&RHCKCKCHR&", 
		"&RHCKCKCHR&", 
		"&RHCCCCCHR&", 
		".&RHCKCHR&.", 
		"..&RHHHR&..", 
		"...&RRR&...", 
		"....&&&....", 
	], 
	"axe": [
		"............KKK.....", 
		"..........KKWWWK....", 
		".........KGGGGWWK...", 
		"........KgGGGGGWK...", 
		"........KgGGGGGGWK..", 
		"........KggGGGGGWK..", 
		"KKKKKKKKKKKgGGGGGWK.", 
		"KNnnnnnnnnKggGGGGWK.", 
		"KKKKKKKKKKKgGGGGGWK.", 
		"........KggGGGGGWK..", 
		"........KgGGGGGGWK..", 
		"........KgGGGGGWK...", 
		".........KGGGGWWK...", 
		"..........KKWWWK....", 
		"............KKK.....", 
	], 
}


static func tinted(name: String, color: Color) -> Array:
	var key: = "%s|%s" % [name, color.to_html()]
	if _tinted.has(key):
		return _tinted[key]
	var steel: = Color(0.72, 0.75, 0.82).lerp(Color(color, 1.0), 0.12)
	var pal: = {
		"K": color.darkened(0.82), "&": color.darkened(0.55), "r": color.darkened(0.28), "R": color, 
		"H": color.lightened(0.45), "C": color.lightened(0.85), 
		"W": steel.lightened(0.6), "G": steel, "g": steel.darkened(0.35), 
		"Y": Color(0.95, 0.78, 0.3), "n": Color(0.42, 0.27, 0.17), "N": Color(0.6, 0.42, 0.26), 
	}
	var frames: Array = []
	var n: = 1
	var crop: = Rect2i()
	while GRIDS.has(name if n == 1 else "%s/%d" % [name, n]):
		var r: = PixelArt.used_rect(GRIDS[name if n == 1 else "%s/%d" % [name, n]])
		crop = r if not crop.has_area() else crop.merge(r)
		n += 1
	for i in n - 1:
		frames.append(PixelArt.build(GRIDS[name if i == 0 else "%s/%d" % [name, i + 1]], pal, crop, ART_FACTOR))
	_tinted[key] = frames
	return frames



static func draw_sprite(canvas: CanvasItem, name: String, color: Color, frame: = 0, modulate: = Color.WHITE, offset: = Vector2.ZERO) -> void :
	var frames: = tinted(name, color)
	var tex: Texture2D = frames[frame % frames.size()]
	var size: = tex.get_size() * SPRITE_PX
	canvas.draw_texture_rect(tex, Rect2( - size * 0.5 + offset * SPRITE_PX, size), false, modulate)


static func snap(p: Vector2) -> Vector2:
	return (p / PIXEL).floor() * PIXEL


static func dot(canvas: CanvasItem, p: Vector2, color: Color, n: = 1) -> void :
	canvas.draw_rect(Rect2(snap(p) - Vector2.ONE * DOT * (n - 1) * 0.5, Vector2.ONE * DOT * n), color)









static func pool_frames(radius: float, color: Color, variant: int) -> Array:
	var px: = maxi(4, roundi(radius / PIXEL))
	variant = variant % POOL_VARIANTS
	var key: = "%d|%s|%d" % [px, color.to_html(), variant]
	if _pools.has(key):
		return _pools[key]
	if _pool_tasks.has(key):
		var id: int = _pool_tasks[key]
		if WorkerThreadPool.is_task_completed(id):
			WorkerThreadPool.wait_for_task_completion(id)
			_pool_tasks.erase(key)
			_pool_lock.lock()
			var images: Array = _pool_images[key]
			_pool_images.erase(key)
			_pool_lock.unlock()
			var frames: Array = []
			for img: Image in images:
				frames.append(ImageTexture.create_from_image(img))
			_pools[key] = frames
			return frames
	else:
		_pool_tasks[key] = WorkerThreadPool.add_task(_bake_pool.bind(key, px, color, variant))
	var best: Array = []
	var best_gap: = 1 << 30
	var tail: = "|%s|%d" % [color.to_html(), variant]
	for k: String in _pools:
		if k.ends_with(tail) and absi(int(k.get_slice("|", 0)) - px) < best_gap:
			best_gap = absi(int(k.get_slice("|", 0)) - px)
			best = _pools[k]
	return best


static func pool_size(radius: float) -> float:
	return (maxi(4, roundi(radius / PIXEL)) * 2 + 8) * PIXEL


static func _bake_pool(key: String, px: int, color: Color, variant: int) -> void :
	var outline: = color.darkened(0.85)
	var crust: = color.darkened(0.55)
	var crust_lit: = color.darkened(0.4)
	var body: = color.darkened(0.1)
	var hot: = color.lightened(0.45)
	var core: = color.lightened(0.8)
	var shape: = FastNoiseLite.new()
	shape.seed = 11 + variant * 97
	shape.frequency = 0.9
	var cells: = FastNoiseLite.new()
	cells.seed = 5 + variant * 31
	cells.noise_type = FastNoiseLite.TYPE_CELLULAR
	cells.cellular_return_type = FastNoiseLite.RETURN_DISTANCE2_SUB
	cells.frequency = PIXEL / 19.0
	var n: = px * 2 + 8
	var c: = Vector2(n, n) * 0.5
	var frames: Array = []
	for f in POOL_FRAMES:
		var img: = Image.create_empty(n, n, false, Image.FORMAT_RGBA8)
		for y in n:
			for x in n:
				var v: = Vector2(x + 0.5, y + 0.5) - c
				var d: = v.length()
				var dir: = v / maxf(d, 0.001)
				var edge: = px * (0.9 + 0.16 * shape.get_noise_2d(dir.x * 2.0, dir.y * 2.0))
				if d > edge:
					continue
				var t: = d / edge
				var col: Color
				if d > edge - 1.0:
					col = outline
				elif d > edge - 2.0:
					col = crust
				elif d > edge - 3.0:
					col = body
				else:
					var border: = cells.get_noise_2d(x, y) + 1.0
					var width: = 0.2 + 0.5 * (1.0 - t) * (1.0 - t) + (0.06 if f == 1 else 0.0)
					if t < 0.22:
						col = core if border < 0.35 else hot
					elif border < width * 0.45:
						col = core if t < 0.55 else hot
					elif border < width:
						col = hot if t < 0.6 else body
					elif border > 0.75 and t < 0.75:
						col = crust_lit
					else:
						col = crust
				img.set_pixel(x, y, col)
		frames.append(img)
	_pool_lock.lock()
	_pool_images[key] = frames
	_pool_lock.unlock()







static func _span(ci: CanvasItem, x0: float, x1: float, y: float, color: Color) -> void :
	var a: = roundf(x0 / PIXEL) * PIXEL
	var b: = roundf(x1 / PIXEL) * PIXEL
	if b > a:
		ci.draw_rect(Rect2(a, y, b - a, PIXEL), color)

static func _rows(y0: float, y1: float) -> Array:
	var out: = []
	var y: = floorf(y0 / PIXEL) * PIXEL
	while y < y1:
		out.append(y)
		y += PIXEL
	return out







const SHAPE_CACHE_MAX: = 1500



const NATIVE_FROM: = 24
static var _shapes: = {}



static var _old_shapes: = {}


static func _shape_texture(outer: int, inner: int, pad: = 0) -> Texture2D:
	var key: = Vector3i(outer, inner, pad)
	if _shapes.has(key):
		return _shapes[key]
	if _shapes.size() >= SHAPE_CACHE_MAX:
		_old_shapes = _shapes
		_shapes = {}
	if _old_shapes.has(key):
		_shapes[key] = _old_shapes[key]
		return _shapes[key]
	var n: = outer * 2
	var img: = Image.create_empty(n + pad * 2, n + pad * 2, false, Image.FORMAT_RGBA8)
	for y in n:
		var dy: = y + 0.5 - outer
		if absf(dy) > outer:
			continue
		var o: = roundi(sqrt(outer * outer - dy * dy))
		if absf(dy) >= inner:
			if o > 0:
				img.fill_rect(Rect2i(pad + outer - o, pad + y, o * 2, 1), Color.WHITE)
		else:
			var i: = roundi(sqrt(inner * inner - dy * dy))
			if o > i:
				img.fill_rect(Rect2i(pad + outer - o, pad + y, o - i, 1), Color.WHITE)
				img.fill_rect(Rect2i(pad + outer + i, pad + y, o - i, 1), Color.WHITE)
	var tex: = ImageTexture.create_from_image(img)
	_shapes[key] = tex
	return tex

static func _draw_shape(ci: CanvasItem, center: Vector2, outer: int, inner: int, color: Color) -> void :
	if outer <= 0:
		return
	if PIXEL == 1.0 and outer >= NATIVE_FROM:
		var c: = snap(center)
		if inner <= 0:
			ci.draw_circle(c, outer, color)
		else:
			ci.draw_arc(c, (outer + inner) * 0.5, 0.0, TAU, _arc_points(outer, TAU), color, outer - inner)
		return
	var tex: = _shape_texture(outer, inner)
	var size: = Vector2.ONE * outer * 2 * PIXEL
	ci.draw_texture_rect(tex, Rect2(snap(center) - size * 0.5, size), false, color)


static func _arc_points(r: float, span: float) -> int:
	return clampi(ceili(absf(span) / (2.0 * acos(clampf(1.0 - 0.33 / maxf(r, 1.0), -1.0, 1.0)))), 8, 256) + 1


static func disc(ci: CanvasItem, center: Vector2, r: float, color: Color, filled: = true) -> void :
	if not filled:
		arc(ci, center, r, 0.0, TAU, color, PIXEL)
		return
	if r <= 0.0:
		return
	_draw_shape(ci, center, roundi(r / PIXEL), 0, color)




static func arc(ci: CanvasItem, center: Vector2, r: float, a0: float, a1: float, color: Color, width: = -1.0, baked: = false) -> void :
	var w: = maxf(width, PIXEL)
	var ro: = r + w * 0.5
	var ri: = maxf(r - w * 0.5, 0.0)
	if absf(a1 - a0) >= TAU - 0.001:
		var o: = roundi(ro / PIXEL)
		_draw_shape(ci, center, o, mini(roundi(ri / PIXEL), o - 1), color)
		return
	if absf(a1 - a0) < 0.002 or ro <= 0.0:
		return
	if baked:
		_baked_arc(ci, center, ro, ri, a0, a1, color)
		return


	var step: = 2.0 * acos(clampf(1.0 - PIXEL * 0.25 / ro, -1.0, 1.0))
	var steps: = clampi(ceili(absf(a1 - a0) / maxf(step, 0.01)), 3, 256)
	var band: = PackedVector2Array()
	for i in steps + 1:
		band.append(center + Vector2.RIGHT.rotated(lerpf(a0, a1, float(i) / steps)) * ro)
	for i in range(steps, -1, -1):
		band.append(center + Vector2.RIGHT.rotated(lerpf(a0, a1, float(i) / steps)) * ri)
	poly(ci, band, color)




static func _baked_arc(ci: CanvasItem, center: Vector2, ro: float, ri: float, a0: float, a1: float, color: Color) -> void :
	const PAD: = 2
	var o: = roundi(ro / PIXEL)
	if o <= 0:
		return
	if PIXEL == 1.0 and o >= NATIVE_FROM:
		ci.draw_arc(snap(center), (ro + ri) * 0.5, a0, a1, _arc_points(ro, a1 - a0), color, maxf(ro - ri, 1.0))
		return
	var tex: = _shape_texture(o, mini(roundi(ri / PIXEL), o - 1), PAD)
	var half: = o * PIXEL
	var tex_size: = (o + PAD) * 2.0 * PIXEL
	var c: = snap(center)
	var span: = a1 - a0

	var steps: = clampi(ceili(absf(span) / 0.12), 2, 64)
	var rim: = half / cos(absf(span) / steps * 0.5) + PIXEL
	var pts: = PackedVector2Array([c])
	var uvs: = PackedVector2Array([Vector2(0.5, 0.5)])
	for i in steps + 1:
		var d: = Vector2.RIGHT.rotated(a0 + span * i / steps) * rim
		pts.append(c + d)
		uvs.append(Vector2(0.5, 0.5) + d / tex_size)
	ci.draw_polygon(pts, PackedColorArray([color]), uvs, tex)


static func poly(ci: CanvasItem, points: PackedVector2Array, color: Color) -> void :
	var n: = points.size()
	if n < 3:
		return
	var y0: = INF
	var y1: = - INF
	for p in points:
		y0 = minf(y0, p.y)
		y1 = maxf(y1, p.y)
	for y in _rows(y0, y1):
		var yc: float = y + PIXEL * 0.5
		var xs: Array[float] = []
		for i in n:
			var a: = points[i]
			var b: = points[(i + 1) % n]
			if (a.y <= yc and b.y > yc) or (b.y <= yc and a.y > yc):
				xs.append(a.x + (yc - a.y) / (b.y - a.y) * (b.x - a.x))
		xs.sort()
		for k in range(0, xs.size() - 1, 2):
			_span(ci, xs[k], xs[k + 1], y, color)


static func line(ci: CanvasItem, a: Vector2, b: Vector2, color: Color, width: = -1.0) -> void :
	var w: = maxf(width, PIXEL) * 0.5
	var d: = b - a
	if d.length_squared() < 0.01:
		disc(ci, a, w, color)
		return
	var side: = d.normalized().orthogonal() * w
	var along: = d.normalized() * w * 0.5
	_quad(ci, a - along + side, b + along + side, b + along - side, a - along - side, color)




static func _quad(ci: CanvasItem, p0: Vector2, p1: Vector2, p2: Vector2, p3: Vector2, color: Color) -> void :
	var y0: = minf(minf(p0.y, p1.y), minf(p2.y, p3.y))
	var y1: = maxf(maxf(p0.y, p1.y), maxf(p2.y, p3.y))
	var y: = floorf(y0 / PIXEL) * PIXEL
	while y < y1:
		var yc: = y + PIXEL * 0.5
		var lo: = INF
		var hi: = - INF
		for e in 4:
			var a: Vector2 = p0 if e == 0 else (p1 if e == 1 else (p2 if e == 2 else p3))
			var b: Vector2 = p1 if e == 0 else (p2 if e == 1 else (p3 if e == 2 else p0))
			if (a.y <= yc and b.y > yc) or (b.y <= yc and a.y > yc):
				var x: = a.x + (yc - a.y) / (b.y - a.y) * (b.x - a.x)
				lo = minf(lo, x)
				hi = maxf(hi, x)
		if hi > lo:
			_span(ci, lo, hi, y, color)
		y += PIXEL






static func bake_polylines(lines: Array, width_mults: Array, layers: Array) -> Dictionary:
	var pad: = 0.0
	for layer: Array in layers:
		pad = maxf(pad, float(layer[1]))
	var lo: = Vector2(INF, INF)
	var hi: = Vector2( - INF, - INF)
	for pts: PackedVector2Array in lines:
		for p in pts:
			lo = lo.min(p)
			hi = hi.max(p)
	lo = snap(lo - Vector2.ONE * (pad + PIXEL))
	hi += Vector2.ONE * (pad + PIXEL)
	var size: = Vector2i(ceili((hi.x - lo.x) / PIXEL) + 1, ceili((hi.y - lo.y) / PIXEL) + 1)
	var img: = Image.create_empty(size.x, size.y, false, Image.FORMAT_RGBA8)
	for layer: Array in layers:
		for k in lines.size():
			var pts: PackedVector2Array = lines[k]
			var w: = maxf(float(layer[1]) * float(width_mults[k]), PIXEL) * 0.5
			for i in pts.size() - 1:
				var a: = pts[i] - lo
				var b: = pts[i + 1] - lo
				var d: = b - a
				if d.length_squared() < 0.01:
					continue
				var side: = d.normalized().orthogonal() * w
				var along: = d.normalized() * w * 0.5
				_quad_into(img, a - along + side, b + along + side, b + along - side, a - along - side, layer[0])
	return {"tex": ImageTexture.create_from_image(img), "pos": lo}


static func _quad_into(img: Image, p0: Vector2, p1: Vector2, p2: Vector2, p3: Vector2, color: Color) -> void :
	var y0: = minf(minf(p0.y, p1.y), minf(p2.y, p3.y))
	var y1: = maxf(maxf(p0.y, p1.y), maxf(p2.y, p3.y))
	var y: = floorf(y0 / PIXEL) * PIXEL
	while y < y1:
		var yc: = y + PIXEL * 0.5
		var lo: = INF
		var hi: = - INF
		for e in 4:
			var a: Vector2 = p0 if e == 0 else (p1 if e == 1 else (p2 if e == 2 else p3))
			var b: Vector2 = p1 if e == 0 else (p2 if e == 1 else (p3 if e == 2 else p0))
			if (a.y <= yc and b.y > yc) or (b.y <= yc and a.y > yc):
				var x: = a.x + (yc - a.y) / (b.y - a.y) * (b.x - a.x)
				lo = minf(lo, x)
				hi = maxf(hi, x)
		var ta: = roundi(lo / PIXEL)
		var tb: = roundi(hi / PIXEL)
		var row: = int(y / PIXEL)
		if tb > ta and row >= 0 and row < img.get_height():
			ta = clampi(ta, 0, img.get_width())
			tb = clampi(tb, 0, img.get_width())
			if tb > ta:
				img.fill_rect(Rect2i(ta, row, tb - ta, 1), color)
		y += PIXEL

static func polyline(ci: CanvasItem, points: PackedVector2Array, color: Color, width: = -1.0) -> void :
	for i in points.size() - 1:
		line(ci, points[i], points[i + 1], color, width)

static func rect(ci: CanvasItem, r: Rect2, color: Color) -> void :
	var a: = (r.position / PIXEL).round() * PIXEL
	var b: = (r.end / PIXEL).round() * PIXEL
	if b.x > a.x and b.y > a.y:
		ci.draw_rect(Rect2(a, b - a), color)
