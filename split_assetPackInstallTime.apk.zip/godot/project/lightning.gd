class_name Lightning
extends Weapon

const ID: = "lightning"
const COOLDOWN_TEXT: = "strikes %d%% more often"
const FLASH_TIME: = 0.18
const IMPACT_TIME: = 0.45
const SPLASH: = 50.0
const BASE: = {"damage": 14.0, "cooldown": 1.4, "count": 1, "area": 1.0}
const UPGRADES: = [
	{"damage": 6.0}, 
	{"cooldown": 0.88}, 
	{"count": 1}, 
	{"area": 1.25}, 
	{"damage": 8.0}, 
	{"cooldown": 0.88}, 
	{"count": 2}, 
]




const HOLY: = {"damage": 14.0, "area": 1.25, "cooldown": 0.85}
const ECHO_DELAY: = 0.3
const HEART_CHANCE: = 0.025

var cooldown: = 1.4
var damage: = 14.0
var count: = 1
var area: = 1.0
var _timer: = 0.3
var _strikes: Array[Dictionary] = []
var _echoes: Array[Dictionary] = []
var _time: = 0.0
var _ground: Node2D

func _on_level() -> void :
	Layers.put(self, Layers.SKY)
	if _ground == null:
		_ground = Layers.canvas(self, Layers.GROUND_EFFECTS, _draw_ground, false)

func splash() -> float:
	return area_of(SPLASH * area)

func _process(delta: float) -> void :
	_time += delta
	if not _echoes.is_empty():
		for ec in _echoes:
			ec["t"] -= delta
		var due: = _echoes.filter( func(ec: Dictionary) -> bool: return ec["t"] <= 0.0)
		_echoes = _echoes.filter( func(ec: Dictionary) -> bool: return ec["t"] > 0.0)
		for ec in due:
			_strike(ec["at"], true)
	if not _strikes.is_empty():
		for s in _strikes:
			s["time"] -= delta
		_strikes = _strikes.filter( func(s: Dictionary) -> bool: return s["time"] > 0.0)
		_redraw()
	_timer -= delta
	if _timer > 0.0:
		return
	var targets: = enemies_on_screen()
	if targets.is_empty():
		return
	_timer = cooldown_of(cooldown)
	targets.shuffle()
	for i in mini(amount_of(count), targets.size()):
		_strike(targets[i].global_position)


func _strike(at: Vector2, echo: = false) -> void :
	for e: Enemy in Enemy.near(at, splash()):
		var reach: = splash() + e.radius
		if at.distance_squared_to(e.global_position) < reach * reach:
			e.take_damage(power(damage))
	var sparks: = PackedVector2Array()
	for k in 8:
		sparks.append(Vector2.RIGHT.rotated(randf() * TAU) * randf_range(0.6, 1.0))
	var bolt: = _bolt()
	_strikes.append({"bolt_tex": bolt["tex"], "bolt_pos": PixelFx.snap(at + bolt["pos"]), "at": at, "sparks": sparks, "time": IMPACT_TIME})
	if holy and not echo:
		_echoes.append({"at": at, "t": ECHO_DELAY})
		if randf() < HEART_CHANCE * player.luck:
			Pickup.little_heart(get_tree().current_scene, at)
	_redraw()






const BOLT_VARIANTS: = 10
var _bolts: Array[Dictionary] = []
var _bolts_holy: = false

func _bolt() -> Dictionary:
	if _bolts_holy != holy:
		_bolts.clear()
		_bolts_holy = holy
	if _bolts.size() < BOLT_VARIANTS:
		var top: = Vector2(randf_range(-60, 60), -700)
		var main: = _jagged(top, Vector2.ZERO, 14, 26.0)
		var lines: Array[PackedVector2Array] = [main]
		for k in 2:
			var from: = main[randi_range(5, 11)]
			lines.append(_jagged(from, from + Vector2(randf_range(-90, 90), randf_range(60, 150)), 5, 12.0))
		var hot: = color.lightened(0.6)
		var layers: Array = [[color.darkened(0.6), 10.0], [color, 6.0], [hot.lerp(Color.WHITE, 0.5), 2.0]]
		if holy:
			layers.push_front([Color(color, 0.35), 16.0])
		var baked: = PixelFx.bake_polylines(lines, [1.0, 0.5, 0.5], layers)
		_bolts.append(baked)
		return baked
	return _bolts.pick_random()

func _jagged(from: Vector2, to: Vector2, segments: int, jitter: float) -> PackedVector2Array:
	var points: = PackedVector2Array()
	for j in segments + 1:
		var p: = from.lerp(to, float(j) / segments)
		if j > 0 and j < segments:
			p += Vector2(randf_range( - jitter, jitter), randf_range( - jitter, jitter) * 0.3)
		points.append(p)
	return points

func _draw() -> void :
	for s in _strikes:
		var age: = IMPACT_TIME - float(s["time"])
		if age > FLASH_TIME:
			continue
		var a: = 1.0 - age / FLASH_TIME
		var tex: Texture2D = s["bolt_tex"]
		draw_texture_rect(tex, Rect2(to_local(s["bolt_pos"]), tex.get_size() * PixelFx.PIXEL), false, Color(1, 1, 1, a))
		PixelFx.disc(self, to_local(s["at"]), splash() * 0.3 * a, Color(1, 1, 1, (0.3 if holy else 0.55) * a))


func _draw_ground() -> void :
	var hot: = color.lightened(0.6)
	var r: = splash()
	for s in _strikes:
		var left: float = s["time"]
		var age: = IMPACT_TIME - left
		var fade: = left / IMPACT_TIME
		var at: = to_local(s["at"])
		PixelFx.disc(_ground, at, r * 0.7, Color(0, 0, 0, 0.25 * fade))
		PixelFx.disc(_ground, at, r, Color(color, 0.22 * fade))
		var wave: = r * (0.4 + 0.9 * age / IMPACT_TIME)
		PixelFx.arc(_ground, at, wave, 0, TAU, Color(hot, 0.7 * fade), 3.0 * fade + 1.0)
		for d: Vector2 in s["sparks"]:
			var p: = at + d * r * (0.3 + 1.6 * age / IMPACT_TIME)
			PixelFx.rect(_ground, Rect2(p - Vector2(2, 2), Vector2(4, 4)), Color(hot, fade))


func _redraw() -> void :
	queue_redraw()
	_ground.queue_redraw()
