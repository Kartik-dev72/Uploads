class_name FloatText
extends Node2D










const MAX_ITEMS: = 70
const SOFT_MAX: = 26

var _items: Array[Dictionary] = []

const GLYPH_W: = 5
const GLYPH_H: = 7
const ADVANCE: = 6
const GLYPHS: = {
	"0": [".###.", "#...#", "#..##", "#.#.#", "##..#", "#...#", ".###."], 
	"1": ["..#..", ".##..", "..#..", "..#..", "..#..", "..#..", ".###."], 
	"2": [".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####"], 
	"3": ["####.", "....#", "....#", ".###.", "....#", "....#", "####."], 
	"4": ["...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#."], 
	"5": ["#####", "#....", "####.", "....#", "....#", "#...#", ".###."], 
	"6": [".###.", "#....", "#....", "####.", "#...#", "#...#", ".###."], 
	"7": ["#####", "....#", "...#.", "..#..", ".#...", ".#...", ".#..."], 
	"8": [".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###."], 
	"9": [".###.", "#...#", "#...#", ".####", "....#", "....#", ".###."], 
	"+": [".....", "..#..", "..#..", "#####", "..#..", "..#..", "....."], 
	"-": [".....", ".....", ".....", "#####", ".....", ".....", "....."], 
	"!": ["..#..", "..#..", "..#..", "..#..", "..#..", ".....", "..#.."], 
	",": [".....", ".....", ".....", ".....", ".....", "..#..", ".#..."], 
	".": [".....", ".....", ".....", ".....", ".....", ".....", "..#.."], 
}
static var _atlas: Texture2D
static var _regions: = {}


static func _bake_atlas() -> void :
	var cell: = Vector2i(GLYPH_W + 2, GLYPH_H + 2)
	var keys: = GLYPHS.keys()
	var img: = Image.create_empty(cell.x * keys.size(), cell.y, false, Image.FORMAT_RGBA8)
	for i in keys.size():
		var rows: Array = GLYPHS[keys[i]]
		var ox: = i * cell.x
		for y in GLYPH_H:
			for x in GLYPH_W:
				if rows[y][x] != "#":
					continue
				for dy in range(-1, 2):
					for dx in range(-1, 2):
						var q: = Vector2i(ox + 1 + x + dx, 1 + y + dy)
						if img.get_pixelv(q).a == 0.0:
							img.set_pixelv(q, Color.BLACK)
		for y in GLYPH_H:
			for x in GLYPH_W:
				if rows[y][x] == "#":
					img.set_pixel(ox + 1 + x, 1 + y, Color.WHITE)
		_regions[keys[i]] = Rect2(ox, 0, cell.x, cell.y)
	_atlas = ImageTexture.create_from_image(img)

static func _is_number(text: String) -> bool:
	for ch in text:
		if not GLYPHS.has(ch):
			return false
	return true


static func _texel(font_size: int) -> int:
	return maxi(2, roundi(font_size / 8.0))
static var _live: FloatText


static func soft_full() -> bool:
	return is_instance_valid(_live) and _live._items.size() >= SOFT_MAX


static func pop(from: Node, text: String, pos: Vector2, color: = Color.WHITE, font_size: = 22, life: = 0.7, 
		rise: = 70.0, kick: = 1.5, soft: = false) -> void :
	var tree: = from.get_tree()
	if tree == null:
		return

	var ft: = _live if is_instance_valid(_live) and _live.is_inside_tree() else tree.get_first_node_in_group("float_text") as FloatText
	if ft == null:
		ft = FloatText.new()
		ft.add_to_group("float_text")
		_live = ft
		Layers.put(ft, Layers.FLOAT_TEXT)
		tree.current_scene.add_child(ft)
	if soft and ft._items.size() >= SOFT_MAX:
		return
	ft._add(text, pos, color, font_size, life, rise, kick, soft)

func _add(text: String, pos: Vector2, color: Color, font_size: int, life: float, rise: float, kick: float, soft: = false) -> void :
	if _items.size() >= MAX_ITEMS:
		_items.pop_front()
	var digits: = _is_number(text)
	var width: = 0.0
	if digits:
		width = float((text.length() * ADVANCE + 1) * _texel(font_size))
	else:
		width = ThemeDB.fallback_font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
	_items.append({"text": text, "pos": pos, "color": color, "size": font_size, "life": life, "age": 0.0, 
		"rise": rise, "kick": kick, "width": width, "drift": randf_range(-14.0, 14.0), "digits": digits, "soft": soft})

func _process(delta: float) -> void :
	if _items.is_empty():
		return
	for it in _items:
		it["age"] += delta
	_items = _items.filter( func(it: Dictionary) -> bool: return it["age"] < it["life"])
	queue_redraw()



const SOFT_ALPHA: = 0.75
const CLEAR_RADIUS: = 110.0
const NEAR_ALPHA: = 0.25

func _draw() -> void :
	var font: = ThemeDB.fallback_font
	var player: = get_tree().get_first_node_in_group("player") as Node2D
	var me: = player.global_position + Vector2(0, -30) if player else Vector2(INF, INF)
	for it in _items:
		var t: float = it["age"] / it["life"]
		var ease_out: = 1.0 - (1.0 - t) * (1.0 - t)
		var alpha: = 1.0 if t < 0.6 else 1.0 - (t - 0.6) / 0.4
		var pop_t: float = clampf(it["age"] / 0.14, 0.0, 1.0)
		var s: = lerpf(it["kick"], 1.0, pop_t)
		var p: Vector2 = it["pos"] + Vector2(it["drift"] * ease_out, - it["rise"] * ease_out)
		if it["soft"]:
			var near: = clampf(p.distance_to(me) / CLEAR_RADIUS, 0.0, 1.0)
			alpha *= lerpf(NEAR_ALPHA, SOFT_ALPHA, near * near)
		var fs: int = it["size"]
		draw_set_transform(p, 0.0, Vector2(s, s))
		var at: = Vector2( - it["width"] * 0.5, fs * 0.35)
		var c: Color = it["color"]
		if it["digits"]:
			if _atlas == null:
				_bake_atlas()
			var px: = _texel(fs)
			var x: = - float(it["width"]) * 0.5
			var size: = Vector2(GLYPH_W + 2, GLYPH_H + 2) * px
			for ch: String in it["text"]:
				draw_texture_rect_region(_atlas, Rect2(Vector2(x, - size.y * 0.5).round(), size), _regions[ch], Color(c, alpha))
				x += ADVANCE * px
			continue
		draw_string_outline(font, at, it["text"], HORIZONTAL_ALIGNMENT_LEFT, -1, fs, maxi(4, fs / 5), Color(0, 0, 0, alpha * 0.9))
		draw_string(font, at, it["text"], HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(c, alpha))
	draw_set_transform(Vector2.ZERO)
