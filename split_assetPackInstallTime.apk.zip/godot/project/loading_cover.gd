class_name LoadingCover
extends CanvasLayer








const MIN_TIME: = 0.45
const FADE: = 0.3
const SETUP_FRAMES: = 2
const WARM_BUDGET_MS: = 12
const TIMEOUT: = 6.0

enum State{LEAVING, SETUP, LOADING, FADING}

var _state: = State.LEAVING
var _old_scene: = 0
var _frames: = 0
var _age: = 0.0
var _fade: = 0.0
var _warm: Array[Callable] = []
var _warm_total: = 1
var _root: Control
var _bar: ColorRect
var _dots: Label


static func go(tree: SceneTree, change: Callable) -> void :
	if tree.root.get_children().any( func(n: Node) -> bool: return n is LoadingCover):
		return
	var cover: = LoadingCover.new()
	cover._old_scene = tree.current_scene.get_instance_id() if tree.current_scene else 0
	tree.root.add_child(cover)
	for i in 2:
		await tree.process_frame
	change.call()

func _ready() -> void :
	layer = 120
	process_mode = Node.PROCESS_MODE_ALWAYS
	var t: = Game.theme
	_root = Control.new()
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_root)
	var bg: = ColorRect.new()
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.color = Color(0.04, 0.015, 0.02)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(bg)
	var view: = Game.view_size()
	var title: = Label.new()
	title.text = str(Game.tier_info(Game.tier).get("name", "")).to_upper() if not Game.dev_mode else "DEV ARENA"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.position = Vector2(0, view.y * 0.42)
	title.size = Vector2(view.x, 90)
	title.add_theme_font_size_override("font_size", 64)
	title.add_theme_color_override("font_color", t.ui["accent"])
	title.add_theme_color_override("font_outline_color", Color.BLACK)
	title.add_theme_constant_override("outline_size", 12)
	_root.add_child(title)
	_dots = Label.new()
	_dots.text = "Descending"
	_dots.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_dots.position = Vector2(0, view.y * 0.42 + 96)
	_dots.size = Vector2(view.x, 40)
	_dots.add_theme_font_size_override("font_size", 26)
	_dots.add_theme_color_override("font_color", Color(1, 1, 1, 0.6))
	_root.add_child(_dots)
	var track: = ColorRect.new()
	track.position = Vector2(view.x * 0.25, view.y * 0.42 + 150)
	track.size = Vector2(view.x * 0.5, 6)
	track.color = Color(1, 1, 1, 0.12)
	_root.add_child(track)
	_bar = ColorRect.new()
	_bar.position = track.position
	_bar.size = Vector2(0, 6)
	_bar.color = t.ui["accent"]
	_root.add_child(_bar)

func _process(delta: float) -> void :
	_age += delta
	_dots.text = "Descending" + ".".repeat(int(_age * 3.0) % 4)
	var tree: = get_tree()
	match _state:
		State.LEAVING:
			var scene: = tree.current_scene
			if scene != null and scene.get_instance_id() != _old_scene:
				_state = State.SETUP
			elif _age > TIMEOUT:
				queue_free()
		State.SETUP:
			_frames += 1
			if _frames >= SETUP_FRAMES:
				tree.paused = true
				_build_warm_list()
				_state = State.LOADING
		State.LOADING:
			var start: = Time.get_ticks_msec()
			while not _warm.is_empty() and Time.get_ticks_msec() - start < WARM_BUDGET_MS:
				(_warm.pop_back() as Callable).call()
			var map: = tree.get_first_node_in_group("map") as GameMap
			var painting: = map != null and map.collect_paint()
			var done: = 1.0 - float(_warm.size()) / _warm_total
			_bar.size.x = lerpf(_bar.size.x, Game.view_size().x * 0.5 * (done * 0.8 + (0.0 if painting else 0.2)), 0.35)
			if (_warm.is_empty() and not painting and _age >= MIN_TIME) or _age > TIMEOUT:
				_state = State.FADING
				_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
				LevelUpScreen.resume_if_clear(tree, false)
		State.FADING:
			_fade += delta / FADE
			_root.modulate.a = 1.0 - _fade
			if _fade >= 1.0:
				queue_free()



func _build_warm_list() -> void :
	var t: = Game.theme
	var seen: = {}
	for row: Dictionary in t.spawn_table:
		var sprite: = str(t.enemies.get(row.get("enemy", ""), {}).get("sprite", ""))
		if sprite != "" and not seen.has(sprite):
			seen[sprite] = true
			_warm.append(t.frames.bind(sprite, "rim"))
			_warm.append(t.texture.bind(sprite))
	for p: Dictionary in t.props:
		var sprite: = str(p.get("sprite", ""))
		if sprite != "" and not seen.has(sprite):
			seen[sprite] = true
			_warm.append(t.frames.bind(sprite, "prop_rim"))
	for sprite: String in t.pickups.values():
		_warm.append(t.texture.bind(sprite))
	_warm.reverse()
	_warm_total = maxi(_warm.size(), 1)
