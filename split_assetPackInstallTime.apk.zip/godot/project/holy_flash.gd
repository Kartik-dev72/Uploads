class_name HolyFlash
extends Node2D





const DURATION: = 1.3
const RAYS: = 18
const SCREEN_MARGIN: = 40.0

var _player: Node2D
var _time: = 0.0
var _holy: Color

static func purge(player: Player) -> void :
	var tree: = player.get_tree()
	var view: = player.get_viewport()
	var on_screen: = (view.get_canvas_transform().affine_inverse() * view.get_visible_rect()).grow(SCREEN_MARGIN)
	for node: Node in tree.get_nodes_in_group("enemies"):
		var e: = node as Enemy
		if e == null or e is Breakable or e.is_boss or e.behavior == "still":
			continue
		if on_screen.has_point(e.global_position):
			e.die()
	var fx: = HolyFlash.new()
	fx._player = player
	fx.position = player.global_position
	tree.current_scene.add_child(fx)

func _ready() -> void :
	Layers.put(self, Layers.FLASH)
	process_mode = Node.PROCESS_MODE_ALWAYS
	_holy = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))

func _process(delta: float) -> void :
	_time += delta
	if _time >= DURATION:
		queue_free()
		return
	if is_instance_valid(_player):
		position = _player.global_position
	queue_redraw()

func _draw() -> void :
	var t: = _time / DURATION
	var fade: = 1.0 - t

	draw_rect(Rect2(-1200, -1600, 2400, 3200), Color(Color.WHITE.lerp(_holy, t), 0.9 * fade * fade))

	for i in RAYS:
		var a: = TAU * i / RAYS + _time * 0.6
		var dir: = Vector2.RIGHT.rotated(a)
		var side: = dir.orthogonal() * 40.0
		draw_colored_polygon(PackedVector2Array([Vector2.ZERO, dir * 1500 + side, dir * 1500 - side]), Color(_holy, 0.35 * fade))

	var s: = 1.0 + t * 1.5
	var glow: = Color(Color.WHITE, 0.8 * fade)
	draw_rect(Rect2(-16 * s, -150 * s, 32 * s, 260 * s), glow)
	draw_rect(Rect2(-90 * s, -80 * s, 180 * s, 32 * s), glow)

	var ring: = 1000.0 * (1.0 - pow(1.0 - t, 3.0))
	draw_arc(Vector2.ZERO, ring, 0, TAU, 64, Color(_holy, fade), 40.0 * fade + 2.0)
	draw_arc(Vector2.ZERO, ring * 0.92, 0, TAU, 64, Color(Color.WHITE, 0.6 * fade), 12.0 * fade + 1.0)
