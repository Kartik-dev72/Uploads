class_name TerrainFx
extends Node2D






const MAX: = 46
const PX: = 2.0

var map: GameMap
var _bits: Array[Dictionary] = []
var _time: = 0.0

func _ready() -> void :
	Layers.put(self, Layers.MAP_DETAIL)

func _process(delta: float) -> void :
	_time += delta
	var cam: = get_viewport().get_camera_2d()
	if not cam or not map:
		return
	var view: = Rect2(cam.get_screen_center_position() - Game.view_size() / 2.0, Game.view_size()).grow(60.0)
	for b in _bits:
		b["age"] += delta
		if b["kind"] == "current":
			b["pos"] += map.flow_at(b["pos"]) * 1.4 * delta
		elif b["kind"] == "mote":
			b["pos"] += Vector2(0, 10.0) * delta
	_bits = _bits.filter( func(b: Dictionary) -> bool: return b["age"] < b["life"] and view.has_point(b["pos"]))
	for i in 8:
		if _bits.size() >= MAX:
			break
		var p: = view.position + Vector2(randf(), randf()) * view.size
		var kind: = _kind_at(map.ground_at(p))
		if kind != "":
			_bits.append({"pos": p, "age": 0.0, "life": randf_range(0.9, 2.2) if kind != "current" else randf_range(1.4, 2.6), "kind": kind})
	queue_redraw()

func _kind_at(g: int) -> String:
	match g:
		GameMap.Ground.LAVA:
			return "bubble"
		GameMap.Ground.CURRENT:
			return "current"
		GameMap.Ground.DEEP:
			return "ripple" if randf() < 0.35 else ""
		GameMap.Ground.VOID:
			return "mote" if randf() < 0.5 else ""
		GameMap.Ground.ICE:
			return "glint" if randf() < 0.3 else ""
	return ""

func _draw() -> void :
	var c: Dictionary = Game.theme.map
	var hot: Color = c.get("path_core", Color(1, 0.8, 0.3))
	var foam: Color = c.get("path_core", Color(0.6, 0.9, 1))
	var glint: Color = (c.get("pool_edge", Color(0.7, 0.8, 0.9)) as Color).lightened(0.35)
	for b in _bits:
		var k: float = b["age"] / b["life"]
		var p: = (b["pos"] as Vector2).snapped(Vector2.ONE * PX)
		var fade: = sin(PI * k)
		match b["kind"]:
			"bubble":
				if k < 0.75:
					var r: = snappedf(lerpf(PX, PX * 3.0, k / 0.75), PX)
					draw_rect(Rect2(p - Vector2.ONE * r, Vector2.ONE * r * 2.0), Color(hot.lightened(0.3), 0.85))
					draw_rect(Rect2(p - Vector2.ONE * r + Vector2(PX, PX), Vector2.ONE * PX), Color(1, 1, 0.9, 0.9))
				else:
					var d: = snappedf(lerpf(PX * 3.0, PX * 6.0, (k - 0.75) / 0.25), PX)
					for dir: Vector2 in [Vector2.UP, Vector2.DOWN, Vector2.LEFT, Vector2.RIGHT]:
						draw_rect(Rect2(p + dir * d, Vector2.ONE * PX), Color(hot, 1.0 - k))
			"current":
				var f: = map.flow_at(b["pos"])
				if f == Vector2.ZERO:
					continue
				var dir: = f.normalized()
				for i in 4:
					draw_rect(Rect2((p - dir * i * PX).snapped(Vector2.ONE * PX), Vector2.ONE * PX), Color(foam.lightened(0.45), 0.8 * fade * (1.0 - i * 0.2)))
			"ripple":
				var r: = snappedf(lerpf(PX * 2.0, PX * 9.0, k), PX)
				var col: = Color(glint, 0.5 * (1.0 - k))
				draw_rect(Rect2(p - Vector2(r, PX * 0.5), Vector2(PX, PX)), col)
				draw_rect(Rect2(p + Vector2(r - PX, - PX * 0.5), Vector2(PX, PX)), col)
				draw_rect(Rect2(p - Vector2(r * 0.6, r * 0.45), Vector2(r * 1.2, PX)), col)
				draw_rect(Rect2(p + Vector2( - r * 0.6, r * 0.45 - PX), Vector2(r * 1.2, PX)), col)
			"glint":
				var a: = 0.9 * fade
				var arm: = PX if k < 0.3 or k > 0.7 else PX * 2.0
				draw_rect(Rect2(p, Vector2.ONE * PX), Color(1, 1, 1, a))
				for dir: Vector2 in [Vector2.UP, Vector2.DOWN, Vector2.LEFT, Vector2.RIGHT]:
					draw_rect(Rect2(p + dir * arm, Vector2.ONE * PX), Color(0.8, 0.95, 1, a * 0.7))
			"mote":
				draw_rect(Rect2(p, Vector2.ONE * PX), Color(glint, 0.7 * fade))
