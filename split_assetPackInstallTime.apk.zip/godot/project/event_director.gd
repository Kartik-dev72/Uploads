class_name EventDirector
extends Node2D










const ENEMY: = preload("res://enemy.tscn")
const ERUPT_RADIUS: = 90.0
const ERUPT_DELAY: = 1.1
const ERUPT_FADE: = 0.4
const ERUPT_EVERY: = 1.5
const ERUPT_DAMAGE: = 0.5
const MOON_RATE: = 2.2
const MOON_XP: = 2.0
const GAP: = 40.0

var rate_mult: = 1.0

var _spawner: Spawner
var _player: Player
var _next: = 0
var _active: = {}
var _left: = 0.0
var _clock: = 0.0
var _hazards: Array[Dictionary] = []
var _tint: ColorRect
var _tint_alpha: = 0.0
var _time: = 0.0
var _gloom: Gloom
var _calm: = 0.0


const MOODS: = {
	"blood_moon": ["moon_rise", "moon_loop", 0.88, 20000.0, -3.0], 
	"eruption": ["quake", "quake_loop", 1.0, 20000.0, -2.0], 
	"gloom": ["gloom_rise", "gloom_loop", 0.96, 700.0, 0.0], 
}
const LOOP_DB: = -4.0
var _loop: AudioStreamPlayer
var _edges: Node2D

func setup(spawner: Spawner) -> void :
	_spawner = spawner

func _ready() -> void :
	Layers.put(self, Layers.WARNINGS)
	_player = get_tree().get_first_node_in_group("player") as Player
	var layer: = CanvasLayer.new()
	layer.layer = 0
	add_child(layer)
	_tint = ColorRect.new()
	_tint.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_tint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_tint.color = Color(0, 0, 0, 0)
	layer.add_child(_tint)
	_gloom = get_tree().get_first_node_in_group("gloom") as Gloom
	_edges = Layers.canvas(self, Layers.SHOTS, _draw_edges)
	_loop = AudioStreamPlayer.new()
	_loop.bus = "SFX"
	add_child(_loop)
	add_to_group("event_director")

func _exit_tree() -> void :
	Game.music_mood(1.0, 20000.0, 0.0, 0.3)


func _sound_on(type: String) -> void :
	var mood: Array = MOODS.get(type, [])
	if mood.is_empty():
		return
	Game.sfx(mood[0])
	Game.music_mood(mood[2], mood[3], mood[4])
	_loop.stream = Game.loop_stream(mood[1])
	if _loop.stream:
		_loop.volume_db = -40.0
		_loop.play()
		create_tween().tween_property(_loop, "volume_db", LOOP_DB, 2.0)



func stop_for_win() -> void :
	set_process(false)
	silence()
	_hazards.clear()
	queue_redraw()
	_edges.queue_redraw()
	_tint.color.a = 0.0
	if _active.get("type", "") == "gloom" and _gloom:
		_gloom.pop()
	_active = {}


func silence() -> void :
	Game.music_mood(1.0, 20000.0, 0.0, 0.5)
	if _loop and _loop.playing:
		var t: = create_tween().set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
		t.tween_property(_loop, "volume_db", -40.0, 0.5)
		t.tween_callback(_loop.stop)

func _sound_off() -> void :
	Game.music_mood()
	if _loop.playing:
		var t: = create_tween()
		t.tween_property(_loop, "volume_db", -40.0, 1.5)
		t.tween_callback(_loop.stop)
	if not _player.is_dead():
		Game.sfx("event_end")

func _process(delta: float) -> void :
	if not is_instance_valid(_player) or not is_instance_valid(_spawner):
		return
	_time += delta
	var events: Array = Game.theme.events
	if _active.is_empty():
		_calm = 0.0 if _spawner.fighting() else _calm + delta
		if _next < events.size() and _player.survived >= float(events[_next]["at"]) and _calm >= GAP:
			_start(events[_next])
			_next += 1
			_calm = 0.0
	else:
		_calm = 0.0
		_run(delta)
	_update_hazards(delta)
	var moon: bool = _active.get("type", "") == "blood_moon"
	var want: = (0.16 + 0.05 * sin(_time * 3.0)) if moon else 0.0
	_tint_alpha = move_toward(_tint_alpha, want, delta * 0.4)
	var c: Color = Game.theme.event_colors.get("blood_moon", Color(0.9, 0.05, 0.1))
	_tint.color = Color(c, _tint_alpha)
	queue_redraw()



func save_state() -> Dictionary:
	return {"next": _next, "active": _active.duplicate(true), "left": _left, "calm": _calm}

func load_state(d: Dictionary) -> void :
	_next = int(d["next"])
	_calm = float(d["calm"])
	var active: Dictionary = d["active"]
	if active.is_empty():
		return
	var left: = float(d["left"])
	ready.connect( func() -> void :
		_start(active)
		_left = left, CONNECT_ONE_SHOT)


func status() -> String:
	if _active.is_empty():
		return ""
	return "%s  %ds" % [str(_active.get("banner", "")), ceili(_left)]

func _start(e: Dictionary) -> void :
	_spawner.show_banner(str(e.get("banner", "")), str(e.get("info", "")))
	match e["type"]:
		"blood_moon":
			_active = e
			_left = e.get("time", 30.0)
			rate_mult = MOON_RATE
			_player.event_xp_mult = MOON_XP
			_sound_on("blood_moon")
		"eruption":
			_active = e
			_left = e.get("time", 25.0)
			_clock = 0.0
			_sound_on("eruption")
		"miniboss":
			_spawn_champion(e)
			Game.sfx("champion")
		"gloom":
			_active = e
			_left = e.get("time", 20.0)
			if _gloom:
				_gloom.push(e)
			_sound_on("gloom")

func _run(delta: float) -> void :
	_left -= delta
	if _active["type"] == "eruption":
		_clock -= delta
		if _clock <= 0.0:
			_clock = ERUPT_EVERY
			_drop_hazards()
	if _left <= 0.0:
		if _active["type"] == "gloom" and _gloom:
			_gloom.pop()
		if _active["type"] == "blood_moon":
			rate_mult = 1.0
			_player.event_xp_mult = 1.0
			if not _player.is_dead():
				Game.track("moons")
		_active = {}
		_sound_off()

func _spawn_champion(e: Dictionary) -> void :
	var data: Dictionary = Game.theme.enemies.get(e.get("enemy", ""), {})
	if data.is_empty():
		push_warning("miniboss event names unknown enemy '%s'" % e.get("enemy", ""))
		return
	var enemy: = ENEMY.instantiate() as Enemy
	enemy.configure(data, _spawner.hp_mult(_player.survived), _spawner.speed_mult())
	enemy.make_elite("champion")
	enemy.kind_id = str(e.get("enemy", ""))
	enemy.global_position = GameMap.current.ring_point(_player.global_position, Game.offscreen_distance()) if GameMap.current else _player.global_position + Vector2.RIGHT.rotated(randf() * TAU) * Game.offscreen_distance()
	_spawner.add_child(enemy)




func _drop_hazards() -> void :
	_add_hazard(_player.global_position + _player.facing * 170.0)
	_add_hazard(GameMap.reachable(_player.global_position + Vector2.RIGHT.rotated(randf() * TAU) * randf_range(140.0, 420.0)))

func _add_hazard(pos: Vector2) -> void :
	_hazards.append({"pos": pos, "t": 0.0, "boom": false})

func _update_hazards(delta: float) -> void :
	for h in _hazards:
		h["t"] += delta
		if not h["boom"] and h["t"] >= ERUPT_DELAY:
			h["boom"] = true
			_explode(h["pos"])
	_hazards = _hazards.filter( func(h: Dictionary) -> bool: return h["t"] < ERUPT_DELAY + ERUPT_FADE)

func _explode(pos: Vector2) -> void :
	Game.sfx("explode")
	_player.shake(4.0)
	if _player.global_position.distance_to(pos) < ERUPT_RADIUS + _player.radius * 0.5:
		_player.take_hit(1.0)
	for e: Enemy in Enemy.near(pos, ERUPT_RADIUS):
		if e.targetable and not e.is_boss and e.global_position.distance_squared_to(pos) < pow(ERUPT_RADIUS + e.radius, 2):
			e.take_damage(e.max_hp * ERUPT_DAMAGE, 0.0)






func _draw() -> void :
	var c: Color = Game.theme.event_colors.get("eruption", Color(1, 0.45, 0.1))
	for h in _hazards:
		var p: Vector2 = h["pos"]
		var t: float = h["t"]
		if t < ERUPT_DELAY:
			var k: = t / ERUPT_DELAY
			var blink: = 0.7 + 0.3 * sin(t * 30.0) if k > 0.6 else 1.0
			draw_circle(p, ERUPT_RADIUS, Color(0, 0, 0, 0.32))
			draw_circle(p, ERUPT_RADIUS, Color(c, (0.14 + 0.18 * k) * blink))
			draw_circle(p, ERUPT_RADIUS * k, Color(c.lightened(0.2), 0.45))
		else:
			var f: = (t - ERUPT_DELAY) / ERUPT_FADE
			draw_circle(p, ERUPT_RADIUS * (1.0 + 0.25 * f), Color(1.0, 0.9, 0.6, 0.8 * (1.0 - f)))
			draw_arc(p, ERUPT_RADIUS * (1.0 + 0.6 * f), 0, TAU, 40, Color(c, 1.0 - f), 8.0 * (1.0 - f) + 1.0)

func _draw_edges() -> void :
	var c: Color = Game.theme.event_colors.get("eruption", Color(1, 0.45, 0.1))
	for h in _hazards:
		var t: float = h["t"]
		if t >= ERUPT_DELAY:
			continue
		var p: Vector2 = h["pos"]
		var k: = t / ERUPT_DELAY
		var on: = k < 0.6 or int(t * 16.0) % 2 == 0
		_edges.draw_arc(p, ERUPT_RADIUS, 0, TAU, 48, Color(0, 0, 0, 0.9), 9.0)
		_edges.draw_arc(p, ERUPT_RADIUS - 6.0, 0, TAU, 48, Color(c.lightened(0.25), 0.9), 3.0)
		if on:
			for i in 12:
				var a: = TAU * i / 12.0 + t * 1.6
				_edges.draw_arc(p, ERUPT_RADIUS, a, a + TAU / 24.0, 4, Color(1, 1, 1, 0.75 + 0.25 * k), 4.0)
		var s: = 9.0
		_edges.draw_line(p - Vector2(s, s), p + Vector2(s, s), Color(0, 0, 0, 0.85), 6.0)
		_edges.draw_line(p - Vector2(s, - s), p + Vector2(s, - s), Color(0, 0, 0, 0.85), 6.0)
		_edges.draw_line(p - Vector2(s, s), p + Vector2(s, s), Color(1, 1, 1, 0.9), 2.5)
		_edges.draw_line(p - Vector2(s, - s), p + Vector2(s, - s), Color(1, 1, 1, 0.9), 2.5)
