class_name EnemyShot
extends Node2D







const RADIUS: = 11.0
static var live: = 0

var velocity: = Vector2.ZERO
var damage: = 10.0
var color: = Color(1, 0.4, 0.15)
var life: = 3.5
var _player: Player
var big: = false
var _time: = randf() * 10.0

static func fire(parent: Node, from: Vector2, dir: Vector2, speed: float, hit_damage: float, tint: Color, boss: = false) -> void :
	var s: = EnemyShot.new()
	s.big = boss
	s.position = from
	s.velocity = dir * speed
	s.damage = hit_damage
	s.color = tint
	parent.add_child.call_deferred(s)

func _ready() -> void :
	Layers.put(self, Layers.SHOTS)
	add_to_group("enemy_shots")
	_player = get_tree().get_first_node_in_group("player") as Player
	if not big:
		live += 1

func _exit_tree() -> void :
	if not big:
		live -= 1

func _process(delta: float) -> void :
	if Enemy.frozen:
		queue_redraw()
		return
	_time += delta
	life -= delta
	if life <= 0.0 or not is_instance_valid(_player):
		queue_free()
		return
	position += velocity * delta
	if position.distance_squared_to(_player.global_position) < pow(RADIUS + _player.radius * 0.8, 2):
		_player.take_shot(damage)
		queue_free()
		return
	queue_redraw()




const STAR_FRAMES: = 6
static var _stars: = {}

static func _star_frames(c: Color, is_big: bool) -> Array:
	var key: = "%s|%s" % [c.to_html(), is_big]
	if _stars.has(key):
		return _stars[key]
	var r: = RADIUS * (1.4 if is_big else 1.0)
	var ext: = ceili(r * 1.45 + 6.0)
	var frames: = []
	for f in STAR_FRAMES:
		var img: = Image.create_empty(ext * 2, ext * 2, false, Image.FORMAT_RGBA8)
		var star: = PackedVector2Array()
		var outline: = PackedVector2Array()
		for j in 8:
			var a: = PI / 2.0 * f / STAR_FRAMES + TAU * j / 8.0
			var reach: = r * (1.45 if j % 2 == 0 else 0.6)
			star.append(Vector2(ext, ext) + Vector2.RIGHT.rotated(a) * reach)
			outline.append(Vector2(ext, ext) + Vector2.RIGHT.rotated(a) * (reach + 4.0))
		_fill(img, outline, Color(0.02, 0.0, 0.04, 0.95))
		_fill(img, star, c)
		frames.append(ImageTexture.create_from_image(img))
	_stars[key] = frames
	return frames


static func _fill(img: Image, pts: PackedVector2Array, c: Color) -> void :
	for y in img.get_height():
		var yc: = y + 0.5
		var xs: Array[float] = []
		for i in pts.size():
			var a: = pts[i]
			var b: = pts[(i + 1) % pts.size()]
			if (a.y <= yc and b.y > yc) or (b.y <= yc and a.y > yc):
				xs.append(a.x + (yc - a.y) / (b.y - a.y) * (b.x - a.x))
		xs.sort()
		for k in range(0, xs.size() - 1, 2):
			var x0: = clampi(roundi(xs[k]), 0, img.get_width())
			var x1: = clampi(roundi(xs[k + 1]), 0, img.get_width())
			if x1 > x0:
				img.fill_rect(Rect2i(x0, y, x1 - x0, 1), c)

func _draw() -> void :
	var k: = 1.4 if big else 1.0
	var r: = RADIUS * k
	var blink: = fmod(_time * 7.0, 1.0) < 0.5
	var back: = - velocity.normalized()


	PixelFx.disc(self, Vector2.ZERO, r * 2.6, Color(0, 0, 0, 0.38))
	for i in 3:
		PixelFx.disc(self, back * (12.0 + i * 10.0) * k, r * (1.15 - i * 0.18), Color(0, 0, 0, 0.22 - i * 0.06))
	for i in 5:
		PixelFx.disc(self, back * (12.0 + i * 10.0) * k, r * (0.85 - i * 0.14), Color(color, 0.5 - i * 0.09))
	PixelFx.disc(self, Vector2.ZERO, r * 2.1, Color(color, 0.22))
	PixelFx.arc(self, Vector2.ZERO, r * 1.65, 0.0, TAU, Color(0, 0, 0, 0.85), PixelFx.PIXEL * 3.5)
	PixelFx.arc(self, Vector2.ZERO, r * 1.65, 0.0, TAU, Color.WHITE if blink else color, PixelFx.PIXEL * 1.5)
	var frames: = _star_frames(color, big)
	var turn: = fposmod(_time * 9.0, PI / 2.0) / (PI / 2.0)
	var tex: Texture2D = frames[int(turn * STAR_FRAMES) % STAR_FRAMES]
	draw_texture(tex, - tex.get_size() / 2.0)
	PixelFx.disc(self, Vector2.ZERO, r * 0.55, color.lightened(0.7))
	PixelFx.disc(self, Vector2.ZERO, r * 0.3, Color.WHITE)
