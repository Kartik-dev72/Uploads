class_name Whip
extends Weapon




const ID: = "whip"
const COOLDOWN_TEXT: = "lashes %d%% faster"
const LENGTH: = 230.0
const WIDTH: = 70.0
const SLASH_GAP: = 0.12
const SHOW_TIME: = 0.18


const ROW_STEP: = 0.6
const BASE: = {"damage": 14.0, "cooldown": 1.1, "count": 1, "area": 1.0}
const UPGRADES: = [
	{"damage": 6.0}, 
	{"area": 1.15}, 
	{"count": 1}, 
	{"cooldown": 0.88}, 
	{"damage": 8.0}, 
	{"area": 1.2}, 
	{"damage": 10.0}, 
]




const HOLY: = {"damage": 12.0, "area": 1.1}
const HOLY_CRIT: = 0.15
const CRIT_HEAL: = 3.0
const CRIT_HEALS: = 4

var damage: = 14.0
var cooldown: = 1.1
var count: = 1
var area: = 1.0
var _timer: = 0.5
var _queue: Array[Vector2] = []
var _gap: = 0.0
var _slashes: Array[Dictionary] = []
var _time: = 0.0
var _heals_left: = 0

func _on_level() -> void :
	Layers.put(self, Layers.PLAYER_EFFECTS)

func _process(delta: float) -> void :
	_time += delta
	if not _slashes.is_empty():
		for s in _slashes:
			s["time"] -= delta
		_slashes = _slashes.filter( func(s: Dictionary) -> bool: return s["time"] > 0.0)
		queue_redraw()
	if not _queue.is_empty():
		_gap -= delta
		if _gap <= 0.0:
			var next: Vector2 = _queue.pop_front()
			_slash(next.x, int(next.y))
			_gap = SLASH_GAP
	_timer -= delta
	if _timer > 0.0:
		return
	_timer = cooldown_of(cooldown)
	_heals_left = CRIT_HEALS
	var front: = signf(player.facing.x) if absf(player.facing.x) > 0.1 else 1.0
	for i in amount_of(count):
		_queue.append(Vector2(front if i % 2 == 0 else - front, floori(i / 2.0)))
	_gap = 0.0

func _slash(side: float, row: int) -> void :
	var size: = area_of(area)
	var rect: = _rect(side, size, row)
	rect.position += global_position
	var healed: = 0.0
	for e: Enemy in Enemy.in_rect(rect):
		if rect.grow(e.radius * 0.6).has_point(e.global_position):
			var crit: = e.take_damage(power(damage), 1.0, HOLY_CRIT if holy else 0.0)
			if crit and holy and _heals_left > 0 and player.hp < player.max_hp:
				_heals_left -= 1
				healed += CRIT_HEAL * player.threat()
	if healed > 0.0:
		player.heal(healed)
		player.leech_flash()
	_slashes.append({"side": side, "time": SHOW_TIME, "size": size, "row": row})
	queue_redraw()


func _rect(side: float, size: float, row: = 0) -> Rect2:
	var length: = LENGTH * size
	var width: = WIDTH * size
	var x: = 10.0 if side > 0.0 else -10.0 - length
	return Rect2(x, - width * 0.5 - 10.0 - row * width * ROW_STEP, length, width)






func _draw() -> void :
	var hot: = color.lightened(0.55)
	for s in _slashes:
		var a: float = s["time"] / SHOW_TIME
		var reach: = clampf((1.0 - a) / 0.45, 0.0, 1.0)
		reach = maxf(1.0 - (1.0 - reach) * (1.0 - reach), 0.1)
		var side: float = s["side"]
		var size: float = s["size"]
		var r: = _rect(side, size, s.get("row", 0))
		var mid: = r.get_center().y
		var half: = r.size.y * 0.5
		var x0: = _strip_x(r, side, 0.0)
		var x1: = _strip_x(r, side, reach)
		var dir: = signf(x1 - x0)

		var band: = half * 0.42
		var taper: = x1 - dir * minf(absf(x1 - x0) * 0.25, 40.0 * size)
		PixelFx.poly(self, PackedVector2Array([Vector2(x0, mid - band * 0.6), Vector2(taper, mid - band), 
			Vector2(x1, mid), Vector2(taper, mid + band), Vector2(x0, mid + band * 0.6)]), Color(color, 0.8 * a))
		PixelFx.line(self, Vector2(x0, mid - band * 0.35), Vector2(taper, mid - band * 0.5), Color(hot, a), PixelFx.PIXEL)

		var link_alpha: = minf(1.0, a * 1.6)
		var link: float = 8.0 * size
		var links: = maxi(1, int(absf(x1 - x0) / (link * 1.7)))
		for j in links:
			var p: = Vector2(x0 + dir * (j + 0.5) * link * 1.7, mid)
			if j % 2 == 0:
				draw_set_transform(p, 0.0, Vector2(1, 0.6))
				PixelFx.arc(self, Vector2.ZERO, link, 0, TAU, Color(0.05, 0.03, 0.04, link_alpha), 6.0)
				PixelFx.arc(self, Vector2.ZERO, link, 0, TAU, Color(color, link_alpha), 3.5)
				PixelFx.arc(self, Vector2.ZERO, link, PI * 1.1, PI * 1.6, Color(hot, link_alpha), 1.5)
			else:
				draw_set_transform(p)
				PixelFx.line(self, Vector2( - link, 0), Vector2(link, 0), Color(0.05, 0.03, 0.04, link_alpha), 6.0)
				PixelFx.line(self, Vector2( - link, 0), Vector2(link, 0), Color(color, link_alpha), 3.5)
				PixelFx.line(self, Vector2( - link * 0.6, -1), Vector2(link * 0.3, -1), Color(hot, link_alpha), 1.0)
		draw_set_transform(Vector2.ZERO)
		var tip: = Vector2(x1, mid)
		PixelFx.disc(self, tip, 9.0 * size * a, Color(hot, 0.8 * a))
		PixelFx.disc(self, tip, 4.0 * size * a, Color(1, 1, 1, a))
		if holy:
			PixelFx.line(self, Vector2(x0, mid), tip, Color(1, 1, 1, 0.8 * a), 3.0)

func _strip_x(r: Rect2, side: float, f: float) -> float:
	return r.position.x + r.size.x * (f if side > 0.0 else 1.0 - f)
