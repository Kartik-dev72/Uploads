class_name Layers









const MAP: = -20
const MAP_DETAIL: = -19
const UNDERGROUND: = -16
const GROUND_EFFECTS: = -14
const GROUND_OBJECTS: = -12
const PICKUPS: = -10
const AROUND_PLAYER: = -8



const WARNINGS: = -4
const BODIES: = 0
const PLAYER_EFFECTS: = 2
const FLYING: = 4
const SHOTS: = 6
const SKY: = 8


const GLOOM: = 15
const PLAYER_HP: = 20
const ARENA_ARROWS: = 40
const BANNERS: = 50
const FLASH: = 100
const FLOAT_TEXT: = 200

static func put(node: CanvasItem, layer: int) -> void :
	node.z_as_relative = false
	node.z_index = layer




static func canvas(owner: Node2D, layer: int, draw: Callable, live: = true) -> Node2D:
	var c: = LayerCanvas.new()
	c.set_process(live)
	put(c, layer)
	c.draw.connect(draw)
	owner.add_child(c)
	return c

class LayerCanvas extends Node2D:
	func _process(_delta: float) -> void :
		queue_redraw()
