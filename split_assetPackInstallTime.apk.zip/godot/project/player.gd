class_name Player
extends Node2D










signal leveled_up(new_level: int)
signal minute_survived(minutes: int, points: int)
signal scored(points: int)
signal hit_taken
signal healed(amount: float)
signal coins_gained(amount: int, at: Vector2, bag: bool)

const REVIVE_INVULN: = 3.0



const BITE_DAMAGE: = 6.0
const BITE_EVERY: = 0.5
const HIT_WINDOW: = 0.2
const ARMOR_FLOOR: = 1.0



const HIT_CAP_MIN: = 10.0
const RETALIATION_PER_ARMOR: = 0.1
const HIT_DAMAGE: = 15.0



const THREAT_PER_MIN: = 0.08
const COOLDOWN_FLOOR: = 0.5
const HEAL_HP: = 20.0



const LEECH_GROWTH: = 0.5
const LEECH_GAP: = 3.0
const GENTLE_TIME: = 60.0
const GRACE_TIME: = 1.1
const GRACE_HOLD: = 0.3
const GRACE_SLOW: = 0.25
const GRACE_INVULN: = 0.8
const GRACE_DANGER: = 320.0
const PAUSE_INVULNS: = 2
const PAUSE_WINDOW: = 30.0


const SHOT_IMMUNE: = 0.5
const NEW_HIT_GAP: = 0.6
const HURT_POP_EVERY: = 0.35
const PACT_DELAY: = 0.6
const SECONDS_PER_SOUL: = 15.0
const KILLS_PER_SOUL: = 130

const THORN_TICK: = 0.3
const RELIC_AT: = 0.25
const RELIC_HEAL: = 0.4
const RELIC_INVULN: = 1.0
const RELIC_REACH: = 260.0
const RELIC_PUSH: = 1100.0
const CENSER_RADIUS: = 170.0

@export var base_speed: = 250.0
@export var joystick: Control
@export var radius: = 28.0
@export var base_pickup_range: = 120.0
@export var sprite_scale: = 3.0

var speed: = base_speed
var max_hp: = 100.0
var hp: = max_hp
var might: = 1.0
var regen: = 0.0
var pickup_range: = base_pickup_range
var cooldown_mult: = 1.0
var area: = 1.0
var extra_projectiles: = 0
var armor: = 0.0
var growth: = 1.0
var passives: = {}
var facing: = Vector2.RIGHT
var moving: = false
var level: = 1
var xp: = 0.0
var xp_to_next: = xp_for_level(1)
var survived: = 0.0
var maxed_auto: = ""
var last_chest_at: = 0.0
var kills: = 0
var score: = 0
var coins: = 0
var rerolls: = 1
var exiles: = 0
var skips: = 1
var duration: = 1.0
var luck: = 1.0
var luck_found: = 0.0
var exiled: Array = []
var crit_chance: = 0.05
var won: = false
var outro: = false
var bonus_souls: = 0
var hits_taken: = 0
var soul_mult: = 1.0
var curse: = 0
var blast_chance: = 0.0
var heal_every: = 0
var elite_bonus: = 0.0
var event_xp_mult: = 1.0
var pact: = ""
var pact_price: = ""
var spawn_mult: = 1.0
var heal_mult: = 1.0
var thorns: = 0.0
var retaliation: = 1.0
var censer_slow: = 0.0
var trophy: = {}
var _relic_ready: = 0.0
var _thorn_flash: = 0.0
var _dead: = false
var _in_lava: = false



const ICE_SPEED: = 1.25
const ICE_STOP: = 0.3
var _ice_vel: = Vector2.ZERO
var _on_ice: = false
var _minutes_paid: = 0
var _walk: = 0.0
var _shake: = 0.0
var _settled: = false
var _revived: = false
var _revives_used: = 0
var _invuln: = 0.0
var grace: = 0.0
var _grace_end: = 0
var _grace_invuln: = true
var _pause_invuln_times: Array[float] = []
var _contact: = 0.0
var _contact_hits: = 0.0
var _biter: Enemy
var _bite: = 1.0
var _hit_window: = 0.0
var _since_hurt: = 10.0
var _shot_immune: = 0.0
var _hurt_shown: = 0.0
var _hurt_pop_t: = 0.0
var _bar_hp: = 100.0
var _overlay: Node2D
var _censer: Node2D
var _track_clock: = 0.0
var _heal_kills: = 0
var _leech_ready: = 0.0

const LEECH_FLASH: = 1.0
const HEART_PIXELS: = [".##.##.", "#######", "#######", ".#####.", "..###..", "...#..."]
var _leech_flash: = 0.0
var _survivor: = {}
var _map: GameMap
var _spawner: Spawner

@onready var _sprite: Sprite2D = $Sprite2D
@onready var _camera: Camera2D = $Camera2D

func _enter_tree() -> void :

	add_to_group("player")



	Game.begin_run()

func _ready() -> void :
	_map = get_tree().get_first_node_in_group("map") as GameMap
	_spawner = get_parent().get_node_or_null("Spawner") as Spawner
	Layers.put(self, Layers.BODIES)
	Enemy._bestiary.clear()
	_overlay = Node2D.new()
	Layers.put(_overlay, Layers.PLAYER_HP)
	_overlay.draw.connect(_draw_overlay)
	add_child(_overlay)
	_censer = Layers.canvas(self, Layers.AROUND_PLAYER, _draw_censer)
	_apply_survivor(Game.survivor())
	rerolls = 1 + Game.upgrade_level("reroll")
	exiles = Game.upgrade_level("exile")
	skips = 1 + Game.upgrade_level("skip")
	if not Game.resume.is_empty():
		RunSave.restore(self, Game.resume)
		Game.resume = {}
	else:
		if not Game.dev_mode:
			_spawn_slot.call_deferred()
		var start: = int(_survivor.get("start_level", 1))
		if start > 1:
			_start_levels.call_deferred(start)

func _start_levels(start: int) -> void :
	while level < start:
		level += 1
		xp_to_next = xp_for_level(level)
		recalc_stats()
		leveled_up.emit(level)





func _spawn_slot() -> void :
	get_tree().create_timer(PACT_DELAY, false).timeout.connect(_open_pact)

func _open_pact() -> void :
	if not is_inside_tree() or _dead:
		return
	if get_tree().paused:
		get_tree().create_timer(0.1, true).timeout.connect(_open_pact)
		return
	var screen: = get_tree().get_first_node_in_group("slot_screen")
	if screen:
		screen.open()

func _apply_survivor(s: Dictionary) -> void :
	_survivor = s
	recalc_stats()
	hp = max_hp
	_bar_hp = hp
	_sprite.texture = Game.theme.texture(s["sprite"])
	_sprite.scale = Vector2.ONE * float(s.get("scale", sprite_scale))
	var weapon_script: Script = Game.WEAPONS.get(s.get("weapon", ""))
	if weapon_script:
		add_child(weapon_script.new())


func _pact_for(id: String) -> float:
	return Game.pact_value(pact) if pact == id else 0.0


func _price_for(id: String) -> float:
	return Game.pact_value(pact_price) if pact_price == id else 0.0






const DOUBLE_XP_LEVELS: = [{"level": 20, "growth": 1.0}, {"level": 21, "growth": -1.0}, {"level": 40, "growth": 1.0}, {"level": 41, "growth": -1.0}]

const AREA_PER_LEVEL_CAP: = 41




func level_bonus(stat: String) -> float:
	var total: = 0.0
	var prev: = 1
	for step: Dictionary in _survivor.get("levels", []):
		var at: = int(step["level"])
		var v: = float(step.get(stat, 0.0))
		if step.has("revives") or at - prev <= 1:
			total += v if level >= at else 0.0
		else:
			total += v * clampf(float(level - prev) / float(at - prev), 0.0, 1.0)
		prev = at
	for step: Dictionary in DOUBLE_XP_LEVELS:
		if level >= int(step["level"]):
			total += float(step.get(stat, 0.0))
	if stat == "area":
		total += float(_survivor.get("area_per_level", 0.0)) * (mini(level, AREA_PER_LEVEL_CAP) - 1)
	if stat == "cooldown":
		total += float(_survivor.get("start_cooldown", 0.0))
	return total

func recalc_stats() -> void :
	var s: = _survivor
	var old_max: = max_hp
	max_hp = s.get("hp", 100.0) + Game.upgrade_bonus("max_hp") + passive_bonus("max_hp") + _pact_for("vital") + trophy.get("max_hp", 0.0)
	max_hp = maxf(max_hp - _price_for("frail"), 20.0)
	speed = base_speed * (s.get("speed", 1.0) + level_bonus("speed")) * (1.0 + Game.upgrade_bonus("speed")) * (1.0 + passive_bonus("speed") + trophy.get("speed", 0.0)) * (1.0 + _pact_for("haste")) * (1.0 - _price_for("sluggish"))
	might = (s.get("might", 1.0) + level_bonus("might")) * (1.0 + Game.upgrade_bonus("might")) * (1.0 + passive_bonus("might") + trophy.get("might", 0.0)) * (1.0 + _pact_for("frenzy")) * (1.0 - _price_for("feeble"))
	pickup_range = base_pickup_range * s.get("magnet", 1.0) * (1.0 + Game.upgrade_bonus("magnet")) * (1.0 + passive_bonus("magnet")) * (1.0 - _price_for("dim"))
	crit_chance = 0.05 + s.get("crit", 0.0) + Game.upgrade_bonus("crit") + passive_bonus("crit")
	regen = s.get("regen", 0.0) + Game.upgrade_bonus("regen") + passive_bonus("regen")
	cooldown_mult = maxf((s.get("cooldown", 1.0) + level_bonus("cooldown")) * (1.0 - passive_bonus("cooldown") - Game.upgrade_bonus("cooldown")) / (1.0 + _pact_for("haste") * 0.6), COOLDOWN_FLOOR) * (1.0 + _price_for("rusted"))
	area = s.get("area", 1.0) + level_bonus("area") + passive_bonus("area") + Game.upgrade_bonus("area")
	extra_projectiles = int(passive_bonus("amount")) + int(Game.upgrade_bonus("amount")) + int(_pact_for("titan"))


	armor = passive_bonus("armor") + Game.upgrade_bonus("armor") + float(s.get("armor", 0.0)) + level_bonus("armor")
	retaliation = 1.0 + RETALIATION_PER_ARMOR * armor
	growth = s.get("growth", 1.0) + level_bonus("growth") + passive_bonus("growth") + Game.upgrade_bonus("growth") + _pact_for("greed") - _price_for("dull")
	curse = passives.get("curse", 0)

	soul_mult = Game.tier_info(Game.run_tier)["souls"] * (1.0 + 0.25 * curse + _pact_for("greed") + Game.upgrade_bonus("greed")) * (1.0 - _price_for("debt"))
	spawn_mult = 1.0 + _price_for("hunted") + level_bonus("curse")
	heal_mult = 1.0 - _price_for("barren")
	blast_chance = passive_bonus("blast")
	thorns = passive_bonus("thorns")
	censer_slow = passive_bonus("censer")
	if is_instance_valid(_censer):
		_censer.set_process(censer_slow > 0.0)
		_censer.queue_redraw()
	elite_bonus = passive_bonus("bounty")
	duration = 1.0 + s.get("duration", 0.0) + level_bonus("duration") + passive_bonus("duration")
	luck = 1.0 + s.get("luck", 0.0) + level_bonus("luck") + passive_bonus("luck") + Game.upgrade_bonus("luck") + luck_found
	var steal: Array = Game.PASSIVES["lifesteal"]["kills"]
	var every: int = steal[mini(passives.get("lifesteal", 0), steal.size() - 1)]
	var leech: = int(_pact_for("leech"))
	heal_every = leech if every == 0 else (every if leech == 0 else mini(every, leech))
	if max_hp > old_max:
		hp += max_hp - old_max
	hp = minf(hp, max_hp)
	queue_redraw()

func passive_bonus(id: String) -> float:
	return Game.PASSIVES[id]["per_level"] * passives.get(id, 0)

func add_passive(id: String) -> void :
	passives[id] = passives.get(id, 0) + 1
	recalc_stats()
	Game.track_max("plvl_" + id, passives[id])
	var maxed_defense: = 0
	for p: String in passives:
		if Game.pool_of(p) == "defense" and passives[p] >= Game.PASSIVES[p]["max"]:
			maxed_defense += 1
	Game.track_max("maxed_defense", maxed_defense)


func add_trophy(stat: String, amount: float) -> void :
	trophy[stat] = trophy.get(stat, 0.0) + amount
	recalc_stats()




func thorn_hit(e: Enemy) -> void :
	var growth: = _spawner.time_growth(survived) if is_instance_valid(_spawner) else 1.0
	e.take_damage(thorns * might * THORN_TICK * growth * retaliation, 0.0)
	_thorn_flash = 0.2
	if e.is_dead():
		Game.track("thorn_kills")


func relic_cooldown() -> float:
	return maxf(_relic_ready - survived, 0.0) if passives.has("relic") else 0.0


func _relic_save() -> void :
	var secs: Array = Game.PASSIVES["relic"]["secs"]
	_relic_ready = survived + float(secs[mini(passives["relic"], secs.size() - 1)])
	heal(max_hp * RELIC_HEAL)
	_invuln = maxf(_invuln, RELIC_INVULN)
	for e: Enemy in Enemy.near(global_position, RELIC_REACH):
		var off: = e.global_position - global_position
		if off.length_squared() < RELIC_REACH * RELIC_REACH:
			e.knock(off.normalized() * RELIC_PUSH * (1.0 - off.length() / RELIC_REACH * 0.5))
	var holy: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
	RingFx.spawn(get_parent(), global_position, RELIC_REACH, holy)
	FloatText.pop(self, str(Game.theme.passive("relic").get("name", "")).to_upper(), global_position + Vector2(0, -120), holy, 40, 1.4, 50.0, 2.0)
	Game.sfx("holy")
	shake(10.0)
	Game.track("relic_saves")


func set_pact(id: String, price: String) -> void :
	pact = id
	pact_price = price
	recalc_stats()
	Game.track("slot")
	if price == "":
		Game.track("voided")
	FloatText.pop(self, Game.theme.pact(id)["name"].to_upper(), global_position + Vector2(0, -120), 
		Game.theme.ui["accent"], 44, 1.8, 50.0, 2.0)


func free_revives() -> int:
	return Game.upgrade_level("revive") + int(_pact_for("second_chance")) + int(level_bonus("revives")) - _revives_used

func _input_dir() -> Vector2:
	var dir: = Input.get_vector("move_left", "move_right", "move_up", "move_down")
	if dir == Vector2.ZERO and joystick:
		dir = joystick.direction
	return dir

func _process(delta: float) -> void :
	if outro:
		_tick_feedback(delta)
		return
	survived += delta
	_tick_feedback(delta)
	_track_clock += delta
	if _track_clock >= 1.0:
		_track_clock = 0.0
		Game.track_max("time", survived)
		Game.track_max("time_" + str(_survivor.get("id", "")), survived)
		Game.track_max("time_realm_%d" % Game.run_tier, survived)
	if not won and not Game.dev_mode and survived >= Game.theme.win_time:
		_win()
	if int(survived / 60.0) > _minutes_paid:
		_minutes_paid = int(survived / 60.0)
		add_score(Game.SCORE["minute"], Vector2.INF, false)
		minute_survived.emit(_minutes_paid, Game.SCORE["minute"])
	var dir: = _input_dir()
	moving = dir != Vector2.ZERO
	if moving:
		facing = dir.normalized()
	var motion: = dir * speed * delta
	if _map and _map.has_terrain:
		motion = _terrain(motion, delta)
	var before: = global_position
	global_position = _map.move(global_position, motion, radius * 0.75) if _map else global_position + motion
	if _on_ice and delta > 0.0:
		_ice_vel = (global_position - before) / delta
	_animate(dir, delta)
	if regen > 0.0 and hp < max_hp:
		heal(regen * threat() * delta)
	_tick_damage(delta)
	_overlay.queue_redraw()

	_sprite.modulate = _sprite.modulate.lerp(Color.WHITE, 10.0 * delta)

func _animate(dir: Vector2, delta: float) -> void :
	if absf(dir.x) > 0.1:
		_sprite.flip_h = dir.x < 0.0
	if dir != Vector2.ZERO:
		_walk += delta * 12.0
	else:
		_walk = move_toward(fmod(_walk, PI), 0.0, delta * 12.0)
	_sprite.position.y = - absf(sin(_walk)) * 5.0
	_sprite.rotation = sin(_walk) * 0.08



func _terrain(motion: Vector2, delta: float) -> Vector2:
	var g: = _map.ground_at(global_position)
	motion *= _map.ground_speed(g)
	if delta > 0.0:
		_on_ice = g == GameMap.Ground.ICE
		if _on_ice:
			var target: = motion / delta * ICE_SPEED
			_ice_vel = _ice_vel.move_toward(target, speed * ICE_SPEED / ICE_STOP * delta)
			motion = _ice_vel * delta
		else:
			_ice_vel = motion / delta
	if g == GameMap.Ground.CURRENT:
		motion += _map.flow_at(global_position) * delta
	var in_lava: = g == GameMap.Ground.LAVA
	if in_lava:
		if not _in_lava:
			Game.sfx("fire_hiss")
		_hurt(_map.scorch() * delta, false, false)
	_in_lava = in_lava
	return motion


func touch(amount: float, by: Enemy = null, hits: = 1.0) -> void :
	_contact += amount
	if hits > _contact_hits:
		_contact_hits = hits
		_biter = by




func realm_damage() -> float:
	return float(Game.tier_info(Game.run_tier).get("damage", 1.0))

func threat() -> float:
	return 1.0 + THREAT_PER_MIN * Spawner.curve_minutes(survived)


func take_hit(hits: = 1.0, scaled: = true) -> void :
	if hits > 0.0:
		_hurt(HIT_DAMAGE * hits * (threat() * realm_damage() if scaled else 1.0), true)


func take_shot(hits: = 1.0) -> void :
	if _shot_immune > 0.0 or _dead:
		return
	_shot_immune = SHOT_IMMUNE
	take_hit(hits)


func _tick_damage(delta: float) -> void :
	if hp < max_hp * 0.3:
		queue_redraw()
	if _hit_window > 0.0:
		_hit_window -= delta
	if _contact > 0.0:



		_bite = minf(_bite + _contact / BITE_EVERY, 1.0)
		if _bite >= 1.0 and _hit_window <= 0.0:
			_bite = 0.0
			_hit_window = HIT_WINDOW
			_hurt(BITE_DAMAGE * _contact_hits * threat() * realm_damage(), false)
		_contact = 0.0
		_contact_hits = 0.0
		_biter = null
	else:
		_bite = minf(_bite + delta / BITE_EVERY, 1.0)
	if _thorn_flash > 0.0:
		_thorn_flash -= delta
	if _shot_immune > 0.0:
		_shot_immune -= delta
	if _leech_flash > 0.0:
		_leech_flash -= delta
		_overlay.queue_redraw()
	_since_hurt += delta
	_hurt_pop_t -= delta
	if _hurt_shown >= 1.0 and (_hurt_pop_t <= 0.0 or _since_hurt > 0.15):
		if _since_hurt <= 0.15:
			Game.sfx("hurt", 1.15, -8.0)
		_pop_hurt()
	if _bar_hp > hp:
		_bar_hp = move_toward(_bar_hp, hp, maxf(30.0, (_bar_hp - hp) * 2.5) * delta) if _since_hurt > 0.4 else _bar_hp
		queue_redraw()
	else:
		_bar_hp = hp



func _hurt(amount: float, burst: bool, blockable: = true) -> void :
	if _dead or outro or _invuln > 0.0 or amount <= 0.0:
		return
	for c in get_children():
		if blockable and c.has_method("absorb") and c.absorb():
			return
	if blockable:
		if amount > max_hp:
			amount = maxf(max_hp - 1.0, HIT_CAP_MIN)
		amount = maxf(amount - armor, minf(ARMOR_FLOOR, amount))
		hit_taken.emit()
	if survived < GENTLE_TIME:
		amount *= 0.5
	var fresh: = burst or _since_hurt > NEW_HIT_GAP
	_since_hurt = 0.0
	if not Game.dev_mode:
		hp -= amount
	_hurt_shown += amount
	_sprite.modulate = Color(1, 0.4, 0.4)
	if fresh:
		hits_taken += 1
		shake(10.0 if burst else 6.0)
		Game.sfx("hurt")
		_hurt_pop_t = HURT_POP_EVERY
	if burst:
		_pop_hurt()
	queue_redraw()
	if hp <= 0.001:
		hp = 0.0
		die()
	elif hp < max_hp * RELIC_AT and passives.has("relic") and survived >= _relic_ready:
		_relic_save()

func _pop_hurt() -> void :
	if _hurt_shown < 1.0:
		return
	FloatText.pop(self, "-%d" % int(round(_hurt_shown)), global_position + Vector2(randf_range(-24, 24), -60), 
		Game.theme.ui["hp"].lightened(0.25), 34, 0.8, 60.0, 1.6)
	_hurt_shown = 0.0
	_hurt_pop_t = HURT_POP_EVERY

func heal(amount: float) -> void :
	var before: = hp
	hp = minf(hp + amount * heal_mult, max_hp)
	if hp > before:
		healed.emit(hp - before)
	if amount >= 5.0:
		FloatText.pop(self, "+%d" % int(round(amount * heal_mult)), global_position + Vector2(0, -60), Color(0.4, 1, 0.5), 30, 0.9, 70.0, 1.6)
	queue_redraw()






func begin_grace(from_pause: = false) -> void :
	_grace_invuln = true
	if from_pause:
		_pause_invuln_times = _pause_invuln_times.filter( func(t: float) -> bool: return survived - t < PAUSE_WINDOW)
		_grace_invuln = _pause_invuln_times.size() < PAUSE_INVULNS
		if _grace_invuln:
			_pause_invuln_times.append(survived)
	if _grace_invuln:
		_invuln = maxf(_invuln, GRACE_INVULN)
	_contact = 0.0
	if not _danger_near():
		_end_grace()
		return
	grace = GRACE_TIME
	_grace_end = Time.get_ticks_msec() + int(GRACE_TIME * 1000.0)
	Engine.time_scale = GRACE_SLOW
	if not get_tree().process_frame.is_connected(_grace_tick):
		get_tree().process_frame.connect(_grace_tick)
	_overlay.queue_redraw()



func _danger_near() -> bool:
	for group: String in ["enemies", "enemy_shots"]:
		for n in get_tree().get_nodes_in_group(group):
			var e: = n as Node2D
			if e and ( not e is Enemy or (e as Enemy).hits > 0.0) and e.global_position.distance_squared_to(global_position) < GRACE_DANGER * GRACE_DANGER:
				return true
	return false

func _grace_tick() -> void :
	if get_tree().paused:
		_end_grace()
		_overlay.queue_redraw()
		return
	grace = maxf((_grace_end - Time.get_ticks_msec()) / 1000.0, 0.0)
	_overlay.queue_redraw()
	if grace > 0.0:
		var k: = clampf((GRACE_TIME - grace - GRACE_HOLD) / (GRACE_TIME - GRACE_HOLD), 0.0, 1.0)
		Engine.time_scale = lerpf(GRACE_SLOW, 1.0, k * k * (3.0 - 2.0 * k))
		return
	_end_grace()

func _end_grace() -> void :
	grace = 0.0
	Engine.time_scale = 1.0
	if get_tree() and get_tree().process_frame.is_connected(_grace_tick):
		get_tree().process_frame.disconnect(_grace_tick)


func _exit_tree() -> void :
	_end_grace()



func add_score(points: int, at: = Vector2.INF, pop: = true) -> void :
	if _dead or points <= 0:
		return
	score += points
	scored.emit(points)
	if pop and points >= 100:
		var pos: = at if at != Vector2.INF else global_position + Vector2(0, -70)
		FloatText.pop(self, "+" + HUD.format_score(points), pos + Vector2(0, -30), Game.theme.ui["accent"], 
			int(clampf(20.0 + points / 45.0, 20.0, 50.0)), 0.9 + minf(points / 4000.0, 0.6), 90.0, 1.8)


func register_kill(points: int, at: Vector2) -> void :
	kills += 1
	Game.track("kills")
	add_score(points, at)
	if heal_every > 0:
		_heal_kills += 1
		if _heal_kills >= leech_kills() and survived >= _leech_ready:
			_heal_kills = 0
			if hp < max_hp:
				_leech_ready = survived + LEECH_GAP
				heal(HEAL_HP)
				Game.sfx("crunch", randf_range(0.92, 1.08))
				_leech_flash = LEECH_FLASH


func leech_flash() -> void :
	_leech_flash = LEECH_FLASH
	_overlay.queue_redraw()


func leech_kills() -> int:
	return roundi(heal_every * (1.0 + LEECH_GROWTH * (threat() - 1.0)))


func heal_drop() -> float:
	return HEAL_HP * threat()


func shake(amount: float) -> void :
	_shake = maxf(_shake, amount)


func _tick_feedback(delta: float) -> void :
	if _invuln > 0.0:
		_invuln -= delta
		_sprite.self_modulate.a = 0.35 if int(_invuln * 10.0) % 2 == 0 else 1.0
		if _invuln <= 0.0:
			_sprite.self_modulate.a = 1.0
	if _shake > 0.05:
		_camera.offset = Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * _shake
		_shake = move_toward(_shake, 0.0, (4.0 + _shake * 6.0) * delta)
	elif _camera.offset != Vector2.ZERO:
		_camera.offset = Vector2.ZERO



func add_coins(amount: int, at: = Vector2.INF, bag: = false) -> int:
	amount = maxi(1, int(round(amount * soul_mult)))
	coins += amount
	coins_gained.emit(amount, at, bag)
	add_score(amount * Game.SCORE["coin"], Vector2.INF, not bag)
	if not Game.dev_mode:
		Game.coins += amount
		Game.track_souls(amount)
	return amount

func is_dead() -> bool:
	return _dead

func die() -> void :
	if _dead:
		return
	_dead = true
	_end_grace()
	if free_revives() > 0 and not Game.dev_mode:
		_revives_used += 1
		_revive(true)
		return
	Game.sfx("death")
	var screen: = get_tree().get_first_node_in_group("game_over_screen") as GameOverScreen
	var taunts: Array = Game.theme.death_taunts
	if screen and not taunts.is_empty():
		var first: bool = Game.progress.stats.get("deaths", 0) == 0
		Game.track("deaths")
		DeathTaunt.play(screen.get_parent(), taunts[0] if first else DeathTaunt.next_taunt(taunts), _after_death.bind(screen))
	else:
		_after_death(screen)

func _after_death(screen: GameOverScreen) -> void :
	if screen and not _revived and not Game.dev_mode and Ads.can_show():
		screen.open_revive(_summary(), _on_revive_offer)
	else:
		_finish()


func _on_revive_offer(accepted: bool) -> void :
	if not accepted:
		_finish()
		return
	Ads.show_rewarded( func(earned: bool) -> void :
		if earned:
			_revived = true
			var taunt: = get_tree().get_first_node_in_group("death_taunt") as DeathTaunt
			if taunt:
				taunt.rewind(_revive)
			else:
				_revive()
		else:
			_finish())





func _revive(free: = false) -> void :
	_dead = false
	Game.track("revives")
	_invuln = REVIVE_INVULN
	hp = minf(maxf(40.0, ceilf(max_hp * 0.5)), max_hp)
	_bar_hp = hp
	queue_redraw()
	var screen: = get_tree().get_first_node_in_group("game_over_screen") as GameOverScreen
	if screen:
		screen.hide()
		for c in screen.get_children():
			c.queue_free()
	LevelUpScreen.resume_if_clear(get_tree())
	HolyFlash.purge(self)
	Game.sfx("holy")
	var holy: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
	FloatText.pop(self, "EXTRA LIFE!" if free else "REVIVED!", global_position + Vector2(0, -110), holy, 52, 1.6, 50.0, 2.0)
	if free:
		var left: = free_revives()
		FloatText.pop(self, ("%d left" % left) if left > 0 else "none left", global_position + Vector2(0, -62), Color(holy, 0.9), 30, 1.8, 40.0, 2.2)
		shake(12.0)
	_overlay.queue_redraw()


func _finish() -> void :
	_settle()
	var summary: = _summary()
	var rank: = Game.end_run(summary)
	var screen: = get_tree().get_first_node_in_group("game_over_screen") as GameOverScreen
	if screen:
		screen.open(summary, rank)
	else:
		get_tree().change_scene_to_file.call_deferred("res://menu.tscn")


func end_run() -> void :
	_settle()
	Game.end_run(_summary())
	get_tree().change_scene_to_file.call_deferred("res://menu.tscn")




func _win() -> void :
	won = true
	add_score(Game.SCORE["victory"], global_position)
	var words: = ""
	var sub: = ""
	var after: Array[Callable] = []
	var final: = Game.run_tier >= Game.theme.difficulties.size() - 1
	if final:
		words = "SAVED"
		sub = "You have escaped hell"
	if not Game.dev_mode:
		var first_time: = not Game.progress.tiers_won.has(Game.run_tier)
		Game.progress.mark_tier_won(Game.run_tier)
		Game.track("wins")
		if hits_taken == 0:
			Game.track("flawless")
		if hp <= HEAL_HP:
			Game.track("close_call")
		var next: = Game.run_tier + 1
		if first_time and next < Game.theme.difficulties.size():
			words = "NEW REALM UNLOCKED"
			sub = str(Game.tier_info(next)["name"])
			after.append(Game.announce.bind("REALM UNLOCKED", "Win %s" % str(Game.tier_info(Game.run_tier)["name"]), 
				"Reward: %s, a harder realm with better rewards" % str(Game.tier_info(next)["name"]), Game.theme.ui["title"]))
		for s: Dictionary in Game.theme.survivors:
			if first_time and int(s.get("requires_win", -1)) == Game.run_tier:
				after.append(Game.announce.bind("A SOUL IS FREED", "Win %s" % str(Game.tier_info(Game.run_tier)["name"]), 
					"Reward: %s the %s joins you" % [s["name"], s.get("title", "")], Game.theme.ui.get("holy", Color(1, 0.93, 0.55)), str(s["sprite"])))
				Game.progress.add_news("unlock", "New survivor: %s" % s["name"], "Freed by winning %s" % str(Game.tier_info(Game.run_tier)["name"]), str(s["sprite"]))
	WinOutro.play(self, final, words, sub, after)



func begin_outro() -> void :
	outro = true
	_invuln = 0.0
	_sprite.self_modulate.a = 1.0
	_overlay.hide()
	for c in get_children():
		if c is Weapon:
			c.set_process(false)
			(c as CanvasItem).hide()


func outro_pose(offset: Vector2, size: float, tint: Color, shown: bool) -> void :
	_sprite.position = offset
	_sprite.rotation = 0.0
	_sprite.scale = Vector2.ONE * float(_survivor.get("scale", sprite_scale)) * size
	_sprite.modulate = tint
	_sprite.visible = shown
	queue_redraw()

func cash_out() -> void :
	if _dead:
		return
	_dead = true
	_finish()



func _settle() -> void :
	if _settled:
		return
	_settled = true
	Enemy.flush_bestiary()
	if Game.dev_mode:
		return
	var base: = int(survived / SECONDS_PER_SOUL) + kills / KILLS_PER_SOUL + (Game.WIN_SOULS if won else 0)
	bonus_souls = int(base * soul_mult)
	Game.coins += bonus_souls
	Game.track_souls(bonus_souls)


func save_state() -> Dictionary:
	return {"survived": survived, "level": level, "xp": xp, "kills": kills, "score": score, "coins": coins, 
		"hp": hp, "passives": passives.duplicate(), "trophy": trophy.duplicate(), "rerolls": rerolls, 
		"exiles": exiles, "skips": skips, "luck_found": luck_found, "exiled": exiled.duplicate(), "pact": pact, "pact_price": pact_price, 
		"won": won, "hits_taken": hits_taken, "revived": _revived, "revives_used": _revives_used, 
		"minutes_paid": _minutes_paid, "heal_kills": _heal_kills, "relic_ready": _relic_ready, 
		"soul_mult": soul_mult, "facing": facing, "last_chest_at": last_chest_at, "maxed_auto": maxed_auto}

func load_state(d: Dictionary) -> void :
	survived = float(d["survived"])
	last_chest_at = float(d.get("last_chest_at", survived))
	maxed_auto = str(d.get("maxed_auto", ""))
	level = int(d["level"])
	xp_to_next = xp_for_level(level)
	xp = float(d["xp"])
	kills = int(d["kills"])
	score = int(d["score"])
	coins = int(d["coins"])
	passives = (d["passives"] as Dictionary).duplicate()
	for id: String in passives.keys():
		if not Game.PASSIVES.has(id):
			passives.erase(id)
	trophy = (d["trophy"] as Dictionary).duplicate()
	rerolls = int(d["rerolls"])
	exiles = int(d["exiles"])
	skips = int(d.get("skips", 1 + Game.upgrade_level("skip")))
	luck_found = float(d.get("luck_found", 0.0))
	exiled = (d["exiled"] as Array).duplicate()
	pact = str(d["pact"])
	pact_price = str(d["pact_price"])
	won = bool(d["won"])
	hits_taken = int(d["hits_taken"])
	_revived = bool(d["revived"])
	_revives_used = int(d["revives_used"])
	_minutes_paid = int(d["minutes_paid"])
	_heal_kills = int(d["heal_kills"])
	_relic_ready = float(d["relic_ready"])
	facing = d.get("facing", Vector2.RIGHT)
	recalc_stats()
	hp = clampf(float(d["hp"]), 1.0, max_hp)
	_bar_hp = hp

func _summary() -> Dictionary:
	return {"score": score, "time": survived, "level": level, "kills": kills, "coins": coins, 
		"bonus": bonus_souls, "won": won, "tier": Game.run_tier}

func add_xp(amount: int) -> void :
	if outro:
		return
	add_score(amount * Game.SCORE["xp"])
	xp += amount * growth * event_xp_mult
	while xp >= xp_to_next:
		xp -= xp_to_next
		level += 1
		xp_to_next = xp_for_level(level)
		_grow()
		add_score(level * Game.SCORE["level"])
		Game.track_max("level", level)
		leveled_up.emit(level)


func _grow() -> void :
	recalc_stats()
	for st: Dictionary in DOUBLE_XP_LEVELS:
		if int(st["level"]) == level and float(st["growth"]) > 0.0:
			FloatText.pop(self, "DOUBLE XP", global_position + Vector2(0, -80), Game.theme.ui.get("holy", Color(1, 0.93, 0.55)), 34, 1.6, 70.0)








const XP_WALLS: = {20: 4.08, 40: 5.67}

static func xp_for_level(lvl: int) -> int:
	var n: = lvl - 1
	return roundi((5 + 12 * n + n * n / 2) * minf(1.0, 0.5 + 0.1 * n) * float(XP_WALLS.get(lvl, 1.0)))




func blast(at: Vector2) -> void :
	Enemy.blasting = true
	var growth: = _spawner.time_growth(survived) if is_instance_valid(_spawner) else 1.0
	for e: Enemy in Enemy.near(at, 110.0):
		if e.targetable and e.global_position.distance_squared_to(at) < pow(110.0 + e.radius, 2):
			e.take_damage(maxf(20.0, 25.0 * might) * growth, 0.0)
	Enemy.blasting = false
	RingFx.spawn(get_parent(), at, 110.0, Game.theme.ui["death"])
	Game.sfx("explode")

func _draw() -> void :
	if outro and ( not _sprite.visible or _sprite.position.length() > 2.0):
		return

	draw_set_transform(Vector2(0, 24), 0.0, Vector2(1, 0.35))
	draw_circle(Vector2.ZERO, 22.0, Color(0, 0, 0, 0.3))
	draw_set_transform(Vector2.ZERO)

func _draw_overlay() -> void :
	_draw_defenses(_overlay)
	_draw_lives(_overlay)
	_draw_hp_bar(_overlay)
	if grace > 0.0:
		var k: = grace / GRACE_TIME
		var ready_color: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
		_overlay.draw_arc(Vector2(0, -6), 46.0 + 40.0 * k, 0.0, TAU, 48, Color(ready_color, 0.25 + 0.5 * (1.0 - k)), 3.0)



func _draw_censer() -> void :
	if censer_slow <= 0.0:
		return
	var t: = Time.get_ticks_msec() / 1000.0
	var incense: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
	var reach: = CENSER_RADIUS + 10.0
	for i in 24:
		var a: = TAU * i / 24.0 + t * 0.25
		var p: = Vector2(cos(a), sin(a) * 0.75) * (reach + sin(t * 1.3 + i) * 6.0) + Vector2(0, 10)
		var puff: = 0.5 + 0.5 * sin(t * 2.0 + i * 1.7)
		PixelFx.dot(_censer, p, Color(incense, 0.12 + 0.16 * puff), 4)
		PixelFx.dot(_censer, p + Vector2(0, -3), Color(1, 1, 1, 0.1 * puff), 2)



func _draw_defenses(ci: CanvasItem) -> void :
	var t: = Time.get_ticks_msec() / 1000.0
	if _thorn_flash > 0.0:
		var k: = _thorn_flash / 0.2
		var thorn: = Color(0.85, 0.2, 0.15, 0.8 * k)
		for i in 10:
			var a: = TAU * i / 10.0 + 0.3
			var base: = Vector2(cos(a), sin(a) * 0.8) * 34.0
			PixelFx.line(ci, base, base * 1.45, thorn, 2.0)
	if passives.has("relic"):
		var holy: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
		var at: = Vector2(-74, 47.5)
		var cd: = relic_cooldown()
		if cd <= 0.0:
			ci.draw_circle(at, 8.0 + sin(t * 4.0), Color(holy, 0.35))
			ci.draw_circle(at, 5.0, holy)
		else:
			var secs: Array = Game.PASSIVES["relic"]["secs"]
			var total: = float(secs[mini(passives["relic"], secs.size() - 1)])
			ci.draw_circle(at, 6.0, Color(0, 0, 0, 0.7))
			ci.draw_arc(at, 5.0, - PI / 2.0, - PI / 2.0 + TAU * (1.0 - cd / total), 16, Color(holy, 0.6), 2.5)


func _draw_lives(ci: CanvasItem) -> void :
	var n: = free_revives()
	if n <= 0 or Game.dev_mode:
		return
	var tex: = Game.theme.texture(Game.theme.upgrade_icon("revive"))
	if tex == null:
		return
	var x: = -74.0 - (20.0 if passives.has("relic") else 0.0)
	var size: = Vector2(18, 18)
	for i in mini(n, 3):
		ci.draw_texture_rect(tex, Rect2(Vector2(x - 9.0 - i * 14.0, 38.5), size), false)
	if n > 3:
		ci.draw_string_outline(ThemeDB.fallback_font, Vector2(x - 72.0, 54.0), "x%d" % n, HORIZONTAL_ALIGNMENT_RIGHT, 30, 15, 4, Color(0, 0, 0, 0.9))
		ci.draw_string(ThemeDB.fallback_font, Vector2(x - 72.0, 54.0), "x%d" % n, HORIZONTAL_ALIGNMENT_RIGHT, 30, 15, Color.WHITE)



func _draw_hp_bar(ci: CanvasItem) -> void :
	var hp_color: Color = Game.theme.ui["hp"]
	var w: = 120.0
	var h: = 19.0
	var rect: = Rect2( - w / 2.0, 38.0, w, h)
	ci.draw_rect(rect.grow(2.0), Color(0, 0, 0, 0.8))
	ci.draw_rect(rect, Color(hp_color.darkened(0.75), 0.9))
	var trail: = clampf(_bar_hp / max_hp, 0.0, 1.0)
	var fill: = clampf(hp / max_hp, 0.0, 1.0)
	if trail > fill:
		ci.draw_rect(Rect2(rect.position + Vector2(w * fill, 0), Vector2(w * (trail - fill), h)), Color(1, 0.85, 0.75, 0.85))
	if fill > 0.0:
		var low: = fill < 0.3 and int(Time.get_ticks_msec() / 250) % 2 == 0
		var c: = hp_color.lightened(0.35) if low else hp_color
		ci.draw_rect(Rect2(rect.position, Vector2(w * fill, h)), c)
		ci.draw_rect(Rect2(rect.position, Vector2(w * fill, 4.0)), Color(1, 1, 1, 0.25))
	var font: = ThemeDB.fallback_font
	var text: = "%d / %d" % [ceili(hp), roundi(max_hp)]
	var pos: = Vector2(rect.position.x, rect.position.y + h - 2.0)
	ci.draw_string_outline(font, pos, text, HORIZONTAL_ALIGNMENT_CENTER, w, 17, 5, Color(0, 0, 0, 0.95))
	ci.draw_string(font, pos, text, HORIZONTAL_ALIGNMENT_CENTER, w, 17, Color.WHITE)
	if _leech_flash > 0.0:
		_draw_leech_heart(ci, Vector2(rect.end.x + 16.0, rect.get_center().y))


func _draw_leech_heart(ci: CanvasItem, at: Vector2) -> void :
	var k: = _leech_flash / LEECH_FLASH
	var a: = clampf(k * 2.5, 0.0, 1.0)
	var px: = 3.0 * (1.0 + 0.5 * maxf(0.0, (k - 0.8) / 0.2))
	var hp_color: Color = Game.theme.ui["hp"]
	var top: = at + Vector2(-3.5 * px, -3.0 * px - (1.0 - k) * 12.0)
	for y in HEART_PIXELS.size():
		var row: String = HEART_PIXELS[y]
		for x in row.length():
			if row[x] == "#":
				ci.draw_rect(Rect2(top + Vector2(x, y) * px - Vector2(1, 1), Vector2(px + 2, px + 2)), Color(0, 0, 0, 0.9 * a))
	for y in HEART_PIXELS.size():
		var row: String = HEART_PIXELS[y]
		for x in row.length():
			if row[x] == "#":
				var c: = Color(1, 0.75, 0.75) if (x == 1 and y == 1) else hp_color.lightened(0.15)
				ci.draw_rect(Rect2(top + Vector2(x, y) * px, Vector2(px, px)), Color(c, a))
	var tip: = top + Vector2(3.5 * px, -4.0 - 6.0 * (1.0 - k))
	ci.draw_colored_polygon(PackedVector2Array([tip, tip + Vector2(6, 7), tip + Vector2(-6, 7)]), Color(0.4, 1, 0.5, a))
