extends Node2D




@export var max_props: = 12
@export var check_interval: = 1.2
@export var spawn_min: = 850.0
@export var spawn_max: = 1300.0
@export var despawn_distance: = 2000.0
@export var initial_props: = 4

var _timer: = 0.0
var _player: Player

func _ready() -> void :
	_player = get_tree().get_first_node_in_group("player") as Player
	if Game.dev_mode:
		set_process(false)
		return
	for i in initial_props:
		_spawn(randf_range(250.0, 550.0))

func _process(delta: float) -> void :
	_timer -= delta
	if _timer > 0.0 or not is_instance_valid(_player):
		return
	_timer = check_interval
	for prop: Node2D in get_children():
		if prop.global_position.distance_to(_player.global_position) > despawn_distance:
			prop.queue_free()
	if get_child_count() < max_props:
		var near: = maxf(spawn_min, Game.offscreen_distance() + 50.0)
		_spawn(randf_range(near, maxf(spawn_max, near + 300.0)))

func _spawn(distance: float) -> void :
	var props: Array = Game.theme.props
	if props.is_empty() or not is_instance_valid(_player):
		return
	var prop: = Breakable.new()
	prop.configure(props.pick_random())
	prop.global_position = GameMap.current.ring_point(_player.global_position, distance, 80.0) if GameMap.current else _player.global_position + Vector2.RIGHT.rotated(randf() * TAU) * distance
	var map: = get_tree().get_first_node_in_group("map") as GameMap
	if map:
		prop.global_position = map.push_out(prop.global_position, prop.radius + 10.0)
	add_child(prop)
