class_name RingFx
extends Node2D




const LIFE: = 0.35
const MAX_ALIVE: = 30

var radius: = 100.0
var color: = Color.WHITE
var _t: = 0.0

static func spawn(parent: Node, pos: Vector2, ring_radius: float, tint: Color) -> void :
	if parent == null or parent.get_tree().get_node_count_in_group("ring_fx") >= MAX_ALIVE:
		return
	var fx: = RingFx.new()
	fx.position = pos
	fx.radius = ring_radius
	fx.color = tint
	parent.add_child.call_deferred(fx)

func _ready() -> void :
	add_to_group("ring_fx")
	Layers.put(self, Layers.GROUND_EFFECTS)

func _process(delta: float) -> void :
	_t += delta
	if _t >= LIFE:
		queue_free()
		return
	queue_redraw()

func _draw() -> void :
	var k: = _t / LIFE
	var fade: = 1.0 - k
	PixelFx.disc(self, Vector2.ZERO, radius * (0.4 + 0.6 * k), Color(color.lightened(0.5), 0.3 * fade))
	PixelFx.arc(self, Vector2.ZERO, radius * (0.3 + 0.7 * k), 0, TAU, Color(color.lightened(0.3), 0.9 * fade), 6.0 * fade + 1.0)
	PixelFx.arc(self, Vector2.ZERO, radius * (0.2 + 0.5 * k), 0, TAU, Color(1, 1, 1, 0.7 * fade), 2.0)
