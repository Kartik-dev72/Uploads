class_name GroundPainter
extends RefCounted



















const SUB: = 4
const F: = 2
const CELL: = 8
const HEAT_REACH: = 1.65

var image: Image

var _map: GameMap
var _origin: Vector2
var _bridges: Array
var _c: Dictionary
var _style: String
var _seed: int

func _init(map: GameMap, origin: Vector2, bridges: Array) -> void :
	_map = map
	_origin = origin
	_bridges = bridges
	_c = Game.theme.map.duplicate()
	_style = _c.get("style", "")
	_seed = map.map_seed

func paint() -> void :
	var n: = GameMap.CHUNK_SIZE / SUB
	var cells: = GameMap.CHUNK_SIZE / CELL
	image = Image.create_empty(n, n, false, Image.FORMAT_RGB8)
	var ox: = int(_origin.x) / SUB
	var oy: = int(_origin.y) / SUB
	var width: = _map.river_width
	for cx in cells:
		for cy in cells:
			var center: = _origin + (Vector2(cx, cy) + Vector2.ONE * 0.5) * CELL
			var pn: = _map.path_noise.get_noise_2dv(center) if width > 0.0 else 1.0
			var g: = _map.classify(center, pn, _bridges)
			var info: = {
				"g": g, 
				"depth": absf(pn) / width if width > 0.0 else 99.0, 
				"into": _map.pool_noise.get_noise_2dv(center) - _map.pool_above if _map.pool_kind != "" else -1.0, 
				"gn": _map.ground_noise.get_noise_2dv(center) * 0.5 + 0.5, 
				"a": _map.accent_noise.get_noise_2dv(center) * 0.5 + 0.5, 
			}
			if g == GameMap.Ground.CURRENT:
				info["flow"] = _map.flow_at(center).normalized()
			var per: = CELL / SUB
			for dx in per:
				for dy in per:
					var sx: = ox + cx * per + dx
					var sy: = oy + cy * per + dy
					image.set_pixel(cx * per + dx, cy * per + dy, _texel(sx, sy, info))


static func h(x: int, y: int, s: int) -> float:
	var v: = x * 374761393 + y * 668265263 + s * 1442695041
	v = (v ^ (v >> 13)) * 1274126177
	v = v ^ (v >> 16)
	return float(v & 65535) / 65535.0

func _texel(sx: int, sy: int, info: Dictionary) -> Color:
	var g: int = info["g"]
	var w: = Vector2(sx, sy) * SUB + Vector2.ONE * (SUB * 0.5)
	match g:
		GameMap.Ground.BRIDGE:
			return _bridge(w, sx, sy)
		GameMap.Ground.PATH:
			return _road(sx, sy, w, info)
		GameMap.Ground.LAVA:
			return _lava(sx, sy, w, info)
		GameMap.Ground.CURRENT:
			return _current(sx, sy, w, info)
		GameMap.Ground.DEEP, GameMap.Ground.VOID:
			return _pool(sx, sy, info)
		GameMap.Ground.ICE:
			return _ice(sx, sy, info)
	return _land(sx, sy, w, info)



func _land(sx: int, sy: int, w: Vector2, info: Dictionary) -> Color:
	var gn: float = info["gn"]
	var a: float = info["a"]
	var grain: = h(sx, sy, _seed)
	var base: = (_c["ground_dark"] as Color).lerp(_c["ground_light"], gn)
	var color: Color
	match _style:
		"ash":
			color = base.lerp(_c["ground_light"], 0.25)
			var tuft: = h(floori(sx / float(F)), floori(sy / (2.0 * F)), _seed + 1)
			if a > 0.56 and tuft > 0.8 and posmod(sx, F) == 0:
				color = _c.get("grass", Color(0.33, 0.3, 0.22)) if posmod(sy, 2 * F) < F else _c.get("grass_dark", Color(0.22, 0.2, 0.15))
			elif grain > 0.975:
				color = _c.get("pebble", base.lightened(0.35))
			elif grain < 0.05:
				color = base.darkened(0.25)
			else:
				var cel: = _map.cell_noise.get_noise_2dv(w)
				if cel < -0.975 and grain > 0.3:
					color = color.darkened(0.18)
		"plates":
			var cel: = _map.cell_noise.get_noise_2dv(w)
			var plate: = base.lightened(0.1 * h(int(w.x / 90.0), int(w.y / 90.0), 7))
			color = plate
			if cel < -0.95:
				color = _c.get("seam", base.darkened(0.55))
				var near: float = info["depth"]
				if near < HEAT_REACH * 1.6:
					color = color.lerp(_c.get("seam_glow", Color(0.7, 0.25, 0.05)), clampf(1.0 - (near - 1.0) / (HEAT_REACH * 1.6 - 1.0), 0.0, 1.0))
				elif grain > 0.97:
					color = _c.get("seam_glow", Color(0.7, 0.25, 0.05)).darkened(0.3)
			elif grain > 0.94:
				color = plate.lightened(0.08)
			if a > 0.62:
				color = color.lerp(_c.get("ground_accent", color), 0.5)
		"mud":
			color = base
			var into: float = info["into"]
			var near: float = info["depth"]
			if into > -0.07 or near < 1.5:
				color = _c.get("shore", Color(0.22, 0.2, 0.16))
				if posmod(sy + int(2.0 * F * sin(sx * 0.6 / F)), 3 * F) == 0:
					color = _c.get("shore_dark", color.darkened(0.2))
			elif sin((sx * 0.55 + sy * 0.18) / F + gn * 9.0) > 0.92 and grain > 0.25:
				color = _c.get("sheen", base.lightened(0.18))
			elif grain > 0.96:
				color = base.darkened(0.3)
			if a > 0.6 and grain < 0.3:
				color = color.lerp(_c.get("ground_accent", color), 0.7)
		"tiles":
			color = _tile(sx, sy, base)
		"frost":
			color = base
			var cel: = _map.cell_noise.get_noise_2dv(w)
			if cel < -0.965 and grain > 0.2:
				color = _c.get("crack", base.lightened(0.25))
			elif a > 0.6:
				color = color.lerp(_c.get("snow", Color(0.6, 0.66, 0.74)), smoothstep(0.6, 0.72, a) * 0.8)
				if grain > 0.9:
					color = color.lightened(0.08)
			elif grain > 0.985:
				color = _c.get("snow", base.lightened(0.4))
			elif grain < 0.04:
				color = base.darkened(0.2)
		_:
			color = base
			if _c.has("ground_accent"):
				color = color.lerp(_c["ground_accent"], smoothstep(0.55, 0.7, a) * 0.85)
			if grain > 0.93:
				color = color.darkened(0.18)
			elif grain > 0.86:
				color = color.lightened(0.07)
	if _c.has("path_heat") and _style != "plates":
		var near: float = info["depth"]
		if near < HEAT_REACH:
			color = color.lerp(_c["path_heat"], 0.4 * (1.0 - (near - 1.0) / (HEAT_REACH - 1.0)))
	return color


func _tile(sx: int, sy: int, base: Color) -> Color:
	const T: = 6 * F
	var tx: = floori(sx / float(T))
	var ty: = floori(sy / float(T))
	var lx: = sx - tx * T
	var ly: = sy - ty * T
	var th: = h(tx, ty, _seed + 11)
	var grout: Color = _c.get("grout", base.darkened(0.5))
	if th < 0.1:
		return _c.get("rubble", base.darkened(0.3)) if h(sx, sy, _seed) > 0.85 else grout.lerp(base, 0.4)
	if lx == 0 or ly == 0:
		return grout
	var tones: = [_c.get("tile_a", base), _c.get("tile_b", base.lightened(0.08)), _c.get("tile_c", base.darkened(0.08))]
	var color: Color = tones[int(th * 97.0) % 3]
	if th < 0.18 and lx == ly:
		return grout.lerp(color, 0.3)
	if h(tx, ty, _seed + 12) > 0.72 and (lx / F + ly / F * 2) % 7 == 3:
		return _c.get("vein", color.lightened(0.15))
	if lx == T - 1 or ly == T - 1:
		return color.darkened(0.12)
	return color



func _road(sx: int, sy: int, w: Vector2, info: Dictionary) -> Color:
	var depth: float = info["depth"]
	match _style:
		"ash":
			var row: = floori(sy / (2.0 * F))
			var shifted: = sx + (row % 2) * 2 * F
			var col: = floori(shifted / (3.0 * F))
			var edge: = (shifted - col * 3 * F == 0) or (sy - row * 2 * F == 0)
			if depth > 0.7 and h(col, row, _seed + 3) > 0.5:
				return _land(sx, sy, w, info)
			if edge:
				return _c["path_edge"]
			return (_c["path"] as Color).lightened(0.12 * h(col, row, _seed + 4) - 0.04)
		"tiles":
			var tile: = _tile(sx, sy, _c["ground_dark"])
			var blood: Color = _c.get("path_core", _c["path"]) if depth < 0.35 else _c["path"]
			return tile.lerp(blood, 0.85 if depth < 0.7 else 0.55)
	if depth > 0.67:
		return _c["path_edge"]
	var color: Color = _c["path"] if depth > 0.3 else _c.get("path_core", _c["path"])
	return color.lightened(0.06) if h(sx, sy, _seed) > 0.85 else color


func _lava(sx: int, sy: int, w: Vector2, info: Dictionary) -> Color:
	var depth: float = info["depth"]
	if depth > 0.85:
		return _c["path_edge"]
	var cel: = _map.cell_noise.get_noise_2dv(w * 1.7 + Vector2(311, 97))
	var molten: = cel < -0.9 + 0.35 * (1.0 - depth)
	if molten:
		return (_c.get("path_core", _c["path"]) as Color).lightened(0.12 if h(sx, sy, _seed) > 0.8 else 0.0)
	var crust: Color = _c["path"]
	return crust.darkened(0.35) if depth > 0.5 else crust


func _current(sx: int, sy: int, w: Vector2, info: Dictionary) -> Color:
	var depth: float = info["depth"]
	if depth > 0.75:
		return _c["path_edge"]
	var color: Color = _c["path"] if depth > 0.35 else _c.get("path_core", _c["path"])
	var f: Vector2 = info.get("flow", Vector2.RIGHT)
	var across: = floori(w.dot(f.orthogonal()) / (SUB * F))
	var along: = floori(w.dot(f) / (SUB * F * 3.0))
	if across % 3 == 0 and h(along, across, _seed + 5) > 0.45:
		return color.lightened(0.22)
	return color


func _pool(sx: int, sy: int, info: Dictionary) -> Color:
	var into: float = info["into"]
	var pool: Color = _c.get("pool", Color(0.02, 0.02, 0.03))
	var edge: Color = _c.get("pool_edge", pool.lightened(0.2))
	var deep: Color = _c.get("pool_deep", pool.darkened(0.4))
	var glint: Color = _c.get("pool_glint", pool.lightened(0.35))
	var grain: = h(sx, sy, _seed + 9)
	if info["g"] == GameMap.Ground.VOID:
		if into < 0.03:
			return edge if grain > 0.3 else edge.darkened(0.4)
		if into < 0.07:
			return pool
		return glint if grain > 0.992 else deep
	if into < 0.03:
		return edge
	var color: = pool if into < 0.1 else deep
	if posmod(sy + int(round(1.5 * F * sin((sx * 0.45 + sy * 0.2) / F))), 4 * F) == 0 and grain > 0.35:
		return color.lerp(glint, 0.6)
	return color


func _ice(sx: int, sy: int, info: Dictionary) -> Color:
	var into: float = info["into"]
	var ice: Color = _c.get("ice", Color(0.32, 0.46, 0.62))
	var grain: = h(sx, sy, _seed + 13)
	if into < 0.025:
		return _c.get("ice_edge", ice.lightened(0.45))
	var color: = ice if into > 0.08 else ice.lightened(0.08)
	var gn: float = info["gn"]
	var band: = sin((sx - sy * 0.6) / (2.5 * F) + gn * 7.0)
	if band > 0.9:
		color = color.lightened(0.18 if band > 0.97 else 0.09)
	elif grain > 0.992:
		color = Color(0.95, 1, 1)
	elif grain < 0.03:
		color = color.darkened(0.12)
	return color

func _bridge(w: Vector2, sx: int, sy: int) -> Color:
	var color: Color = _c.get("bridge", Color(0.3, 0.27, 0.26))
	var edge: Color = _c.get("bridge_edge", color.darkened(0.45))
	for b: Dictionary in _bridges:
		var d: Vector2 = w - b["pos"]
		var dir: Vector2 = b["dir"]
		var along: = d.dot(dir)
		var side: = absf(d.dot(dir.orthogonal()))
		if absf(along) < b["half_len"] and side < GameMap.BRIDGE_HALF_W:
			if side > GameMap.BRIDGE_HALF_W - SUB * F * 1.5:
				return edge
			var slab: = floori(along / (SUB * F * 2.0))
			var plank: = color if slab % 2 == 0 else color.darkened(0.12)
			if absf(along - slab * SUB * F * 2.0) < SUB * F * 0.6:
				plank = plank.darkened(0.25)
			return plank.darkened(0.15) if h(sx, sy, _seed) > 0.9 else plank
	return color
