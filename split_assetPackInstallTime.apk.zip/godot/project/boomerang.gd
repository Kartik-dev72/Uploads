class_name Boomerang
extends Weapon




const ID: = "boomerang"
const COOLDOWN_TEXT: = "throws %d%% faster"
const THROW_SPEED: = 650.0
const BASE: = {"damage": 14.0, "cooldown": 1.5, "count": 1, "speed": 1.0, "area": 1.0}
const UPGRADES: = [
	{"damage": 7.0}, 
	{"speed": 1.2}, 
	{"count": 1}, 
	{"cooldown": 0.88}, 
	{"area": 1.25}, 
	{"damage": 12.0, "count": 1}, 
	{"cooldown": 0.88, "damage": 10.0}, 
]


const HOLY: = {"damage": 14.0, "count": 1, "area": 1.1}
const WHEEL_ORBIT: = 210.0
const WHEEL_TURN: = 2.6
const WHEEL_HIT_GAP: = 0.45
const WHEEL_RADIUS: = 14.0

var damage: = 14.0
var cooldown: = 1.5
var count: = 1
var speed: = 1.0
var area: = 1.0
var _timer: = 0.0
var _time: = 0.0
var _orbit: = 0.0
var _wheels: Array[Vector2] = []
var _wheel_hits: Array[Dictionary] = []

func _on_level() -> void :
	Layers.put(self, Layers.PLAYER_EFFECTS)

func _process(delta: float) -> void :
	if holy:
		_circle(delta)
		return
	_timer -= delta
	if _timer > 0.0:
		return
	_timer = cooldown_of(cooldown)
	var n: = amount_of(count)
	var targets: = nearest_enemies_on_screen(1)
	var aim: = player.facing
	if not targets.is_empty():
		aim = global_position.direction_to(targets[0].global_position)
	for i in n:
		var dir: = aim.rotated((i - (n - 1) / 2.0) * 0.35)
		var p: = fire_projectile(global_position, dir, THROW_SPEED * speed, damage, 999, Projectile.Style.GLAIVE, area)
		p.motion = Projectile.Motion.BOOMERANG
		p.radius = 10.0
		p.lifetime = 2.2


func _circle(delta: float) -> void :
	_time += delta
	_orbit = fmod(_orbit + WHEEL_TURN * speed * delta, TAU)
	var n: = amount_of(count)
	var orbit_r: = WHEEL_ORBIT * area_of(1.0) * (1.0 + 0.3 * sin(_time * 0.9))
	var reach_r: = WHEEL_RADIUS * area_of(area)
	var prev: = _wheels.duplicate()
	_wheels.resize(n)
	while _wheel_hits.size() < n:
		_wheel_hits.append({})
	for i in n:
		_wheels[i] = global_position + Vector2.RIGHT.rotated(_orbit + TAU * i / n) * orbit_r
	while prev.size() < n:
		prev.append(_wheels[prev.size()])
	for e: Enemy in Enemy.near(global_position, orbit_r + reach_r * 2.0 + 40.0):
		if absf(global_position.distance_to(e.global_position) - orbit_r) > reach_r * 2.0 + e.radius + 40.0:
			continue
		var id: = e.get_instance_id()
		for i in n:
			if _time < _wheel_hits[i].get(id, 0.0):
				continue
			var closest: = Geometry2D.get_closest_point_to_segment(e.global_position, prev[i], _wheels[i])
			var reach: = reach_r * 1.4 + e.radius
			if closest.distance_squared_to(e.global_position) < reach * reach:
				_wheel_hits[i][id] = _time + WHEEL_HIT_GAP
				e.take_damage(power(damage))
	for hits in _wheel_hits:
		if hits.size() > 300:
			hits.clear()
	queue_redraw()

func _draw() -> void :
	if not holy:
		return
	for i in _wheels.size():
		var r: = WHEEL_RADIUS * area_of(area) * 1.35
		var pos: = to_local(_wheels[i])
		PixelFx.disc(self, pos, r * 2.4, Color(color, 0.12))
		Projectile.draw_holy_wheel(self, pos, r, _time * 9.0, - _time * 14.0, color, _time)
