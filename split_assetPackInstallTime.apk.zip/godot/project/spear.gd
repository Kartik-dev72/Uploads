class_name Spear
extends Weapon







const ID: = "spear"
const COOLDOWN_TEXT: = "thrusts %d%% faster"
const LENGTH: = 360.0
const WIDTH: = 30.0
const START: = 20.0
const THRUST_TIME: = 0.08
const SHOW_TIME: = 0.3
const FAN: = 0.22
const GAP: = 0.07
const BASE: = {"damage": 24.0, "cooldown": 1.5, "count": 1, "area": 1.0}
const UPGRADES: = [
	{"damage": 8.0}, 
	{"area": 1.15}, 
	{"cooldown": 0.85}, 
	{"count": 1}, 
	{"damage": 12.0}, 
	{"area": 1.2}, 
	{"damage": 16.0}, 
]
const HOLY: = {"damage": 20.0}
const BEAM_TIME: = 1.0
const BEAM_TICK: = 0.25
const BEAM_SHARE: = 0.3

var damage: = 24.0
var cooldown: = 1.5
var count: = 1
var area: = 1.0
var _timer: = 0.6
var _queue: Array[float] = []
var _gap: = 0.0
var _thrusts: Array[Dictionary] = []
var _beams: Array[Dictionary] = []
var _time: = 0.0

func _on_level() -> void :
	Layers.put(self, Layers.PLAYER_EFFECTS)

func _process(delta: float) -> void :
	_time += delta
	_timer -= delta
	if _timer <= 0.0:
		_timer = cooldown_of(cooldown)
		var aim: = player.facing.angle()
		var n: = amount_of(count)
		for i in n:
			_queue.append(aim + (i - (n - 1) / 2.0) * FAN)
		_gap = 0.0
	if not _queue.is_empty():
		_gap -= delta
		if _gap <= 0.0:
			_thrust(_queue.pop_front())
			_gap = GAP
	if _thrusts.is_empty() and _beams.is_empty():
		return
	for t in _thrusts:
		t["t"] += delta
	_thrusts = _thrusts.filter( func(t: Dictionary) -> bool: return t["t"] < SHOW_TIME)
	if not _beams.is_empty():
		_burn(delta)
	queue_redraw()

func _thrust(angle: float) -> void :
	var dir: = Vector2.RIGHT.rotated(angle)
	_thrusts.append({"from": global_position, "dir": dir, "t": 0.0})
	_strike(global_position, dir, 1.0)
	if holy:
		_beams.append({"from": global_position, "dir": dir, "t": 0.0, "tick": BEAM_TICK})
	Game.sfx("dodge", randf_range(1.15, 1.3))


func _strike(from: Vector2, dir: Vector2, share: float) -> void :
	var length: = LENGTH * area_of(area)
	var half: = WIDTH * area_of(area) * 0.5
	for e: Enemy in Enemy.near(from + dir * length * 0.5, length * 0.5 + half):
		var to: = e.global_position - from
		var along: = to.dot(dir)
		if along < START - e.radius or along > length + e.radius:
			continue
		if absf(to.dot(dir.orthogonal())) > half + e.radius:
			continue
		var dmg: = power(damage) * share
		e.take_damage(dmg)

func _burn(delta: float) -> void :
	for b in _beams:
		b["t"] += delta
		b["tick"] -= delta
		if b["tick"] <= 0.0:
			b["tick"] += BEAM_TICK
			_strike(b["from"], b["dir"], BEAM_SHARE)
	_beams = _beams.filter( func(b: Dictionary) -> bool: return b["t"] < BEAM_TIME)



func _draw() -> void :
	var length: = LENGTH * area_of(area)
	var half: = WIDTH * area_of(area) * 0.5
	var hot: = color.lightened(0.55)
	for b in _beams:
		var o: = to_local(b["from"])
		var d: Vector2 = b["dir"]
		var fade: = 1.0 - pow(b["t"] / BEAM_TIME, 2.0)
		var flicker: = 0.85 + 0.15 * sin(_time * 30.0 + b["t"] * 7.0)
		PixelFx.line(self, o + d * START, o + d * length, Color(color, 0.35 * fade * flicker), half * 2.0)
		PixelFx.line(self, o + d * START, o + d * length, Color(1, 1, 0.95, 0.8 * fade), half * 0.6)
	for t in _thrusts:
		var o: = to_local(t["from"])
		var d: Vector2 = t["dir"]
		var k: = minf(t["t"] / THRUST_TIME, 1.0)
		var fade: = 1.0 - maxf(0.0, t["t"] - THRUST_TIME) / (SHOW_TIME - THRUST_TIME)
		var tip: = o + d * lerpf(START + 40.0, length, k)
		var tail: = tip - d * minf(length * 0.55, 200.0)
		var side: = d.orthogonal()
		PixelFx.line(self, o + d * START, tip, Color(color, 0.22 * fade), half * 1.6)
		PixelFx.line(self, o + d * START, tip, Color(hot, 0.5 * fade), 4.0)
		PixelFx.line(self, tail, tip - d * 30.0, Color(0.08, 0.05, 0.05, fade), 10.0)
		PixelFx.line(self, tail, tip - d * 30.0, Color(0.55, 0.36, 0.22, fade), 5.0)
		PixelFx.poly(self, PackedVector2Array([tip + d * 3.0, tip - d * 38.0 + side * 13.0, tip - d * 30.0, tip - d * 38.0 - side * 13.0]), 
			Color(0.1, 0.08, 0.1, fade))
		PixelFx.poly(self, PackedVector2Array([tip - d * 1.0, tip - d * 34.0 + side * 9.0, tip - d * 29.0, tip - d * 34.0 - side * 9.0]), 
			Color(color, fade))
		PixelFx.line(self, tip - d * 4.0, tip - d * 28.0, Color(1, 1, 1, fade), 3.0)
