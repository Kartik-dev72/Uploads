class_name Gloom
extends Node2D






const TEXELS: = 64
const EASE: = 0.6

var _player: Player
var _base: = {}
var _want: = {}
var _tex: ImageTexture
var _color: = Color.BLACK
var _alpha: = 0.0
var _outer: = 600.0
var _inner_frac: = 0.5
var _time: = 0.0

func _ready() -> void :
	add_to_group("gloom")
	Layers.put(self, Layers.GLOOM)
	_player = get_tree().get_first_node_in_group("player") as Player
	_base = Game.theme.gloom
	_want = _base
	if not _base.is_empty():
		_alpha = _base.get("alpha", 0.6)
		_outer = _base.get("outer", 600.0)
		_bake(_base)

func push(g: Dictionary) -> void :
	_want = g
	_bake(g)

func pop() -> void :
	_want = _base
	if not _base.is_empty():
		_bake(_base)

func _process(delta: float) -> void :
	_time += delta
	var target_alpha: float = _want.get("alpha", 0.0) if not _want.is_empty() else 0.0
	var target_outer: float = _want.get("outer", _outer)
	var k: = 1.0 - pow(1.0 - EASE, delta)
	_alpha = lerpf(_alpha, target_alpha, k * 1.5)
	_outer = lerpf(_outer, target_outer, k)
	if is_instance_valid(_player):
		global_position = _player.global_position
	visible = _alpha > 0.01 and _tex != null
	if visible:
		queue_redraw()


func _bake(g: Dictionary) -> void :
	_color = g.get("color", Color.BLACK)
	_inner_frac = clampf(float(g.get("inner", 300.0)) / float(g.get("outer", 600.0)), 0.05, 0.95)
	const BAYER: = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5]
	var img: = Image.create_empty(TEXELS, TEXELS, false, Image.FORMAT_RGBA8)
	var half: = TEXELS / 2.0
	for x in TEXELS:
		for y in TEXELS:
			var r: = Vector2(x + 0.5 - half, y + 0.5 - half).length() / half
			var a: = smoothstep(_inner_frac, 1.0, r) * 4.0
			var step: = floorf(a)
			if a - step > (BAYER[(y % 4) * 4 + x % 4] + 0.5) / 16.0:
				step += 1.0
			img.set_pixel(x, y, Color(_color, minf(step / 4.0, 1.0)))
	_tex = ImageTexture.create_from_image(img)

func _draw() -> void :
	if _tex == null:
		return
	var breathe: = 1.0 + 0.025 * sin(_time * 0.9)
	var r: = _outer * breathe
	var m: = Color(1, 1, 1, _alpha)
	draw_texture_rect(_tex, Rect2(Vector2( - r, - r), Vector2(r, r) * 2.0), false, m)
	var far: = 2400.0
	var c: = Color(_color, _alpha)
	draw_rect(Rect2( - far, - far, far * 2.0, far - r), c)
	draw_rect(Rect2( - far, r, far * 2.0, far - r), c)
	draw_rect(Rect2( - far, - r, far - r, r * 2.0), c)
	draw_rect(Rect2(r, - r, far - r, r * 2.0), c)
