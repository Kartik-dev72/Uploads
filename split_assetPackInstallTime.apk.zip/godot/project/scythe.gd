class_name Scythe
extends Weapon














const ID: = "scythe"
const COOLDOWN_TEXT: = "swings %d%% faster"
const RADIUS: = 150.0
const INNER: = 24.0
const SWEEP_TIME: = 0.22
const HOLY_SWEEP_TIME: = 0.34
const DOOM_TIME: = 3.0
const FADE: = 0.14
const BASE: = {"damage": 16.0, "cooldown": 1.5, "count": 1, "area": 1.0, "doom": 0.15}
const UPGRADES: = [
	{"damage": 6.0}, 
	{"area": 1.15}, 
	{"count": 1}, 
	{"doom": 0.1}, 
	{"cooldown": 0.85}, 
	{"damage": 9.0}, 
	{"area": 1.15}, 
]
const HOLY: = {"damage": 12.0, "doom": 0.1}
const LEAP_RANGE: = 240.0
const LEAP_TIME: = 0.14
const LEAP_SHARE: = 0.7
const CHAIN_PER_SWING: = 10
const MAX_LEAPS: = 12
const WING_FEATHERS: = 6
const WING_SPAN: = 100.0
const MAX_FEATHERS: = 40

var damage: = 16.0
var cooldown: = 1.5
var count: = 1
var area: = 1.0
var doom: = 0.15
var _timer: = 0.8
var _swings: Array[Dictionary] = []
var _marks: = {}
var _leaps: Array[Dictionary] = []
var _chain_left: = 0
var _feathers: Array[Dictionary] = []
var _time: = 0.0

func _on_level() -> void :
	Layers.put(self, Layers.PLAYER_EFFECTS)

func _process(delta: float) -> void :
	_time += delta
	_timer -= delta
	if _timer <= 0.0:
		_timer = cooldown_of(cooldown)
		var mid: = player.facing.angle()
		var sweeps: = 1 if holy else count
		for i in sweeps:
			_swings.append({"mid": mid + (PI if i % 2 == 1 else 0.0), "t": 0.0, "delay": _sweep_time() * i, "hit": {}})
		_chain_left = CHAIN_PER_SWING
	if holy:
		_update_holy(delta)
	if _swings.is_empty():
		if not _leaps.is_empty() or not _feathers.is_empty():
			queue_redraw()
		return
	for s in _swings:
		if s["delay"] > 0.0:
			s["delay"] -= delta
			continue
		if s["t"] == 0.0:
			Game.sfx("reap", randf_range(0.92, 1.08))
		s["t"] += delta
		_cut(s)
	var span: = _sweep_time() + FADE
	_swings = _swings.filter( func(s: Dictionary) -> bool: return s["t"] < span)
	queue_redraw()

func _sweep_time() -> float:
	return HOLY_SWEEP_TIME if holy else SWEEP_TIME


func _arc(s: Dictionary) -> Vector2:
	if holy:
		return Vector2(s["mid"], s["mid"] + TAU)
	return Vector2(s["mid"] - PI / 2.0, s["mid"] + PI / 2.0)


func _cut(s: Dictionary) -> void :
	var k: = minf(s["t"] / _sweep_time(), 1.0)
	var arc: = _arc(s)
	var swept: = (arc.y - arc.x) * k
	var reach: = RADIUS * area_of(area)
	var hit: Dictionary = s["hit"]
	for e: Enemy in Enemy.near(global_position, reach):
		var id: = e.get_instance_id()
		if hit.has(id):
			continue
		var to: = e.global_position - global_position
		var d: = to.length()
		if d > reach + e.radius or d < INNER - e.radius:
			continue
		var rel: = fposmod(to.angle() - arc.x, TAU)
		var slack: = e.radius / maxf(d, 1.0)
		if rel > swept + slack and rel < TAU - slack:
			continue
		hit[id] = true
		_reap(e, power(damage))


func _reap(e: Enemy, amount: float) -> void :
	var id: = e.get_instance_id()
	if holy:
		if not e.died.is_connected(_on_marked_died):
			e.died.connect(_on_marked_died, CONNECT_ONE_SHOT)
		_marks[id] = _time + DOOM_TIME
	e.take_damage(amount)
	if not e.is_dead():
		e.mark_doom(doom, duration_of(DOOM_TIME))

func _on_marked_died(e: Enemy) -> void :
	var id: = e.get_instance_id()
	var until: float = _marks.get(id, -1.0)
	_marks.erase(id)
	if not holy or until < _time or _chain_left <= 0 or _leaps.size() >= MAX_LEAPS:
		return
	var from: = e.global_position
	var best: Enemy = null
	var best_d: = LEAP_RANGE * LEAP_RANGE
	for o: Enemy in Enemy.near(from, LEAP_RANGE):
		if o == e or o.is_dead() or not o.targetable or _marks.has(o.get_instance_id()):
			continue
		var d: = from.distance_squared_to(o.global_position)
		if d < best_d:
			best_d = d
			best = o
	if best == null:
		return
	_chain_left -= 1
	_marks[best.get_instance_id()] = _time + DOOM_TIME + LEAP_TIME
	if not best.died.is_connected(_on_marked_died):
		best.died.connect(_on_marked_died, CONNECT_ONE_SHOT)
	_leaps.append({"from": from, "e": best, "to": best.global_position, "t": 0.0})


func _update_holy(delta: float) -> void :
	for l in _leaps:
		l["t"] += delta
		var target: Variant = l["e"]
		var alive: = is_instance_valid(target) and not (target as Enemy).is_dead()
		if alive:
			l["to"] = (target as Enemy).global_position
		if l["t"] >= LEAP_TIME and not l.has("done"):
			l["done"] = true
			if alive:
				_reap(target as Enemy, power(damage) * LEAP_SHARE)
				Game.sfx("reap", 1.5)
	_leaps = _leaps.filter( func(l: Dictionary) -> bool: return l["t"] < LEAP_TIME + FADE)
	for f in _feathers:
		f["life"] -= delta
		f["pos"] += f["vel"] * delta
		f["vel"] *= 1.0 - 2.0 * delta
	_feathers = _feathers.filter( func(f: Dictionary) -> bool: return f["life"] > 0.0)
	if not _swings.is_empty() and _feathers.size() < MAX_FEATHERS and randf() < 0.5:
		var back: = player.facing.angle() + PI + randf_range(-1.4, 1.4)
		_feathers.append({"pos": global_position + Vector2.RIGHT.rotated(back) * randf_range(30, 80), 
			"vel": Vector2.RIGHT.rotated(back) * randf_range(20, 60) + Vector2(0, randf_range(10, 30)), "life": randf_range(0.6, 1.1), 
			"spin": randf() * TAU})
	if _marks.size() > 200:
		for id: int in _marks.keys():
			if _marks[id] < _time:
				_marks.erase(id)



func _draw() -> void :
	if holy:
		_draw_holy()
	var reach: = RADIUS * area_of(area)
	var hot: = color.lightened(0.55)
	for s in _swings:
		if s["delay"] > 0.0:
			continue
		var k: = minf(s["t"] / _sweep_time(), 1.0)
		var fade: = 1.0 - maxf(0.0, s["t"] - _sweep_time()) / FADE
		var arc: = _arc(s)
		var cur: = lerpf(arc.x, arc.y, k)
		var dir: = signf(arc.y - arc.x)

		if cur != arc.x:
			PixelFx.arc(self, Vector2.ZERO, reach * 0.62, arc.x, cur, Color(color, 0.14 * fade), reach * 0.7, true)
			PixelFx.arc(self, Vector2.ZERO, reach * 0.88, maxf(arc.x, cur - 0.7) if dir > 0 else minf(arc.x, cur + 0.7), cur, 
				Color(hot, 0.45 * fade), 6.0, true)
		if fade < 1.0:
			continue
		var d: = Vector2.RIGHT.rotated(cur)
		PixelFx.line(self, d * INNER, d * reach * 0.92, Color(0.1, 0.07, 0.08), 6.0)
		PixelFx.line(self, d * INNER, d * reach * 0.92, Color(0.45, 0.32, 0.25), 3.0)

		var tip_a: = cur - dir * 0.55
		var pts: = PackedVector2Array()
		for i in 7:
			var a: = lerpf(cur, tip_a, i / 6.0)
			pts.append(Vector2.RIGHT.rotated(a) * reach * lerpf(0.95, 1.02, i / 6.0))
		for i in range(6, -1, -1):
			var a: = lerpf(cur, tip_a, i / 6.0)
			pts.append(Vector2.RIGHT.rotated(a) * reach * lerpf(0.8, 1.0, pow(i / 6.0, 0.6)))
		PixelFx.poly(self, pts, Color(0.12, 0.1, 0.12))
		PixelFx.arc(self, Vector2.ZERO, reach * 0.96, minf(cur, tip_a), maxf(cur, tip_a), Color(hot, 0.95), 3.0, true)

func _draw_holy() -> void :
	var hot: = color.lightened(0.55)

	for s in _swings:
		if s["delay"] > 0.0:
			continue
		var open: = ease(minf(s["t"] / 0.14, 1.0), 0.4)
		var fade: = 1.0 - maxf(0.0, s["t"] - _sweep_time()) / FADE
		var back: = Vector2.RIGHT.rotated(s["mid"] + PI)
		for side: float in [-1.0, 1.0]:
			_draw_wing(back, back.rotated(side * PI / 2.0), WING_SPAN * open, fade, hot)
	for f in _feathers:
		var p: Vector2 = f["pos"] - global_position
		var d: = Vector2.RIGHT.rotated(f["spin"] + f["life"] * 3.0) * 4.0
		PixelFx.line(self, p - d, p + d, Color(hot, clampf(f["life"], 0.0, 1.0) * 0.8), 1.0)

	for l in _leaps:
		var k: = minf(l["t"] / LEAP_TIME, 1.0)
		var fade: = 1.0 - maxf(0.0, l["t"] - LEAP_TIME) / FADE
		var a: Vector2 = l["from"] - global_position
		var b: Vector2 = l["to"] - global_position
		var head: = a.lerp(b, k)
		PixelFx.line(self, a.lerp(b, maxf(k - 0.5, 0.0)), head, Color(color, 0.45 * fade), 6.0)
		PixelFx.line(self, a.lerp(b, maxf(k - 0.25, 0.0)), head, Color(hot, 0.95 * fade), 2.0)
		if k >= 1.0:
			var ang: = (b - a).angle()
			PixelFx.arc(self, b, 20.0, ang - 1.4, ang + 1.4, Color(color, 0.5 * fade), 7.0)
			PixelFx.arc(self, b, 20.0, ang - 1.2, ang + 1.2, Color(hot, fade), 2.0)



func _draw_wing(back: Vector2, out: Vector2, span: float, fade: float, hot: Color) -> void :
	if span < 4.0:
		return
	var at: = func(o: float, b: float) -> Vector2: return back * 8.0 + out * (6.0 + o) + back * b
	var edge: = PackedVector2Array()
	for i in 7:
		var u: = i / 6.0
		edge.append(at.call(span * u, - span * 0.22 * sin(PI * u * 0.85) + span * 0.1 * u * u))
	var pts: = edge.duplicate()
	for k in range(WING_FEATHERS, -1, -1):
		var u: = float(k) / WING_FEATHERS
		var length: = span * (0.3 + 0.22 * u)
		var o: = span * u * 0.97
		pts.append(at.call(o, length))
		if k > 0:
			pts.append(at.call(o - span * 0.5 / WING_FEATHERS, length * 0.72))
	PixelFx.poly(self, pts, Color(color, 0.5 * fade))
	for k in range(1, WING_FEATHERS + 1):
		var u: = float(k) / WING_FEATHERS
		var root: Vector2 = edge[mini(int(round(u * 6.0)), 6)]
		PixelFx.line(self, root, at.call(span * u * 0.97, span * (0.3 + 0.22 * u) * 0.9), Color(hot, 0.45 * fade), 1.0)
	PixelFx.polyline(self, edge, Color(hot, 0.95 * fade), 2.0)
