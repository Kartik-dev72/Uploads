class_name SoulFever
extends Node














const TIME: = 10.0



const DROP_CHANCE: = 0.18
const GOLD: = Color(1.0, 0.82, 0.3)
const CAP: = 10.0
const PICKUP_TIME: = [[Pickup.COFFER, 10.0], [Pickup.POUCH, 5.0], [1, 0.5]]

static var active: = false

var _left: = 0.0
var _length: = TIME
var _tint: ColorRect
var _t: = 0.0
var _overlay: Control
var _aura: Node2D
var _player: Player
var _coins_start: = 0
var _rain: Array = []
var _soul_tex: Texture2D
var _banner_in: = 0.0
const RAIN: = 30

static func start(parent: Node, player: Node2D) -> void :
	for p: XPGem in parent.get_tree().get_nodes_in_group("soul_pickups"):
		p.pull()
	var running: = parent.get_tree().get_first_node_in_group("soul_fever") as SoulFever
	if running and running._left > 0.0:
		running._length = minf(running._length + TIME, running.cap())
		running._left = running._length
	else:
		var f: = SoulFever.new()
		f._left = TIME
		f._length = TIME
		parent.add_child(f)
	active = true
	Game.sfx("fever")
	Game.sfx("jackpot")


static func soul_taken(tree: SceneTree, souls: int) -> void :
	if not active:
		return
	var f: = tree.get_first_node_in_group("soul_fever") as SoulFever
	if f == null or f._left <= 0.0:
		return
	var add: = 0.0
	for step: Array in PICKUP_TIME:
		if souls >= int(step[0]):
			add = float(step[1])
			break
	add *= f._duration()
	var elapsed: = f._length - f._left
	f._length = minf(f._length + add, f.cap())
	if elapsed - add >= 0.0:
		elapsed -= add
	f._left = f._length - elapsed

func _ready() -> void :
	add_to_group("soul_fever")
	_tint = ColorRect.new()
	_tint.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_tint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_tint.color = Color(GOLD, 0.0)
	var ui: = get_parent().get_node_or_null("UI")
	if ui:
		ui.add_child(_tint)
		ui.move_child(_tint, 0)
	else:
		var layer: = CanvasLayer.new()
		add_child(layer)
		layer.add_child(_tint)
	_player = get_tree().get_first_node_in_group("player") as Player
	_coins_start = _player.coins if _player else 0
	_soul_tex = Game.theme.texture(Game.theme.pickups.get("coin", "coin"))
	_overlay = Control.new()
	_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_overlay.draw.connect(_draw_overlay)
	_tint.add_sibling(_overlay)
	var hud: = _tint.get_parent().get_node_or_null("HUD")
	if hud:
		_tint.get_parent().move_child(_overlay, hud.get_index())
	var view: = Game.view_size()
	for i in RAIN:
		_rain.append([Vector2(randf() * view.x, randf() * view.y), randf_range(220, 520), randf_range(0.6, 1.2), randf() * TAU])
	get_tree().process_frame.connect(_hide_when_paused)
	if _player:
		_aura = Layers.canvas(_player, Layers.AROUND_PLAYER, _draw_aura, false)


func _hide_when_paused() -> void :
	if is_instance_valid(_overlay):
		_overlay.visible = not get_tree().paused

func _duration() -> float:
	return _player.duration if is_instance_valid(_player) else 1.0


func cap() -> float:
	return CAP * _duration()

func gained() -> int:
	return maxi((_player.coins if is_instance_valid(_player) else _coins_start) - _coins_start, 0)

func _process(delta: float) -> void :
	_left -= delta
	_t += delta
	_banner_in = minf(_banner_in + delta * 4.0, 1.0)
	var fade: = clampf(_left, 0.0, 1.0)
	_tint.color = Color(GOLD, (0.03 + 0.03 * sin(_t * 6.0)) * fade)
	var view: = Game.view_size()
	for r: Array in _rain:
		r[0] = (r[0] as Vector2) + Vector2(sin(_t * 2.0 + float(r[3])) * 30.0, float(r[1])) * delta
		if (r[0] as Vector2).y > view.y + 20.0:
			r[0] = Vector2(randf() * view.x, -20.0)
	_overlay.queue_redraw()
	if is_instance_valid(_aura):
		_aura.queue_redraw()
	if _left <= 0.0:
		Game.track_max("fever_souls", gained())
		if is_instance_valid(_player) and gained() > 0:
			FloatText.pop(_player, "FEVER OVER  +%d %s" % [gained(), Game.theme.currency], _player.global_position + Vector2(0, -110), GOLD, 40, 2.0, 50.0, 1.6)
			Game.sfx("buy")
		queue_free()


func _draw_overlay() -> void :
	var view: = _overlay.size
	var fade: = clampf(_left, 0.0, 1.0)
	var pulse: = 0.5 + 0.5 * sin(_t * 6.0)
	for i in 6:
		var w: = 14.0 + i * 14.0
		var a: = (0.24 - i * 0.035) * (0.7 + 0.3 * pulse) * fade
		_overlay.draw_rect(Rect2(0, 0, w, view.y), Color(GOLD, a))
		_overlay.draw_rect(Rect2(view.x - w, 0, w, view.y), Color(GOLD, a))
		_overlay.draw_rect(Rect2(0, 0, view.x, w * 0.6), Color(GOLD, a * 0.7))
		_overlay.draw_rect(Rect2(0, view.y - w * 0.6, view.x, w * 0.6), Color(GOLD, a * 0.7))
	if _soul_tex:
		for r: Array in _rain:
			var sz: = _soul_tex.get_size() * 3.0 * float(r[2])
			var p: Vector2 = r[0]
			_overlay.draw_rect(Rect2(p + Vector2(-1.5, - sz.y * 1.6), Vector2(3, sz.y * 1.2)), Color(GOLD, 0.25 * fade))
			_overlay.draw_texture_rect(_soul_tex, Rect2(p - sz / 2.0, sz), false, Color(1, 0.9, 0.55, 0.4 * fade * minf(float(r[2]), 1.0)))

	var font: = ThemeDB.fallback_font
	var w: = 420.0
	var top: = HUD.text_bottom() + 70.0 - (1.0 - _banner_in) * 120.0
	var box: = Rect2((view.x - w) / 2.0, top, w, 92.0)
	_overlay.draw_rect(box, Color(0.12, 0.07, 0.0, 0.82 * fade))
	_overlay.draw_rect(box, Color(GOLD, (0.6 + 0.4 * pulse) * fade), false, 3.0)
	var title: = "SOUL FEVER"
	var ts: = 38 + int(3.0 * pulse)
	var tw: = font.get_string_size(title, HORIZONTAL_ALIGNMENT_LEFT, -1, ts).x
	_overlay.draw_string_outline(font, Vector2(view.x / 2.0 - tw / 2.0, top + 40.0), title, HORIZONTAL_ALIGNMENT_LEFT, -1, ts, 8, Color(0, 0, 0, fade))
	_overlay.draw_string(font, Vector2(view.x / 2.0 - tw / 2.0, top + 40.0), title, HORIZONTAL_ALIGNMENT_LEFT, -1, ts, Color(GOLD.lightened(0.3 * pulse), fade))
	var count: = "+%d %s" % [gained(), Game.theme.currency]
	var cw: = font.get_string_size(count, HORIZONTAL_ALIGNMENT_LEFT, -1, 24).x
	_overlay.draw_string(font, Vector2(view.x / 2.0 - cw / 2.0, top + 66.0), count, HORIZONTAL_ALIGNMENT_LEFT, -1, 24, Color(0.85, 0.95, 1.0, fade))
	var bar: = Rect2(box.position.x + 16.0, top + 74.0, w - 32.0, 9.0)
	_overlay.draw_rect(bar, Color(0, 0, 0, 0.7 * fade))
	var k: = clampf(_left / maxf(_length, 0.01), 0.0, 1.0)
	var hot: = GOLD if _left > 3.0 else GOLD.lerp(Color(1, 0.3, 0.2), pulse)
	_overlay.draw_rect(Rect2(bar.position, Vector2(bar.size.x * k, bar.size.y)), Color(hot, fade))
	var secs: = "%.1f s" % maxf(_left, 0.0)
	_overlay.draw_string(font, Vector2(box.end.x - 70.0, top + 66.0), secs, HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color(1, 1, 1, 0.75 * fade))


func _draw_aura() -> void :
	var fade: = clampf(_left, 0.0, 1.0)
	var pulse: = 0.5 + 0.5 * sin(_t * 5.0)
	_aura.draw_circle(Vector2.ZERO, 50.0 + 8.0 * pulse, Color(GOLD, 0.2 * fade))
	_aura.draw_arc(Vector2.ZERO, 58.0 + 10.0 * pulse, 0.0, TAU, 40, Color(GOLD, 0.7 * fade), 4.0)
	_aura.draw_arc(Vector2.ZERO, 78.0 - 10.0 * pulse, 0.0, TAU, 40, Color(GOLD, 0.4 * fade), 2.5)
	for i in 8:
		var ph: = fmod(_t * 0.8 + i / 8.0, 1.0)
		var at: = Vector2(cos(i * 2.4) * 36.0, 20.0 - ph * 90.0)
		_aura.draw_rect(Rect2(at, Vector2(6, 6)), Color(GOLD.lightened(0.3), (1.0 - ph) * fade))

func _exit_tree() -> void :
	if get_tree().process_frame.is_connected(_hide_when_paused):
		get_tree().process_frame.disconnect(_hide_when_paused)
	remove_from_group("soul_fever")
	active = get_tree().get_first_node_in_group("soul_fever") != null
	if is_instance_valid(_tint):
		_tint.queue_free()
	if is_instance_valid(_overlay):
		_overlay.queue_free()
	if is_instance_valid(_aura):
		_aura.queue_free()
