extends Node













const TEST_REWARDED_ID: = "ca-app-pub-3940256099942544/5224354917"

const REWARDED_UNIT_ID: = "ca-app-pub-5088131806706139/4968154517"
const FAKE_AD_SECONDS: = 3.0

var _backend: RefCounted
var _fake: = false

func _ready() -> void :
	process_mode = Node.PROCESS_MODE_ALWAYS
	if OS.get_name() == "Android" and _plugin_installed():
		_backend = (load("res://ads_admob.gd") as Script).new()
		_backend.start(unit_id())
	elif OS.is_debug_build():
		_fake = true

func unit_id() -> String:
	return TEST_REWARDED_ID if OS.is_debug_build() or REWARDED_UNIT_ID == "" else REWARDED_UNIT_ID

func can_show() -> bool:
	if Game.no_ads:
		return true
	if _backend != null:
		return _backend.is_ready()
	return _fake


func privacy_options_required() -> bool:
	return _backend != null and _backend.privacy_options_required()


func show_privacy_options(done: = func() -> void : pass) -> void :
	if _backend != null:
		_backend.show_privacy_options(done)
	else:
		done.call()

func show_rewarded(done: Callable) -> void :
	if Game.no_ads:
		done.call_deferred(true)
		return
	if _backend != null:
		_backend.show(done)
	elif _fake:
		_show_fake(done)
	else:
		done.call(false)



func _plugin_installed() -> bool:
	for c: Dictionary in ProjectSettings.get_global_class_list():
		if c["class"] == "RewardedAdLoader":
			return true
	return false



func _show_fake(done: Callable) -> void :
	var layer: = CanvasLayer.new()
	layer.layer = 100
	layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(layer)
	var dim: = ColorRect.new()
	dim.color = Color(0.05, 0.05, 0.1, 0.96)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.add_child(dim)
	var label: = Label.new()
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	label.add_theme_font_size_override("font_size", 44)
	layer.add_child(label)
	var skip: = Button.new()
	skip.text = "Close (no reward)"
	skip.custom_minimum_size = Vector2(0, 80)
	skip.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE, Control.PRESET_MODE_MINSIZE, 40)
	layer.add_child(skip)
	var state: = {"left": FAKE_AD_SECONDS, "finished": false}
	var finish: = func(earned: bool) -> void :
		if state["finished"]:
			return
		state["finished"] = true
		layer.queue_free()
		done.call(earned)
	skip.pressed.connect( func() -> void : finish.call(false))
	var tick: = Timer.new()
	tick.wait_time = 0.1
	tick.process_mode = Node.PROCESS_MODE_ALWAYS
	layer.add_child(tick)
	tick.timeout.connect( func() -> void :
		state["left"] -= 0.1
		label.text = "TEST AD\n\nreward in %.1f s" % maxf(state["left"], 0.0)
		if state["left"] <= 0.0:
			finish.call(true))
	tick.start()
	label.text = "TEST AD\n\nreward in %.1f s" % FAKE_AD_SECONDS
