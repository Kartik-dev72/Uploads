class_name BandEdge
extends Node2D






const SPACING: = 46.0
const ROWS: = 3
const ROW_GAP: = 34.0
const DARK_FADE: = 220.0

var map: GameMap
var _pieces: Array = []

func _ready() -> void :
	Layers.put(self, Layers.GROUND_OBJECTS)
	for o: Dictionary in Game.theme.map_obstacles:
		var tex: = Game.theme.texture(str(o["sprite"]))
		if tex:
			for k in maxi(1, roundi(float(o.get("weight", 1.0)))):
				_pieces.append([tex, float(o.get("scale", 3.0))])

func _process(_delta: float) -> void :
	queue_redraw()

func _draw() -> void :
	if map == null or map.band_axis == "":
		return
	var view: = get_canvas_transform().affine_inverse() * get_viewport_rect()
	view = view.grow(200.0)
	var h: = map.band_half
	for side: float in [-1.0, 1.0]:
		if map.band_axis == "x":
			_draw_side(view, side, h, true)
		else:
			_draw_side(view, side, h, false)


func _draw_side(view: Rect2, side: float, h: float, along_x: bool) -> void :
	var lo: = view.position.x if along_x else view.position.y
	var hi: = view.end.x if along_x else view.end.y
	var far: = (view.end.y if side > 0.0 else view.position.y) if along_x else (view.end.x if side > 0.0 else view.position.x)
	var edge: = side * h
	if (far - edge) * side <= 0.0:
		return

	var steps: = 6
	for i in steps:
		var a: = (i + 1.0) / steps
		var d0: = edge + side * DARK_FADE * i / steps
		var d1: = edge + side * DARK_FADE * (i + 1) / steps
		_band_rect(lo, hi, d0, d1, along_x, Color(0, 0, 0, 0.75 * a))
	_band_rect(lo, hi, edge + side * DARK_FADE, far, along_x, Color(0.0, 0.0, 0.0, 0.92))
	if _pieces.is_empty():
		return

	var first: = floori(lo / SPACING) - 2
	var last: = ceili(hi / SPACING) + 2
	var order: Array = range(ROWS)
	if not along_x or side < 0.0:
		order.reverse()
	for row: int in order:
		for i in range(first, last + 1):
			var hsh: int = hash(Vector3i(i, row, int(side) + (7 if along_x else 0)))
			var piece: Array = _pieces[absi(hsh) % _pieces.size()]
			var tex: Texture2D = piece[0]
			var size: = tex.get_size() * float(piece[1]) * (0.85 + 0.3 * _bits(hsh, 8))
			var along: = (i + (0.5 if row % 2 == 1 else 0.0)) * SPACING + (_bits(hsh, 16) - 0.5) * 20.0
			var across: = edge + side * (row * ROW_GAP + (_bits(hsh, 24) - 0.5) * 12.0)
			var base: = Vector2(along, across) if along_x else Vector2(across, along)
			var shade: = 1.0 - 0.25 * row
			draw_texture_rect(tex, Rect2(base - Vector2(size.x * 0.5, size.y), size), false, Color(shade, shade, shade))

func _band_rect(lo: float, hi: float, d0: float, d1: float, along_x: bool, color: Color) -> void :
	var a: = minf(d0, d1)
	var b: = maxf(d0, d1)
	var r: = Rect2(lo, a, hi - lo, b - a) if along_x else Rect2(a, lo, b - a, hi - lo)
	draw_rect(r, color)


static func _bits(h: int, shift: int) -> float:
	return float((h >> shift) & 255) / 255.0
