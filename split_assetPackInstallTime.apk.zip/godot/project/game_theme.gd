class_name GameTheme
extends RefCounted












const BASE_PALETTE: = {
	"K": Color(0.12, 0.09, 0.14), 
	"E": Color(0.08, 0.08, 0.12), 
	"S": Color(0.98, 0.8, 0.64), 
	"s": Color(0.85, 0.62, 0.5), 
	"W": Color(0.97, 0.97, 0.95), 
	"w": Color(0.72, 0.75, 0.8), 
	"G": Color(0.5, 0.53, 0.58), 
	"Y": Color(1.0, 0.85, 0.25), 
	"o": Color(1.0, 0.95, 0.6, 0.55), 
	"O": Color(0.95, 0.55, 0.15), 
	"m": Color(0.7, 0.35, 0.1), 
	"R": Color(0.85, 0.18, 0.2), 
	"B": Color(0.25, 0.4, 0.85), 
	"b": Color(0.15, 0.22, 0.55), 
	"C": Color(0.4, 0.85, 1.0), 
	"H": Color(0.25, 0.55, 0.3), 
	"h": Color(0.15, 0.35, 0.2), 
	"Z": Color(0.52, 0.7, 0.42), 
	"L": Color(0.55, 0.36, 0.2), 
	"N": Color(0.62, 0.42, 0.22), 
	"n": Color(0.45, 0.28, 0.15), 
	"D": Color(0.22, 0.16, 0.14), 
	"A": Color(0.98, 0.8, 0.35), 
	"P": Color(0.5, 0.25, 0.7), 
	"V": Color(0.33, 0.2, 0.42), 
	"T": Color(0.35, 0.4, 0.6), 
	"t": Color(0.24, 0.27, 0.42), 
	"X": Color(0.92, 0.9, 0.8), 
	"F": Color(0.88, 0.94, 1.0, 0.8), 
}


const BASE_SPRITES: = {
	"ice_shard": [
		"...KK...", 
		"..KBWK..", 
		".KBBWWK.", 
		".KBBWWK.", 
		"KBBBWWWK", 
		".KBBWWK.", 
		"..KBWK..", 
		"...KK...", 
	], 

	"map_tree": [
		"......KKKK......", 
		"....KKHHHHKK....", 
		"...KHHHHHHHHK...", 
		"..KHHHHHHhHHHK..", 
		"..KHhHHHHHHHHK..", 
		".KHHHHHHHHHhHHK.", 
		".KHHHhHHHHHHHHK.", 
		".KhHHHHHHhHHHhK.", 
		"..KhHHHHHHHHhK..", 
		"..KhhhHHHHhhhK..", 
		"...KKhhhhhhKK...", 
		".....KKnnKK.....", 
		"......KnnK......", 
		"......KnNK......", 
		".....KnnNnK.....", 
		"....KKKKKKKK....", 
	], 
	"map_boulder": [
		"....KKKK....", 
		"..KKwwwGKK..", 
		".KwwwGGGGGK.", 
		"KwwGGGGGGGGK", 
		"KwGGGGGGGGKK", 
		"KGGGGGGGGKGK", 
		".KKGGGGGKGK.", 
		"...KKKKKKK..", 
	], 
	"map_grass": [
		"H...H", 
		"H.H.H", 
		".hHh.", 
	], 
	"map_flowers": [
		".R....", 
		"RYR.W.", 
		".R.WYW", 
		"....W.", 
	], 
	"map_pebbles": [
		".KK...", 
		"KwGK..", 
		".KK.KK", 
		"....KG", 
	], 
	"coin": [
		"..KKKK..", 
		".KYYYYK.", 
		"KYWYYYmK", 
		"KYWYYYmK", 
		"KYYYYYmK", 
		"KYYYYmmK", 
		".KmmmmK.", 
		"..KKKK..", 
	], 
	"heart": [
		".KK..KK.", 
		"KRRKKRRK", 
		"KRWRRRRK", 
		"KRRRRRRK", 
		".KRRRRK.", 
		"..KRRK..", 
		"...KK...", 
	], 
	"crate": [
		"KKKKKKKKKKKKKKKK", 
		"KNNNNNNNNNNNNNNK", 
		"KNnnnnnnnnnnnnNK", 
		"KNnNNnnnnnnNNnNK", 
		"KNnnNNnnnnNNnnNK", 
		"KNnnnNNnnNNnnnNK", 
		"KNnnnnNNNNnnnnNK", 
		"KNnnnnnNNnnnnnNK", 
		"KNnnnnNNNNnnnnNK", 
		"KNnnnNNnnNNnnnNK", 
		"KNnnNNnnnnNNnnNK", 
		"KNnNNnnnnnnNNnNK", 
		"KNnnnnnnnnnnnnNK", 
		"KNNNNNNNNNNNNNNK", 
		"KKKKKKKKKKKKKKKK", 
	], 
	"barrel": [
		"....KKKKKKKK....", 
		"...KNNNNNNNNK...", 
		"..KNnnnnnnnnNK..", 
		"..KGGGGGGGGGGK..", 
		"..KNnnnnnnnnNK..", 
		".KNnnnnnnnnnnNK.", 
		".KNnnnnnnnnnnNK.", 
		".KGGGGGGGGGGGGK.", 
		".KNnnnnnnnnnnNK.", 
		".KNnnnnnnnnnnNK.", 
		"..KNnnnnnnnnNK..", 
		"..KGGGGGGGGGGK..", 
		"..KNnnnnnnnnNK..", 
		"...KNNNNNNNNK...", 
		"....KKKKKKKK....", 
	], 
	"statue": [
		"....KKKK....", 
		"...KwwwwK...", 
		"..KwGwwGwK..", 
		"..KwRwwRwK..", 
		"..KwwwwwwK..", 
		"...KwGGwK...", 
		"..KKwwwwKK..", 
		".KwwKwwKwwK.", 
		".KwGwwwwGwK.", 
		".KwwwwwwwwK.", 
		"..KwwGGwwK..", 
		"..KwwwwwwK..", 
		".KGGGGGGGGK.", 
		"KGwwwwwwwwGK", 
		"KGGGGGGGGGGK", 
		"KKKKKKKKKKKK", 
	], 
	"icon_glaive": [
		".....KK.....", 
		"....KWGK....", 
		"....KWGK....", 
		".....KK.....", 
		".KKK.KK.KKK.", 
		"KWWWKGGKGGGK", 
		"KGGGKGGKWWWK", 
		".KKK.KK.KKK.", 
		".....KK.....", 
		"....KGWK....", 
		"....KGWK....", 
		".....KK.....", 
	], 
	"icon_axe": [
		"......KKKK..", 
		".....KwwwwK.", 
		"....KwWWwwwK", 
		"...KnKwWwwwK", 
		"..KnK.KwwwK.", 
		"..KnK..KKK..", 
		".KnK........", 
		".KnK........", 
		"KnK.........", 
		"KK..........", 
	], 
	"icon_flask": [
		"...KKKK...", 
		"...KwwK...", 
		"...KwwK...", 
		"..KKwwKK..", 
		".KwCCCCwK.", 
		"KwCCWCCCwK", 
		"KCCWCCCCCK", 
		"KCCCCCCCCK", 
		"KCCCCCCbCK", 
		".KCCCCbbK.", 
		"..KKKKKK..", 
	], 
	"icon_whip": [
		"......KKK...", 
		".....KLLLK..", 
		"....KLK.KLK.", 
		"....KLK..KLK", 
		".....KLK.KLK", 
		"......KK.KLK", 
		"........KLK.", 
		"KK.....KLK..", 
		"KLKKKKKLK...", 
		".KLLLLLK....", 
		"..KYYK......", 
		"..KNNK......", 
	], 
	"icon_fist": [
		"..KKKKKKK...", 
		".KGGKGGKGK..", 
		".KGwKGwKwGK.", 
		".KGGKGGKGGK.", 
		".KGGGGGGGGK.", 
		"KKKGGGGGGGK.", 
		"KwGKGGGGGGK.", 
		"KGGGGGGGGK..", 
		".KGGGGGGGK..", 
		"..KGGGGGK...", 
		"..KLLLLLK...", 
		"..KKKKKKK...", 
	], 
	"icon_hourglass": [
		"KKKKKKKKKK", 
		"KNNNNNNNNK", 
		".KwwwwwwK.", 
		".KwYYYYwK.", 
		"..KwYYwK..", 
		"...KwYK...", 
		"...KwwK...", 
		"..KwwYwK..", 
		".KwwYYYwK.", 
		".KwYYYYYK.", 
		"KNNNNNNNNK", 
		"KKKKKKKKKK", 
	], 
	"icon_tome": [
		".KKKKKKKKK..", 
		".KPPPPPPPPK.", 
		".KPPYYYYPPK.", 
		".KPPYPPYPPK.", 
		".KPPYYYYPPK.", 
		".KPPPPPPPPK.", 
		".KPPPPPPPPK.", 
		".KPPPPPPPPK.", 
		".KKKKKKKKKK.", 
		".KWWWWWWWWK.", 
		"..KKKKKKKKK.", 
	], 
	"icon_ring": [
		"....KKKK....", 
		"...KCWCCK...", 
		"....KKKK....", 
		"...KYYYYK...", 
		"..KYK..KYK..", 
		".KYK....KYK.", 
		".KYK....KYK.", 
		".KYK....KYK.", 
		"..KYK..KmK..", 
		"...KYYmmK...", 
		"....KKKK....", 
	], 
	"icon_boot": [
		"..KKKKK.....", 
		"..KLLLK.....", 
		"..KLLLK..K..", 
		"..KLLLK.KWK.", 
		"..KLLLKKWWK.", 
		"..KLLLLKWK..", 
		"..KLLLLLKK..", 
		".KLLLLLLLKK.", 
		"KLLLLLLLLLLK", 
		"KnnnnnnnnnnK", 
		".KKKKKKKKKK.", 
	], 
	"icon_dice": [
		"..KKKKKKKK..", 
		".KWWWWWWWWK.", 
		"KWWKWWWWWWwK", 
		"KWWWWWWWWWwK", 
		"KWWWWWWWWWwK", 
		"KWWWWKWWWWwK", 
		"KWWWWWWWWWwK", 
		"KWWWWWWWWWwK", 
		"KWWWWWWWKWwK", 
		"KwwwwwwwwwwK", 
		".KwwwwwwwwK.", 
		"..KKKKKKKK..", 
	], 
	"icon_magnet": [
		".KKKK..KKKK.", 
		".KWWK..KWWK.", 
		".KRRK..KRRK.", 
		".KRRK..KRRK.", 
		".KRRK..KRRK.", 
		".KRRKKKKRRK.", 
		".KRRRRRRRRK.", 
		"..KRRRRRRK..", 
		"...KKKKKK...", 
	], 
	"icon_cross": [
		"....KKKK....", 
		"....KHHK....", 
		"....KHHK....", 
		"KKKKKHHKKKKK", 
		"KHHHHWHHHHHK", 
		"KHHHHHHHHHHK", 
		"KKKKKHHKKKKK", 
		"....KHHK....", 
		"....KHHK....", 
		"....KKKK....", 
	], 
	"icon_shield": [
		"KKKKKKKKKK", 
		"KBBBBBBBBK", 
		"KBWBBYYBBK", 
		"KBWBYYYYBK", 
		"KBBBBYYBBK", 
		"KBBBBYYBBK", 
		".KBBBBBBK.", 
		".KBBBBBBK.", 
		"..KBBBBK..", 
		"...KBBK...", 
		"....KK....", 
	], 
	"icon_star": [
		".....KK.....", 
		"....KYYK....", 
		"....KYYK....", 
		"KKKKKYYKKKKK", 
		"KYYYYWYYYYYK", 
		".KYYYYYYYYK.", 
		"..KYYYYYYK..", 
		"..KYYKKYYK..", 
		".KYYK..KYYK.", 
		".KKK....KKK.", 
	], 
	"icon_bolt": [
		"..........KKKK..", 
		".........KoooK..", 
		"......KKKooYoK..", 
		".....KooYYYYoK..", 
		"....KoYYWWWYYoK.", 
		"...KoYWWWWWWYoK.", 
		"...KoYWWWWWWYoK.", 
		"..KoYYWWWWWWYoK.", 
		"..KoYYWWWWWYYoK.", 
		".KoYYYYWWWYYoK..", 
		".KoYYYYYYYYoK...", 
		"KooYYYYYYooK....", 
		"KoooYYoooKK.....", 
		"KoooooKKK.......", 
		".KKKKK..........", 
	], 
	"icon_knife": [
		"..............KK", 
		".............KWK", 
		"............KWwK", 
		"...........KWwK.", 
		"..........KWwK..", 
		".........KWwK...", 
		"........KWwK....", 
		".......KWwK.....", 
		"......KWwK......", 
		"...KK.KWK.......", 
		"...KYKKK........", 
		"....KYYK........", 
		"...KLKYK........", 
		"..KLLK.KK.......", 
		".KLLK...........", 
		".KKK............", 
	], 
	"icon_aura": [
		".....oooooo.....", 
		"...oo......oo...", 
		"..o..YYYYYY..o..", 
		".o..Y......Y..o.", 
		".o.Y..WWWW..Y.o.", 
		"o..Y.W....W.Y..o", 
		"o.Y.W..WW..W.Y.o", 
		"o.Y.W..WW..W.Y.o", 
		"o..Y.W....W.Y..o", 
		".o.Y..WWWW..Y.o.", 
		".o..Y......Y..o.", 
		"..o..YYYYYY..o..", 
		"...oo......oo...", 
		".....oooooo.....", 
	], 
	"icon_orbs": [
		"......KKK.......", 
		".....KCWCK......", 
		".....KCCCK......", 
		"......KKK.......", 
		"................", 
		"..KKK.......KKK.", 
		".KCWCK.....KCWCK", 
		".KCCCK.....KCCCK", 
		"..KKK.......KKK.", 
		"................", 
		"......KKK.......", 
		".....KCWCK......", 
		".....KCCCK......", 
		"......KKK.......", 
	], 
	"icon_lightning": [
		"..........KKKK..", 
		".........KYYYK..", 
		"........KYYYK...", 
		".......KYYYK....", 
		"......KYYYK.....", 
		".....KYYYKKKK...", 
		"....KYYYYYYYK...", 
		"...KKKKKYYYK....", 
		"......KYYYK.....", 
		".....KYYYK......", 
		"....KYYK........", 
		"...KYYK.........", 
		"...KYK..........", 
		"..KYK...........", 
		"..KK............", 
	], 

	"attractor_orb": [
		"...KKKK...", 
		"..KCCCCK..", 
		".KCWWCCCK.", 
		"KCWWCCCCBK", 
		"KCWCCCCCBK", 
		"KCCCCCCBBK", 
		"KCCCCCBBbK", 
		".KCCBBBbK.", 
		"..KBbbbK..", 
		"...KKKK...", 
	], 

	"rosary": [
		"...KXXXXK...", 
		"..KXK..KXK..", 
		".KXK....KXK.", 
		".KXK....KXK.", 
		"..KXK..KXK..", 
		"...KXKKXK...", 
		"....KYYK....", 
		"..KKKYYKKK..", 
		"..KYYYYYYK..", 
		"..KKKYYKKK..", 
		"....KYYK....", 
		"....KYYK....", 
		"....KYYK....", 
		"....KKKK....", 
	], 

	"blessing": [
		"...KKKKKKKKKK...", 
		"..KYWWWWWWWWYK..", 
		".KYWWWWYYWWWWYK.", 
		"KYWWWWYYYYWWWWYK", 
		"KYWWWWWYYWWWWWYK", 
		"KYYYYYYYYYYYYYYK", 
		"KKKKKKKYYKKKKKKK", 
		"KYWWWWKYYKWWWWYK", 
		"KYWWWWWKKWWWWWYK", 
		"KYWWWWWWWWWWWWYK", 
		"KYYYYYYYYYYYYYYK", 
		"KKKKKKKKKKKKKKKK", 
	], 
	"blessing_open": [
		"..KKKKKKKKKKKK..", 
		".KYWWWWWWWWWWYK.", 
		"KYWWWWWYYWWWWWYK", 
		"KYYYYYYYYYYYYYYK", 
		"KKKKKKKKKKKKKKKK", 
		"..W..o....o..W..", 
		".o..W..oo..W..o.", 
		"KKKKKKKKKKKKKKKK", 
		"KYWWWWWWWWWWWWYK", 
		"KYWWWWWWWWWWWWYK", 
		"KYWWWWWWWWWWWWYK", 
		"KYWWWWWWWWWWWWYK", 
		"KYYYYYYYYYYYYYYK", 
		"KKKKKKKKKKKKKKKK", 
	], 
}

var id: = ""
var display_name: = ""
var title: = "SURVIVOR SURVIVOR"
var currency: = "Gold"
var music: = ""



var sounds: = {
	"xp": "res://sfx/xp.wav", 
	"xp_big": "res://sfx/xp_big.wav", 
	"coin": "res://sfx/coin.wav", 
	"heal": "res://sfx/heal.wav", 
	"hurt": "res://sfx/hurt.wav", 
	"death": "res://sfx/death.wav", 
	"hit": "res://sfx/hit.wav", 
	"kill": "res://sfx/kill.wav", 
	"break": "res://sfx/break.wav", 
	"crumble": "res://sfx/crumble.wav", 
	"fire_rise": "res://sfx/fire_rise.wav", 
	"fire_hiss": "res://sfx/fire_hiss.wav", 
	"fire_out": "res://sfx/fire_out.wav", 
	"boss_spawn": "res://sfx/boss_spawn.wav", 
	"boss_die": "res://sfx/boss_die.wav", 
	"swarm": "res://sfx/swarm.wav", 
	"level_up": "res://sfx/level_up.wav", 
	"select": "res://sfx/select.wav", 
	"click": "res://sfx/click.wav", 
	"buy": "res://sfx/buy.wav", 
	"blessing_1": "res://sfx/blessing_1.wav", 
	"blessing_2": "res://sfx/blessing_2.wav", 
	"blessing_3": "res://sfx/blessing_3.wav", 
	"reveal": "res://sfx/reveal.wav", 
	"holy": "res://sfx/holy.wav", 
	"reroll": "res://sfx/reroll.wav", 
	"chest_spawn": "res://sfx/chest_spawn.wav", 
	"vacuum": "res://sfx/vacuum.wav", 
	"purge": "res://sfx/purge.wav", 
	"dodge": "res://sfx/dodge.wav", 
	"reap": "res://sfx/reap.wav", 
	"laugh": "res://sfx/laugh.wav", 
	"rewind": "res://sfx/rewind.wav", 
	"explode": "res://sfx/explode.wav", 
	"splash": "res://sfx/splash.wav", 
	"barrier": "res://sfx/barrier.wav", 
	"slot_spin": "res://sfx/slot_spin.wav", 
	"slot_stop": "res://sfx/slot_stop.wav", 
	"jackpot": "res://sfx/jackpot.wav", 
	"achievement": "res://sfx/achievement.wav", 
	"thud": "res://sfx/thud.wav", 
	"fever": "res://sfx/fever.wav", 
	"crunch": "res://sfx/crunch.wav", 

	"moon_rise": "res://sfx/moon_rise.wav", 
	"moon_loop": "res://sfx/moon_loop.wav", 
	"quake": "res://sfx/quake.wav", 
	"quake_loop": "res://sfx/quake_loop.wav", 
	"gloom_rise": "res://sfx/gloom_rise.wav", 
	"gloom_loop": "res://sfx/gloom_loop.wav", 
	"champion": "res://sfx/champion.wav", 
	"event_end": "res://sfx/event_end.wav", 

	"holy_wipe": "res://sfx/holy_wipe.wav", 
	"earth_crack": "res://sfx/earth_crack.wav", 
	"fall": "res://sfx/fall.wav", 
	"ascend": "res://sfx/ascend.wav", 
}


var ui: = {
	"background": Color(0.08, 0.06, 0.12), 
	"title": Color(0.9, 0.25, 0.3), 
	"accent": Color(1, 0.85, 0.3), 
	"panel": Color(0.16, 0.13, 0.22), 
	"hp": Color(0.85, 0.2, 0.25), 
	"xp": Color(0.3, 0.7, 1), 
	"xp_big": Color(0.95, 0.2, 0.35), 
	"warning": Color(1, 0.3, 0.25), 
	"arena_fire": Color(1, 0.4, 0.08), 
	"holy": Color(1, 0.93, 0.55), 
	"death": Color(1, 1, 1), 
}

var palette: = {}
var sprites: = {}
var sprite_palettes: = {}




var weapons: = {}


var passives: = {
	"might": {"name": "Might", "icon": "icon_fist"}, 
	"cooldown": {"name": "Haste", "icon": "icon_hourglass"}, 
	"area": {"name": "Reach", "icon": "icon_tome"}, 
	"amount": {"name": "Duplicator", "icon": "icon_ring"}, 
	"speed": {"name": "Swiftness", "icon": "icon_boot"}, 
	"magnet": {"name": "Magnet", "icon": "icon_magnet"}, 
	"regen": {"name": "Recovery", "icon": "icon_cross"}, 
	"max_hp": {"name": "Vitality", "icon": "heart"}, 
	"armor": {"name": "Armor", "icon": "icon_shield"}, 
	"growth": {"name": "Growth", "icon": "icon_star"}, 
	"crit": {"name": "Keen Edge", "icon": "icon_knife"}, 
	"lifesteal": {"name": "Leech Fang", "icon": "icon_cross"}, 
	"bounty": {"name": "Bounty", "icon": "icon_star"}, 
	"blast": {"name": "Volatile Blood", "icon": "icon_bolt"}, 
	"curse": {"name": "Curse", "icon": "icon_dice"}, 
	"thorns": {"name": "Thorns", "icon": "icon_knife"}, 
	"relic": {"name": "Second Wind", "icon": "icon_cross"}, 
	"censer": {"name": "Warding Smoke", "icon": "icon_aura"}, 
	"luck": {"name": "Luck", "icon": "icon_star"}, 
}



var upgrades: = {
	"reroll": {"icon": "icon_dice"}, 
	"revive": {"icon": "icon_cross"}, 
	"exile": {"icon": "icon_dice"}, 
	"greed": {"icon": "icon_star"}, 
	"skip": {"icon": "icon_star"}, 
}






var survivors: Array = []





var enemies: = {}


var spawn_table: Array = []





var swarms: Array = []








var bosses: Array = []
var boss_first: = 180.0
var boss_every: = 180.0
var death_title: = "GAME OVER"



var death_taunts: Array = []



var taunt_sprite: = "pact_devil"



var devil_tips: = {}

var ambient: = {}
var win_time: = 600.0



var difficulties: Array = [
	{"name": "Normal", "desc": "How the game is meant to be played.", "hp": 1.0, "speed": 1.0, "rate": 1.0, "elite": 1.0, "souls": 1.0}, 
	{"name": "Hard", "desc": "Tougher, faster, more elites. Souls x1.25.", "hp": 1.35, "speed": 1.05, "rate": 1.2, "elite": 1.5, "souls": 1.25}, 
	{"name": "Nightmare", "desc": "A crowd that does not stop. Souls x1.5.", "hp": 1.8, "speed": 1.08, "rate": 1.45, "elite": 2.2, "souls": 1.5}, 
	{"name": "Impossible", "desc": "Only the best survive. Souls x1.75.", "hp": 2.5, "speed": 1.12, "rate": 1.8, "elite": 3.0, "souls": 1.75}, 
]










var pact_title: = "SELL YOUR SOUL?"
var pact_taunts: = {}
var pact_words: = {
	"header": "INFERNAL CONTRACT", "receives": "The undersigned shall receive", "exchange": "IN EXCHANGE", 
	"sign": "SIGN IN BLOOD", "lawyer": "Angelic lawyer", "reroll": "New terms", "walk": "Walk away", 
	"void": "VOID", "objection": "OBJECTION!", "signed": "SIGNED", 
}
var pact_prices: = {
	"frail": {"name": "Frailty", "text": "-%d max HP for this run", "icon": "heart"}, 
	"sluggish": {"name": "Heavy Feet", "text": "-%d%% move speed", "icon": "icon_boot"}, 
	"feeble": {"name": "Weakness", "text": "-%d%% damage", "icon": "icon_fist"}, 
	"rusted": {"name": "Rust", "text": "Weapons attack %d%% slower", "icon": "icon_ring"}, 
	"dim": {"name": "Short Reach", "text": "-%d%% pickup range", "icon": "icon_star"}, 
	"dull": {"name": "Dull Mind", "text": "-%d%% XP", "icon": "icon_star"}, 
	"debt": {"name": "Debt", "text": "-%d%% souls this run", "icon": "icon_star"}, 
	"hunted": {"name": "Hunted", "text": "+%d%% more monsters", "icon": "icon_cross"}, 
	"barren": {"name": "Barren", "text": "All HP you restore is %d%% lower", "icon": "heart"}, 
}
var pacts: = {
	"frenzy": {"name": "Frenzy", "text": "+%d%% damage for this run", "icon": "icon_fist"}, 
	"haste": {"name": "Haste", "text": "+%d%% move and attack speed for this run", "icon": "icon_boot"}, 
	"vital": {"name": "Vitality", "text": "+%d max HP for this run", "icon": "heart"}, 
	"greed": {"name": "Greed", "text": "+%d%% XP and souls for this run", "icon": "icon_star"}, 
	"titan": {"name": "Multiply", "text": "+%d projectile on every weapon", "icon": "icon_ring"}, 
	"leech": {"name": "Leech", "text": "Heal 20 HP every %d kills", "icon": "icon_cross"}, 
	"second_chance": {"name": "Second Chance", "text": "%d free revive this run", "icon": "icon_shield"}, 
}





var events: Array = []
var event_colors: = {"blood_moon": Color(0.9, 0.05, 0.1), "eruption": Color(1, 0.45, 0.1)}



var lore: = {}
var elite_lore: = {}
var elite_stand_ins: = {}
var survivor_lore: = {}
var elite_colors: = {"swift": Color(0.4, 0.9, 1), "brute": Color(1, 0.6, 0.15), "volatile": Color(1, 0.3, 0.5), "champion": Color(1, 0.85, 0.2)}




var props: Array = []



var pickups: = {"coin": "coin", "heart": "heart", "blessing": "blessing", "blessing_open": "blessing_open", 
	"vacuum": "attractor_orb", "purge": "rosary", "freeze": "ice_shard", "fever": "coin", "luck": "icon_star", 
	"soul_pouch": "coin", "soul_coffer": "coin"}

var pickup_names: = {"heart": "Healing", "soul_pouch": "Coin Pouch", "soul_coffer": "Coin Chest", 
	"vacuum": "Attractor", "purge": "Rosary", "freeze": "Freeze Shard", "fever": "Gold Fever", "luck": "Lucky Charm"}
var blessing_name: = "HOLY BLESSING"


func pickup_name(kind: String) -> String:
	return str(pickup_names.get(kind, str(pickups.get(kind, kind)).replace("_", " ").capitalize()))



var map: = {
	"ground_dark": Color(0.2, 0.36, 0.17), 
	"ground_light": Color(0.32, 0.5, 0.22), 
	"path": Color(0.5, 0.4, 0.27), 
	"path_edge": Color(0.42, 0.34, 0.22), 
}





var terrain: = {}


var gloom: = {}



var map_obstacles: Array = [
	{"sprite": "map_tree", "scale": 3.5, "radius": 18, "weight": 3}, 
	{"sprite": "map_boulder", "scale": 3.5, "radius": 22, "weight": 2}, 
]

var map_decor: Array = [
	{"sprite": "map_grass", "scale": 3.0, "weight": 5}, 
	{"sprite": "map_flowers", "scale": 3.0, "weight": 3}, 
	{"sprite": "map_pebbles", "scale": 3.0, "weight": 2}, 
]





var level_looks: Array = []
var _base_level: = {}


func apply_level(index: int) -> void :
	if _base_level.is_empty():
		_base_level = {"map": map, "map_obstacles": map_obstacles, "map_decor": map_decor, "spawn_table": spawn_table, 
			"swarms": swarms, "bosses": bosses, "ambient": ambient, "events": events, "terrain": terrain, "gloom": gloom, 
			"props": props, "vignette": ui.get("vignette", Color(0, 0, 0, 0.6))}
	var look: Dictionary = {} if level_looks.is_empty() else level_looks[clampi(index, 0, level_looks.size() - 1)]
	for key: String in ["map", "map_obstacles", "map_decor", "spawn_table", "swarms", "bosses", "ambient", "terrain", "gloom", "props"]:
		set(key, look.get(key, _base_level[key]))
	ui["vignette"] = look.get("vignette", _base_level["vignette"])
	events = look.get("events", _base_level["events"])
	if look.has("champion"):
		var named: Array = []
		for e: Dictionary in events:
			named.append(e.merged({"enemy": look["champion"]}, true) if e["type"] == "miniboss" else e)
		events = named


func level_look(index: int, key: String) -> Variant:
	var look: Dictionary = {} if level_looks.is_empty() else level_looks[clampi(index, 0, level_looks.size() - 1)]
	return look.get(key, _base_level.get(key, get(key)))

var _textures: = {}




var art_factor: = 2
const BIG_ART_FACTOR: = 4
const BIG_ART_SCALE: = 3.6
var _big_art: = {}




const ART_CACHE: = "res://art_hd"
var bake_mode: = false


var native_art: = {}



func build_full_art() -> void :
	pass

static func cache_key(key: String) -> String:
	return key.replace("/", "~").replace("|", "+")

func art_cache_path(key: String, factor: int) -> String:
	return "%s/%s/%s@%d.png" % [ART_CACHE, id if id != "" else "theme", cache_key(key), factor]


func _from_cache(key: String, factor: int) -> Texture2D:
	if bake_mode or (factor <= 1 and not native_art.has(key.get_slice("|", 0).get_slice("/", 0))):
		return null
	var path: = art_cache_path(key, factor)
	if not ResourceLoader.exists(path):
		return null
	var img: = (load(path) as Texture2D).get_image()
	var tex: = ImageTexture.create_from_image(img)
	tex.set_size_override(img.get_size() / factor)
	return tex

func _factor_for(base: String) -> int:
	if native_art.has(base):
		return 1
	if art_factor <= 1:
		return 1
	if _big_art.is_empty():
		_big_art["-"] = true
		for e: Dictionary in enemies.values():
			if float(e.get("scale", 3.0)) >= BIG_ART_SCALE:
				_big_art[str(e.get("sprite", ""))] = true
	return BIG_ART_FACTOR if _big_art.has(base) else art_factor
var _palette: = {}



func xp_tier_color(tier: int) -> Color:
	var tiers: Array = ui.get("xp_tiers", [ui["xp"], Color(0.35, 0.65, 1), ui.get("xp_big", Color(1, 0.25, 0.3))])
	return tiers[clampi(tier, 0, tiers.size() - 1)]

func texture(sprite_name: String) -> Texture2D:
	if _textures.has(sprite_name):
		return _textures[sprite_name]
	if _palette.is_empty():
		_palette = BASE_PALETTE.merged(palette, true)
	var slash: = sprite_name.find("/")
	var base: = sprite_name if slash < 0 else sprite_name.left(slash)
	var frame: = "" if slash < 0 else sprite_name.substr(slash)
	var baked: = _from_cache(sprite_name, _factor_for(base))
	if baked:
		_textures[sprite_name] = baked
		return baked
	var crop: = Rect2i()
	if sprites.has(base + "/2"):
		var n: = 1
		var key: = base
		while sprites.has(key):
			var r: = PixelArt.used_rect(sprites[key])
			crop = r if not crop.has_area() else crop.merge(r)
			n += 1
			key = "%s/%d" % [base, n]
	var rows: Array = sprites.get(base + frame, BASE_SPRITES.get(base + frame, ["K"]))
	var colors: Dictionary = _palette
	if sprite_palettes.has(base):
		colors = _palette.merged(sprite_palettes[base], true)
	var tex: = PixelArt.build(rows, colors, crop, _factor_for(base))
	_textures[sprite_name] = tex
	return tex


func frames(sprite_name: String, ui_key: = "") -> Array[Texture2D]:
	var out: Array[Texture2D] = []
	var n: = 1
	while n == 1 or sprites.has("%s/%d" % [sprite_name, n]):
		var key: = sprite_name if n == 1 else "%s/%d" % [sprite_name, n]
		out.append(rim_texture(key, ui_key) if ui_key != "" else texture(key))
		n += 1
	return out



func rim_texture(sprite_name: String, ui_key: = "rim") -> Texture2D:
	if not ui.has(ui_key):
		return texture(sprite_name)
	var key: = "%s|%s" % [sprite_name, ui_key]
	if not _textures.has(key):
		var slash: = sprite_name.find("/")
		var baked: = _from_cache(key, _factor_for(sprite_name if slash < 0 else sprite_name.left(slash)))
		_textures[key] = baked if baked else PixelArt.with_rim(texture(sprite_name), ui[ui_key])
	return _textures[key]

func weapon(weapon_id: String) -> Dictionary:
	return weapons.get(weapon_id, {"name": weapon_id.capitalize(), "description": "", "icon": "icon_star", "color": Color.WHITE})

func pact(pact_id: String) -> Dictionary:
	return pacts.get(pact_id, {"name": pact_id.capitalize(), "text": "%d", "icon": "icon_star"})

func pact_price(price_id: String) -> Dictionary:
	return pact_prices.get(price_id, {"name": price_id.capitalize(), "text": "%d", "icon": "icon_star"})


func price_icon(price_id: String) -> Texture2D:
	var key: = "price:" + price_id
	if _textures.has(key):
		return _textures[key]
	var src: = texture(pact_price(price_id)["icon"])
	var img: = src.get_image()
	img.convert(Image.FORMAT_RGBA8)
	for y in img.get_height():
		for x in img.get_width():
			var c: = img.get_pixel(x, y)
			var l: = c.get_luminance()
			img.set_pixel(x, y, Color(0.25 + l * 0.5, 0.18 + l * 0.38, 0.28 + l * 0.48, c.a))
	var tex: = ImageTexture.create_from_image(img)
	tex.set_size_override(Vector2i(src.get_size()))
	_textures[key] = tex
	return tex

func passive(passive_id: String) -> Dictionary:
	return passives.get(passive_id, {"name": passive_id.capitalize(), "icon": ""})

func upgrade_icon(upgrade_id: String) -> String:
	return upgrades.get(upgrade_id, {}).get("icon", passive(upgrade_id).get("icon", ""))

func survivor(survivor_id: String) -> Dictionary:
	for s: Dictionary in survivors:
		if s["id"] == survivor_id:
			return s
	return survivors[0]
