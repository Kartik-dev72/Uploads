class_name Breakable
extends Enemy






var heart_chance: = 0.5






const DROPS: = [
	[Pickup.Kind.COIN, 1, 30.0], [Pickup.Kind.COIN, Pickup.POUCH, 18.0], [Pickup.Kind.FREEZE, 0, 1.0], [Pickup.Kind.VACUUM, 0, 1.0], 
	[Pickup.Kind.COIN, Pickup.COFFER, 1.0], [Pickup.Kind.PURGE, 0, 0.5], [Pickup.Kind.FEVER, 0, 1.0], [Pickup.Kind.LUCK, 0, 0.25], 
]

func _init() -> void :
	targetable = false
	hits = 0.0
	coin_chance = 0.0

func configure(data: Dictionary, hp_mult: = 1.0, speed_mult: = 1.0) -> void :
	super (data, hp_mult, speed_mult)
	heart_chance = data.get("heart_chance", heart_chance)

func _process(delta: float) -> void :
	_update_flash(delta)

func die() -> void :
	_dead = true
	remove_from_group("enemies")
	Game.sfx("break")
	if is_instance_valid(_player):
		_player.add_score(Game.SCORE["prop"])
	Game.track("props")
	var scene: = get_tree().current_scene
	DeathFx.spawn(scene, global_position, Game.theme.texture(sprite_name), sprite_scale, _sprite.flip_h, radius)
	var luck: = _player.luck if is_instance_valid(_player) else 1.0
	if randf() < heart_chance:
		Pickup.spawn(scene, Pickup.Kind.HEART, global_position)
	else:
		var total: = 0.0
		for d: Array in DROPS:
			total += d[2] * (1.0 if d[1] == 1 else luck)
		var roll: = randf() * total
		for d: Array in DROPS:
			roll -= d[2] * (1.0 if d[1] == 1 else luck)
			if roll <= 0.0:
				Pickup.spawn(scene, d[0], global_position, maxi(d[1], 1))
				break
	queue_free()
