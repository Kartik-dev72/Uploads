
























const SETTINGS_PATH: = "user://sample_admob_settings.cfg"
const LOCALIZATION_SECTION: = "localization"
const LOCALE_KEY: = "locale"

static var logger: Node = null
static var safe_area: Node = null
