





















class_name VungleMediationExtras
extends MediationExtras

const USER_ID_KEY: = "USER_ID_KEY"

var user_id: String:
	set(value):
		extras[USER_ID_KEY] = value


func _get_ios_mediation_extra_class_name() -> String:
	return "VunglePoingExtrasBuilder"
