





















@tool
extends Node

const TranslationService: = preload("res://addons/admob/internal/services/translation_service.gd")

var _translation_service: = TranslationService.new()


func _enter_tree() -> void :
	_translation_service.setup()


func _exit_tree() -> void :
	_translation_service.cleanup()
