class_name ThrowingKnife
extends Weapon

const ID: = "throwing_knife"
const COOLDOWN_TEXT: = "throws %d%% faster"
const BASE: = {"damage": 8.0, "cooldown": 0.9, "count": 1, "pierce": 3}
const UPGRADES: = [
	{"damage": 3.0}, 
	{"cooldown": 0.85}, 
	{"pierce": 1}, 
	{"count": 1}, 
	{"damage": 4.0}, 
	{"cooldown": 0.85, "count": 1}, 
	{"count": 2}, 
]




const HOLY: = {"damage": 2.0, "cooldown": 0.38, "pierce": 1}
const STREAM_GAP: = 0.05
const SCATTER: = 0.12

var cooldown: = 0.9
var damage: = 8.0
var count: = 1
var pierce: = 3
var _timer: = 0.0
var _queue: = 0
var _gap: = 0.0

func _process(delta: float) -> void :
	if _queue > 0:
		_gap -= delta
		if _gap <= 0.0:
			_queue -= 1
			_gap = STREAM_GAP
			var d: = _aim().rotated(randf_range( - SCATTER, SCATTER))
			fire_projectile(global_position + d.orthogonal() * randf_range(-10.0, 10.0), d, 950.0, damage, pierce, Projectile.Style.KNIFE)
	_timer -= delta
	if _timer > 0.0:
		return
	_timer = cooldown_of(cooldown)
	var dir: = _aim()
	var side: = dir.orthogonal()
	var n: = amount_of(count)
	if holy:
		_queue += n
		return
	for i in n:

		var offset: = side * (i - (n - 1) / 2.0) * 16.0
		fire_projectile(global_position + offset, dir, 900.0, damage, pierce, Projectile.Style.KNIFE)


func _aim() -> Vector2:
	return player.facing
