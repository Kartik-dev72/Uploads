class_name RescueReveal
extends Control







const DIM: = 0.82
const FADE: = 0.25
const RISE_AT: = 0.15
const RISE: = 0.45
const REVEAL_AT: = 1.35
const REVEAL: = 0.7
const NAME_AT: = 1.75
const TAP_AT: = 2.6
const SCALE: = 9.0
const CENTER: = Vector2(360, 560)

var _survivor: = {}
var _t: = 0.0
var _last_tap: = -1.0
var _burst: = false
var _tex: Texture2D

static func play(host: Node, survivor: Dictionary) -> void :
	var node: = RescueReveal.new()
	node._survivor = survivor
	host.add_child(node)

func _ready() -> void :
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_to_group("pause_screen")
	get_tree().paused = true
	_tex = Game.theme.texture(str(_survivor.get("sprite", "")))
	Game.sfx("chest_spawn", 0.7)

func _process(delta: float) -> void :
	_t += delta
	if not _burst and _t >= REVEAL_AT:
		_burst = true
		Game.sfx("holy")
		Game.sfx("reveal")
	queue_redraw()

func _gui_input(event: InputEvent) -> void :
	var tapped: bool = (event is InputEventScreenTouch and event.pressed) or (event is InputEventMouseButton and event.pressed)
	if not tapped:
		return
	accept_event()
	var now: = Time.get_ticks_msec() / 1000.0
	if now - _last_tap < 0.2:
		return
	_last_tap = now
	if _t < REVEAL_AT:
		_t = REVEAL_AT
	elif _t < TAP_AT:
		_t = TAP_AT
	else:
		_close()

func _unhandled_input(event: InputEvent) -> void :
	if event.is_action_pressed("ui_accept") and _t >= TAP_AT:
		_close()

func _close() -> void :
	Game.sfx("select")
	remove_from_group("pause_screen")
	hide()
	queue_free()
	LevelUpScreen.resume_if_clear(get_tree())

func _draw() -> void :
	var view: = get_viewport_rect().size
	var holy: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
	draw_rect(Rect2(Vector2.ZERO, view), Color(0, 0, 0, DIM * clampf(_t / FADE, 0.0, 1.0)))
	draw_set_transform(Vector2((view.x - 720.0) / 2.0, Game.design_offset()))
	var lit: = clampf((_t - REVEAL_AT) / REVEAL, 0.0, 1.0)
	var glow: = lit * lit * (3.0 - 2.0 * lit)
	if lit > 0.0:
		for i in 12:
			var a: = TAU * i / 12.0 + _t * 0.35
			var w: = 0.11
			var far: = 620.0
			draw_colored_polygon(PackedVector2Array([CENTER, CENTER + Vector2.from_angle(a - w) * far, CENTER + Vector2.from_angle(a + w) * far]), 
				Color(holy, 0.16 * glow))
		for i in 4:
			draw_circle(CENTER, 250.0 - i * 50.0, Color(holy, 0.05 * glow + 0.02 * i * glow))
	if _tex and _t >= RISE_AT:
		var r: = clampf((_t - RISE_AT) / RISE, 0.0, 1.0)
		var fig: = _tex.get_size() * SCALE * (0.85 + 0.15 * r)
		var shake: = Vector2.ZERO
		if lit <= 0.0 and _t > RISE_AT + RISE:
			shake = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * 3.0 * clampf((_t - RISE_AT - RISE) / (REVEAL_AT - RISE_AT - RISE), 0.0, 1.0)
		var at: = CENTER - fig / 2.0 + Vector2(0, (1.0 - r) * 60.0) + shake
		var rim: = Color(holy, (0.35 + 0.25 * sin(_t * 6.0)) * r * (1.0 - glow))
		for o: Vector2 in [Vector2(-4, 0), Vector2(4, 0), Vector2(0, -4), Vector2(0, 4)]:
			draw_texture_rect(_tex, Rect2(at + o, fig), false, rim)
		var shade: = Color(0, 0, 0).lerp(Color.WHITE, glow)
		draw_texture_rect(_tex, Rect2(at, fig), false, Color(shade, r))
	var flash: = 1.0 - clampf((_t - REVEAL_AT) / 0.45, 0.0, 1.0) if _t >= REVEAL_AT else 0.0
	if flash > 0.0:
		draw_set_transform(Vector2.ZERO)
		draw_rect(Rect2(Vector2.ZERO, view), Color(1, 0.98, 0.85, 0.85 * flash))
		draw_set_transform(Vector2((view.x - 720.0) / 2.0, Game.design_offset()))
	var font: = ThemeDB.fallback_font
	var top: = CENTER.y - 330.0
	if _t >= RISE_AT:
		var a: = clampf((_t - RISE_AT) / 0.4, 0.0, 1.0)
		var head: = "SOUL RESCUED" if lit > 0.0 else "WHO IS IT?"
		draw_string_outline(font, Vector2(0, top), head, HORIZONTAL_ALIGNMENT_CENTER, 720, 40, 10, Color(0, 0, 0, a))
		draw_string(font, Vector2(0, top), head, HORIZONTAL_ALIGNMENT_CENTER, 720, 40, Color(holy, a))
	if _t >= NAME_AT:
		var a: = clampf((_t - NAME_AT) / 0.35, 0.0, 1.0)
		var punch: = 1.0 + 0.6 * maxf(0.0, 1.0 - (_t - NAME_AT) / 0.15)
		var y: = CENTER.y + 300.0
		var who: = str(_survivor.get("name", "")).to_upper()
		var big: = int(64 * punch)
		draw_string_outline(font, Vector2(0, y), who, HORIZONTAL_ALIGNMENT_CENTER, 720, big, 12, Color(0, 0, 0, a))
		draw_string(font, Vector2(0, y), who, HORIZONTAL_ALIGNMENT_CENTER, 720, big, Color(1, 1, 1, a))
		var title: = "the %s" % str(_survivor.get("title", "")) if str(_survivor.get("title", "")) != "" else ""
		draw_string_outline(font, Vector2(0, y + 50), title, HORIZONTAL_ALIGNMENT_CENTER, 720, 32, 8, Color(0, 0, 0, a))
		draw_string(font, Vector2(0, y + 50), title, HORIZONTAL_ALIGNMENT_CENTER, 720, 32, Color(holy, a))
		var line: = "Free for good: pick them in the Survivors tab"
		draw_string_outline(font, Vector2(0, y + 110), line, HORIZONTAL_ALIGNMENT_CENTER, 720, 26, 7, Color(0, 0, 0, a))
		draw_string(font, Vector2(0, y + 110), line, HORIZONTAL_ALIGNMENT_CENTER, 720, 26, Color(1, 1, 1, 0.85 * a))
	if _t >= TAP_AT:
		var a: = 0.35 + 0.15 * sin(_t * 4.0)
		draw_string(font, Vector2(0, 1140), "tap to continue", HORIZONTAL_ALIGNMENT_CENTER, 720, 26, Color(1, 1, 1, a))
	draw_set_transform(Vector2.ZERO)
