class_name WinOutro
extends Node2D









const WIPE_SPREAD: = 0.9
const WIPE: = 1.6
const SHAKE: = 2.2

const SHAKE_FROM: = 7.0
const SHAKE_TO: = 22.0
const RUMBLE_EVERY: = 0.55
const RUMBLE_DB: = -4.0
const CRACK: = 0.7
const SPLIT: = 0.8
const FALL: = 1.0
const FADE: = 0.8
const WORDS: = 2.4
const CRACK_REACH: = 300.0
const CRACK_STEP: = 16.0
const GAP: = 64.0
const RISE: = 2.0
const RISE_HEIGHT: = 280.0
const DARKEN: = 0.6

var _player
var _final: = false
var _words: = ""
var _sub: = ""
var _after: Array[Callable] = []
var _t: = 0.0
var _wiped: = false
var _ring: = 0.0
var _crack: PackedVector2Array
var _branches: Array[PackedVector2Array] = []
var _embers: Array[Dictionary] = []
var _screen: Control
var _finished: = false
var _sfx_done: = {}
var _rumble: AudioStreamPlayer
var _next_crunch: = 0.0

static func play(player: Node2D, final: bool, words: String, sub: String, after: Array[Callable]) -> void :
	var o: = WinOutro.new()
	o._player = player
	o._final = final
	o._words = words
	o._sub = sub
	o._after = after
	player.get_parent().add_child(o)

func _ready() -> void :
	Layers.put(self, Layers.WARNINGS)
	global_position = _player.global_position + Vector2(0, 22)
	_player.begin_outro()
	for n in _player.get_parent().get_children():
		if n is Spawner:
			(n as Spawner).stop_for_win()
		if n is EventDirector:
			(n as EventDirector).stop_for_win()
		if n is Spawner:
			for c in n.get_children():
				if c.has_method("douse_for_win"):
					c.douse_for_win()
	_clear_projectiles()
	_build_crack()
	_screen = Control.new()
	_screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_screen.mouse_filter = Control.MOUSE_FILTER_STOP
	_screen.draw.connect(_draw_screen)
	var ui: Node = _player.get_parent().get_node_or_null("UI")
	if ui:
		ui.add_child(_screen)
		var results: Node = ui.get_node_or_null("GameOverScreen")
		if results:
			ui.move_child(_screen, results.get_index())
	else:
		var layer: = CanvasLayer.new()
		add_child(layer)
		layer.add_child(_screen)
	_sfx("holy_wipe")
	_player.shake(8.0)

func _exit_tree() -> void :
	if is_instance_valid(_screen):
		_screen.queue_free()



func _clear_projectiles() -> void :
	var gold: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
	var roots: Array[Node] = [_player.get_parent()]
	if get_tree().current_scene != _player.get_parent():
		roots.append(get_tree().current_scene)
	var gone: Array[Node] = []
	gone.append_array(get_tree().get_nodes_in_group("enemy_shots"))
	gone.append_array(get_tree().get_nodes_in_group("win_clear"))
	for r in roots:
		for n in r.get_children():
			if n is Projectile or n is DamageZone or n is SigilMine or n is Ghost:
				gone.append(n)
	var view: = _view()
	var sparks: = 0
	for n in gone:
		if n is Node2D and sparks < 24 and view.has_point((n as Node2D).global_position):
			sparks += 1
			RingFx.spawn(get_parent(), (n as Node2D).global_position, 26.0, gold)
		n.queue_free()

func _sfx(name: String, pitch: = 1.0) -> void :
	if not _sfx_done.has(name):
		_sfx_done[name] = true
		Game.sfx(name, pitch)

func _process(delta: float) -> void :
	_t += delta
	_wipe()
	if _final:
		_ascend()
	else:
		_swallow()
	for e in _embers:
		e["t"] = float(e["t"]) + delta
		e["p"] = (e["p"] as Vector2) + (e["v"] as Vector2) * delta
	_embers = _embers.filter( func(e: Dictionary) -> bool: return float(e["t"]) < float(e["life"]))
	queue_redraw()
	_screen.queue_redraw()



func _wipe() -> void :
	var far: = Game.offscreen_distance() + 200.0
	_ring = far * clampf(_t / WIPE_SPREAD, 0.0, 1.0)
	if _wiped:
		return
	var origin: Vector2 = _player.global_position
	var view: = _view()
	var gold: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
	for e: Enemy in get_tree().get_nodes_in_group("enemies"):
		if e is Breakable or e.is_dead():
			continue
		if _t >= WIPE_SPREAD or e.global_position.distance_to(origin) <= _ring:
			if view.has_point(e.global_position):
				FloatText.pop(e, str(ceili(e.hp)), e.global_position + Vector2(0, -40), gold, 30, 0.9, 50.0, 1.2, true)
			e.burn_to_ash()
	if _t >= WIPE_SPREAD:
		_wiped = true

func _view() -> Rect2:
	return get_canvas_transform().affine_inverse() * get_viewport_rect()



func _swallow() -> void :
	var t: = _t - WIPE
	if t < 0.0:
		return
	_sfx("quake")
	if _rumble == null:
		_start_rumble()
	if t < SHAKE + CRACK + SPLIT:
		_player.shake(lerpf(SHAKE_FROM, SHAKE_TO, clampf(t / (SHAKE + CRACK), 0.0, 1.0)) * randf_range(0.85, 1.15))
		if randf() < 0.8:
			_dust()
		if t >= _next_crunch:
			_next_crunch = t + RUMBLE_EVERY * randf_range(0.7, 1.3)
			Game.sfx("crumble", randf_range(0.7, 1.0), -6.0)
	if t >= SHAKE:
		_sfx("earth_crack")
	if t >= SHAKE + CRACK and randf() < 0.9:
		_ember()
	var fall: = t - (SHAKE + CRACK + SPLIT * 0.6)
	if fall >= 0.0:
		_sfx("fall")
		_stop_rumble()
		var k: = clampf(fall / FALL, 0.0, 1.0)
		_player.outro_pose(Vector2(0, 30.0 * k * k), 1.0 - 0.85 * k * k, Color(1, 0.6, 0.35).lerp(Color(0.25, 0.05, 0.02), k), k < 1.0)
	if t >= SHAKE + CRACK + SPLIT * 0.6 + FALL + FADE + (WORDS if _words != "" else 0.4):
		_finish()



func _ascend() -> void :
	var t: = _t - WIPE
	if t < 0.0:
		return
	_sfx("ascend")
	if t >= 0.6:
		var k: = clampf((t - 0.6) / RISE, 0.0, 1.0)
		var e: = k * k * (3.0 - 2.0 * k)
		_player.outro_pose(Vector2(0, - RISE_HEIGHT * e), 1.0 - 0.6 * e, Color(1, 1, 1).lerp(Color(3, 3, 2.4), e), true)
		if randf() < 0.6:
			_spark()
	if _t >= _darken_at() + DARKEN:
		_finish()

func _darken_at() -> float:
	return WIPE + 0.6 + RISE + FADE * 0.5 + (WORDS if _words != "" else 0.4)

func _finish() -> void :
	if _finished:
		return
	_finished = true
	set_process(false)
	_stop_rumble()
	_player.cash_out()
	for f in _after:
		f.call()



func _start_rumble() -> void :
	_rumble = AudioStreamPlayer.new()
	_rumble.bus = "SFX"
	_rumble.stream = Game.loop_stream("quake_loop")
	add_child(_rumble)
	if _rumble.stream:
		_rumble.volume_db = RUMBLE_DB
		_rumble.play()

func _stop_rumble() -> void :
	if _rumble and _rumble.playing and not _rumble.has_meta("stopping"):
		_rumble.set_meta("stopping", true)
		var tw: = _rumble.create_tween()
		tw.tween_property(_rumble, "volume_db", -40.0, 0.9)
		tw.tween_callback(_rumble.stop)

func _build_crack() -> void :
	var pts: Array[Vector2] = []
	for side in [-1.0, 1.0]:
		var p: = Vector2.ZERO
		var dir: = Vector2(side, randf_range(-0.25, 0.25)).normalized()
		var arm: Array[Vector2] = []
		var gone: = 0.0
		while gone < CRACK_REACH:
			dir = dir.rotated(randf_range(-0.55, 0.55))
			dir = Vector2(side * maxf(absf(dir.x), 0.6), clampf(dir.y, -0.7, 0.7)).normalized()
			p += dir * CRACK_STEP
			gone += CRACK_STEP
			arm.append(p)
			if randf() < 0.18 and gone < CRACK_REACH * 0.8:
				var b: = PackedVector2Array([p])
				var bd: = dir.rotated(randf_range(0.6, 1.1) * (1.0 if randf() < 0.5 else -1.0))
				var q: = p
				for i in randi_range(2, 4):
					q += bd.rotated(randf_range(-0.4, 0.4)) * CRACK_STEP * 0.8
					b.append(q)
				_branches.append(b)
		if side < 0.0:
			arm.reverse()
			pts.append_array(arm)
			pts.append(Vector2.ZERO)
		else:
			pts.append_array(arm)
	_crack = PackedVector2Array(pts)


func _crack_state() -> Vector2:
	var t: = _t - WIPE - SHAKE
	if _final or t < 0.0:
		return Vector2.ZERO
	var run: = clampf(t / CRACK, 0.0, 1.0)
	var open: = clampf((t - CRACK) / SPLIT, 0.0, 1.0)
	return Vector2(run, open * open * (3.0 - 2.0 * open))

func _dust() -> void :
	var a: = randf() * TAU
	var p: = Vector2.RIGHT.rotated(a) * randf_range(40.0, 360.0) * Vector2(1, 0.6)
	_embers.append({"p": p, "v": Vector2(randf_range(-20, 20), randf_range(-70, -30)), "t": 0.0, "life": 0.6, 
		"c": Color(0.55, 0.5, 0.45, 0.6), "n": 2})

func _ember() -> void :
	if _crack.is_empty():
		return
	var i: = randi() % _crack.size()
	var w: = _width_at(i) * _crack_state().y
	_embers.append({"p": _crack[i] + Vector2(randf_range( - w, w) * 0.3, 0), "v": Vector2(randf_range(-25, 25), randf_range(-260, -120)), 
		"t": 0.0, "life": randf_range(0.5, 1.1), "c": Color(1.0, randf_range(0.45, 0.85), 0.15), "n": randi_range(1, 2)})

func _spark() -> void :
	var gold: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
	_embers.append({"p": Vector2(randf_range(-60, 60), randf_range(-40, 10)), "v": Vector2(randf_range(-10, 10), randf_range(-420, -220)), 
		"t": 0.0, "life": randf_range(0.6, 1.2), "c": gold.lightened(0.3), "n": randi_range(1, 2)})


func _width_at(i: int) -> float:
	var mid: = (_crack.size() - 1) / 2.0
	var k: = absf(i - mid) / maxf(mid, 1.0)
	return GAP * 0.5 * (1.0 - k * k)

func _draw() -> void :
	var gold: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))

	if _t < WIPE_SPREAD + 0.4:
		var fade: = clampf(1.0 - (_t - WIPE_SPREAD) / 0.4, 0.0, 1.0)
		var at: Vector2 = _player.global_position - global_position
		draw_arc(at, _ring, 0.0, TAU, 96, Color(gold, 0.85 * fade), 22.0)
		draw_arc(at, _ring * 0.94, 0.0, TAU, 96, Color(1, 1, 1, 0.6 * fade), 8.0)
		draw_circle(at, _ring, Color(gold, 0.12 * fade))
	if _final:
		_draw_pillar(gold)
	else:
		_draw_crack()
	for e in _embers:
		var k: = float(e["t"]) / float(e["life"])
		PixelFx.dot(self, e["p"], Color(e["c"], (e["c"] as Color).a * (1.0 - k)), int(e["n"]))

func _draw_crack() -> void :
	var st: = _crack_state()
	if st.x <= 0.0 or _crack.size() < 2:
		return
	var mid: = (_crack.size() - 1) / 2.0
	var reach: = st.x * mid
	var first: = maxi(0, floori(mid - reach))
	var last: = mini(_crack.size() - 1, ceili(mid + reach))
	if st.y > 0.0:
		var glow: = 0.75 + 0.25 * sin(_t * 9.0)
		for layer in [[1.0, Color(0.05, 0.01, 0.0)], [0.7, Color(0.75, 0.18, 0.04, glow)], [0.42, Color(1.0, 0.55, 0.12, glow)], [0.18, Color(1.0, 0.92, 0.6)]]:
			var top: = PackedVector2Array()
			var bottom: = PackedVector2Array()
			for i in range(first, last + 1):
				var w: float = _width_at(i) * st.y * float(layer[0])
				top.append(_crack[i] + Vector2(0, - w))
				bottom.append(_crack[i] + Vector2(0, w))
			bottom.reverse()
			top.append_array(bottom)
			if top.size() >= 3:
				PixelFx.poly(self, top, layer[1])

		for i in range(first, last + 1, 2):
			var w: = _width_at(i) * st.y
			if w < 4.0:
				continue
			var h: = w * (3.0 + 1.5 * sin(_t * 7.0 + i))
			draw_rect(Rect2(_crack[i] + Vector2( - w * 0.5, - h), Vector2(w, h)), Color(1.0, 0.6, 0.15, 0.1 * st.y))
	var line: = PackedVector2Array()
	for i in range(first, last + 1):
		line.append(_crack[i])
	if line.size() >= 2:
		PixelFx.polyline(self, line, Color(0.06, 0.02, 0.01), 5.0)
		PixelFx.polyline(self, line, Color(1.0, 0.55, 0.15, 0.5 + 0.5 * st.x), 2.0)
	for b in _branches:
		if st.x >= 0.6:
			PixelFx.polyline(self, b, Color(0.08, 0.03, 0.01, (st.x - 0.6) / 0.4), 3.0)

func _draw_pillar(gold: Color) -> void :
	var t: = _t - WIPE
	if t <= 0.0:
		return
	var k: = clampf(t / 0.6, 0.0, 1.0)
	var top: = _view().position.y - global_position.y - 40.0
	var beat: = 0.9 + 0.1 * sin(_t * 8.0)
	for layer in [[110.0, Color(gold, 0.18)], [70.0, Color(gold, 0.35)], [36.0, Color(1, 1, 0.92, 0.75)]]:
		var w: float = float(layer[0]) * k * beat
		draw_rect(Rect2(Vector2( - w / 2.0, top), Vector2(w, - top + 20.0)), layer[1])
	PixelFx.disc(self, Vector2(0, 6), 70.0 * k, Color(gold, 0.35))



func _draw_screen() -> void :
	var size: = _screen.size
	var gold: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
	var flash: = clampf(1.0 - _t / 1.2, 0.0, 1.0)
	if flash > 0.0:
		_screen.draw_rect(Rect2(Vector2.ZERO, size), Color(1, 0.97, 0.85, 0.75 * flash * flash))
	var fade_at: = WIPE + (0.6 + RISE - FADE * 0.5 if _final else SHAKE + CRACK + SPLIT * 0.6 + FALL)
	var f: = clampf((_t - fade_at) / FADE, 0.0, 1.0)
	if f <= 0.0:
		return
	var dark: = clampf((_t - _darken_at()) / DARKEN, 0.0, 1.0) if _final else 0.0
	var cover: = Color(1, 0.98, 0.9).lerp(Color(0.02, 0.02, 0.03), dark) if _final else Color(0, 0, 0)
	_screen.draw_rect(Rect2(Vector2.ZERO, size), Color(cover, f))
	if _words == "" or f < 1.0:
		return
	var w: = clampf((_t - fade_at - FADE) / 0.35, 0.0, 1.0) * (1.0 - dark)
	var font: = ThemeDB.fallback_font
	var y: = size.y * 0.42
	var big: = lerpf(110.0, 64.0, w)
	var wide: = font.get_string_size(_words, HORIZONTAL_ALIGNMENT_LEFT, -1, int(big)).x
	big = minf(big, big * (size.x - 60.0) / maxf(wide, 1.0))
	var ink: = Color(0.35, 0.22, 0.05) if _final else gold
	_screen.draw_string_outline(font, Vector2(0, y), _words, HORIZONTAL_ALIGNMENT_CENTER, size.x, int(big), 12, Color(0, 0, 0, w * (0.3 if _final else 1.0)))
	_screen.draw_string(font, Vector2(0, y), _words, HORIZONTAL_ALIGNMENT_CENTER, size.x, int(big), Color(ink, w))
	if _sub != "":
		var s: = clampf((_t - fade_at - FADE - 0.45) / 0.4, 0.0, 1.0) * (1.0 - dark)
		var red: Color = Game.theme.ui["title"] if not _final else Color(0.45, 0.3, 0.1)
		_screen.draw_string(font, Vector2(0, y + 80.0), _sub, HORIZONTAL_ALIGNMENT_CENTER, size.x, 44, Color(red, s))
