class_name PauseScreen
extends Control










const BUTTON_SIZE: = 72.0
const BUTTON_POS: = Vector2(20, 144)

var _player: Player
var _button: Button
var _menu: Control
var _quit: Button
var _exit_row: HBoxContainer
var _end: Button
var _quit_armed: = false
var _box: VBoxContainer
var _build: VBoxContainer
const SLOT_WIDTH: = 96.0
const SLOT_WIDTH_TIGHT: = 84.0
const INFO_WIDTH: = 540.0
const INFO_LINES: = 4
const INFO_LINE_HEIGHT: = 29.0

var _sheet: Control
var _sheet_list: VBoxContainer
var _sheet_scroll: ScrollContainer
const POOL_TITLES: = {"damage": ["DAMAGE", Color(1, 0.45, 0.25)], "defense": ["DEFENSE", Color(0.45, 0.75, 1)], 
	"utility": ["UTILITY", Color(0.55, 1, 0.5)], "": ["RISK", Color(0.85, 0.4, 0.95)]}

func _ready() -> void :
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_player = get_tree().get_first_node_in_group("player") as Player
	_build_button()
	_build_menu()

func _notification(what: int) -> void :
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		open()
	elif what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_back()

func _unhandled_input(event: InputEvent) -> void :
	if event.is_action_pressed("ui_cancel"):
		_back()
		get_viewport().set_input_as_handled()


func _back() -> void :
	if _sheet.visible:
		_close_sheet()
	elif _menu.visible:
		_resume()
	else:
		open()

func open() -> void :
	if _menu == null or _menu.visible or get_tree().paused:
		return
	if is_instance_valid(_player) and _player.outro:
		return
	_show_exit(false)
	_sheet.hide()
	_fill_build()
	_menu.show()
	get_tree().paused = true
	_box.scale = Vector2.ONE
	get_tree().process_frame.connect(_fit_box, CONNECT_ONE_SHOT)


func _fit_box() -> void :
	var view: = get_viewport_rect().size
	var room: = view.y - Game.safe_top() - 48.0
	var h: = _box.get_combined_minimum_size().y
	var k: = minf(1.0, room / maxf(h, 1.0))
	_box.size = Vector2(_box.size.x, h)
	_box.position.y = Game.safe_top() + 24.0 + (room - h * k) / 2.0
	_box.pivot_offset = Vector2(_box.size.x / 2.0, 0.0)
	_box.scale = Vector2.ONE * k

func _resume() -> void :
	_menu.hide()
	Game.save_profile()
	LevelUpScreen.resume_if_clear(get_tree(), true, true)



func _build_button() -> void :
	_button = Button.new()
	_button.position = BUTTON_POS + Vector2(0, Game.safe_top())
	_button.size = Vector2(BUTTON_SIZE, BUTTON_SIZE)
	_button.focus_mode = Control.FOCUS_NONE
	_button.add_to_group("joystick_block")
	for state: String in ["normal", "hover", "pressed"]:
		var style: = StyleBoxFlat.new()
		style.bg_color = Color(0, 0, 0, 0.35 if state != "pressed" else 0.6)
		style.border_color = Color(1, 1, 1, 0.5)
		style.set_border_width_all(2)
		style.set_corner_radius_all(10)
		_button.add_theme_stylebox_override(state, style)
	_button.draw.connect( func() -> void :
		var bar: = Vector2(BUTTON_SIZE * 0.14, BUTTON_SIZE * 0.42)
		var top: = (BUTTON_SIZE - bar.y) / 2.0
		_button.draw_rect(Rect2(Vector2(BUTTON_SIZE * 0.31, top), bar), Color.WHITE)
		_button.draw_rect(Rect2(Vector2(BUTTON_SIZE * 0.55, top), bar), Color.WHITE))
	_button.pressed.connect( func() -> void :
		Game.sfx("click")
		open())
	add_child(_button)



func _build_menu() -> void :
	var t: = Game.theme
	_menu = Control.new()
	_menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_menu.add_to_group("pause_screen")
	_menu.hide()
	add_child(_menu)
	var dim: = ColorRect.new()
	dim.color = Color(0, 0, 0, 0.65)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_menu.add_child(dim)

	var box: = VBoxContainer.new()
	_box = box
	box.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	box.custom_minimum_size = Vector2(520, 0)
	box.grow_horizontal = Control.GROW_DIRECTION_BOTH
	box.grow_vertical = Control.GROW_DIRECTION_BOTH
	box.add_theme_constant_override("separation", 20)
	_menu.add_child(box)

	var title: = Label.new()
	title.text = "PAUSED"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 64)
	title.add_theme_color_override("font_color", t.ui["accent"])
	title.add_theme_color_override("font_outline_color", Color.BLACK)
	title.add_theme_constant_override("outline_size", 12)
	box.add_child(title)
	_build = VBoxContainer.new()
	_build.add_theme_constant_override("separation", 10)
	box.add_child(_build)
	box.add_child(_menu_button("Resume", t.ui["accent"], _resume))
	box.add_child(_menu_button("Cheat Sheet", t.ui["xp"], _open_sheet))
	build_settings(box, true)
	_quit = _menu_button("Exit to Menu", Color(1, 1, 1, 0.6), func() -> void : _show_exit(true))
	box.add_child(_quit)
	_exit_row = HBoxContainer.new()
	_exit_row.add_theme_constant_override("separation", 12)
	var save: = _menu_button("Save & Exit", t.ui["accent"], _on_save_exit)
	_end = _menu_button("End Run", Color(1, 0.3, 0.25, 0.8), _on_quit)
	for b: Button in [save, _end]:
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.size_flags_stretch_ratio = 1.0
		b.add_theme_font_size_override("font_size", 30)
		b.clip_text = true
		_exit_row.add_child(b)
	_exit_row.hide()
	box.add_child(_exit_row)
	if Ads.privacy_options_required():
		box.add_child(_menu_button("Ad Privacy Settings", Color(1, 1, 1, 0.4), func() -> void : Ads.show_privacy_options()))
	_build_sheet()




static func build_settings(box: Control, _in_run: bool) -> void :
	box.add_child(_slider("Music", Game.music_volume, Game.set_music_volume))
	box.add_child(_slider("Sounds", Game.sfx_volume, func(v: float) -> void :
		Game.set_sfx_volume(v)
		Game.sfx("click")))
	box.add_child(_numbers_button())
	box.add_child(_goal_arrows_button())



static func _goal_arrows_button() -> Button:
	var b: = _menu_button("", Color(1, 1, 1, 0.6), func() -> void : pass)
	b.add_theme_font_size_override("font_size", 28)
	b.custom_minimum_size = Vector2(0, 72)
	var paint: = func() -> void :
		b.text = "Rescue & treasure arrows: %s" % ("Shown" if Game.goal_arrows else "Hidden")
	paint.call()
	b.pressed.connect( func() -> void :
		Game.goal_arrows = not Game.goal_arrows
		paint.call()
		Game.save_profile())
	return b


const NUMBER_MODES: = ["Off", "Big hits only", "All"]
static func _numbers_button() -> Button:
	var b: = _menu_button("", Color(1, 1, 1, 0.6), func() -> void : pass)
	b.add_theme_font_size_override("font_size", 28)
	b.custom_minimum_size = Vector2(0, 72)
	b.text = "Damage numbers: %s" % NUMBER_MODES[Game.damage_numbers]
	b.pressed.connect( func() -> void :
		Game.damage_numbers = (Game.damage_numbers + 2) % 3
		b.text = "Damage numbers: %s" % NUMBER_MODES[Game.damage_numbers]
		Game.save_profile())
	return b






func _fill_build() -> void :
	for c in _build.get_children():
		c.queue_free()
	var accent: Color = Game.theme.ui["accent"]
	var weapons: = HBoxContainer.new()
	weapons.alignment = BoxContainer.ALIGNMENT_CENTER
	weapons.add_theme_constant_override("separation", 8)
	_build.add_child(weapons)
	var held: = 0
	for c in _player.get_children():
		if c is Weapon:
			var w: = c as Weapon
			var info: = Weapon.theme_info(w.get_script())
			var done: = w.holy
			var fill: = accent
			if w.holy:
				fill = info.get("holy_color", Game.theme.ui.get("holy", Color(1, 0.93, 0.55)))
			weapons.add_child(_build_slot(w.icon(), w.level, Weapon.max_level(w.get_script()), fill, done))
			held += 1
	for i in maxi(Game.MAX_WEAPONS - held, 0):
		weapons.add_child(_build_slot("", 0, 0, accent))
	_fit_build_row(weapons)
	var passives: = HBoxContainer.new()
	passives.alignment = BoxContainer.ALIGNMENT_CENTER
	passives.add_theme_constant_override("separation", 8)
	_build.add_child(passives)
	var xp_color: Color = Game.theme.ui["xp"]
	for id: String in _player.passives:
		passives.add_child(_build_slot(str(Game.theme.passive(id).get("icon", "")), _player.passives[id], Game.PASSIVES[id]["max"], xp_color))
	for i in maxi(Game.MAX_PASSIVES - _player.passives.size(), 0):
		passives.add_child(_build_slot("", 0, 0, xp_color))
	_fit_build_row(passives)
	if _player.pact != "":
		_build.add_child(_deal_panel())


func _deal_panel() -> Control:
	var t: = Game.theme
	var panel: = PanelContainer.new()
	var style: = _panel_style(Color(t.ui["hp"], 0.7))
	style.set_content_margin_all(10)
	style.bg_color = Color(0.12, 0.02, 0.03, 0.85)
	panel.add_theme_stylebox_override("panel", style)
	var col: = VBoxContainer.new()
	col.add_theme_constant_override("separation", 2)
	panel.add_child(col)
	var lines: = [["DEVIL'S DEAL: " + str(t.pact(_player.pact).get("name", "")).to_upper(), 24, t.ui["accent"]], 
		["Boon: " + Game.pact_text(_player.pact), 22, t.ui["xp"]]]
	if _player.pact_price != "":
		lines.append(["Price: " + Game.pact_text(_player.pact_price), 22, t.ui["hp"]])
	else:
		lines.append(["The price was voided", 22, Color(1, 1, 1, 0.6)])
	for l: Array in lines:
		var label: = Label.new()
		label.text = l[0]
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		label.add_theme_font_size_override("font_size", l[1])
		label.add_theme_color_override("font_color", l[2])
		col.add_child(label)
	return panel


func _fit_build_row(row: HBoxContainer) -> void :
	if row.get_child_count() <= Game.MAX_WEAPONS:
		return
	for c in row.get_children():
		(c as Control).custom_minimum_size.x = SLOT_WIDTH_TIGHT


func _build_slot(icon: String, level: int, top: int, fill: Color, done: = false) -> Control:
	var col: = VBoxContainer.new()
	col.custom_minimum_size = Vector2(SLOT_WIDTH, 0)
	col.add_theme_constant_override("separation", 6)
	var frame: = PanelContainer.new()
	var maxed: = icon != "" and (done or level >= top)
	var style: = _panel_style(Color(fill, 0.9) if maxed else Color(1, 1, 1, 0.25 if icon != "" else 0.1))
	style.set_content_margin_all(6)
	style.bg_color = Color(fill.darkened(0.7), 0.6) if maxed else Color(0, 0, 0, 0.4)
	frame.add_theme_stylebox_override("panel", style)
	frame.custom_minimum_size = Vector2(76, 76)
	frame.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	col.add_child(frame)
	if icon != "":
		var tex: = _fusion_icon(icon, Color.WHITE)
		tex.custom_minimum_size = Vector2(62, 62)
		frame.add_child(tex)
		var pips: = LevelPips.new().setup(level, top, fill, done, false, SLOT_WIDTH_TIGHT - 4.0)
		pips.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		col.add_child(pips)
	else:
		var spacer: = Control.new()
		spacer.custom_minimum_size = Vector2(0, LevelPips.PIP + 2.0)
		col.add_child(spacer)
	return col



func _build_sheet() -> void :
	_sheet = Control.new()
	_sheet.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_sheet.mouse_filter = Control.MOUSE_FILTER_STOP
	_sheet.hide()
	_menu.add_child(_sheet)
	var bg: = ColorRect.new()
	bg.color = Color(0.03, 0.01, 0.02)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_sheet.add_child(bg)
	var col: = VBoxContainer.new()
	col.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	col.offset_left = 24
	col.offset_right = -24
	col.offset_top = 24 + Game.safe_top()
	col.offset_bottom = -24
	col.add_theme_constant_override("separation", 14)
	_sheet.add_child(col)
	var title: = Label.new()
	title.text = "CHEAT SHEET"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 48)
	title.add_theme_color_override("font_color", Game.theme.ui["accent"])
	title.add_theme_color_override("font_outline_color", Color.BLACK)
	title.add_theme_constant_override("outline_size", 10)
	col.add_child(title)
	_sheet_scroll = ScrollContainer.new()
	_sheet_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_sheet_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_sheet_scroll.mouse_filter = Control.MOUSE_FILTER_PASS
	col.add_child(_sheet_scroll)
	_sheet_list = VBoxContainer.new()
	_sheet_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_sheet_list.add_theme_constant_override("separation", 10)
	_sheet_list.mouse_filter = Control.MOUSE_FILTER_PASS
	_sheet_scroll.add_child(_sheet_list)
	col.add_child(_menu_button("Back", Game.theme.ui["accent"], _close_sheet))

func _open_sheet() -> void :
	for c in _sheet_list.get_children():
		c.queue_free()
	_sheet_list.add_child(_fusion_panel())
	for pool: String in Game.POOLS + [""]:
		_sheet_list.add_child(_section_title(pool))
		for id: String in Game.WEAPONS:
			if Game.pool_of(id) == pool:
				_sheet_list.add_child(_item_row(id, true))
		for id: String in Game.PASSIVES:
			if Game.pool_of(id) == pool:
				_sheet_list.add_child(_item_row(id, false))
	_sheet_scroll.scroll_vertical = 0
	_sheet.show()

func _close_sheet() -> void :
	_sheet.hide()

func _section_title(pool: String) -> Control:
	var l: = Label.new()
	l.text = POOL_TITLES[pool][0]
	l.add_theme_font_size_override("font_size", 34)
	l.add_theme_color_override("font_color", POOL_TITLES[pool][1])
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 8)
	l.mouse_filter = Control.MOUSE_FILTER_PASS
	var box: = MarginContainer.new()
	box.add_theme_constant_override("margin_top", 14)
	box.mouse_filter = Control.MOUSE_FILTER_PASS
	box.add_child(l)
	return box



func _item_row(id: String, weapon: bool) -> Control:
	var info: = Game.item_info(id)
	var level: = 0
	var top: = 0
	var owned: Weapon = null
	if weapon:
		top = Weapon.max_level(Game.WEAPONS[id])
		for c in _player.get_children():
			if c is Weapon and c.get_script() == Game.WEAPONS[id]:
				owned = c as Weapon
				level = owned.level
	else:
		top = Game.PASSIVES[id]["max"]
		level = _player.passives.get(id, 0)
	var unlocked: = level > 0 or Game.is_item_unlocked(id)
	var panel: = PanelContainer.new()
	var style: = _panel_style(Color(POOL_TITLES[Game.pool_of(id)][1], 0.8) if level > 0 else Color(1, 1, 1, 0.12))
	style.set_content_margin_all(10)
	style.set_border_width_all(2 if level > 0 else 1)
	panel.add_theme_stylebox_override("panel", style)
	panel.mouse_filter = Control.MOUSE_FILTER_PASS
	var row: = HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	row.mouse_filter = Control.MOUSE_FILTER_PASS
	panel.add_child(row)


	var form_name: = str(info.get("name", id))
	var form_text: = str(info.get("description", ""))
	var form_color: = Color.WHITE
	var done: = false
	if owned and owned.holy:
		form_name = str(info.get("holy_name", form_name)) + "  (HOLY)"
		form_text = Weapon.holy_text(Game.WEAPONS[id])
		form_color = info.get("holy_color", Color(1, 0.95, 0.6))
		done = true
	var icon: = _fusion_icon(owned.icon() if owned else str(info.get("icon", "")), Color.WHITE)
	icon.custom_minimum_size = Vector2(56, 56)
	icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	icon.mouse_filter = Control.MOUSE_FILTER_PASS
	if not unlocked:
		icon.modulate = Color(0.2, 0.2, 0.2, 0.8)
	row.add_child(icon)
	var texts: = VBoxContainer.new()
	texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	texts.mouse_filter = Control.MOUSE_FILTER_PASS
	row.add_child(texts)
	var head: = HBoxContainer.new()
	head.mouse_filter = Control.MOUSE_FILTER_PASS
	texts.add_child(head)
	var name_label: = Label.new()
	name_label.text = form_name if unlocked else "???"
	if _player.exiled.has(id):
		name_label.text += "  (EXILED)"
		name_label.modulate = Color(1, 0.6, 0.55)
	if done:
		name_label.add_theme_color_override("font_color", form_color)
	name_label.add_theme_font_size_override("font_size", 26)
	name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(name_label)
	if level > 0:
		var pips: = LevelPips.new().setup(level, top, form_color if done else (Game.theme.ui["accent"] if weapon else Game.theme.ui["xp"]), done, false, 200.0)
		pips.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		head.add_child(pips)
	var desc: = Label.new()
	if not unlocked:
		desc.text = "Unlock: " + Game.unlock_text(id)
	elif weapon:
		desc.text = form_text
	else:
		desc.text = _passive_blurb(id)
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc.add_theme_font_size_override("font_size", 20)
	desc.add_theme_color_override("font_color", Color(1, 1, 1, 0.7))
	texts.add_child(desc)
	for l: Label in [name_label, desc]:
		l.mouse_filter = Control.MOUSE_FILTER_PASS
	return panel






func _fusion_panel() -> Control:
	var is_known: = func(id: String) -> bool: return Game.dev_mode or Game.progress.is_fusion_known(id)
	var found: int = Game.EVOLUTIONS.keys().filter(is_known).size()
	var panel: = PanelContainer.new()
	var style: = _panel_style(Color(1, 1, 1, 0.15))
	style.bg_color = Color(0.05, 0.02, 0.02, 0.92)
	style.set_content_margin_all(14)
	panel.add_theme_stylebox_override("panel", style)
	panel.mouse_filter = Control.MOUSE_FILTER_PASS
	var col: = VBoxContainer.new()
	col.mouse_filter = Control.MOUSE_FILTER_PASS
	col.add_theme_constant_override("separation", 10)
	panel.add_child(col)
	var label: = Label.new()
	label.text = "HOLY RECIPES FOUND  %d / %d" % [found, Game.EVOLUTIONS.size()]
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", 24)
	label.add_theme_color_override("font_color", Color(1, 1, 1, 0.6))
	col.add_child(label)
	var grid: = GridContainer.new()
	grid.columns = 3
	grid.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	grid.add_theme_constant_override("h_separation", 22)
	grid.add_theme_constant_override("v_separation", 12)
	grid.mouse_filter = Control.MOUSE_FILTER_PASS
	col.add_child(grid)
	var info_name: = Label.new()
	var info_text: = Label.new()
	var show_info: = func(title: String, text: String, color: Color) -> void :
		Game.sfx("click")
		info_name.text = title
		info_name.add_theme_color_override("font_color", color)
		info_text.text = text
	var secret: = show_info.bind("???", "Not found yet. Max a weapon, hold the passive that belongs with it, and open a chest.", Color(1, 1, 1, 0.6))
	for id: String in Game.EVOLUTIONS:
		var row: = HBoxContainer.new()
		row.add_theme_constant_override("separation", 3)
		row.mouse_filter = Control.MOUSE_FILTER_PASS
		grid.add_child(row)
		if not is_known.call(id):
			row.add_child(_tappable(_mystery(false), secret))
			row.add_child(_fusion_sign("+"))
			row.add_child(_tappable(_mystery(false), secret))
			row.add_child(_fusion_sign("="))
			row.add_child(_tappable(_mystery(true), secret))
			continue
		var w: = Game.theme.weapon(id)
		var pid: String = Game.EVOLUTIONS[id]
		row.add_child(_tappable(_fusion_icon(w.get("icon", ""), Color.WHITE), show_info.bind(w.get("name", ""), w.get("description", ""), Color.WHITE)))
		row.add_child(_fusion_sign("+"))
		row.add_child(_tappable(_fusion_icon(Game.theme.passive(pid).get("icon", ""), Color.WHITE), 
			show_info.bind(Game.theme.passive(pid).get("name", ""), _passive_blurb(pid), Game.theme.ui["xp"])))
		row.add_child(_fusion_sign("="))
		var fused: = _fusion_icon(w.get("holy_icon", w.get("icon", "")), Color.WHITE)
		var fused_text: = "%s + %s: %s" % [w.get("name", ""), Game.theme.passive(pid).get("name", ""), w.get("holy_text", "")]
		_tappable(fused, show_info.bind(w.get("holy_name", ""), fused_text, w.get("holy_color", Color.WHITE)))
		fused.custom_minimum_size = Vector2(52, 44)
		var glow: Color = w.get("holy_color", Color.WHITE)
		fused.draw.connect( func() -> void :
			var r: = fused.size.y * 0.55
			fused.draw_circle(fused.size / 2.0, r, Color(glow, 0.3))
			fused.draw_arc(fused.size / 2.0, r, 0.0, TAU, 24, Color(glow, 0.9), 2.0))
		row.add_child(fused)



	var info: = Control.new()
	info.custom_minimum_size = Vector2(INFO_WIDTH, 34 + INFO_LINES * INFO_LINE_HEIGHT)
	info.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_child(info)
	info_name.text = "Tap an icon to read about it"
	info_name.add_theme_color_override("font_color", Color(1, 1, 1, 0.45))
	info_name.add_theme_font_size_override("font_size", 26)
	info_name.position = Vector2.ZERO
	info_name.size = Vector2(INFO_WIDTH, 34)
	info_name.clip_text = true
	info_text.add_theme_font_size_override("font_size", 21)
	info_text.add_theme_color_override("font_color", Color(1, 1, 1, 0.8))
	info_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info_text.position = Vector2(0, 34)
	info_text.size = Vector2(INFO_WIDTH, INFO_LINES * INFO_LINE_HEIGHT)
	info_text.clip_text = true
	for l: Label in [info_name, info_text]:
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		l.vertical_alignment = VERTICAL_ALIGNMENT_TOP
		l.mouse_filter = Control.MOUSE_FILTER_IGNORE
		info.add_child(l)
	return panel


func _mystery(fused: bool) -> Control:
	var box: = Control.new()
	box.mouse_filter = Control.MOUSE_FILTER_PASS
	box.custom_minimum_size = Vector2(52, 44) if fused else Vector2(40, 40)
	box.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	box.draw.connect( func() -> void :
		var c: = box.size / 2.0
		if fused:
			var r: = box.size.y * 0.55
			box.draw_circle(c, r, Color(1, 1, 1, 0.08))
			box.draw_arc(c, r, 0.0, TAU, 24, Color(1, 1, 1, 0.3), 2.0)
		else:
			box.draw_rect(Rect2(c - Vector2(17, 17), Vector2(34, 34)), Color(1, 1, 1, 0.07))
			box.draw_rect(Rect2(c - Vector2(17, 17), Vector2(34, 34)), Color(1, 1, 1, 0.25), false, 2.0)
		var font: = ThemeDB.fallback_font
		box.draw_string(font, Vector2(0, c.y + 10), "?", HORIZONTAL_ALIGNMENT_CENTER, box.size.x, 28, Color(1, 1, 1, 0.55)))
	return box



func _tappable(icon: Control, on_tap: Callable) -> Control:
	icon.mouse_filter = Control.MOUSE_FILTER_PASS
	var down: = [Vector2.INF]
	icon.gui_input.connect( func(event: InputEvent) -> void :
		if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
			if event.pressed:
				down[0] = event.global_position
			elif down[0] != Vector2.INF and event.global_position.distance_to(down[0]) < 20.0:
				on_tap.call())
	return icon


func _passive_blurb(id: String) -> String:
	var p: Dictionary = Game.PASSIVES[id]
	if p.has("texts"):
		return p["texts"].back()
	var text: String = (p["fmt"] %Game._passive_value(p, p["max"])) + " at max level"
	var about: = Game.passive_about(id)
	return text + (". " + about if about != "" else "")

func _fusion_icon(sprite: String, tint: Color) -> TextureRect:
	var icon: = TextureRect.new()
	icon.texture = Game.theme.texture(sprite)
	icon.custom_minimum_size = Vector2(40, 40)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	icon.modulate = tint.lightened(0.2) if tint != Color.WHITE else tint
	return icon

func _fusion_sign(text: String) -> Label:
	var l: = Label.new()
	l.mouse_filter = Control.MOUSE_FILTER_PASS
	l.text = text
	l.add_theme_font_size_override("font_size", 22)
	l.add_theme_color_override("font_color", Color(1, 1, 1, 0.7))
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	return l

func _show_exit(on: bool) -> void :
	_set_quit_armed(false)
	_quit.visible = not on
	_exit_row.visible = on


func _on_save_exit() -> void :
	if is_instance_valid(_player) and not _player.is_dead() and not Game.dev_mode:
		RunSave.write(_player)
	get_tree().change_scene_to_file("res://menu.tscn")

func _on_quit() -> void :
	if not _quit_armed:
		_set_quit_armed(true)
		return
	if is_instance_valid(_player):
		_player.end_run()
	else:
		get_tree().change_scene_to_file("res://menu.tscn")

func _set_quit_armed(armed: bool) -> void :
	_quit_armed = armed
	_end.text = "Tap again" if armed else "End Run"

static func _menu_button(text: String, border: Color, action: Callable) -> Button:
	var b: = Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 96)
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", 34)
	for state: String in ["normal", "hover", "pressed"]:
		var style: = _panel_style(border)
		if state == "pressed":
			style.bg_color = style.bg_color.lightened(0.15)
		b.add_theme_stylebox_override(state, style)
	b.pressed.connect( func() -> void :
		Game.sfx("click")
		action.call())
	return b


static func _slider(label_text: String, value: float, on_change: Callable) -> Control:
	var panel: = PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _panel_style(Color(1, 1, 1, 0.25)))
	var col: = VBoxContainer.new()
	col.add_theme_constant_override("separation", 6)
	panel.add_child(col)
	var row: = HBoxContainer.new()
	col.add_child(row)
	var label: = Label.new()
	label.text = label_text
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.add_theme_font_size_override("font_size", 30)
	row.add_child(label)
	var percent: = Label.new()
	percent.add_theme_font_size_override("font_size", 30)
	percent.add_theme_color_override("font_color", Game.theme.ui["accent"])
	row.add_child(percent)

	var slider: = HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.05
	slider.value = value
	slider.focus_mode = Control.FOCUS_NONE
	slider.custom_minimum_size = Vector2(0, 56)
	var track: = StyleBoxFlat.new()
	track.bg_color = Color(0, 0, 0, 0.5)
	track.set_corner_radius_all(6)
	track.content_margin_top = 6
	track.content_margin_bottom = 6
	var fill: = track.duplicate() as StyleBoxFlat
	fill.bg_color = Game.theme.ui["accent"]
	slider.add_theme_stylebox_override("slider", track)
	slider.add_theme_stylebox_override("grabber_area", fill)
	slider.add_theme_stylebox_override("grabber_area_highlight", fill)
	var knob: = _knob_texture(40)
	slider.add_theme_icon_override("grabber", knob)
	slider.add_theme_icon_override("grabber_highlight", knob)
	col.add_child(slider)

	percent.text = "%d%%" % roundi(value * 100)
	slider.value_changed.connect( func(v: float) -> void :
		percent.text = "%d%%" % roundi(v * 100)
		on_change.call(v))
	slider.drag_ended.connect( func(_changed: bool) -> void : Game.save_profile())
	return panel

static func _panel_style(border: Color) -> StyleBoxFlat:
	var style: = StyleBoxFlat.new()
	style.bg_color = Game.theme.ui["panel"]
	style.border_color = border
	style.set_border_width_all(3)
	style.set_corner_radius_all(12)
	style.set_content_margin_all(16)
	return style


static func _knob_texture(d: int) -> ImageTexture:
	var img: = Image.create_empty(d, d, false, Image.FORMAT_RGBA8)
	var c: = Vector2(d, d) / 2.0
	for y in d:
		for x in d:
			var r: = Vector2(x + 0.5, y + 0.5).distance_to(c)
			if r <= d / 2.0:
				img.set_pixel(x, y, Color.WHITE if r < d / 2.0 - 3.0 else Color(0, 0, 0, 0.8))
	return ImageTexture.create_from_image(img)
