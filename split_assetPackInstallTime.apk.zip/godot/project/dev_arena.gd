class_name DevArena
extends Node2D












const XP_COUNT: = 60
const XP_SPACING: = 34.0
const SHOWCASE_HP: = 3000.0
const PERF_TIME: = 25.0
const PERF_RAMP: = 8.0

var _player: Player
var _spawner: Node
var _items: Array[Node] = []
var _perf_on: = false
var _perf_t: = 0.0
var _perf_frames: Array[float] = []
var _perf_draws: = 0.0
var _perf_peak_enemies: = 0
var _perf_peak_nodes: = 0
var _perf_events: = {}
var _perf_label: Label
const SHOWCASE_COLUMNS: = 8

func _ready() -> void :
	if not Game.dev_mode:
		queue_free()
		return
	_player = get_tree().get_first_node_in_group("player") as Player
	_spawner = get_parent().get_node("Spawner")
	_player.rerolls = 99
	for c in _player.get_children():
		if c is Weapon:
			while not c.is_maxed():
				c.level_up()
	_lay_out_items.call_deferred(_player.global_position)
	_lay_out_showcase.call_deferred(_player.global_position)
	_build_panel()

func _process(delta: float) -> void :
	if not _perf_on:
		return
	_perf_t += delta
	_perf_frames.append(delta * 1000.0)
	_perf_draws += Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)

	if _player.joystick:
		_player.joystick.direction = Vector2.from_angle(_perf_t * 0.7)
	for chest in get_tree().get_nodes_in_group(OffscreenPointer.GROUP):
		chest.queue_free()
	var enemies: = get_tree().get_nodes_in_group("enemies").size()
	var nodes: = int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT))
	_perf_peak_enemies = maxi(_perf_peak_enemies, enemies)
	_perf_peak_nodes = maxi(_perf_peak_nodes, nodes)

	var want: = int(lerpf(20.0, float(_spawner.max_enemies), clampf(_perf_t / PERF_RAMP, 0.0, 1.0)))
	for i in 6:
		if enemies < want:
			_spawner.spawn(_player.survived + 300.0)
			enemies += 1
	for at: float in [4.0, 12.0, 18.0]:
		if _perf_t >= at and not _perf_events.has(at):
			_perf_events[at] = true
			_spawner._warn_swarm(Game.theme.swarms.pick_random())
	if _perf_t >= 8.0 and not _perf_events.has("boss"):
		_perf_events["boss"] = true
		_spawner.start_boss_now()
	_perf_label.text = """PERF TEST  %d/%ds
FPS %d   enemies %d
nodes %d   draws %d""" %[_perf_t, PERF_TIME, 
		Engine.get_frames_per_second(), enemies, nodes, Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)]
	if _perf_t >= PERF_TIME:
		_finish_perf()



func _start_perf() -> void :
	if _perf_on:
		return
	for id: String in Game.WEAPONS:
		var script: Script = Game.WEAPONS[id]
		var have: = _player.get_children().filter( func(c: Node) -> bool: return c is Weapon)
		if have.size() >= Game.MAX_WEAPONS:
			break
		if not have.any( func(w: Node) -> bool: return w.get_script() == script):
			_player.add_child(script.new())
	for c in _player.get_children():
		if c is Weapon:
			while not c.is_maxed():
				c.level_up()
	_player.growth = 0.0
	_perf_frames.clear()
	_perf_draws = 0.0
	_perf_peak_enemies = 0
	_perf_peak_nodes = 0
	_perf_events.clear()
	_perf_t = 0.0
	if _perf_label == null:
		_perf_label = Label.new()
		_perf_label.position = Vector2(20, 1090)
		_perf_label.add_theme_font_size_override("font_size", 26)
		_perf_label.add_theme_color_override("font_outline_color", Color.BLACK)
		_perf_label.add_theme_constant_override("outline_size", 8)
		_perf_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		get_parent().get_node("UI").add_child(_perf_label)
	_perf_label.add_theme_color_override("font_color", Color(1, 1, 0.5))
	_perf_on = true

func _finish_perf() -> void :
	_perf_on = false
	_player.recalc_stats()
	var n: = _perf_frames.size()
	if n == 0:
		return
	var sorted: = _perf_frames.duplicate()
	sorted.sort()
	var total: = 0.0
	for f: float in _perf_frames:
		total += f
	var avg_ms: = total / n
	var worst_ms: float = sorted[n - 1]
	var low1_ms: float = sorted[mini(n - 1, int(n * 0.99))]
	var avg_fps: = 1000.0 / avg_ms
	var low1_fps: = 1000.0 / low1_ms
	var verdict: = "SMOOTH (60 fps holds)"
	var color: = Color(0.5, 1, 0.5)
	if low1_fps < 30.0 or avg_fps < 40.0:
		verdict = "TOO SLOW: needs optimizing"
		color = Color(1, 0.4, 0.3)
	elif low1_fps < 50.0 or avg_fps < 55.0:
		verdict = "PLAYABLE, but dips"
		color = Color(1, 0.85, 0.3)
	var report: = """PERF RESULT: %s
avg %.0f fps (%.1f ms)   1%% low %.0f fps
worst frame %.0f ms   frames %d
peak enemies %d   peak nodes %d   avg draws %d""" %[
		verdict, avg_fps, avg_ms, low1_fps, worst_ms, n, _perf_peak_enemies, _perf_peak_nodes, int(_perf_draws / n)]
	_perf_label.text = report
	_perf_label.add_theme_color_override("font_color", color)
	print(report)



func _lay_out_items(origin: Vector2) -> void :
	for n in _items:
		if is_instance_valid(n):
			n.queue_free()
	_items.clear()
	var scene: = get_parent()

	for i in XP_COUNT:
		var gem: = XPGem.new()
		gem.value = 1 + i / 10
		gem.mergeable = false
		gem.position = origin + Vector2(160 + i * XP_SPACING, 130)
		scene.add_child(gem)
		_items.append(gem)
	for t in XPGem.TIERS.size():
		var big: = XPGem.new()
		big.value = XPGem.TIERS[t]
		big.position = origin + Vector2(160 + XP_COUNT * XP_SPACING + 40 + t * 50, 130)
		scene.add_child(big)
		_items.append(big)
	_items.append(_label(origin + Vector2(100, 80), "XP  >>>"))

	var tiers: = [1, 2, 3, 0]
	for i in tiers.size():
		var pos: = origin + Vector2(-255 + i * 170, 260)
		var chest: = Pickup.spawn(scene, Pickup.Kind.BLESSING, pos)
		chest.tier = tiers[i]
		chest.blessed = true
		_items.append(chest)
		_items.append(_label(pos + Vector2(-60, 40), "%d upgrade%s" % [tiers[i], "s" if tiers[i] > 1 else ""] if tiers[i] > 0 else "random"))

	if not Game.theme.bosses.is_empty():
		var tpos: = origin + Vector2(-255 + tiers.size() * 170, 260)
		var head: = Pickup.spawn(scene, Pickup.Kind.BLESSING, tpos)
		head.blessed = true
		head.trophy = Game.theme.enemies.get(str(Game.theme.bosses[0].get("boss", "")), {})
		_items.append(head)
		_items.append(_label(tpos + Vector2(-60, 40), "boss trophy"))

	for i in 6:
		_items.append(Pickup.spawn(scene, Pickup.Kind.COIN, origin + Vector2(-300 + i * 40, -300)))
	for i in 3:
		_items.append(Pickup.spawn(scene, Pickup.Kind.HEART, origin + Vector2(80 + i * 60, -300)))

	_items.append(Pickup.spawn(scene, Pickup.Kind.VACUUM, origin + Vector2(-200, -400)))
	_items.append(_label(origin + Vector2(-260, -370), "vacuum"))
	_items.append(Pickup.spawn(scene, Pickup.Kind.PURGE, origin + Vector2(200, -400)))
	_items.append(_label(origin + Vector2(140, -370), "rosary"))

func _lay_out_showcase(origin: Vector2) -> void :
	var regular: Array = []
	var bosses: Array = []
	for id: String in Game.theme.enemies:
		var data: Dictionary = Game.theme.enemies[id]
		(bosses if data.get("boss", false) else regular).append(data)

	var rows: = ceili(regular.size() / float(SHOWCASE_COLUMNS))
	for r in rows:
		_row(regular.slice(r * SHOWCASE_COLUMNS, (r + 1) * SHOWCASE_COLUMNS), origin + Vector2(0, -620 - r * 170), 150.0)
	_row(bosses, origin + Vector2(0, -620 - (rows - 1) * 170 - 380), 360.0)

	var props: Array = Game.theme.props
	for i in props.size() * 2:
		var prop: = Breakable.new()
		prop.configure(props[i % props.size()])
		prop.position = origin + Vector2( - (props.size() * 2 - 1) * 60 + i * 120, 480)
		_spawner.add_child(prop)

func _row(list: Array, center: Vector2, spacing: float) -> void :
	for i in list.size():
		var data: Dictionary = list[i]
		var e: = (load("res://enemy.tscn") as PackedScene).instantiate() as Enemy
		e.configure(data)
		e.behavior = "still"
		e.hits = 0.0
		e.targetable = false
		e.max_hp = SHOWCASE_HP if not data.get("boss", false) else SHOWCASE_HP * 5
		e.hp = e.max_hp
		e.position = center + Vector2((i - (list.size() - 1) / 2.0) * spacing, 0)
		_spawner.add_child(e)
		var label: = _label(e.position + Vector2(-70, e.radius + 14), data.get("name", "?"))
		label.size.x = 140

func _label(pos: Vector2, text: String) -> Label:
	var label: = Label.new()
	label.text = text
	label.position = pos
	label.size = Vector2(120, 30)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", 18)
	label.add_theme_color_override("font_outline_color", Color.BLACK)
	label.add_theme_constant_override("outline_size", 6)
	Layers.put(label, Layers.SKY)
	add_child(label)
	return label



func _build_panel() -> void :
	var panel: = VBoxContainer.new()
	panel.position = Vector2(580, 150)
	panel.size = Vector2(130, 0)
	panel.add_theme_constant_override("separation", 8)
	panel.add_to_group("joystick_block")
	var ui: = get_parent().get_node("UI")
	ui.add_child(panel)
	ui.move_child(panel, ui.get_node("HUD").get_index() + 1)
	var title: = Label.new()
	title.text = "DEV TEST"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 22)
	title.add_theme_color_override("font_color", Game.theme.ui["warning"])
	title.add_theme_color_override("font_outline_color", Color.BLACK)
	title.add_theme_constant_override("outline_size", 6)
	panel.add_child(title)
	_button(panel, "Level up", func() -> void :
		_player.add_xp(ceili((_player.xp_to_next - _player.xp) / _player.growth) + 1))
	_button(panel, "Wave", func() -> void :
		for i in 10:
			_spawner.spawn(_player.survived + 300.0))
	_button(panel, "Boss", func() -> void : _spawner.start_boss_now())
	_button(panel, "Swarm", func() -> void :
		if not Game.theme.swarms.is_empty():
			_spawner._warn_swarm(Game.theme.swarms.pick_random()))
	_button(panel, "Perf test", _start_perf)
	_button(panel, "Items", func() -> void : _lay_out_items(_player.global_position))
	_button(panel, "Restart", func() -> void : get_tree().reload_current_scene())
	_button(panel, "Menu", func() -> void : get_tree().change_scene_to_file("res://menu.tscn"))

func _button(panel: Control, text: String, action: Callable) -> void :
	var b: = Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(130, 56)
	b.add_theme_font_size_override("font_size", 22)
	b.modulate = Color(1, 1, 1, 0.85)
	b.pressed.connect( func() -> void :
		Game.sfx("click")
		action.call())
	panel.add_child(b)
