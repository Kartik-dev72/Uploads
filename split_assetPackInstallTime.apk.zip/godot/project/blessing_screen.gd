class_name BlessingScreen
extends Control

































const FIRST_CHESTS: = [1, 1, 2, 1, 1, 3]



const BIG_CHEST_LEVEL: = 2
const CHEST_PRIZES: = [0, 1, 3, 5]
const CHEST_SOULS: = [0.0, 12.0, 36.0, 60.0]

const LIST_LIFT: = 140.0
const ROW_STEP_FIVE: = 110.0
const ROW_HEIGHT_FIVE: = 100.0
const TREASURE: = [
	[0, [0, 0, 30], 1, ["evolution", "existing_any", "existing_any", "existing_any", "existing_any"]], 
	[3, [0, 5, 40], 1, ["existing_weapon", "existing_any", "existing_any", "existing_any", "existing_any"]], 
	[5, [1, 5, 100], 1, ["existing_weapon", "existing_any", "existing_any", "existing_any", "existing_any"]], 
	[7, [3, 10, 50], 2, ["existing_weapon", "existing_any", "existing_any", "existing_any", "existing_any"]], 
	[9, [3, 10, 50], 1, ["existing_weapon", "existing_any", "existing_any", "existing_weapon", "existing_weapon"]], 
	[10, [3, 10, 100], 1, ["evolution", "existing_any", "existing_any", "existing_weapon", "existing_weapon"]], 
	[12, [1, 5, 50], 1, ["evolution", "existing_any", "existing_any", "existing_any", "existing_any"]], 
	[14, [3, 10, 100], 1, ["evolution", "existing_any", "existing_any", "existing_any", "existing_any"]], 
	[16, [1, 5, 50], 1, ["evolution", "existing_any", "existing_any", "existing_any", "existing_any"]], 
	[18, [3, 10, 100], 1, ["evolution", "existing_any", "existing_any", "existing_any", "existing_any"]], 
]
const FALLBACK_COINS: = Vector2i(5, 20)
const SHAKE_TIME: = 0.9
const REVEAL_DELAY: = 0.35
const REVEAL_GAP: = 0.5
const CONTINUE_DELAY: = 0.5
const CHEST_CENTER: = Vector2(360, 420)
const CHEST_SCALE: = 10.0
const ASC_CHARGE: = 1.1
const ASC_TIME: = 4.2
const ASC_SKIP_AFTER: = 2.4
const ASC_CENTER: = Vector2(360, 520)
const ASC_SCALE: = 11.0

const RAYS: = [8, 14, 24]
const PARTICLES: = [30, 80, 160]
const FLASH: = [0.35, 0.7, 1.0]
const SHAKE: = [3.0, 6.0, 12.0]
const TROPHY_CHOICES: = 3
const TROPHY_LEVEL: = 3
const TROPHY_UPGRADES: = 3
const TILE_SIZE: = Vector2(98, 132)
const TILE_GAP: = 10
const DETAIL_ICON: = 144.0
const TROPHY_SCALE: = 14.0
const FLY_TIME: = 0.42
const LID_GRAVITY: = 2600.0
const ROW_STEP: = 128.0


const TROPHY_FALLBACK: = {"damage": 0.06, "defense": 15.0, "utility": 0.1, "souls": 10}

var _player: Player
var _level_up: LevelUpScreen
var _rewards: Array[Dictionary] = []
var _picked: Array = []
var _tier: = 1




var _fx: = 1
var _chest_souls: = 0
var _chest_souls_all: = 0
var _chest_prizes: = 0
var _chest_rows: = 0
var _escalating: = false
const ESCALATE_AT: = {1: 2, 3: 3}
const CHEST_GAP: = 0.85
var _list_top: = 640.0
var _row_step: = ROW_STEP
var _trophy_tex: Texture2D
var _choosing: = false
var _kind: = ""
var _upgrades_left: = 0
var _upgraded: Array[Dictionary] = []
var _pool_box: VBoxContainer
var _head_top: Texture2D
var _head_bottom: Texture2D
var _lid_pos: = Vector2.ZERO
var _lid_vel: = Vector2.ZERO
var _lid_rot: = 0.0
var _lid_spin: = 0.0
var _flyers: Array[Dictionary] = []


const SOUL_COUNTER: = Vector2(360, 282)
const SOUL_RISE: = 0.45
const SOUL_HOME: = 0.35
const SOUL_MAX_BITS: = 22
var _souls_bits: Array[Dictionary] = []
var _souls_shown: = 0.0
var _souls_total: = 0
var _souls_punch: = 0.0
var _souls_t: = -1.0
var _subtitle: Label
var _time: = 0.0
var _opened: = false
var _second_burst: = false
var _revealed: = 0
var _flash: = 0.0
var _flash_color: = Color.WHITE
var _shake: = Vector2.ZERO
var _oy: = 0.0
var _particles: Array[Dictionary] = []
var _holy_color: Color

var _ascending: = false
var _asc_t: = 0.0
var _asc_skip: = false
var _asc_burst: = false
var _asc_reward: Dictionary = {}
var _asc_sparks: Array[Dictionary] = []

var _title: Label
var _list: VBoxContainer
var _continue: Button
var _bonus: Button
var _bonus_used: = false

func _ready() -> void :
	hide()
	add_to_group("blessing_screen")
	add_to_group("pause_screen")
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_STOP
	set_anchors_preset(Control.PRESET_FULL_RECT)
	_player = get_tree().get_first_node_in_group("player") as Player
	_level_up = get_parent().get_node_or_null("LevelUpScreen") as LevelUpScreen
	_holy_color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
	_build_ui()


func open(force_tier: = 0, min_level: = 0) -> void :
	_trophy_tex = null
	_choosing = false
	_title.text = Game.theme.blessing_name
	_subtitle.hide()
	_pool_box.hide()
	_begin(force_tier, min_level)


func open_trophy(boss: Dictionary) -> void :
	_list_top = 640.0
	_row_step = ROW_STEP
	_list.add_theme_constant_override("separation", int(ROW_STEP - 112.0))
	_trophy_tex = Pickup.trophy_texture(boss)
	var img: = _trophy_tex.get_image()
	var f: = PixelArt.factor_of(_trophy_tex, img)
	var lo_h: = img.get_height() / f
	var cut: = clampi(roundi(lo_h * float(boss.get("head_split", 0.5))), 1, lo_h - 1) * f
	_head_top = ImageTexture.create_from_image(img.get_region(Rect2i(0, 0, img.get_width(), cut)))
	_head_bottom = ImageTexture.create_from_image(img.get_region(Rect2i(0, cut, img.get_width(), img.get_height() - cut)))
	if f > 1:
		_head_top.set_size_override(Vector2i(img.get_width(), cut) / f)
		_head_bottom.set_size_override(Vector2i(img.get_width(), img.get_height() - cut) / f)
	_lid_pos = Vector2.ZERO
	_lid_vel = Vector2.ZERO
	_lid_rot = 0.0
	_choosing = true
	_kind = ""
	_tier = 3
	_fx = 3
	_escalating = false
	_chest_souls = 0
	_title.text = str(boss.get("name", "")).to_upper()
	_subtitle.add_theme_color_override("font_color", Color(1, 1, 1, 0.8))
	_subtitle.position.y = 230 + Game.design_offset()
	_subtitle.show()
	_open_common()
	_title.modulate.a = 1.0
	get_tree().paused = true
	Game.sfx("boss_die", 0.8)
	_upgraded.clear()
	if _level_up != null and not _upgradable().is_empty():
		_upgrades_left = TROPHY_UPGRADES
		_build_upgrade_tiles(true)
		return
	var kinds: = _open_kinds()
	if kinds.is_empty():
		_finish_trophy_full()
	elif kinds.size() == 1:
		_pick_kind(kinds[0])
	else:
		_build_kind_cards()

func _begin(force_tier: int, min_level: = 0) -> void :
	_roll(force_tier, min_level)
	_open_common()
	get_tree().paused = true


func _open_common() -> void :
	_oy = Game.design_offset()
	_title.position.y = 150 + _oy
	_list.position.y = _list_top + _oy
	_continue.position.y = 1110 + _oy
	_bonus.position.y = 1110 + _oy
	_bonus.hide()
	_bonus_used = false
	for child in _list.get_children():
		child.queue_free()
	_time = 0.0
	_opened = false
	_second_burst = false
	_revealed = 0
	_flash = 0.0
	_particles.clear()
	_flyers.clear()
	_souls_bits.clear()
	_souls_t = -1.0
	_souls_total = 0
	_souls_shown = 0.0
	_ascending = false
	_title.show()
	_list.show()
	_title.modulate.a = 0.0
	_continue.hide()
	show()




func _upgradable() -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	for c in _player.get_children():
		if c is Weapon and not (c as Weapon).is_maxed():
			out.append({"weapon": c.get_script()})
	for id: String in _player.passives:
		if _player.passives[id] < Game.PASSIVES[id]["max"]:
			out.append({"passive": id})
	return out



func _build_upgrade_tiles(fresh: = false) -> void :
	_clear_pool()
	_pool_box.position.y = 600 + _oy
	_pool_box.show()
	_subtitle.text = "Level up what you own: %d upgrade%s left" % [_upgrades_left, "" if _upgrades_left == 1 else "s"]
	_subtitle.add_theme_color_override("font_color", Color(1, 0.85, 0.4))
	var weapons: = HBoxContainer.new()
	weapons.alignment = BoxContainer.ALIGNMENT_CENTER
	weapons.add_theme_constant_override("separation", TILE_GAP)
	_pool_box.add_child(weapons)
	for c in _player.get_children():
		if c is Weapon:
			var w: = c as Weapon
			weapons.add_child(_upgrade_tile({"weapon": w.get_script()}, w.icon(), w.level, Weapon.max_level(w.get_script()), 
				Game.theme.ui["accent"], w.is_maxed(), fresh))
	var passives: = HBoxContainer.new()
	passives.alignment = BoxContainer.ALIGNMENT_CENTER
	passives.add_theme_constant_override("separation", TILE_GAP)
	_pool_box.add_child(passives)
	for id: String in _player.passives:
		var top: int = Game.PASSIVES[id]["max"]
		passives.add_child(_upgrade_tile({"passive": id}, str(Game.theme.passive(id).get("icon", "")), _player.passives[id], top, 
			Game.theme.ui["xp"], _player.passives[id] >= top, fresh))
	_pool_box.add_child(_mode_switch())

func _clear_pool() -> void :
	for c in _pool_box.get_children():
		_pool_box.remove_child(c)
		c.queue_free()


func _mode_switch() -> Control:
	var box: = VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	var row: = HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	box.add_child(row)
	for slow: bool in [false, true]:
		var on: = Game.trophy_details == slow
		var color: Color = _holy_color if on else Color(0.55, 0.55, 0.55)
		var b: = _choice_button(color, 64, false)
		b.custom_minimum_size = Vector2(300, 64)
		b.text = "SHOW DETAILS" if slow else "QUICK UPGRADE"
		b.add_theme_font_size_override("font_size", 24)
		b.add_theme_color_override("font_color", color if on else Color(1, 1, 1, 0.55))
		b.add_theme_color_override("font_hover_color", color if on else Color(1, 1, 1, 0.75))
		b.add_theme_color_override("font_pressed_color", color)
		b.pressed.connect( func() -> void :
			if Game.trophy_details == slow or not _choosing:
				return
			Game.trophy_details = slow
			Game.save_profile()
			Game.sfx("select", 1.2)
			_build_upgrade_tiles())
		row.add_child(b)
	var hint: = Label.new()
	hint.text = "Tap an item to see what it does first" if Game.trophy_details else "Tap an item to level it up"
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.add_theme_font_size_override("font_size", 20)
	hint.add_theme_color_override("font_color", Color(1, 1, 1, 0.6))
	hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(hint)
	return box


func _upgrade_tile(choice: Dictionary, icon_name: String, level: int, top: int, color: Color, maxed: bool, fresh: bool) -> Button:
	var readable: = maxed and Game.trophy_details
	var b: = _choice_button(color if not maxed else Color(0.45, 0.45, 0.45), TILE_SIZE.y, fresh and ( not maxed or readable))
	b.custom_minimum_size = Vector2(_tile_width(), TILE_SIZE.y)
	if maxed:
		b.disabled = not readable
		b.modulate.a = 0.45
	var col: = VBoxContainer.new()
	col.position = Vector2(0, 8)
	col.size = Vector2(_tile_width(), TILE_SIZE.y - 16)
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_theme_constant_override("separation", 8)
	b.add_child(col)
	var icon: = TextureRect.new()
	icon.texture = Game.theme.texture(icon_name)
	icon.custom_minimum_size = Vector2(64, 64)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	col.add_child(icon)
	var pips: = LevelPips.new().setup(level, top, color, maxed, not maxed, _tile_width() - 8.0)
	pips.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	col.add_child(pips)
	for c in [col, icon, pips]:
		(c as Control).mouse_filter = Control.MOUSE_FILTER_IGNORE
	if not maxed or readable:
		b.pressed.connect(_tap_tile.bind(choice))
	return b


func _tile_width() -> float:
	var most: = maxi(_held("weapon"), _player.passives.size())
	return minf(TILE_SIZE.x, floorf((640.0 - TILE_GAP * (most - 1)) / maxi(most, 1)))

func _tap_tile(choice: Dictionary) -> void :
	if not _choosing or _upgrades_left <= 0:
		return
	if Game.trophy_details:
		Game.sfx("select", 1.1)
		_show_details(choice)
	else:
		_spend_upgrade(choice)



func _show_details(choice: Dictionary) -> void :
	var d: = _item_details(choice)
	var color: Color = d["color"]
	_clear_pool()
	_pool_box.position.y = 560 + _oy
	var panel: = PanelContainer.new()
	panel.custom_minimum_size = Vector2(640, 0)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style: = StyleBoxFlat.new()
	style.bg_color = Color(color.darkened(0.82), 0.95)
	style.border_color = color
	style.set_border_width_all(3)
	style.set_corner_radius_all(14)
	style.set_content_margin_all(22)
	panel.add_theme_stylebox_override("panel", style)
	_pool_box.add_child(panel)
	var col: = VBoxContainer.new()
	col.add_theme_constant_override("separation", 10)
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(col)
	var icon: = TextureRect.new()
	icon.texture = Game.theme.texture(d["icon"])
	icon.custom_minimum_size = Vector2.ONE * DETAIL_ICON
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	col.add_child(icon)
	col.add_child(_detail_label("%s   Lv %d" % [d["name"], d["level"]], 34, d["name_color"], 6))
	var pips: = LevelPips.new().setup(d["level"], d["top"], color, d["maxed"], not d["maxed"], 320.0)
	pips.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	col.add_child(pips)
	if d["kind"] != "":
		col.add_child(_detail_label(d["kind"], 18, Color(color.lightened(0.4), 0.8)))
	col.add_child(_detail_label(d["text"], 24, Color(0.9, 0.9, 0.9)))
	var gap: = Control.new()
	gap.custom_minimum_size = Vector2(0, 6)
	col.add_child(gap)
	if d["maxed"]:
		col.add_child(_detail_label("MAX LEVEL", 26, _holy_color, 6))
	else:
		col.add_child(_detail_label("NEXT LEVEL  (Lv %d)" % (d["level"] + 1), 24, _holy_color, 6))
		col.add_child(_detail_label(d["next"], 26, Color.WHITE))
	var buttons: = HBoxContainer.new()
	buttons.alignment = BoxContainer.ALIGNMENT_CENTER
	buttons.add_theme_constant_override("separation", 20)
	_pool_box.add_child(buttons)
	var back: = _choice_button(Color(0.6, 0.6, 0.6), 90, false)
	back.custom_minimum_size = Vector2(220, 90)
	back.text = "Back"
	back.add_theme_font_size_override("font_size", 30)
	back.pressed.connect( func() -> void :
		if _choosing:
			Game.sfx("select", 0.9)
			_build_upgrade_tiles())
	buttons.add_child(back)
	if not d["maxed"]:
		var up: = _choice_button(_holy_color, 90)
		up.custom_minimum_size = Vector2(360, 90)
		up.text = "UPGRADE"
		up.add_theme_font_size_override("font_size", 34)
		up.add_theme_color_override("font_color", _holy_color)
		up.pressed.connect(_spend_upgrade.bind(choice))
		buttons.add_child(up)

func _detail_label(text: String, font_size: int, color: Color, outline: = 0) -> Label:
	var l: = Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(590, 0)
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	if outline > 0:
		l.add_theme_color_override("font_outline_color", Color.BLACK)
		l.add_theme_constant_override("outline_size", outline)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l



func _item_details(choice: Dictionary) -> Dictionary:
	if choice.has("passive"):
		var id: String = choice["passive"]
		var info: = Game.theme.passive(id)
		var lvl: = int(_player.passives.get(id, 0))
		var top: = int(Game.PASSIVES[id]["max"])
		var pool: = Game.pool_of(id)
		return {"name": info.get("name", id), "name_color": Color.WHITE, "icon": info.get("icon", ""), 
			"color": Game.theme.ui["xp"], "kind": ("%s PASSIVE" % pool.to_upper()) if pool != "" else "PASSIVE", 
			"level": lvl, "top": top, "maxed": lvl >= top, "text": "Now: " + Game.passive_text(id, lvl, true), 
			"next": Game.passive_text(id, lvl + 1) if lvl < top else ""}
	var script: Script = choice["weapon"]
	var w: = _level_up.owned_weapon(script)
	var info: = Weapon.theme_info(script)
	var d: = {"name": info.get("name", "?"), "name_color": Color.WHITE, "icon": w.icon() if w else info.get("icon", ""), 
		"color": Game.theme.ui["accent"], "kind": "WEAPON", "level": w.level if w else 1, "top": Weapon.max_level(script), 
		"maxed": w == null or w.is_maxed(), "text": info.get("description", ""), "next": ""}
	if w and w.holy:
		d["name"] = info.get("holy_name", d["name"])
		d["name_color"] = info.get("holy_color", _holy_color)
		d["kind"] = "HOLY WEAPON"
		d["text"] = Weapon.holy_text(script)
	if not d["maxed"]:
		d["next"] = Weapon.upgrade_text(script, d["level"] + 1)
	return d

func _spend_upgrade(choice: Dictionary) -> void :
	if not _choosing or _upgrades_left <= 0:
		return
	var card: = _level_up.describe(choice)
	_upgraded.append({"key": _level_up._key(choice), "icon": card["icon"], "holy": false, 
		"title": "%s  Lv %d" % [card["name"], card["level"]], "text": card["text"]})
	_level_up.apply(choice)
	_upgrades_left -= 1
	Game.sfx("select", 1.0 + (TROPHY_UPGRADES - _upgrades_left) * 0.12)
	if _upgrades_left > 0 and not _upgradable().is_empty():
		_build_upgrade_tiles()
	else:
		_finish_upgrades()




func _finish_upgrades() -> void :
	_choosing = false
	_pool_box.hide()
	_subtitle.text = "YOUR ARSENAL GROWS"
	Game.track("trophies")
	_rewards.clear()
	_picked.clear()
	_tier = 3
	_fx = 3
	var order: Array[String] = []
	for u in _upgraded:
		if not order.has(u["key"]):
			order.append(u["key"])
	for key in order:
		for u in _upgraded:
			if u["key"] == key:
				_rewards.append(u)

	var holy: = _give_holy()
	if not holy.is_empty():
		_rewards.append(holy)
	if _rewards.size() > 3:
		_list_top = 640.0 - LIST_LIFT
		_row_step = ROW_STEP_FIVE
		_list.add_theme_constant_override("separation", int(ROW_STEP_FIVE - ROW_HEIGHT_FIVE))
	_time = 0.0
	_title.modulate.a = 0.0




func _open_kinds() -> Array[String]:
	var out: Array[String] = []
	for kind: String in ["weapon", "passive"]:
		if not _new_items(kind).is_empty():
			out.append(kind)
	return out

func _kind_color(kind: String) -> Color:
	return Game.theme.ui["accent"] if kind == "weapon" else Game.theme.ui["xp"]

func _build_kind_cards() -> void :
	for c in _pool_box.get_children():
		c.queue_free()
	_pool_box.position.y = 560 + _oy
	_pool_box.show()
	_subtitle.text = "Your build is maxed. Take a new item."
	_subtitle.add_theme_color_override("font_color", Color(1, 0.85, 0.4))
	for kind: String in _open_kinds():
		_pool_box.add_child(_kind_card(kind))


func _kind_card(kind: String) -> Button:
	var color: = _kind_color(kind)
	var b: = _choice_button(color, 150)
	var col: = VBoxContainer.new()
	col.position = Vector2(22, 12)
	col.size = Vector2(596, 126)
	col.add_theme_constant_override("separation", 4)
	b.add_child(col)
	var heading: = Label.new()
	heading.text = "NEW WEAPON" if kind == "weapon" else "NEW PASSIVE"
	heading.add_theme_font_size_override("font_size", 38)
	heading.add_theme_color_override("font_color", color)
	heading.add_theme_color_override("font_outline_color", Color.BLACK)
	heading.add_theme_constant_override("outline_size", 8)
	col.add_child(heading)
	var text: = Label.new()
	text.text = "Choose one of %d. It arrives at Lv %d" % [mini(_new_items(kind).size(), TROPHY_CHOICES), TROPHY_LEVEL]
	text.add_theme_font_size_override("font_size", 22)
	text.add_theme_color_override("font_color", Color(1, 1, 1, 0.75))
	col.add_child(text)
	var line: = Label.new()
	var held: = _held(kind)
	var base: = Game.MAX_WEAPONS if kind == "weapon" else Game.MAX_PASSIVES
	if held >= base:
		line.text = "Takes a %s %s slot" % [_ordinal(held + 1), kind]
		line.add_theme_color_override("font_color", Game.theme.ui.get("holy", Color(1, 0.93, 0.55)))
	else:
		line.text = "%d %s slot%s free" % [base - held, kind, "" if base - held == 1 else "s"]
		line.add_theme_color_override("font_color", Color(color.lightened(0.4), 0.85))
	line.add_theme_font_size_override("font_size", 20)
	col.add_child(line)
	for c in [col, heading, text, line]:
		(c as Control).mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.pressed.connect(_pick_kind.bind(kind))
	return b

func _held(kind: String) -> int:
	if kind == "passive":
		return _player.passives.size()
	return _player.get_children().filter( func(c: Node) -> bool: return c is Weapon).size()


func _pick_kind(kind: String) -> void :
	if not _choosing or _kind != "":
		return
	Game.sfx("select")
	_kind = kind
	var options: = _new_items(kind)
	options.shuffle()
	for c in _pool_box.get_children():
		c.queue_free()
	_pool_box.position.y = 560 + _oy
	_pool_box.show()
	_subtitle.text = "Choose your new %s" % kind
	_subtitle.add_theme_color_override("font_color", _kind_color(kind))
	for choice: Dictionary in options.slice(0, TROPHY_CHOICES):
		_pool_box.add_child(_item_card(choice, _kind_color(kind)))



func _choice_button(color: Color, height: float, delay: = true) -> Button:
	var b: = Button.new()
	b.custom_minimum_size = Vector2(640, height)
	b.focus_mode = Control.FOCUS_NONE
	b.disabled = delay
	for state: String in ["normal", "hover", "pressed", "disabled"]:
		var style: = StyleBoxFlat.new()
		style.bg_color = Color(color.darkened(0.82), 0.95) if state != "pressed" else Color(color.darkened(0.6), 0.95)
		style.border_color = color if state != "disabled" else color.darkened(0.3)
		style.set_border_width_all(3)
		style.set_corner_radius_all(14)
		b.add_theme_stylebox_override(state, style)
	if delay:
		var ref: WeakRef = weakref(b)
		get_tree().create_timer(0.5, true, false, true).timeout.connect( func() -> void :
			var still: = ref.get_ref() as Button
			if still:
				still.disabled = false)
	return b


func _item_card(choice: Dictionary, color: Color) -> Button:
	var card: = _trophy_card(choice)
	var b: = _choice_button(color, 150)
	var row: = HBoxContainer.new()
	row.position = Vector2(18, 12)
	row.size = Vector2(604, 126)
	row.add_theme_constant_override("separation", 18)
	b.add_child(row)
	var icon: = TextureRect.new()
	icon.texture = Game.theme.texture(card["icon"])
	icon.custom_minimum_size = Vector2(88, 88)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	row.add_child(icon)
	var col: = VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_child(col)
	var heading: = Label.new()
	heading.text = "%s   Lv %d" % [card["name"], card["level"]]
	heading.add_theme_font_size_override("font_size", 30)
	heading.add_theme_color_override("font_color", Color.WHITE)
	heading.add_theme_color_override("font_outline_color", Color.BLACK)
	heading.add_theme_constant_override("outline_size", 6)
	col.add_child(heading)
	var text: = Label.new()
	text.text = card["text"]
	text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	text.add_theme_font_size_override("font_size", 22)
	text.add_theme_color_override("font_color", Color(color.lightened(0.5), 0.9))
	col.add_child(text)
	var extra: = _extra_slot(choice)
	if extra != "":
		var note: = Label.new()
		note.text = extra
		note.add_theme_font_size_override("font_size", 19)
		note.add_theme_color_override("font_color", Game.theme.ui.get("holy", Color(1, 0.93, 0.55)))
		note.mouse_filter = Control.MOUSE_FILTER_IGNORE
		col.add_child(note)
	for c in [row, icon, col, heading, text]:
		(c as Control).mouse_filter = Control.MOUSE_FILTER_IGNORE

	row.minimum_size_changed.connect( func() -> void :
		var h: = row.get_combined_minimum_size().y
		row.size.y = maxf(126.0, h)
		b.custom_minimum_size.y = maxf(150.0, h + 24.0))
	b.pressed.connect(_pick_item.bind(choice))
	return b

func _pick_item(choice: Dictionary) -> void :
	if not _choosing:
		return
	Game.sfx("select")
	_finish_trophy(choice)



func _finish_trophy(choice: Dictionary) -> void :
	_choosing = false
	_pool_box.hide()
	_subtitle.text = "NEW %s" % _kind.to_upper()
	_subtitle.add_theme_color_override("font_color", _kind_color(_kind))
	Game.track("trophies")
	_rewards.clear()
	_picked.clear()
	_tier = 3
	_fx = 3
	var card: = _trophy_card(choice)
	for i in card["level"]:
		_level_up.apply(choice)
	_rewards.append({"icon": card["icon"], "title": "%s  Lv %d" % [card["name"], card["level"]], "text": card["text"], "holy": false})
	var holy: = _give_holy()
	if not holy.is_empty():
		_rewards.append(holy)
	_time = 0.0
	_title.modulate.a = 0.0




func _finish_trophy_full() -> void :
	_choosing = false
	_pool_box.hide()
	_subtitle.text = "Your build is complete. Take all its spoils."
	_subtitle.add_theme_color_override("font_color", Color(1, 0.85, 0.4))
	Game.track("trophies")
	_rewards.clear()
	_picked.clear()
	_tier = 3
	_fx = 3
	var holy: = _give_holy()
	var spoils: Array[Dictionary] = []
	for pool: String in ["damage", "defense", "utility"]:
		spoils.append(_trophy_fallback(pool))
	if not holy.is_empty():
		spoils[0]["title"] = "%s, %s" % [spoils[0]["title"], spoils[1]["title"]]
		spoils[0]["text"] = "And fully healed"
		spoils.remove_at(1)
	_rewards.append_array(spoils)
	if not holy.is_empty():
		_rewards.append(holy)
	_time = 0.0
	_title.modulate.a = 0.0




func _new_items(kind: String) -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	if _level_up == null:
		return out
	if kind == "weapon" and _held("weapon") < Game.MAX_WEAPONS + Game.TROPHY_SLOTS:
		for script: Script in Game.WEAPONS.values():
			var id: = str(Weapon.info(script, "ID"))
			if Game.pool_of(id) != "" and not _player.exiled.has(id) and Game.is_item_in_run(id) and _level_up.owned_weapon(script) == null:
				out.append({"weapon": script})
	if kind == "passive" and _held("passive") < Game.MAX_PASSIVES + Game.TROPHY_SLOTS:
		for id: String in Game.PASSIVES:
			if Game.pool_of(id) != "" and not _player.exiled.has(id) and Game.is_item_in_run(id) and not _player.passives.has(id):
				out.append({"passive": id})
	return out


func _extra_slot(choice: Dictionary) -> String:
	if choice.has("passive"):
		if _player.passives.size() >= Game.MAX_PASSIVES:
			return "Takes a %s passive slot" % _ordinal(_player.passives.size() + 1)
		return ""
	var weapons: = _player.get_children().filter( func(c: Node) -> bool: return c is Weapon).size()
	return "Takes a %s weapon slot" % _ordinal(weapons + 1) if weapons >= Game.MAX_WEAPONS else ""

static func _ordinal(n: int) -> String:
	return "%d%s" % [n, {1: "st", 2: "nd", 3: "rd"}.get(n, "th")]


func _trophy_card(choice: Dictionary) -> Dictionary:
	if choice.has("passive"):
		var id: String = choice["passive"]
		var info: = Game.theme.passive(id)
		var lvl: = mini(TROPHY_LEVEL, int(Game.PASSIVES[id]["max"]))
		return {"name": info.get("name", id), "icon": info.get("icon", ""), "level": lvl, "text": Game.passive_text(id, lvl, true)}
	var script: Script = choice["weapon"]
	var winfo: = Weapon.theme_info(script)
	return {"name": winfo.get("name", "?"), "icon": winfo.get("icon", ""), "level": mini(TROPHY_LEVEL, Weapon.max_level(script)), 
		"text": winfo.get("description", "")}


func _trophy_fallback(pool: String) -> Dictionary:
	match pool:
		"damage":
			_player.add_trophy("might", TROPHY_FALLBACK["damage"])
			return {"icon": Game.theme.passive("might").get("icon", ""), "holy": false, 
				"title": "+%d%% damage" % roundi(TROPHY_FALLBACK["damage"] * 100.0), "text": "For the rest of the run"}
		"defense":
			_player.add_trophy("max_hp", TROPHY_FALLBACK["defense"])
			_player.heal(_player.max_hp)
			return {"icon": Game.theme.passive("max_hp").get("icon", ""), "holy": false, 
				"title": "+%d max HP" % roundi(TROPHY_FALLBACK["defense"]), "text": "And fully healed"}
	_player.add_trophy("speed", TROPHY_FALLBACK["utility"])
	_player.add_coins(TROPHY_FALLBACK["souls"])
	return {"icon": Game.theme.passive("speed").get("icon", ""), "holy": false, 
		"title": "+%d%% move speed" % roundi(TROPHY_FALLBACK["utility"] * 100.0), 
		"text": "And %d %s" % [TROPHY_FALLBACK["souls"], Game.theme.currency]}



func _roll(force_tier: = 0, min_level: = 0) -> void :
	_list_top = 640.0
	_row_step = ROW_STEP
	_list.add_theme_constant_override("separation", int(ROW_STEP - 112.0))
	_rewards.clear()
	_picked.clear()
	_escalating = false
	_chest_souls = 0
	if force_tier > 0:
		_tier = clampi(force_tier, 1, 3)
		_fx = _tier
		for i in _tier:
			_rewards.append(_give_one())
		return
	var row: Array = TREASURE[0]
	var minute: = _player.survived / maxf(Game.theme.win_time, 1.0) * 30.0
	for r: Array in TREASURE:
		if minute >= float(r[0]):
			row = r
	var opened: = int(Game.progress.stats.get("chests_rolled", 0))
	Game.track("chests_rolled")
	var level: = 0
	if opened < FIRST_CHESTS.size() and not Game.dev_mode:
		level = FIRST_CHESTS[opened]
	else:
		var chances: Array = row[1]
		for i in chances.size():
			if randf() * 100.0 < float(chances[i]) * _player.luck:
				level = 3 - i
				break
		if level == 0:
			level = int(row[2])
	level = maxi(level, min_level)
	_tier = clampi(level, 1, 3)
	var prizes: Array = row[3]
	for i in CHEST_PRIZES[level]:
		_rewards.append(_give_one(str(prizes[mini(i, prizes.size() - 1)]), i == 0))
	_fx = 1
	_escalating = true

	_list_top = 640.0 - LIST_LIFT
	_row_step = ROW_STEP_FIVE
	_list.add_theme_constant_override("separation", int(ROW_STEP_FIVE - ROW_HEIGHT_FIVE))
	_chest_souls = int(randf() * CHEST_SOULS[level])
	_chest_souls_all = _chest_souls
	_chest_prizes = _rewards.size()
	_chest_rows = 0



func _give_one(prize: = "evolution", first: = true) -> Dictionary:
	var holy: = _give_holy() if prize == "evolution" or first else {}
	if not holy.is_empty():
		return holy
	var weapons: Array[Weapon] = []
	for c in _player.get_children():
		if c is Weapon:
			weapons.append(c)
	var options: Array[Dictionary] = []
	for w in weapons:
		if not w.is_maxed():
			options.append({"weapon": w.get_script()})
	for id: String in _player.passives:
		if prize != "existing_weapon" and _player.passives[id] < Game.PASSIVES[id]["max"]:
			options.append({"passive": id})
	if options.is_empty() and prize == "existing_weapon":
		return _give_one("existing_any", false)
	if options.is_empty() or _level_up == null:
		var souls: = randi_range(FALLBACK_COINS.x, FALLBACK_COINS.y)
		_player.add_coins(souls)
		return {"icon": Game.theme.pickups.get("coin", "coin"), "holy": false, 
			"title": "+%d %s" % [souls, Game.theme.currency], "text": "Everything you own is maxed out"}
	var fresh: = options.filter( func(o: Dictionary) -> bool: return not _picked.has(o))
	var choice: Dictionary = (fresh if not fresh.is_empty() else options).pick_random()
	_picked.append(choice)
	var card: = _level_up.describe(choice)
	_level_up.apply(choice)
	return {"icon": card["icon"], "title": card["title"], "text": card["text"], "holy": false}


func _give_holy() -> Dictionary:
	var weapons: Array[Weapon] = []
	for c in _player.get_children():
		if c is Weapon:
			weapons.append(c)
	var holy_ready: = weapons.filter( func(w: Weapon) -> bool: return w.can_turn_holy())
	if not holy_ready.is_empty():
		var w: Weapon = holy_ready.pick_random()
		w.make_holy()
		var info: = Weapon.theme_info(w.get_script())
		return {"icon": info.get("icon", ""), "new_icon": w.icon(), "holy": true, "banner": "A S C E N D E D", "announce": "ASCENDED", 
			"title": info.get("holy_name", "Holy " + str(info.get("name", "?"))), 
			"old_name": info.get("name", "?"), "tagline": info.get("holy_tagline", ""), 
			"old_color": info.get("color", Color.WHITE), "holy_color": info.get("holy_color", _holy_color), 
			"text": Weapon.holy_text(w.get_script())}
	return {}



func _process(delta: float) -> void :
	if not visible:
		return
	_time += delta
	_flash = maxf(_flash - delta * 1.6, 0.0)
	var shake: float = SHAKE[_fx - 1]
	if _choosing:
		_shake = Vector2.ZERO
		_time = 0.0
	elif _ascending:
		_step_ascension(delta)
	elif not _opened:

		var build: = _time / SHAKE_TIME
		_shake = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * shake * build * 1.5
		if _time >= SHAKE_TIME:
			_burst()
	else:
		var settle: = maxf(0.0, 1.0 - (_time - SHAKE_TIME) * 2.0)
		_shake = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * shake * settle * 2.0
		_title.modulate.a = minf(1.0, (_time - SHAKE_TIME) * 3.0)
		if _fx == 3 and not _second_burst and not _trophy_tex and _time >= SHAKE_TIME + 0.45:
			_second_burst = true
			_spawn_particles(PARTICLES[2] / 2)
			_flash = 0.8
			_flash_color = _holy_color
		var next_at: = SHAKE_TIME + REVEAL_DELAY + _revealed * _gap()
		if _revealed < _rewards.size() and _time >= next_at:
			if _is_chest() and ESCALATE_AT.has(_revealed):
				_escalate(ESCALATE_AT[_revealed])
			_reveal(_rewards[_revealed])
			_revealed += 1
		elif _is_chest() and _revealed > 0 and not _continue.visible:

			var build: = clampf(1.0 - (next_at - _time) / _gap(), 0.0, 1.0)
			_shake += Vector2(randf_range(-1, 1), randf_range(-1, 1)) * 5.0 * build * build
		if not _ascending and _revealed == _rewards.size() and _flyers.is_empty() and not _continue.visible and _time >= next_at - _gap() + (CHEST_GAP if _escalating else CONTINUE_DELAY):
			_show_chest_souls()
			_continue.show()
			var offer: = not _bonus_used and not _trophy_tex and _rewards.size() < 3 and Ads.can_show() and not Game.dev_mode
			_bonus.visible = offer
			_continue.position.x = 40.0 if offer else 210.0

			var below: = _list.position.y + _list.get_combined_minimum_size().y + 24.0
			_continue.position.y = minf(maxf(1110.0 + _oy, below), Game.view_size().y - _continue.size.y - 20.0)
			_bonus.position.y = _continue.position.y
	if _trophy_tex and _opened:
		_lid_vel.y += LID_GRAVITY * delta
		_lid_pos += _lid_vel * delta
		_lid_rot += _lid_spin * delta
	_step_souls(delta)
	for f in _flyers:
		f["t"] = float(f["t"]) + delta / FLY_TIME
		if f["t"] >= 1.0:
			_show_row(f["reward"])
	_flyers = _flyers.filter( func(f: Dictionary) -> bool: return f["t"] < 1.0)
	for p in _particles:
		p["life"] -= delta
		p["vel"] = (p["vel"] as Vector2) * (1.0 - 1.5 * delta) + Vector2(0, 220) * delta
		p["pos"] = (p["pos"] as Vector2) + (p["vel"] as Vector2) * delta
	_particles = _particles.filter( func(p: Dictionary) -> bool: return p["life"] > 0.0)
	queue_redraw()

func _is_chest() -> bool:
	return _escalating

func _gap() -> float:
	return CHEST_GAP if _escalating else REVEAL_GAP


func _escalate(tier: int) -> void :
	_fx = maxi(_fx, tier)
	_flash = FLASH[_fx - 1]
	_flash_color = Color.WHITE
	_spawn_particles(PARTICLES[_fx - 1])
	Game.sfx("blessing_%d" % _fx)



func _chest_row_souls() -> void :
	if not _is_chest() or _chest_souls <= 0 or _chest_prizes <= 0:
		return
	_chest_rows += 1
	var due: = roundi(_chest_souls_all * minf(float(_chest_rows) / _chest_prizes, 1.0))
	_pay_chest_souls(due - (_chest_souls_all - _chest_souls))


func _show_chest_souls() -> void :
	_pay_chest_souls(_chest_souls)



func _pay_chest_souls(amount: int) -> void :
	amount = mini(amount, _chest_souls)
	if amount <= 0 or _trophy_tex:
		return
	_chest_souls -= amount
	var total: = _player.add_coins(amount)
	_subtitle.hide()
	if _souls_t < 0.0:
		_souls_total = 0
		_souls_shown = 0.0
		_souls_t = 0.0
	_souls_total += total
	var bits: = clampi(total / 2, 4, SOUL_MAX_BITS)
	var left: = total
	for i in bits:
		var value: = left / (bits - i)
		left -= value
		var a: = - PI / 2.0 + randf_range(-0.9, 0.9)
		_souls_bits.append({"pos": _hole(), "vel": Vector2.RIGHT.rotated(a) * randf_range(380.0, 760.0), 
			"t": - i * 0.03, "value": value, "from": Vector2.ZERO})
	_flash = 0.35
	_flash_color = Color(0.6, 0.9, 1.0)
	Game.sfx("vacuum", 1.3)

func _burst() -> void :
	_opened = true
	_flash = FLASH[_fx - 1]
	_flash_color = Color.WHITE
	Game.sfx("blessing_%d" % _fx)
	if _trophy_tex:
		var side: = -1.0 if randf() < 0.5 else 1.0
		_lid_vel = Vector2(side * randf_range(260.0, 380.0), -1250.0)
		_lid_spin = side * randf_range(5.0, 8.0)
		_flash = 0.45
		_spawn_particles(PARTICLES[_fx - 1] / 2, _hole(), Color(0, 0, 0, 0), true)
		_spawn_particles(26, _hole(), Game.theme.ui["hp"], true)
		Game.sfx("break", 0.7)
		return
	_spawn_particles(PARTICLES[_fx - 1])


func _hole() -> Vector2:
	if _trophy_tex:
		var size: = _trophy_tex.get_size() * TROPHY_SCALE
		return CHEST_CENTER + Vector2(0, - size.y / 2.0 + _head_top.get_height() * TROPHY_SCALE)
	return CHEST_CENTER + Vector2(0, -40)


func _slot_pos(slot: int) -> Vector2:
	return Vector2(40 + 12 + 40, _list_top + slot * _row_step + _row_height() / 2.0)

func _row_height() -> float:
	return ROW_HEIGHT_FIVE if _row_step == ROW_STEP_FIVE else 112.0


func _spawn_particles(count: int, at: = CHEST_CENTER, tint: = Color(0, 0, 0, 0), up: = false) -> void :
	var base: = tint if tint.a > 0.0 else _holy_color
	for i in count:
		var color: = base
		if _fx == 2 and i % 2 == 0:
			color = Color.WHITE
		elif _fx == 3:
			color = Color.from_hsv(randf(), 0.45, 1.0)
		var life: = randf_range(0.8, 1.8)
		var dir: = Vector2.UP.rotated(randf_range(-0.55, 0.55)) if up else Vector2.RIGHT.rotated(randf() * TAU)
		_particles.append({"pos": at, "vel": dir * randf_range(200, 650 + 150 * _fx) * (1.3 if up else 1.0), 
			"life": life, "max_life": life, "color": color, "size": randf_range(3, 6 + 2 * _fx)})



func _start_ascension(r: Dictionary) -> void :
	_ascending = true
	_asc_t = 0.0
	_asc_skip = false
	_asc_burst = false
	_asc_reward = r
	_asc_sparks.clear()
	_title.hide()
	_list.hide()
	_continue.hide()
	Game.sfx("blessing_1")

func _step_ascension(delta: float) -> void :
	_asc_t += delta
	var hc: Color = _asc_reward["holy_color"]
	if _asc_t < ASC_CHARGE:

		var build: = _asc_t / ASC_CHARGE
		_shake = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * 12.0 * build
		for i in 3:
			_asc_sparks.append({"ang": randf() * TAU, "dist": randf_range(520, 760), "speed": randf_range(520, 900), "size": randf_range(3, 6)})
		for s in _asc_sparks:
			s["dist"] = float(s["dist"]) - float(s["speed"]) * delta * (0.6 + build)
		_asc_sparks = _asc_sparks.filter( func(s: Dictionary) -> bool: return s["dist"] > 30.0)
	else:
		_asc_sparks.clear()
		if not _asc_burst:
			_asc_burst = true
			_flash = 1.0
			_flash_color = Color.WHITE
			Game.sfx("holy")
			Game.sfx("blessing_3")
			_spawn_particles(140, ASC_CENTER, hc)
		_shake = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * 22.0 * maxf(0.0, 1.0 - (_asc_t - ASC_CHARGE) * 2.2)
		if _asc_t > ASC_CHARGE + 0.9 and _particles.size() < 40:
			_spawn_particles(2, ASC_CENTER + Vector2(randf_range(-300, 300), -500), hc)
	if _asc_t >= ASC_TIME or (_asc_skip and _asc_t >= ASC_SKIP_AFTER):
		_ascending = false
		_title.show()
		_list.show()
		_particles.clear()
		_flash = 0.0
		_show_row(_asc_reward)
		_time = SHAKE_TIME + REVEAL_DELAY + (_revealed - 1) * _gap()

func _gui_input(event: InputEvent) -> void :
	if _ascending and event is InputEventMouseButton and event.pressed:
		_asc_skip = true

func _reveal(r: Dictionary) -> void :
	if r["holy"]:
		_start_ascension(r)
	else:
		_flyers.append({"reward": r, "tex": Game.theme.texture(r.get("new_icon", r["icon"])) if r["icon"] != "" else null, 
			"slot": _list.get_child_count() + _flyers.size(), "t": 0.0})
		Game.sfx("reveal", 0.9 + _revealed * 0.1)

func _show_row(r: Dictionary) -> void :
	_chest_row_souls()
	var row: = _reward_row(r)
	_list.add_child(row)
	row.pivot_offset = Vector2(row.custom_minimum_size.x / 2.0, row.custom_minimum_size.y / 2.0)
	row.scale = Vector2(0.3, 0.3)
	row.modulate.a = 0.0
	var tween: = row.create_tween().set_parallel()
	tween.tween_property(row, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tween.tween_property(row, "modulate:a", 1.0, 0.15)
	if r["holy"]:
		Game.sfx("reveal", 0.8)
		_flash = 0.3
		_flash_color = r["holy_color"]
	else:
		Game.sfx("select", 1.2 + _list.get_child_count() * 0.1)
		_spawn_particles(10, _slot_pos(_list.get_child_count() - 1))


func _on_bonus() -> void :
	if _bonus_used:
		return
	_bonus_used = true
	_bonus.disabled = true
	Ads.show_rewarded( func(earned: bool) -> void :
		_bonus.disabled = false
		_bonus.hide()
		_continue.position.x = 210.0
		if not earned or not visible:
			return
		_continue.hide()
		_rewards.append(_give_one()))

func _on_continue() -> void :
	Game.sfx("select")
	if _chest_souls > 0:
		_player.add_coins(_chest_souls)
		_chest_souls = 0
	hide()
	for r in _rewards:
		if r["holy"]:
			FloatText.pop(_player, str(r.get("announce", "ASCENDED")) + ": " + str(r["title"]), _player.global_position + Vector2(0, -130), r["holy_color"], 44, 2.2, 40.0, 2.0)
	LevelUpScreen.resume_if_clear(get_tree())

func _draw() -> void :
	var view: = get_viewport_rect().size
	draw_set_transform(Vector2(0, _oy))
	draw_rect(Rect2(Vector2(0, - _oy), view), Color(0, 0, 0, 0.78))
	if _ascending:
		_draw_ascension(view)
		_draw_overlay(view)
		return
	var center: = CHEST_CENTER + _shake
	var t: = _time
	if _opened:

		var rays: int = RAYS[_fx - 1]
		var grow: = minf(1.0, (t - SHAKE_TIME) * 4.0)
		if grow <= 0.01:
			rays = 0
		for i in rays:
			var a: = TAU * i / rays + t * (0.4 + 0.15 * _fx)
			var width: = 0.09 if _fx < 3 else 0.12
			var length: = (700.0 + 120 * _fx) * grow
			var color: = _holy_color if i % 2 == 0 else Color.WHITE
			if _fx == 3:
				color = Color.from_hsv(fmod(i / float(rays) + t * 0.2, 1.0), 0.35, 1.0)
			var pts: = PackedVector2Array([center, center + Vector2.RIGHT.rotated(a - width) * length, 
				center + Vector2.RIGHT.rotated(a + width) * length])
			draw_colored_polygon(pts, Color(color, 0.16 + 0.04 * _fx))
		if _fx >= 2 and grow > 0.01:
			for i in rays:
				var a: = TAU * (i + 0.5) / rays - t * 0.9
				var pts: = PackedVector2Array([center, center + Vector2.RIGHT.rotated(a - 0.05) * 380 * grow, 
					center + Vector2.RIGHT.rotated(a + 0.05) * 380 * grow])
				draw_colored_polygon(pts, Color(1, 1, 1, 0.18))

	var glow: = (t / SHAKE_TIME) if not _opened else 1.0 + 0.1 * sin(t * 6.0)
	if _choosing:
		glow = 0.85 + 0.08 * sin(Time.get_ticks_msec() * 0.004)
	for k in 3:
		draw_circle(center, (90 + 50 * k) * glow * (1.0 + 0.2 * (_fx - 1)), Color(_holy_color, 0.12))
	if _fx == 3 and _opened:
		for k in 3:
			var r: = fmod((t - SHAKE_TIME) * 260.0 + k * 140.0, 420.0)
			draw_arc(center, r, 0, TAU, 64, Color(1, 1, 1, 0.5 * (1.0 - r / 420.0)), 4)
	var sprite: String = Game.theme.pickups.get("blessing_open" if _opened else "blessing", "blessing")
	var tex: = _trophy_tex if _trophy_tex else Game.theme.texture(sprite)
	var pop: = 1.0
	if _opened:
		pop = 1.0 + 0.25 * maxf(0.0, 1.0 - (t - SHAKE_TIME) * 5.0)
	var size: = tex.get_size() * (TROPHY_SCALE if _trophy_tex else CHEST_SCALE) * pop
	if _trophy_tex:
		_draw_head(tex, center, size)
	else:
		draw_texture_rect(tex, Rect2(center - size / 2.0, size), false)
	_draw_overlay(view)



func _draw_head(tex: Texture2D, center: Vector2, size: Vector2) -> void :
	var blood: Color = Game.theme.ui["hp"]
	draw_circle(center, size.x * 0.7, Color(blood.darkened(0.7), 0.4))
	draw_circle(center, size.x * 0.56, Color(blood.darkened(0.5), 0.5))
	if _choosing:
		var tilt: = -0.12 + 0.03 * sin(Time.get_ticks_msec() * 0.002)
		draw_set_transform(center + Vector2(0, _oy), tilt, Vector2.ONE)
		draw_rect(Rect2( - size.x * 0.38, size.y * 0.5 - 14, size.x * 0.76, 18), blood.darkened(0.3))
		draw_texture_rect(tex, Rect2( - size / 2.0, size), false)
		draw_set_transform(Vector2(0, _oy))
		return
	var px: = size.x / tex.get_width()
	var top: = center - size / 2.0
	var top_h: = _head_top.get_height() * px
	var hole: = Vector2(center.x, top.y + top_h)
	var bottom_rect: = Rect2(Vector2(top.x, hole.y), Vector2(size.x, size.y - top_h))
	var holy: = _holy_color
	if not _opened:

		var build: = clampf(_time / SHAKE_TIME, 0.0, 1.0)
		var lift: = build * build * 14.0
		draw_rect(Rect2(bottom_rect.position + Vector2(0, size.y - top_h - 10), Vector2(size.x, 18)).grow_individual( - size.x * 0.12, 0, - size.x * 0.12, 0), blood.darkened(0.3))
		draw_texture_rect(_head_bottom, bottom_rect, false)
		var crack: = Rect2(top.x + size.x * 0.08, hole.y - lift - 2.0, size.x * 0.84, lift + 4.0)
		draw_rect(crack, Color(holy, 0.35 + 0.6 * build))
		draw_rect(crack.grow_individual(0, - crack.size.y * 0.35, 0, - crack.size.y * 0.35), Color(1, 1, 1, 0.8 * build))
		for i in 5:
			var x: = top.x + size.x * (0.15 + 0.17 * i) + sin(_time * 30.0 + i) * 4.0
			PixelFx.dot(self, Vector2(x, hole.y - lift * 0.5 - build * 20.0 * fmod(_time * 3.0 + i * 0.3, 1.0)), Color(holy.lightened(0.4), build), 2)
		draw_texture_rect(_head_top, Rect2(top - Vector2(0, lift), Vector2(size.x, top_h)), false)
		return

	var since: = _time - SHAKE_TIME
	var beam: = minf(since * 4.0, 1.0)
	var flick: = 0.85 + 0.15 * sin(_time * 9.0)
	var w: = size.x * 0.42
	draw_colored_polygon(PackedVector2Array([hole + Vector2( - w, 0), hole + Vector2(w, 0), 
		hole + Vector2(w * 2.2, -900.0 * beam), hole + Vector2( - w * 2.2, -900.0 * beam)]), Color(holy, 0.28 * flick))
	draw_colored_polygon(PackedVector2Array([hole + Vector2( - w * 0.45, 0), hole + Vector2(w * 0.45, 0), 
		hole + Vector2(w * 0.9, -900.0 * beam), hole + Vector2( - w * 0.9, -900.0 * beam)]), Color(1, 1, 1, 0.3 * flick))
	draw_rect(Rect2(bottom_rect.position + Vector2(size.x * 0.12, size.y - top_h - 10), Vector2(size.x * 0.76, 18)), blood.darkened(0.3))
	draw_texture_rect(_head_bottom, bottom_rect, false, Color(1.2, 1.15, 1.05))
	draw_set_transform(Vector2(0, _oy))

	draw_rect(Rect2(hole + Vector2( - size.x * 0.4, -5), Vector2(size.x * 0.8, 8)), blood.darkened(0.2))
	draw_rect(Rect2(hole + Vector2( - size.x * 0.34, -3), Vector2(size.x * 0.68, 4)), Color(holy.lightened(0.3), flick))
	var lid_center: = Vector2(center.x, top.y + top_h / 2.0) + _lid_pos
	if lid_center.y < 1500.0:
		draw_set_transform(lid_center + Vector2(0, _oy), _lid_rot, Vector2.ONE)
		draw_texture_rect(_head_top, Rect2(Vector2( - size.x / 2.0, - top_h / 2.0), Vector2(size.x, top_h)), false)
		draw_rect(Rect2(Vector2( - size.x * 0.36, top_h / 2.0 - 4), Vector2(size.x * 0.72, 6)), blood.darkened(0.15))
		draw_set_transform(Vector2(0, _oy))


func _draw_flyers() -> void :
	var from: = _hole()
	for f in _flyers:
		var t: float = f["t"]
		var e: = t * t * (3.0 - 2.0 * t)
		var to: = _slot_pos(f["slot"])
		var p: = from.lerp(to, e) + Vector2(0, -260.0 * sin(PI * t))
		var s: = 0.5 + 0.5 * e
		for k in 4:
			var tk: = maxf(t - 0.05 * (k + 1), 0.0)
			var ek: = tk * tk * (3.0 - 2.0 * tk)
			var pk: = from.lerp(to, ek) + Vector2(0, -260.0 * sin(PI * tk))
			draw_circle(pk, 20.0 - k * 4.0, Color(_holy_color, 0.25 - k * 0.05))
		draw_circle(p, 40.0 * s, Color(_holy_color, 0.35))
		var tex: Texture2D = f["tex"]
		if tex:
			var fit: = 80.0 * s / maxf(tex.get_width(), tex.get_height())
			var sz: = tex.get_size() * fit
			draw_texture_rect(tex, Rect2(p - sz / 2.0, sz), false)

func _draw_overlay(view: Vector2) -> void :
	_draw_flyers()
	_draw_souls()
	for p in _particles:
		var a: float = p["life"] / p["max_life"]
		draw_circle(p["pos"], p["size"] * (0.5 + 0.5 * a), Color(p["color"], a))
	if _flash > 0.0:
		draw_rect(Rect2(Vector2(0, - _oy), view), Color(_flash_color, minf(_flash, 1.0) * 0.85))

func _draw_ascension(view: Vector2) -> void :
	var r: = _asc_reward
	var hc: Color = r["holy_color"]
	var oc: Color = r["old_color"]
	var t: = _asc_t
	var since: = maxf(0.0, t - ASC_CHARGE)
	var after: = t >= ASC_CHARGE
	var c: = ASC_CENTER + _shake
	if after:
		c.y += sin(since * 3.0) * 8.0
		draw_rect(Rect2(Vector2(0, - _oy), view), Color(hc.darkened(0.75), minf(since * 2.0, 1.0) * 0.5))
		var grow: = minf(1.0, since * 3.0)
		for i in 18:
			var a: = TAU * i / 18.0 + t * 0.5
			var col: = hc if i % 2 == 0 else Color.WHITE
			var pts: = PackedVector2Array([c, c + Vector2.RIGHT.rotated(a - 0.07) * 1100.0 * grow, c + Vector2.RIGHT.rotated(a + 0.07) * 1100.0 * grow])
			draw_colored_polygon(pts, Color(col, 0.2))
		for i in 10:
			var a: = TAU * (i + 0.5) / 10.0 - t * 1.1
			var pts: = PackedVector2Array([c, c + Vector2.RIGHT.rotated(a - 0.05) * 520.0 * grow, c + Vector2.RIGHT.rotated(a + 0.05) * 520.0 * grow])
			draw_colored_polygon(pts, Color(1, 1, 1, 0.2))
		for k in 4:
			var rr: = since * 900.0 - k * 170.0
			if rr > 0.0:
				var ring_color: = hc if k % 2 == 0 else Color.WHITE
				draw_arc(c, rr, 0, TAU, 72, Color(ring_color, clampf(1.0 - rr / 1100.0, 0.0, 1.0) * 0.8), 6.0)
		for side: float in [-1.0, 1.0]:
			var base: = c + Vector2(side * 70.0, 0)
			for f in 5:
				var tip: = base + Vector2(side * (300.0 - f * 30.0) * grow, -170.0 + f * 80.0)
				draw_colored_polygon(PackedVector2Array([base, tip, base + Vector2(side * 30.0, 50.0 + f * 24.0)]), Color(1, 1, 1, 0.09 + 0.02 * f))
	else:
		var build: = t / ASC_CHARGE
		for k in 3:
			draw_circle(c, (60 + 45 * k) * (0.5 + build), Color(oc, 0.14))
		for s in _asc_sparks:
			var dir: = Vector2.RIGHT.rotated(s["ang"])
			var p: = c + dir * float(s["dist"])
			draw_line(p, p + dir * 38.0, Color(oc.lightened(0.4), 0.8), s["size"])
	for k in 3:
		draw_circle(c, (110 + 60 * k) * (1.0 + 0.08 * sin(t * 7.0)), Color(hc if after else oc, 0.14))

	var tex: = Game.theme.texture(r.get("new_icon", r["icon"]) if after else r["icon"])
	var pop: = 1.0 - 0.18 * (t / ASC_CHARGE)
	var tint: = Color.WHITE
	if after:
		pop = 1.0 + 0.55 * maxf(0.0, 1.0 - since * 4.0) + 0.04 * sin(t * 6.0)
		tint = Color(1.0, 1.0, 1.0).lerp(Color(1.4, 1.35, 1.1), minf(since * 3.0, 1.0))
	var size: = tex.get_size() * ASC_SCALE * pop
	draw_texture_rect(tex, Rect2(c - size / 2.0, size), false, tint)

	var font: = ThemeDB.fallback_font
	if not after:
		_draw_plain(font, str(r["old_name"]), Vector2(360, 250), 44, oc.lightened(0.2), 1.0)
	else:
		var fade: = 1.0 - since * 3.0
		if fade > 0.0:
			_draw_plain(font, str(r["old_name"]), Vector2(360, 250 - since * 120.0), 44 + int(since * 40.0), oc.lightened(0.2), fade)
		var banner_k: = clampf((since - 0.2) / 0.3, 0.0, 1.0)
		if banner_k > 0.0:
			draw_set_transform(Vector2(360, 190 + _oy), 0, Vector2.ONE * (1.0 + (1.0 - banner_k) * 1.2))
			_draw_plain(font, str(r.get("banner", "A S C E N D E D")), Vector2.ZERO, 40, Color.WHITE.lerp(hc, 0.4 + 0.4 * sin(t * 5.0)), banner_k)
			draw_set_transform(Vector2(0, _oy), 0, Vector2.ONE)
		_draw_slam_text(font, str(r["title"]), Vector2(360, 840), 80, since, 0.35, hc)
		var tag_k: = clampf((since - 1.2) / 0.5, 0.0, 1.0)
		if tag_k > 0.0 and r["tagline"] != "":
			_draw_plain(font, str(r["tagline"]), Vector2(360, 905), 30, Color(1, 1, 1).lerp(hc, 0.5), tag_k)
		if _asc_skip or t >= ASC_SKIP_AFTER:
			_draw_plain(font, "tap to continue", Vector2(360, 1180), 24, Color(1, 1, 1), 0.4 + 0.3 * sin(t * 4.0))

func _draw_plain(font: Font, text: String, center: Vector2, font_size: int, color: Color, alpha: float) -> void :
	var w: = font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
	var pos: = Vector2(center.x - w / 2.0, center.y + font_size * 0.35)
	draw_string_outline(font, pos, text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, 10, Color(0, 0, 0, alpha))
	draw_string(font, pos, text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color(color, alpha))



func _draw_slam_text(font: Font, text: String, center: Vector2, font_size: int, since: float, start: float, base: Color) -> void :
	while font_size > 28 and font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x > 660.0:
		font_size -= 2
	var x: = center.x - font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x / 2.0
	for i in text.length():
		var ch: = text[i]
		var adv: = font.get_string_size(ch, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
		var k: = clampf((since - start - i * 0.05) / 0.25, 0.0, 1.0)
		if k > 0.0:
			var shimmer: = maxf(0.0, sin(since * 5.0 - i * 0.45))
			var col: = base.lerp(Color.WHITE, clampf((1.0 - k) + shimmer * 0.4, 0.0, 1.0))
			var s: = 1.0 + (1.0 - k) * 1.8
			var y: = center.y + sin(since * 3.0 + i * 0.5) * 5.0 * k
			draw_set_transform(Vector2(x + adv / 2.0, y + _oy), 0, Vector2(s, s))
			var p: = Vector2( - adv / 2.0, font_size * 0.35)
			draw_string_outline(font, p, ch, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, 16, Color(0.2, 0.1, 0.0, k))
			draw_string(font, p, ch, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color(col, k))
		x += adv
	draw_set_transform(Vector2(0, _oy), 0, Vector2.ONE)



func _build_ui() -> void :
	_title = Label.new()
	_title.text = Game.theme.blessing_name
	_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_title.position = Vector2(0, 150)
	_title.size = Vector2(720, 80)
	_title.add_theme_font_size_override("font_size", 56)
	_title.add_theme_color_override("font_color", _holy_color)
	_title.add_theme_color_override("font_outline_color", Color(0.25, 0.15, 0.0))
	_title.add_theme_constant_override("outline_size", 14)
	add_child(_title)

	_subtitle = Label.new()
	_subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_subtitle.position = Vector2(0, 230)
	_subtitle.size = Vector2(720, 40)
	_subtitle.add_theme_font_size_override("font_size", 28)
	_subtitle.add_theme_color_override("font_color", Color(1, 1, 1, 0.8))
	_subtitle.add_theme_color_override("font_outline_color", Color.BLACK)
	_subtitle.add_theme_constant_override("outline_size", 8)
	_subtitle.hide()
	add_child(_subtitle)

	_pool_box = VBoxContainer.new()
	_pool_box.position = Vector2(40, 560)
	_pool_box.size = Vector2(640, 500)
	_pool_box.add_theme_constant_override("separation", 22)
	_pool_box.hide()
	add_child(_pool_box)

	_list = VBoxContainer.new()
	_list.position = Vector2(40, 640)
	_list.size = Vector2(640, 420)
	_list.add_theme_constant_override("separation", 16)
	_list.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_list)

	_continue = Button.new()
	_continue.text = "Continue"
	_continue.position = Vector2(210, 1110)
	_continue.size = Vector2(300, 100)
	_continue.add_theme_font_size_override("font_size", 36)
	for state: String in ["normal", "hover", "pressed", "focus"]:
		var style: = StyleBoxFlat.new()
		style.bg_color = Game.theme.ui["panel"] if state != "pressed" else (Game.theme.ui["panel"] as Color).lightened(0.15)
		style.border_color = _holy_color
		style.set_border_width_all(3)
		style.set_corner_radius_all(12)
		style.draw_center = state != "focus"
		_continue.add_theme_stylebox_override(state, style)
	_continue.pressed.connect(_on_continue)
	add_child(_continue)

	_bonus = Button.new()
	_bonus.text = "+1 Blessing\n(watch a video)"

	_bonus.position = Vector2(380, 1110)
	_bonus.size = Vector2(300, 100)
	_bonus.add_theme_font_size_override("font_size", 26)
	for state: String in ["normal", "hover", "pressed", "focus", "disabled"]:
		var style: = StyleBoxFlat.new()
		style.bg_color = (Game.theme.ui["panel"] as Color).lightened(0.08 if state != "pressed" else 0.2)
		style.border_color = Color(_holy_color, 0.5 if state == "disabled" else 1.0)
		style.set_border_width_all(3)
		style.set_corner_radius_all(12)
		style.draw_center = state != "focus"
		_bonus.add_theme_stylebox_override(state, style)
	_bonus.pressed.connect(_on_bonus)
	_bonus.hide()
	add_child(_bonus)

func _reward_row(r: Dictionary) -> PanelContainer:
	var holy: bool = r["holy"]
	var panel: = PanelContainer.new()
	panel.custom_minimum_size = Vector2(640, _row_height())
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style: = StyleBoxFlat.new()
	style.bg_color = Color(r.get("holy_color", _holy_color), 0.3) if holy else Game.theme.ui["panel"]
	style.border_color = Color.WHITE if holy else _holy_color
	style.set_border_width_all(4 if holy else 2)
	style.set_corner_radius_all(12)
	style.set_content_margin_all(12)
	panel.add_theme_stylebox_override("panel", style)
	var hbox: = HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 18)
	panel.add_child(hbox)
	var icon: = TextureRect.new()
	icon.texture = Game.theme.texture(r.get("new_icon", r["icon"])) if r["icon"] != "" else null
	icon.custom_minimum_size = Vector2(80, 80)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	if holy:
		icon.modulate = Color(1.3, 1.25, 1.0)
	hbox.add_child(icon)
	var text: = VBoxContainer.new()
	text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	text.alignment = BoxContainer.ALIGNMENT_CENTER
	hbox.add_child(text)
	var accent: Color = r.get("holy_color", _holy_color)
	if holy:
		var tag: = Label.new()
		tag.text = str(r.get("banner", "A S C E N D E D"))
		tag.add_theme_font_size_override("font_size", 16)
		tag.add_theme_color_override("font_color", Color.WHITE)
		tag.add_theme_color_override("font_outline_color", accent.darkened(0.6))
		tag.add_theme_constant_override("outline_size", 6)
		text.add_child(tag)
	var title: = Label.new()
	title.text = r["title"]
	title.add_theme_font_size_override("font_size", 34 if holy else 30)
	title.add_theme_color_override("font_color", accent if holy else Color.WHITE)
	title.add_theme_color_override("font_outline_color", Color.BLACK)
	title.add_theme_constant_override("outline_size", 6)
	text.add_child(title)
	var desc: = Label.new()
	desc.text = r["text"]
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc.add_theme_font_size_override("font_size", 22)
	desc.add_theme_color_override("font_color", Color(0.85, 0.85, 0.85))
	text.add_child(desc)
	return panel



func _step_souls(delta: float) -> void :
	if _souls_t < 0.0:
		return
	_souls_t += delta
	_souls_punch = maxf(0.0, _souls_punch - delta * 4.0)
	var landed: = 0
	for b in _souls_bits:
		b["t"] = float(b["t"]) + delta
		var t: float = b["t"]
		if t < 0.0:
			continue
		if t < SOUL_RISE:
			b["vel"] = (b["vel"] as Vector2) * (1.0 - 2.2 * delta) + Vector2(0, 900) * delta
			b["pos"] = (b["pos"] as Vector2) + (b["vel"] as Vector2) * delta
			b["from"] = b["pos"]
		elif t < SOUL_RISE + SOUL_HOME:
			var k: = (t - SOUL_RISE) / SOUL_HOME
			var from: Vector2 = b["from"]
			var mid: = from.lerp(SOUL_COUNTER, 0.5) + Vector2(0, -120)
			b["pos"] = from.lerp(mid, k).lerp(mid.lerp(SOUL_COUNTER, k), k)
		else:
			_souls_shown += float(b["value"])
			_souls_punch = 1.0
			Game.sfx("coin", 1.0 + minf(_souls_shown / maxf(_souls_total, 1.0), 1.0) * 0.6)
			landed += 1
			b["done"] = true
	if landed > 0:
		_souls_bits = _souls_bits.filter( func(b: Dictionary) -> bool: return not b.get("done", false))
		if _souls_bits.is_empty():
			_souls_shown = _souls_total
			_souls_punch = 1.6
			if _chest_souls <= 0:
				Game.sfx("jackpot")
				_spawn_particles(30, SOUL_COUNTER, Color(0.6, 0.9, 1.0))
			else:
				_spawn_particles(10, SOUL_COUNTER, Color(0.6, 0.9, 1.0))

func _draw_souls() -> void :
	if _souls_t < 0.0:
		return
	var soul: = Game.theme.texture(Game.theme.pickups.get("coin", "coin"))
	for b in _souls_bits:
		if float(b["t"]) < 0.0:
			continue
		var p: Vector2 = b["pos"]
		draw_circle(p, 16.0, Color(0.5, 0.85, 1.0, 0.25))
		var sz: = soul.get_size() * 3.0
		draw_texture_rect(soul, Rect2(p - sz / 2.0, sz), false)

	var a: = clampf(_souls_t * 5.0, 0.0, 1.0)
	var scale: = 1.0 + 0.18 * _souls_punch
	var glow: = Color(0.45, 0.85, 1.0)
	var font: = ThemeDB.fallback_font
	var text: = "+%d" % int(_souls_shown)
	var size: = 58
	var w: = font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	var icon: = soul.get_size() * 4.5
	var full: = icon.x + 14.0 + w
	draw_set_transform(Vector2(0, _oy) + SOUL_COUNTER, 0.0, Vector2.ONE * scale)
	for k in 3:
		draw_circle(Vector2.ZERO, (70.0 + 26.0 * k) * (0.9 + 0.1 * sin(_souls_t * 5.0)), Color(glow, 0.07 * a))
	var plate: = Rect2( - full / 2.0 - 26.0, -44, full + 52.0, 82)
	draw_rect(plate, Color(0.03, 0.06, 0.12, 0.85 * a))
	draw_rect(plate, Color(glow, 0.9 * a), false, 3.0)
	draw_texture_rect(soul, Rect2(Vector2( - full / 2.0, - icon.y / 2.0), icon), false, Color(1, 1, 1, a))
	var x: = - full / 2.0 + icon.x + 14.0
	draw_string_outline(font, Vector2(x, 20), text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, 10, Color(0, 0.05, 0.15, a))
	draw_string(font, Vector2(x, 20), text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, Color(0.85, 0.97, 1.0, a))
	draw_set_transform(Vector2(0, _oy))
