extends Control

const MAX_RADIUS: = 100.0
const KNOB_RADIUS: = 40.0
var direction: = Vector2.ZERO
var _touch_index: = -1
var _origin: = Vector2.ZERO

var _player: Node2D

func _ready() -> void :
	mouse_filter = Control.MOUSE_FILTER_IGNORE


	process_mode = Node.PROCESS_MODE_ALWAYS
	_player = get_tree().get_first_node_in_group("player")


func _blocked() -> bool:
	return get_tree().paused

func _process(_delta: float) -> void :
	if _blocked() and _touch_index != -1:
		_touch_index = -1
		direction = Vector2.ZERO
		queue_redraw()

func _input(event: InputEvent) -> void :
	if _blocked():
		return
	if event is InputEventScreenTouch:
		if event.pressed and _touch_index == -1 and not _on_ui(event.position):
			_touch_index = event.index
			_origin = event.position
			queue_redraw()
		elif not event.pressed and event.index == _touch_index:
			_touch_index = -1
			direction = Vector2.ZERO
			queue_redraw()
	elif event is InputEventScreenDrag and event.index == _touch_index:
		direction = ((event.position - _origin) / MAX_RADIUS).limit_length(1.0)
		queue_redraw()


func _on_ui(pos: Vector2) -> bool:
	for c: Control in get_tree().get_nodes_in_group("joystick_block"):
		if c.is_visible_in_tree() and c.get_global_rect().has_point(pos):
			return true
	return false

func _draw() -> void :
	if _touch_index == -1:
		return
	draw_circle(_origin, MAX_RADIUS, Color(1, 1, 1, 0.15))
	draw_arc(_origin, MAX_RADIUS, 0, TAU, 48, Color(1, 1, 1, 0.4), 3)
	draw_circle(_origin + direction * MAX_RADIUS, KNOB_RADIUS, Color(1, 1, 1, 0.5))
