class_name Sigil
extends Weapon




const ID: = "sigil"
const COOLDOWN_TEXT: = "lays sigils %d%% faster"
const BASE: = {"damage": 28.0, "cooldown": 2.6, "count": 1, "area": 1.0}
const UPGRADES: = [
	{"damage": 10.0}, 
	{"cooldown": 0.88}, 
	{"area": 1.2}, 
	{"count": 1}, 
	{"damage": 14.0}, 
	{"cooldown": 0.88}, 
	{"area": 1.2}, 
]



const HOLY: = {"damage": 15.0, "area": 1.1}
const SEAL_RADIUS: = 190.0
const SEAL_FORM: = 0.25
const SEAL_BIND: = 0.9
const SEAL_GAP: = 0.3
const BLAST_RADIUS: = 115.0
const MAX_MINES: = 6

var damage: = 28.0
var cooldown: = 2.6
var count: = 1
var area: = 1.0
var _timer: = 1.0
var _seals: Array[Dictionary] = []
var _time: = 0.0

func _on_level() -> void :
	Layers.put(self, Layers.GROUND_EFFECTS)
	if holy and is_instance_valid(player):
		_star.clear()
		_hexagram(_seal_radius())

func _process(delta: float) -> void :
	_time += delta
	if not _seals.is_empty():
		_update_seals(delta)
	if holy:
		_timer -= delta
		if _timer <= 0.0:
			_timer = cooldown_of(cooldown)
			_seals.append({"at": global_position, "t": 0.0, "blasts": amount_of(count), "done": 0})
		return
	_timer -= delta
	if _timer > 0.0:
		return
	var alive: = get_tree().get_node_count_in_group("sigil_mines")
	var n: = amount_of(count)
	if alive >= MAX_MINES + 2 * n:
		_timer = 0.5
		return
	_timer = cooldown_of(cooldown)
	for i in n:
		var mine: = SigilMine.new()
		mine.damage = power(damage)
		mine.radius = area_of(BLAST_RADIUS * area)
		mine.color = color
		mine.holy = holy
		var spread: = Vector2.ZERO if i == 0 else Vector2.RIGHT.rotated(randf() * TAU) * randf_range(50.0, 120.0)
		mine.global_position = global_position + spread
		get_tree().current_scene.add_child(mine)



var _star: = {}

func _hexagram(r: float) -> Dictionary:
	if _star.get("r", -1.0) != r:
		var lines: Array = []
		for k in 2:
			var pts: = PackedVector2Array()
			for i in 4:
				pts.append(Vector2.RIGHT.rotated(TAU * i / 3.0 + k * PI / 3.0 - PI / 2.0) * r * 0.86)
			lines.append(pts)
		var baked: = PixelFx.bake_polylines(lines, [1.0, 1.0], [[Color(color.darkened(0.7), 0.6), 8.0], 
			[Color(color.lightened(0.3), 0.95), 5.0], [Color(1, 1, 1, 0.55), 1.0]])
		_star = {"r": r, "tex": baked["tex"], "pos": baked["pos"]}
	return _star

func _seal_radius() -> float:
	return area_of(SEAL_RADIUS * area)

func _update_seals(delta: float) -> void :
	var r: = _seal_radius()
	for seal in _seals:
		seal["t"] += delta
		var t: float = seal["t"]
		var at: Vector2 = seal["at"]
		var blasts: int = seal["blasts"]
		var last: = SEAL_BIND + (blasts - 1) * SEAL_GAP
		for e: Enemy in Enemy.near(at, r):
			if at.distance_squared_to(e.global_position) < pow(r + e.radius, 2):
				if t < last:
					e.bind(0.15)
		while seal["done"] < blasts and t >= SEAL_BIND + seal["done"] * SEAL_GAP:
			seal["done"] += 1
			for e: Enemy in Enemy.near(at, r):
				if at.distance_squared_to(e.global_position) < pow(r + e.radius, 2):
					e.take_damage(power(damage))
			Game.sfx("explode", 1.2)
			player.shake(3.0)
	_seals = _seals.filter( func(seal: Dictionary) -> bool: return seal["t"] < SEAL_BIND + (seal["blasts"] - 1) * SEAL_GAP + 0.45)
	queue_redraw()



func _draw() -> void :
	var r: = _seal_radius()
	for seal in _seals:
		var t: float = seal["t"]
		var at: = to_local(seal["at"])
		var form: = clampf(t / SEAL_FORM, 0.0, 1.0)
		var blasts: int = seal["blasts"]
		var end: = SEAL_BIND + (blasts - 1) * SEAL_GAP
		var fade: = 1.0 - clampf((t - end) / 0.45, 0.0, 1.0)
		var rr: = r * form
		PixelFx.disc(self, at, rr, Color(color, 0.12 * fade))
		PixelFx.arc(self, at, rr, 0, TAU, Color(color, 0.9 * fade), 4.0)
		PixelFx.arc(self, at, rr * 0.86, 0, TAU, Color(1, 1, 1, 0.5 * fade), 2.0)



		var spin: = _time * 0.5
		for k in 2:
			var pts: = PackedVector2Array()
			for i in 3:
				pts.append(at + Vector2.RIGHT.rotated(spin + TAU * i / 3.0 + k * PI / 3.0 - PI / 2.0) * rr * 0.86)
			draw_colored_polygon(pts, Color(color, 0.1 * fade))
		var star: = _hexagram(r)
		draw_set_transform(at, spin, Vector2.ONE * form)
		draw_texture(star["tex"], star["pos"], Color(1, 1, 1, fade))
		draw_set_transform(Vector2.ZERO)
		for i in 6:
			var p: = at + Vector2.RIGHT.rotated(spin + TAU * i / 6.0 - PI / 2.0) * rr * 0.86
			PixelFx.disc(self, p, 12.0 * form, Color(color, 0.35 * fade))
			PixelFx.disc(self, p, 7.0 * form, Color(1, 1, 1, 0.9 * fade))
		for i in 12:
			var d: = Vector2.RIGHT.rotated( - _time * 0.3 + TAU * i / 12.0)
			PixelFx.rect(self, Rect2(at + d * rr * 0.93 - Vector2(2, 5), Vector2(4, 10)), Color(1, 1, 1, 0.6 * fade))
		for b in seal["done"]:
			var since: float = t - (SEAL_BIND + b * SEAL_GAP)
			if since < 0.35:
				var k: float = 1.0 - since / 0.35
				PixelFx.disc(self, at, rr, Color(1, 1, 1, 0.35 * k))
				PixelFx.arc(self, at, rr * (1.0 + 0.3 * (1.0 - k)), 0, TAU, Color(color, k), 8.0 * k + 1.0)
