class_name Projectile
extends Node2D

enum Style{ORB, KNIFE, GLAIVE, AXE, TEAR, NAIL, METEOR}





enum Motion{STRAIGHT, BOOMERANG, ARC, BOUNCE, SPIRAL}

@export var radius: = 8.0
@export var lifetime: = 1.5

var direction: = Vector2.RIGHT
var speed: = 700.0
var damage: = 10.0
var pierce: = 1
var style: = Style.ORB
var motion: = Motion.STRAIGHT
var size: = 1.0
var gravity: = 1300.0
var turn: = 0.0
var color: = Color(1, 0.95, 0.5)
var holy: = false
var bounce_burst: = 0.0
const BURST_HOLD: = 0.8
var on_hit: = Callable()
var _velocity: = Vector2.ZERO
var _returning: = false
var _hit: Array[Enemy] = []
var _time: = randf() * 10.0

func _ready() -> void :
	Layers.put(self, Layers.FLYING)
	_velocity = direction * speed
	rotation = direction.angle()
	scale = Vector2.ONE * size

func _process(delta: float) -> void :
	_time += delta
	queue_redraw()
	match motion:
		Motion.BOOMERANG:
			_velocity -= direction * speed * delta
			if not _returning and _velocity.dot(direction) < 0.0:
				_returning = true
				_hit.clear()
			rotation += 18.0 * delta
		Motion.ARC:
			_velocity.y += gravity * delta
			rotation += 10.0 * delta * signf(direction.x + 0.01)
		Motion.BOUNCE:
			_bounce()
		Motion.SPIRAL:
			_velocity = _velocity.rotated(turn * delta)
			turn *= exp(-0.9 * delta)
			rotation += 12.0 * delta * signf(turn + 0.001)
	global_position += _velocity * delta
	lifetime -= delta
	if lifetime <= 0.0:
		queue_free()
		return
	for e: Enemy in Enemy.near(global_position, radius * size):
		if e in _hit:
			continue
		var reach: = radius * size + e.radius
		if global_position.distance_squared_to(e.global_position) < reach * reach:
			_hit.append(e)
			e.take_damage(damage, 0.5 if style == Style.KNIFE or style == Style.NAIL else 1.0)
			if on_hit.is_valid():
				on_hit.call(e)
			pierce -= 1
			if pierce <= 0:
				queue_free()
				return


func _bounce() -> void :
	var vp: = get_viewport()
	var view: = vp.get_canvas_transform().affine_inverse() * vp.get_visible_rect()
	var p: = global_position + _velocity * get_process_delta_time()
	var turned: = false
	if (p.x < view.position.x and _velocity.x < 0.0) or (p.x > view.end.x and _velocity.x > 0.0):
		_velocity.x = - _velocity.x
		turned = true
	if (p.y < view.position.y and _velocity.y < 0.0) or (p.y > view.end.y and _velocity.y > 0.0):
		_velocity.y = - _velocity.y
		turned = true
	if not turned:
		return
	rotation = _velocity.angle()
	_hit.clear()
	burst()


func burst(mult: = 1.0) -> void :
	if bounce_burst > 0.0:
		var r: = bounce_burst * size
		for e: Enemy in Enemy.near(global_position, r):
			if e.targetable and e.global_position.distance_squared_to(global_position) < pow(r + e.radius, 2):
				e.take_damage(damage * 0.5 * mult, 0.0)
				e.bind(BURST_HOLD)
		RingFx.spawn(get_tree().current_scene, global_position, r, color.lightened(0.4))



func _draw() -> void :
	var hot: = color.lightened(0.55)
	if holy:
		PixelFx.disc(self, Vector2.ZERO, radius * 2.6, Color(color, 0.12 + 0.05 * sin(_time * 10.0)))
		match style:
			Style.ORB:
				_draw_holy_flame()
			Style.KNIFE:
				_draw_holy_blade()
			Style.GLAIVE:
				_draw_holy_wheel()
			Style.AXE:
				_draw_holy_axe()
			Style.TEAR:
				_draw_tear(true)
			Style.NAIL:
				_draw_nail(true)
			Style.METEOR:
				_draw_wormwood()
		return
	match style:
		Style.ORB:
			PixelFx.draw_sprite(self, "fireball", color, int(_time * 14.0), Color.WHITE, Vector2(-3, 0))
			for i in 3:
				var life: = fmod(_time * 3.0 + i * 0.33, 1.0)
				PixelFx.dot(self, Vector2( - radius * (2.4 + life * 3.0), sin(i * 2.7 + _time * 4.0) * radius * (0.4 + life)), Color(hot, 1.0 - life))
		Style.KNIFE:
			for i in 3:
				var y: = (i - 1) * PixelFx.PIXEL * 2.0
				var length: = 14.0 + i * 6.0 + sin(_time * 20.0 + i) * 4.0
				PixelFx.rect(self, Rect2(PixelFx.snap(Vector2(-22 - length, y)), Vector2(length, PixelFx.PIXEL)), Color(color, 0.35))
			PixelFx.draw_sprite(self, "dagger", color)
		Style.GLAIVE:
			for k in [2, 1]:
				draw_set_transform(Vector2.ZERO, -0.3 * k)
				PixelFx.draw_sprite(self, "wheel", color, 0, Color(1, 1, 1, 0.22 / k))
			draw_set_transform(Vector2.ZERO)
			PixelFx.draw_sprite(self, "wheel", color, int(_time * 12.0))
		Style.AXE:
			for k in [2, 1]:
				draw_set_transform(Vector2.ZERO, -0.3 * k * signf(direction.x + 0.01))
				PixelFx.draw_sprite(self, "axe", color, 0, Color(1, 1, 1, 0.2 / k), Vector2(3, 0))
			draw_set_transform(Vector2.ZERO)
			PixelFx.draw_sprite(self, "axe", color, 0, Color.WHITE, Vector2(3, 0))
			return
		Style.TEAR:
			_draw_tear(false)
		Style.NAIL:
			_draw_nail(false)
		Style.METEOR:
			_draw_meteor()



func _draw_nail(is_holy: bool) -> void :
	var iron: = Color(1, 0.86, 0.45) if is_holy else Color(0.62, 0.6, 0.66)
	var dark: = Color(0.08, 0.07, 0.1)
	PixelFx.rect(self, Rect2(PixelFx.snap(Vector2(-30, -1)), Vector2(14, PixelFx.PIXEL)), Color(color, 0.4))
	PixelFx.poly(self, PackedVector2Array([Vector2(14, 0), Vector2(-8, -3.5), Vector2(-8, 3.5)]), dark)
	PixelFx.poly(self, PackedVector2Array([Vector2(12, 0), Vector2(-7, -2), Vector2(-7, 2)]), iron)
	PixelFx.rect(self, Rect2(-12, -6, 5, 12), dark)
	PixelFx.rect(self, Rect2(-11, -5, 3, 10), iron.darkened(0.2))
	PixelFx.line(self, Vector2(-6, -1), Vector2(10, -1), Color(1, 1, 1, 0.55), 1.0)
	if is_holy:
		var c: = Color(1, 1, 1, 0.6 + 0.3 * sin(_time * 14.0))
		PixelFx.line(self, Vector2(-10, -9), Vector2(-10, 9), c, 2.0)
		PixelFx.line(self, Vector2(-15, -3), Vector2(-5, -3), c, 2.0)




func _draw_tear(is_holy: bool) -> void :
	var r: = radius * 1.3
	var ice: = color.lightened(0.3) if is_holy else color
	var deep: = color.darkened(0.5)
	var lit: = Color(1, 0.97, 0.8) if is_holy else Color(0.92, 1, 1)
	var trail: = 6
	for i in trail:
		var k: = float(i) / trail
		PixelFx.rect(self, Rect2(PixelFx.snap(Vector2( - r * (1.4 + k * 5.0), - PixelFx.PIXEL * 0.5)), Vector2(r * 0.8, PixelFx.PIXEL)), Color(ice, 0.55 * (1.0 - k)))

	var turn: = absf(sin(_time * 9.0))
	var w: = r * (0.25 + 0.55 * turn)
	var front: = Vector2(r * 1.9, 0)
	var back: = Vector2( - r * 1.5, 0)
	PixelFx.poly(self, PackedVector2Array([front + Vector2(2, 0), Vector2(0, - w - 2), back - Vector2(2, 0), Vector2(0, w + 2)]), deep)
	PixelFx.poly(self, PackedVector2Array([front, Vector2(0, - w), back, Vector2(0, w)]), ice)
	PixelFx.poly(self, PackedVector2Array([front, Vector2(0, - w), Vector2(r * 0.2, 0)]), lit.lerp(ice, 0.3 + 0.4 * (1.0 - turn)))
	PixelFx.line(self, back, front, Color(lit, 0.6), 1.0)
	if turn > 0.85:
		PixelFx.dot(self, Vector2(r * 0.4, - w * 0.5), Color(1, 1, 1), 3)
	if is_holy:
		var c: = Color(1, 0.95, 0.7, 0.5 + 0.3 * sin(_time * 10.0))
		PixelFx.line(self, Vector2(0, - r * 1.3), Vector2(0, r * 1.3), c, 2.0)
		PixelFx.line(self, Vector2( - r * 0.9, 0), Vector2(r * 0.9, 0), c, 2.0)





func _draw_meteor() -> void :
	var r: = radius
	var hot: = color.lightened(0.5)
	for i in 6:
		var k: = float(i) / 5.0
		var len: = r * (2.2 + 1.4 * sin(PI * k)) * (0.85 + 0.15 * sin(_time * 24.0 + i * 1.7))
		var y: = (k - 0.5) * r * 1.4
		PixelFx.poly(self, PackedVector2Array([Vector2(0, y - r * 0.28), Vector2( - len, y * 0.5), Vector2(0, y + r * 0.28)]), Color(color if i % 2 == 0 else hot, 0.75))
	for i in 4:
		var life: = fmod(_time * 2.5 + i * 0.25, 1.0)
		PixelFx.dot(self, Vector2( - r * (1.5 + life * 4.0), sin(i * 2.3 + _time * 5.0) * r * (0.5 + life)), Color(hot, 1.0 - life), 2)
	PixelFx.disc(self, Vector2.ZERO, r * 1.6, Color(color, 0.3 + 0.1 * sin(_time * 20.0)))
	PixelFx.disc(self, Vector2.ZERO, r * 1.25, Color(hot, 0.45))
	PixelFx.disc(self, Vector2.ZERO, r * 1.05, Color(0.12, 0.05, 0.03))
	PixelFx.disc(self, Vector2.ZERO, r * 0.9, Color(0.42, 0.18, 0.08))
	PixelFx.disc(self, Vector2(r * 0.2, - r * 0.25), r * 0.45, Color(0.62, 0.3, 0.12))
	var glow: = Color(1, 0.85, 0.25, 0.85 + 0.15 * sin(_time * 18.0))
	PixelFx.line(self, Vector2( - r * 0.6, - r * 0.2), Vector2(0, r * 0.1), glow, 2.5)
	PixelFx.line(self, Vector2(0, r * 0.1), Vector2(r * 0.5, - r * 0.4), glow, 2.5)
	PixelFx.line(self, Vector2(0, r * 0.1), Vector2( - r * 0.1, r * 0.65), glow, 2.0)
	PixelFx.disc(self, Vector2(r * 0.55, 0), r * 0.35, Color(hot, 0.8))


func _draw_wormwood() -> void :
	var r: = radius
	for i in 5:
		var k: = float(i) / 4.0
		var len: = r * (3.5 + 2.5 * k) * (0.9 + 0.1 * sin(_time * 16.0 + i))
		PixelFx.poly(self, PackedVector2Array([Vector2(0, - r * (0.9 - 0.15 * i)), Vector2( - len, 0), Vector2(0, r * (0.9 - 0.15 * i))]), 
			Color(Color(0.75, 0.9, 0.4).lerp(color, k), 0.35 + 0.1 * i))
	for i in 8:
		var d: = Vector2.RIGHT.rotated(_time * 2.0 + TAU * i / 8.0)
		PixelFx.line(self, d * r * 0.8, d * r * (1.7 + 0.3 * sin(_time * 9.0 + i)), Color(1, 1, 1, 0.6), 3.0)
	PixelFx.disc(self, Vector2.ZERO, r * 1.1, Color(color, 0.9))
	PixelFx.disc(self, Vector2.ZERO, r * 0.7, Color(1, 0.97, 0.8))
	PixelFx.disc(self, Vector2.ZERO, r * 0.4, Color.WHITE)


func _draw_holy_flame() -> void :
	var r: = radius
	var gold: = color
	var flick: = 0.85 + 0.15 * sin(_time * 30.0)
	for i in 5:
		var life: = fmod(_time * 2.2 + i * 0.2, 1.0)
		var p: = Vector2( - r * (1.6 + life * 5.0), sin(i * 2.3 + _time * 3.0) * r * (0.4 + life * 1.4))
		_feather(p, 0.6 + life * 2.0, r * 0.75 * (1.0 - life * 0.5), Color(1, 1, 1, 0.75 * (1.0 - life)))
	var beat: = sin(_time * 16.0)
	for side: float in [-1.0, 1.0]:
		for f in 3:
			var base: = Vector2( - r * 0.2 - f * r * 0.25, side * r * 0.55)
			var tip: = base + Vector2( - r * (0.9 + f * 0.4), side * r * (2.3 - f * 0.35) * (0.8 + 0.2 * beat))
			PixelFx.poly(self, PackedVector2Array([base, tip, base + Vector2( - r * 0.9, side * r * 0.2)]), Color(1, 1, 1, 0.9 - f * 0.18))
			PixelFx.line(self, base, tip, Color(gold, 0.8), 1.5)
	for layer in 3:
		var w: = r * (1.1 - layer * 0.28)
		var length: = r * (3.4 - layer * 0.9) * flick
		var c: Color = [Color(gold, 0.6), Color(gold.lightened(0.5), 0.9), Color.WHITE][layer]
		PixelFx.poly(self, PackedVector2Array([Vector2(r * 0.4, - w), Vector2( - length * 0.5, - w * 0.6), 
			Vector2( - length, 0), Vector2( - length * 0.5, w * 0.6), Vector2(r * 0.4, w)]), c)
	PixelFx.disc(self, Vector2.ZERO, r * 1.05, Color(gold.lightened(0.4), 0.9))
	PixelFx.disc(self, Vector2(r * 0.15, 0), r * 0.7, Color.WHITE)

func _feather(at: Vector2, angle: float, length: float, c: Color) -> void :
	var d: = Vector2.RIGHT.rotated(angle)
	var side: = d.orthogonal() * length * 0.28
	PixelFx.poly(self, PackedVector2Array([at - d * length * 0.5, at + side, at + d * length * 0.5, at - side * 0.4]), c)



func _draw_holy_blade() -> void :
	var sky: = color
	var big: = Vector2.ONE * 1.5
	for k in [3, 2, 1]:
		draw_set_transform(Vector2( - k * 12.0, 0), (k - 2) * 0.12, big)
		_holy_blade_shape(Color(sky, 0.16), Color(1, 1, 1, 0.12), false)
	draw_set_transform(Vector2.ZERO, 0.0, big)
	_holy_blade_shape(sky, Color.WHITE, true)
	var glint: = fmod(_time * 1.8, 1.0)
	var g: = Vector2(-4 + glint * 26.0, -1)
	PixelFx.poly(self, PackedVector2Array([g + Vector2(0, -6), g + Vector2(1.5, 0), g + Vector2(0, 6), g + Vector2(-1.5, 0)]), Color(1, 1, 1, 0.9 * sin(glint * PI)))
	draw_set_transform(Vector2.ZERO)

func _holy_blade_shape(sky: Color, edge: Color, detail: bool) -> void :
	var outline: = Color(0.1, 0.12, 0.25, sky.a)
	PixelFx.poly(self, PackedVector2Array([Vector2(26, 0), Vector2(-4, -5.5), Vector2(-4, 5.5)]), outline)
	PixelFx.poly(self, PackedVector2Array([Vector2(24, 0), Vector2(-3, -4), Vector2(-3, 0)]), edge)
	PixelFx.poly(self, PackedVector2Array([Vector2(24, 0), Vector2(-3, 0), Vector2(-3, 4)]), sky)
	if not detail:
		return
	var gold: = Color(1, 0.85, 0.35)
	PixelFx.rect(self, Rect2(-7, -10, 4, 20), gold)
	PixelFx.poly(self, PackedVector2Array([Vector2(-7, -10), Vector2(-14, -15), Vector2(-4, -9)]), Color(1, 1, 1, 0.9))
	PixelFx.poly(self, PackedVector2Array([Vector2(-7, 10), Vector2(-14, 15), Vector2(-4, 9)]), Color(1, 1, 1, 0.9))
	PixelFx.rect(self, Rect2(-15, -2.5, 8, 5), Color(0.95, 0.9, 0.75))
	PixelFx.disc(self, Vector2(-17, 0), 3.5, gold)



func _draw_holy_wheel() -> void :
	Projectile.draw_holy_wheel(self, Vector2.ZERO, radius * 1.35, 0.0, - rotation * 2.0, color, _time)

static func draw_holy_wheel(ci: CanvasItem, at: Vector2, r: float, outer: float, inner: float, gold: Color, time: float) -> void :
	ci.draw_set_transform(at, inner)
	PixelFx.arc(ci, Vector2.ZERO, r * 0.55, 0, TAU, Color(1, 1, 1, 0.9), r * 0.16)
	for i in 6:
		var d: = Vector2.RIGHT.rotated(TAU * i / 6.0)
		PixelFx.line(ci, d * r * 0.15, d * r * 0.5, Color(gold.lightened(0.5), 0.9), 2.5)
	ci.draw_set_transform(at, outer)
	PixelFx.arc(ci, Vector2.ZERO, r * 1.05, 0, TAU, Color(gold.darkened(0.3), 0.9), r * 0.36)
	PixelFx.arc(ci, Vector2.ZERO, r * 1.05, 0, TAU, gold, r * 0.24)
	PixelFx.arc(ci, Vector2.ZERO, r * 1.22, 0, TAU, Color(1, 1, 1, 0.5), 2.0)
	for i in 6:
		var d: = Vector2.RIGHT.rotated(TAU * i / 6.0)
		var e: = d * r * 1.05
		PixelFx.disc(ci, e, r * 0.17, Color.WHITE)
		PixelFx.disc(ci, e + d * r * 0.03, r * 0.09, Color(0.25, 0.45, 0.95))
		PixelFx.disc(ci, e + d * r * 0.04, r * 0.04, Color(0.05, 0.05, 0.12))
	PixelFx.disc(ci, Vector2.ZERO, r * 0.16, Color.WHITE)
	for i in 4:
		var d: = Vector2.RIGHT.rotated(TAU * i / 4.0 + time * 2.0)
		PixelFx.poly(ci, PackedVector2Array([d * r * 1.25 + d.orthogonal() * 3.0, d * r * 1.9, d * r * 1.25 - d.orthogonal() * 3.0]), Color(1, 1, 1, 0.55))
	ci.draw_set_transform(Vector2.ZERO)


func _draw_holy_axe() -> void :
	var r: = radius
	var spin: = signf(direction.x + 0.01)
	for k in 6:
		var a0: = -0.25 * k * spin
		PixelFx.arc(self, Vector2.ZERO, r * 2.2, a0 - PI * 0.5 - 0.2, a0 - PI * 0.5 + 0.2, Color(1, 1, 1, 0.22 - k * 0.035), r * 0.8)
		PixelFx.arc(self, Vector2.ZERO, r * 2.2, a0 + PI * 0.5 - 0.2, a0 + PI * 0.5 + 0.2, Color(color, 0.22 - k * 0.035), r * 0.8)
	Projectile.draw_holy_axe(self, Vector2.ZERO, r, 0.0, color)


static func draw_holy_axe(ci: CanvasItem, at: Vector2, r: float, angle: float, gold: Color) -> void :
	ci.draw_set_transform(at, angle)
	var outline: = Color(0.12, 0.08, 0.05)
	var head: = r * 1.3
	PixelFx.rect(ci, Rect2( - r * 2.6, - r * 0.22, r * 4.6, r * 0.44).grow(1.5), outline)
	PixelFx.rect(ci, Rect2( - r * 2.6, - r * 0.22, r * 4.6, r * 0.44), gold.darkened(0.15))
	PixelFx.disc(ci, Vector2( - r * 2.6, 0), r * 0.35, gold)
	for side: float in [-1.0, 1.0]:
		var blade: = PackedVector2Array([Vector2(head + r * 0.3, side * r * 0.2), Vector2(head + r * 0.75, side * r * 1.1), Vector2(head + r * 1.1, side * r * 2.0), 
			Vector2(head, side * r * 1.7), Vector2(head - r * 1.1, side * r * 2.0), Vector2(head - r * 0.75, side * r * 1.1), Vector2(head - r * 0.3, side * r * 0.2)])
		var ring: = blade.duplicate()
		ring.append(blade[0])
		PixelFx.polyline(ci, ring, outline, 3.0)
		PixelFx.poly(ci, blade, gold)
		PixelFx.polyline(ci, PackedVector2Array([Vector2(head - r * 1.1, side * r * 2.0), Vector2(head, side * r * 1.7), Vector2(head + r * 1.1, side * r * 2.0)]), Color.WHITE, 3.5)
	PixelFx.disc(ci, Vector2(head, 0), r * 0.45, Color.WHITE)
	PixelFx.disc(ci, Vector2(head, 0), r * 0.25, gold)
	ci.draw_set_transform(Vector2.ZERO)
