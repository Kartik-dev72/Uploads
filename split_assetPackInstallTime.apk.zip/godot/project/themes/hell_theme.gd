extends GameTheme

const NEW_ART: = true
const ART_V3: = true





func _init() -> void :
	id = "hell"
	display_name = "Hell"
	currency = "Souls"
	music = "res://music/hell.wav"
	title = "HELL SURVIVOR"
	death_title = "YOU DIED"
	devil_tips = {
		"arena_escape": {"lines": ["LEAVING SO SOON?", "MY LITTLE PET HATES COWARDS...", "NOW HE'S ENRAGED!"], "shake": "ENRAGED", 
			"hint": "Out of the ring he hunts you. Step back in to calm him."}, 

		"shop": {"lines": ["BACK ALREADY? AND WITH SOULS...", "BUY ALL THE POWER YOU LIKE...", "I STILL WIN!"], "shake": "STILL", "dim": 0.88, 
			"hint": "You have %d %s: buy a permanent upgrade in Upgrades."}, 
	}
	death_taunts = [
		{"lines": ["YOU WEAKLING...", "I ALWAYS WIN!"], "shake": "ALWAYS"}, 
		{"lines": ["PATHETIC...", "THE HOUSE ALWAYS WINS!"], "shake": "ALWAYS"}, 
		{"lines": ["BACK SO SOON...", "I ALWAYS WIN!"], "shake": "ALWAYS"}, 
		{"lines": ["CRAWL BACK UP, WORM...", "I ALWAYS WIN!"], "shake": "ALWAYS"}, 
		{"lines": ["YOUR SOUL IS MINE...", "I ALWAYS WIN!"], "shake": "ALWAYS"}, 
		{"lines": ["DID THAT HURT...", "GOOD! SUFFER MORE!"], "shake": "SUFFER"}, 
		{"lines": ["THAT WAS IT...", "I BARELY NOTICED YOU!"], "shake": "BARELY"}, 
		{"lines": ["ANOTHER SOUL FOR ME...", "YOU TASTE DELICIOUS!"], "shake": "DELICIOUS"}, 
		{"lines": ["MY LITTLE DEVILS...", "THEY'RE LAUGHING AT YOU!"], "shake": "LAUGHING"}, 
		{"lines": ["SO MUCH FOR A HERO...", "YOU'RE NOTHING!"], "shake": "NOTHING"}, 
		{"lines": ["WHAT A SAD LITTLE FIGHT...", "A DEAD RAT FIGHTS BETTER!"], "shake": "RAT"}, 
		{"lines": ["LEAVING SO SOON...", "YOU'LL NEVER ESCAPE!"], "shake": "NEVER"}, 
		{"lines": ["GO ON, TRY AGAIN...", "I'LL BE WAITING!"], "shake": "WAITING"}, 
		{"lines": ["PRAY ALL YOU WANT...", "NOBODY CAN SAVE YOU!"], "shake": "NOBODY"}, 
		{"lines": ["WEAK. SLOW. DEAD...", "JUST AS I EXPECTED!"], "shake": "EXPECTED"}, 
		{"lines": ["THE FLAMES ATE WELL...", "YOU WERE JUST A SNACK!"], "shake": "SNACK"}, 
		{"lines": ["ANOTHER ONE FOR THE PILE...", "YOUR SOUL IS MINE!"], "shake": "MINE"}, 
		{"lines": ["TOO WEAK, TOO SLOW...", "TOO EASY!"], "shake": "EASY"}, 
		{"lines": ["THE CONTRACT IS CLEAR...", "YOU LOSE, I WIN!"], "shake": "WIN"}, 
		{"lines": ["HERE'S A TIP...", "TRY NOT DYING!"], "shake": "NOT"}, 
		{"lines": ["HOW EMBARRASSING...", "MY GRANNY LASTED LONGER!"], "shake": "LONGER"}, 
		{"lines": ["SAME TIME TOMORROW...", "I NEVER LOSE!"], "shake": "NEVER"}, 
	]
	ambient = {"color": Color(1, 0.5, 0.15)}

	ui = {
		"background": Color(0.08, 0.02, 0.03), 
		"title": Color(1, 0.35, 0.12), 
		"accent": Color(1, 0.7, 0.25), 
		"panel": Color(0.2, 0.06, 0.07), 
		"hp": Color(0.95, 0.15, 0.15), 
		"xp": Color(0.35, 1, 0.4), 
		"xp_big": Color(1, 0.22, 0.3), 
		"warning": Color(1, 0.85, 0.2), 
		"holy": Color(1, 0.93, 0.55), 
		"death": Color(1, 0.45, 0.12), 
		"vignette": Color(0.1, 0.0, 0.04, 0.65), 

		"obstacle_rim": Color(0.38, 0.5, 0.72, 0.32), 
		"prop_rim": Color(1, 0.82, 0.3, 0.85), 
}

	palette = {
		"q": Color(0.13, 0.11, 0.14), 
		"r": Color(0.5, 0.07, 0.09), 
		"g": Color(0.16, 0.12, 0.18), 
		"v": Color(0.32, 0.25, 0.36), 
		"J": Color(0.36, 0.27, 0.26), 
		"j": Color(0.52, 0.38, 0.32), 
		"N": Color(0.42, 0.24, 0.18), 
		"n": Color(0.28, 0.15, 0.12), 
		"Q": Color(0.45, 0.9, 1), 
		"u": Color(0.85, 1, 1), 
		"M": Color(1, 0.45, 0.1), 
		"D": Color(0.2, 0.15, 0.15), 
		"i": Color(0.27, 0.24, 0.31), 
		"I": Color(0.46, 0.42, 0.52), 

		"p": Color(0.66, 0.36, 0.95), 
		"e": Color(0.4, 0.17, 0.6), 
		"x": Color(1.0, 0.35, 0.7), 
		"y": Color(0.65, 0.12, 0.42), 
		"f": Color(0.78, 0.72, 0.62), 
		"c": Color(0.95, 0.9, 0.8), 
		"z": Color(0.55, 0.7, 0.95), 
		"d": Color(0.3, 0.4, 0.65), 
		"k": Color(0.62, 0.15, 0.2), 
		"l": Color(0.32, 0.07, 0.13), 
		"a": Color(0.55, 0.85, 0.3), 
		"U": Color(0.25, 0.48, 0.2), 

		"1": Color(0.78, 0.72, 0.65), 
		"2": Color(0.5, 0.45, 0.43), 
		"3": Color(0.55, 0.65, 0.85), 
		"4": Color(0.3, 0.36, 0.55), 

		"5": Color(1, 0.98, 0.84), 
		"6": Color(0.82, 0.58, 0.16), 
		"7": Color(0.62, 0.82, 1), 
		"8": Color(0.34, 0.5, 0.85), 
}

	weapons = {
		"magic_bolt": {"name": "Hellfire Bolt", "description": "Hurls fireballs at the nearest demon on screen.", "icon": "icon_fireball", 
			"color": Color(1, 0.45, 0.15), "unit": "fireball", "holy_icon": "holy_seraphfire", "holy_name": "Seraphfire", "holy_text": "Fires a nonstop stream of winged flames", "holy_tagline": "Hellfire, cleansed by heaven", "holy_color": Color(1, 0.78, 0.25)}, 
		"throwing_knife": {"name": "Sacrificial Daggers", "description": "Throws daggers the way you're moving.", "icon": "icon_dagger", 
			"color": Color(0.9, 0.25, 0.25), "unit": "dagger", "holy_icon": "holy_absolution", "holy_name": "Blades of Absolution", "holy_text": "A nonstop stream of blades", "holy_tagline": "Every wound forgives", "holy_color": Color(0.6, 0.82, 1)}, 
		"aura": {"name": "Brimstone Ring", "description": "Burns every demon close to you and holds them back.", "icon": "icon_brimstone", 
			"color": Color(1, 0.4, 0.1), "holy_icon": "holy_crown", "holy_name": "Crown of Mercy", "holy_text": "Demons it burns drop little hearts. Healing makes it burn hotter", "holy_tagline": "Mercy for you, none for them", "holy_color": Color(1, 0.7, 0.35)}, 
		"spirit_orbs": {"name": "Damned Souls", "description": "A captured soul circles you and burns what it touches.", "icon": "icon_souls", 
			"color": Color(0.45, 0.95, 1), "unit": "soul", "holy_icon": "holy_choir", "holy_name": "Choir of the Redeemed", "holy_text": "The souls break orbit to dive at demons, then fly back", "holy_tagline": "The damned sing again", "holy_color": Color(0.95, 0.9, 0.6)}, 
		"lightning": {"name": "Hellstorm", "description": "Calls red lightning down on random demons.", "icon": "icon_hellstorm", 
			"color": Color(1, 0.3, 0.2), "unit": "strike", "holy_icon": "holy_wrath", "holy_name": "Heaven's Wrath", "holy_text": "Every bolt strikes twice, and now and then leaves a little heart", "holy_tagline": "The sky answers your prayers", "holy_color": Color(1, 0.88, 0.45)}, 
		"boomerang": {"name": "Infernal Wheel", "description": "A burning wheel thrown at the nearest demon, then back.", "icon": "icon_wheel", 
			"color": Color(1, 0.55, 0.2), "unit": "wheel", "holy_icon": "holy_ezekiel", "holy_name": "Ezekiel's Wheel", "holy_text": "The wheels never return: they circle you all the time", "holy_tagline": "A wheel within a wheel of fire", "holy_color": Color(1, 0.85, 0.2)}, 
		"battle_axe": {"name": "Executioner's Axe", "description": "Lobs heavy axes that arc over and crash down.", "icon": "icon_exec_axe", 
			"color": Color(0.75, 0.2, 0.2), "unit": "axe", "holy_icon": "holy_judgment", "holy_name": "Final Judgment", "holy_text": "A ring of golden axes spirals out through everything", "holy_tagline": "The last verdict falls", "holy_color": Color(1, 0.82, 0.3)}, 
		"holy_water": {"name": "Lava Flask", "description": "Throws flasks that burst into molten pools.", "icon": "icon_lava_flask", 
			"color": Color(1, 0.5, 0.1), "unit": "flask", "holy_icon": "holy_baptism", "holy_name": "Baptismal Flood", "holy_text": "Pools of holy water follow you and grow as they move", "holy_tagline": "Drown them in grace", "holy_color": Color(0.6, 0.85, 1)}, 
		"whip": {"name": "Chain of Torment", "description": "Lashes a wide strip beside you.", "icon": "icon_chain", 
			"color": Color(0.75, 0.3, 0.25), "unit": "lash", "holy_icon": "holy_salvation", "holy_name": "Chain of Salvation", "holy_text": "Crits more often, and every crit heals you", "holy_tagline": "Bound to mercy, bound to win", "holy_color": Color(0.95, 0.9, 0.55)}, 
		"familiar": {"name": "Imp Familiar", "description": "A tame imp circles you and spits fire.", "icon": "icon_familiar", 
			"pet_sprite": "v2_familiar", "holy_pet_sprite": "v2_cherub", 
			"color": Color(1, 0.4, 0.25), "unit": "imp", "holy_icon": "holy_cherub", "holy_name": "Shepherd of Souls", "holy_text": "Demons its fire slays may rise as ghosts that fight for you, fading as they go", "holy_tagline": "Even the damned can be led home", "holy_color": Color(1, 0.95, 0.6)}, 
		"sigil": {"name": "Hex Sigil", "description": "Leaves rune mines that blow up under demons.", "icon": "icon_sigil", 
			"color": Color(0.75, 0.35, 1), "unit": "sigil", "holy_icon": "holy_solomon", "holy_name": "Seal of Solomon", "holy_text": "A giant seal forms around you, binds the demons inside, then blasts them", "holy_tagline": "Binding the unbound", "holy_color": Color(1, 0.9, 0.5)}, 
		"shockwave": {"name": "Doom Bell", "description": "Rarely tolls a blast that hurls back everything near you. It also destroys the loot it touches.", "icon": "icon_bell", 
			"color": Color(0.95, 0.7, 0.35), "unit": "toll", "holy_icon": "holy_trumpet", "holy_name": "Trumpet of Judgment", "holy_text": "Sounds more often, spares the loot and pulls in nearby XP and souls", "holy_tagline": "The last note sounds", "holy_color": Color(1, 0.95, 0.65)}, 
		"bulwark": {"name": "Sacred Bulwark", "description": "A barrier that blocks a hit, then bursts.", "icon": "icon_bulwark", 
			"color": Color(0.45, 0.7, 1), "unit": "charge", "holy_icon": "holy_aegis", "holy_name": "Aegis of Heaven", "holy_text": "A blocked hit also smites the nearest demons with pillars of light", "holy_tagline": "Faith, made solid", "holy_color": Color(1, 0.95, 0.6)}, 

		"winds": {"name": "The Four Winds", "description": "Gusts blow out from you in a cross, pushing demons back.", "icon": "icon_winds", 
			"color": Color(0.86, 0.84, 0.76), "unit": "gust", "holy_icon": "holy_breath", "holy_name": "Breath of God", "holy_text": "Eight winds blow out, then spiral back to you", "holy_tagline": "And the earth fell still", "holy_color": Color(0.8, 0.94, 1)}, 
		"scythe": {"name": "Reaper's Scythe", "description": "Sweeps a half-moon in front of you. What it cuts takes more damage for a moment.", "icon": "icon_scythe", 
			"color": Color(0.7, 0.95, 0.78), "unit": "swing", "holy_icon": "holy_death", "holy_name": "Angel of Death", "holy_text": "A full-circle reap on wings of light. When a doomed demon dies, a cut leaps to the next", "holy_tagline": "None are passed over", "holy_color": Color(0.95, 0.95, 1)}, 
		"maw": {"name": "Abyssal Maw", "description": "Opens a pit in the nearest crowd that drags demons in, then snaps shut.", "icon": "icon_maw", 
			"color": Color(0.62, 0.32, 0.95), "unit": "maw", "holy_icon": "holy_gate", "holy_name": "Gate of Heaven", "holy_text": "Demons dragged to its heart are taken up into the light. It closes in a wide burst", "holy_tagline": "The narrow gate opens", "holy_color": Color(1, 0.92, 0.6)}, 
		"spear": {"name": "Spear of Destiny", "description": "Thrusts a long spear the way you're moving, through every demon in its line.", "icon": "icon_spear", 
			"color": Color(0.95, 0.78, 0.4), "unit": "thrust", "holy_icon": "holy_lance", "holy_name": "Lance of Heaven", "holy_text": "Every thrust leaves a beam of light that keeps burning", "holy_tagline": "It pierced the heavens", "holy_color": Color(1, 0.97, 0.75)}, 

		"requiem": {"name": "Requiem", "description": "A mournful hymn falls through you, grinding every demon above and below.", "icon": "icon_requiem", 
			"color": Color(0.72, 0.62, 0.95), "unit": "hymn", "holy_icon": "holy_dies_irae", "holy_name": "Dies Irae", "holy_text": "Every hymn is a cross: it sweeps sideways through you as well", "holy_tagline": "The day of wrath has come", "holy_color": Color(1, 0.9, 0.55)}, 
		"ravens": {"name": "Grave Ravens", "description": "A raven circles you, dropping bone bombs on the ring of demons around you.", "icon": "icon_ravens", 
			"color": Color(0.55, 0.5, 0.62), "unit": "raven", "holy_icon": "holy_doves", "holy_name": "Noah's Doves", "holy_text": "White doves dive at demons anywhere on screen and burst in light", "holy_tagline": "The flood is over", "holy_color": Color(0.95, 0.97, 1)}, 
		"nails": {"name": "Penitent Nails", "description": "Hammers a volley of iron nails at a random demon.", "icon": "icon_nails", 
			"color": Color(0.7, 0.66, 0.72), "unit": "nail", "holy_icon": "holy_cross_nails", "holy_name": "Nails of the Cross", "holy_text": "Golden nails, and every hit flares into a cross of light", "holy_tagline": "It is finished", "holy_color": Color(1, 0.85, 0.4)}, 
		"sodom": {"name": "Fire of Sodom", "description": "Hurls slow, heavy balls of burning brimstone at random demons.", "icon": "icon_sodom", 
			"color": Color(1, 0.55, 0.15), "unit": "fireball", "holy_icon": "holy_wormwood", "holy_name": "Wormwood", "holy_text": "Two great burning stars that tear through everything", "holy_tagline": "A great star fell from heaven", "holy_color": Color(1, 0.88, 0.45)}, 
		"tear": {"name": "Tear of Cocytus", "description": "A frozen tear that ricochets off the edges of the screen, through every demon it crosses.", "icon": "icon_tear", 
			"color": Color(0.62, 0.9, 1), "unit": "tear", "holy_icon": "holy_tears", "holy_name": "Tears of Mercy", "holy_text": "More tears. They burst into binding frost at every bounce and whenever you are hit", "holy_tagline": "Even the ice weeps", "holy_color": Color(0.9, 0.98, 1)}, 
	}

	passives = {
		"might": {"name": "Demonbane Gauntlet", "icon": "icon_fist"}, 
		"cooldown": {"name": "Hourglass of Ash", "icon": "icon_hourglass"}, 
		"area": {"name": "Forbidden Grimoire", "icon": "icon_tome"}, 
		"amount": {"name": "Twin Halo", "icon": "icon_ring"}, 
		"speed": {"name": "Seraph Feathers", "icon": "icon_feather"}, 
		"magnet": {"name": "Soul Lantern", "icon": "icon_lantern"}, 
		"regen": {"name": "Prayer Beads", "icon": "icon_rosary_beads"}, 
		"max_hp": {"name": "Martyr's Vigor", "icon": "heart"}, 
		"armor": {"name": "Templar Shield", "icon": "icon_shield"}, 
		"growth": {"name": "Morning Star", "icon": "icon_star"}, 
		"crit": {"name": "Executioner's Hood", "icon": "icon_hood"}, 
		"lifesteal": {"name": "Leech Fang", "icon": "icon_fang"}, 
		"bounty": {"name": "Bounty Purse", "icon": "icon_bounty"}, 
		"blast": {"name": "Volatile Blood", "icon": "icon_blast"}, 
		"curse": {"name": "Mark of Cain", "icon": "icon_curse"}, 
		"thorns": {"name": "Crown of Thorns", "icon": "icon_thorns"}, 
		"relic": {"name": "Lazarus Relic", "icon": "icon_relic"}, 
		"censer": {"name": "Holy Censer", "icon": "icon_censer"}, 
		"luck": {"name": "Dunstan's Horseshoe", "icon": "icon_horseshoe"}, 
		"duration": {"name": "Frozen Hourglass", "icon": "icon_frozen_hourglass"}, 
	}


	upgrades = {"reroll": {"icon": "icon_dice"}, "exile": {"icon": "icon_exile"}, "revive": {"icon": "icon_candle"}, "greed": {"icon": "icon_avarice"}, "skip": {"icon": "icon_skip"}}

	pact_title = "SELL YOUR SOUL?"


	pact_taunts = {
		"greedy": ["Just a tiny signature...", "Mmm. I can taste it already.", "Sign... sign... sign...", "Your soul would look lovely on my shelf."], 
		"scared": ["Scared of little old me?", "I don't bite. Much.", "What's the worst that could happen? Eternity?", "Relax. Everybody signs."], 
		"slow": ["It's ONE paragraph.", "Do you need me to read it to you?", "Move your lips if it helps.", "Take your time. I have eternity."], 
		"bored": ["*sigh*", "I've closed deals faster with a goat.", "Riveting. Truly riveting."], 
		"indecisive": ["Sign or don't. Just... decide.", "Your soul isn't worth this much thinking.", "The ink is getting cold.", "Eeny, meeny, miny... damned."], 
		"watch": ["Tick tock.", "I have an apocalypse at four.", "This watch is older than your bloodline.", "Still here. Still waiting."], 
	}
	pacts = {
		"frenzy": {"name": "Blood Frenzy", "text": "+%d%% damage for this run", "icon": "icon_fist"}, 
		"haste": {"name": "Hellwind", "text": "+%d%% move and attack speed for this run", "icon": "icon_feather"}, 
		"vital": {"name": "Unholy Vigor", "text": "+%d max HP for this run", "icon": "heart"}, 
		"greed": {"name": "Soul Tithe", "text": "+%d%% XP and souls for this run", "icon": "icon_avarice"}, 
		"titan": {"name": "Twin Fates", "text": "+%d projectile(s) for weapons that fire them", "icon": "icon_ring"}, 
		"leech": {"name": "Vampiric Pact", "text": "Heal 20 HP every %d kills", "icon": "icon_fang"}, 
		"second_chance": {"name": "Devil's Mercy", "text": "%d free revive(s) this run", "icon": "icon_candle"}, 
	}
	pact_prices = {
		"frail": {"name": "Frail Flesh", "text": "-%d max HP for this run", "icon": "heart"}, 
		"sluggish": {"name": "Leaden Chains", "text": "-%d%% move speed", "icon": "icon_chain"}, 
		"feeble": {"name": "Withered Arm", "text": "-%d%% damage", "icon": "icon_fist"}, 
		"rusted": {"name": "Rusted Hourglass", "text": "Weapons attack %d%% slower", "icon": "icon_hourglass"}, 
		"dim": {"name": "Snuffed Lantern", "text": "-%d%% pickup range", "icon": "icon_lantern"}, 
		"dull": {"name": "Clouded Mind", "text": "-%d%% XP", "icon": "icon_star"}, 
		"debt": {"name": "Soul Debt", "text": "-%d%% souls this run", "icon": "icon_avarice"}, 
		"hunted": {"name": "Mark of the Hunt", "text": "+%d%% more demons hunt you", "icon": "icon_curse"}, 
		"barren": {"name": "Barren Blood", "text": "All HP you restore is %d%% lower", "icon": "icon_rosary_beads"}, 
	}














	difficulties = [
		{"name": "Purgatory", "desc": "Walled graveyards and a creeping fog. The way down begins here.", "hp": 1.0, "speed": 1.0, "rate": 1.0, "elite": 1.0, "souls": 1.0}, 
		{"name": "Inferno", "desc": "Rivers of lava burn all who wade in. Cross at the bridges. Souls x1.25", "hp": 1.3, "boss_hp": 1.2, "speed": 1.03, "rate": 1.12, "elite": 1.25, "damage": 1.35, "souls": 1.25}, 
		{"name": "Abyss", "desc": "The black Styx. Deep water slows, the current carries. Souls x1.5", "hp": 1.45, "boss_hp": 1.3, "speed": 1.04, "rate": 1.18, "elite": 1.4, "damage": 1.9, "souls": 1.5}, 
		{"name": "Oblivion", "desc": "Holes into nothing, and the dark closes in. Souls x1.75", "hp": 1.6, "boss_hp": 1.45, "speed": 1.05, "rate": 1.25, "elite": 1.6, "damage": 2.1, "souls": 1.75}, 
		{"name": "Cocytus", "desc": "The frozen lake at the bottom of hell. Ice sheets: faster for you, but slippery. Souls x2", "hp": 1.4, "boss_hp": 1.3, "speed": 1.05, "rate": 1.05, "elite": 1.2, "damage": 2.5, "souls": 2.0}, 
	]


	win_time = 900.0


	events = [
		{"at": 100, "type": "eruption", "time": 15, "banner": "THE GROUND ERUPTS", "info": "Step out of the red circles. They burn demons too"}, 
		{"at": 330, "type": "blood_moon", "time": 30, "banner": "BLOOD MOON", "info": "Twice the demons, twice the XP"}, 
		{"at": 390, "type": "miniboss", "enemy": "hellbrute", "banner": "A CHAMPION APPROACHES", "info": "Slay it for a blessing"}, 
		{"at": 600, "type": "eruption", "time": 20, "banner": "THE GROUND ERUPTS", "info": "Step out of the red circles. They burn demons too"}, 
		{"at": 660, "type": "blood_moon", "time": 35, "banner": "BLOOD MOON", "info": "Twice the demons, twice the XP"}, 
		{"at": 855, "type": "miniboss", "enemy": "hellbrute", "banner": "A CHAMPION APPROACHES", "info": "Slay it for a blessing"}, 
	]

	survivors = [
		{"id": "exorcist", "riddle": "He read the wrong book aloud, once", "name": "Father Gabriel", "title": "Exorcist", "sprite": "exorcist", "weapon": "magic_bolt", "price": 0, 
			"hp": 100, "perk": "Balanced all-rounder", "levels": [{"level": 5, "growth": 0.1}, {"level": 10, "growth": 0.1}, {"level": 15, "growth": 0.1}], "grows": "+2% XP a level up to Lv 15 (+30%)"}, 
		{"id": "hunter", "riddle": "Her blades find the dark before it finds her", "name": "Hester", "title": "Demon Hunter", "sprite": "hunter", "weapon": "throwing_knife", "price": 500, 
			"hp": 80, "speed": 1.15, "crit": 0.1, "perk": "+15% speed, +10% crit, -20 max HP", "levels": [{"level": 10, "might": 0.1}, {"level": 20, "might": 0.1}, {"level": 30, "might": 0.1}, {"level": 40, "might": 0.1}, {"level": 50, "might": 0.1}], "grows": "+1% damage a level up to Lv 50 (+50%)"}, 
		{"id": "zealot", "name": "Brother Lucan", "title": "Zealot", "sprite": "zealot", "weapon": "whip", "price": 700, "riddle": "He scourges his own sins, and then yours", 
			"hp": 120, "speed": 0.95, "armor": 1, "perk": "+20 max HP, +1 armor, -5% speed", "levels": [{"level": 10, "might": 0.1}, {"level": 20, "might": 0.1}, {"level": 30, "might": 0.1}], "grows": "+1% damage a level up to Lv 30 (+30%)"}, 
		{"id": "plague_doctor", "riddle": "A beaked mask, and a cure worse than any plague", "name": "Doctor Corvus", "title": "Plague Doctor", "sprite": "plague_doctor", "weapon": "holy_water", "price": 900, 
			"hp": 90, "area": 1.2, "perk": "+20% weapon area, -10 max HP", "levels": [], "grows": "+1% weapon area a level up to Lv 41 (+40%)", "area_per_level": 0.01}, 
		{"id": "paladin", "riddle": "A shield that has never taken one step back", "name": "Sir Aldric", "title": "Paladin", "sprite": "paladin", "weapon": "aura", "price": 1500, 
			"hp": 140, "speed": 0.88, "armor": 2, "perk": "+40 max HP, +2 armor, -12% speed", "levels": [{"level": 33, "revives": 1}], "grows": "A free revive at level 33"}, 
		{"id": "chorister", "name": "Cecily", "title": "Chorister", "sprite": "chorister", "weapon": "requiem", "rescue": 1, "riddle": "A voice so pure the stones weep", 
			"hp": 85, "area": 1.15, "duration": 0.15, "perk": "+15% weapon area, +15% effect duration, -15 max HP", "levels": [{"level": 10, "duration": 0.1}, {"level": 20, "duration": 0.1}, {"level": 30, "duration": 0.1}], "grows": "+1% effect duration a level up to Lv 30 (+30%)"}, 
		{"id": "ravenkeeper", "name": "Edgar", "title": "Ravenkeeper", "sprite": "ravenkeeper", "weapon": "ravens", "rescue": 2, "riddle": "Wherever he walks, black wings follow", 
			"hp": 95, "magnet": 1.4, "luck": 0.1, "perk": "+40% pickup range, +10% luck, -5 max HP", "levels": [{"level": 10, "luck": 0.1}, {"level": 20, "luck": 0.1}, {"level": 30, "luck": 0.1}], "grows": "+1% luck a level up to Lv 30 (+30%)"}, 
		{"id": "executioner", "riddle": "His axe has known a thousand necks", "name": "Grimwald", "title": "Executioner", "sprite": "executioner", "weapon": "battle_axe", "price": 4000, 
			"hp": 120, "crit": 0.1, "speed": 0.92, "perk": "+20 max HP, +10% crit, -8% speed", "levels": [{"level": 10, "might": 0.05, "speed": 0.05, "curse": 0.05}, {"level": 20, "might": 0.05, "speed": 0.05, "curse": 0.05}, {"level": 30, "might": 0.05, "speed": 0.05, "curse": 0.05}, {"level": 40, "might": 0.05, "speed": 0.05, "curse": 0.05}], "grows": "+0.5% damage, speed and monsters a level up to Lv 40 (+20%)"}, 
		{"id": "nun", "riddle": "She prays, and the damned answer", "name": "Sister Agnes", "title": "Nun", "sprite": "nun", "weapon": "spirit_orbs", "price": 6000, 
			"hp": 100, "regen": 0.25, "magnet": 1.4, "perk": "Regenerates 15 HP a minute, +40% pickup range", "levels": [{"level": 10, "luck": 0.2}, {"level": 20, "luck": 0.2}, {"level": 30, "luck": 0.2}, {"level": 40, "luck": 0.2}, {"level": 50, "luck": 0.2}], "grows": "+2% luck a level up to Lv 50 (+100%)"}, 
		{"id": "witch", "riddle": "She keeps a little demon as a pet", "name": "Morwen", "title": "Witch", "sprite": "witch", "weapon": "familiar", "rescue": 0, 
			"hp": 85, "growth": 1.25, "perk": "+25% XP, -15 max HP", "levels": [{"level": 10, "cooldown": -0.05}, {"level": 20, "cooldown": -0.05}, {"level": 30, "cooldown": -0.05}], "grows": "Weapons attack 0.5% faster a level up to Lv 30 (15%)"}, 
		{"id": "undertaker", "name": "Mortimer", "title": "Undertaker", "sprite": "undertaker", "weapon": "scythe", "rescue": 3, "riddle": "He has buried everyone. Now he reaps them", 
			"hp": 100, "might": 1.1, "crit": 0.05, "perk": "+10% damage, +5% crit", "levels": [{"level": 10, "might": 0.05, "curse": 0.05}, {"level": 20, "might": 0.05, "curse": 0.05}, {"level": 30, "might": 0.05, "curse": 0.05}], "grows": "+0.5% damage and monsters a level up to Lv 30 (+15%)"}, 
		{"id": "fallen_angel", "riddle": "He fell, but the storm still obeys him", "name": "Azrael", "title": "Fallen Angel", "sprite": "fallen_angel", "weapon": "lightning", "price": 12000, 
			"hp": 80, "might": 1.3, "speed": 1.05, "perk": "+30% damage, +5% speed, -20 max HP", "levels": [{"level": 2, "cooldown": 0.3}, {"level": 3, "cooldown": 0.3}, {"level": 4, "cooldown": 0.3}], "grows": "Attacks far faster at first; it fades by level 4", "start_cooldown": -0.9}, 
		{"id": "crusader", "riddle": "She carries the lance that pierced a god", "name": "Dame Isolde", "title": "Crusader", "sprite": "crusader", "weapon": "spear", "rescue": 4, 
			"hp": 100, "cooldown": 0.9, "speed": 1.05, "perk": "Weapons attack 10% faster, +5% speed", "levels": [], "grows": "Starts at level 2", "start_level": 2}, 
		{"id": "frost_hermit", "name": "Ansgar", "title": "Frost Hermit", "sprite": "frost_hermit", "weapon": "tear", "price": 0, "requires_win": 4, "secret": "A soul lies frozen somewhere far below", 
			"hp": 110, "duration": 0.1, "perk": "+10% effect duration, +10 max HP", "levels": [{"level": 10, "duration": 0.1}, {"level": 20, "duration": 0.1}, {"level": 30, "duration": 0.1}], "grows": "+1% effect duration a level up to Lv 30 (+30%)"}, 
	]

	lore = HellLore.MONSTERS
	elite_lore = HellLore.ELITES
	elite_stand_ins = HellLore.ELITE_STAND_INS
	survivor_lore = HellLore.SURVIVORS

	enemies = {
		"imp": {"name": "Imp", "sprite": "imp", "scale": 2.6, "hp": 6, "speed": 165, "radius": 16, "xp": 1, "motion": "fly"}, 
		"devil": {"name": "Little Devil", "sprite": "devil", "scale": 3.0, "hp": 12, "speed": 105, "radius": 20, "xp": 1}, 
		"cerberus_pup": {"name": "Hellhound Pup", "sprite": "cerberus", "scale": 1.7, "hp": 9, "speed": 180, "radius": 18, "xp": 1, "motion": "gallop"}, 
		"devil_knight": {"name": "Devil Knight", "sprite": "devil_knight", "scale": 3.4, "hp": 28, "speed": 120, "radius": 22, "xp": 2}, 
		"lost_soul": {"name": "Lost Soul", "sprite": "lost_soul", "scale": 3.0, "hp": 18, "speed": 145, "radius": 20, "xp": 2, 
			"motion": "float", "alpha": 0.9}, 
		"hellbrute": {"name": "Hellbrute", "sprite": "hellbrute", "scale": 4.5, "hp": 140, "speed": 68, "radius": 34, "xp": 8}, 

		"hellhound": {"name": "Blazing Hound", "sprite": "hellhound", "scale": 2.0, "hp": 24, "speed": 115, "radius": 22, "xp": 3, "motion": "gallop", 
			"ability": "charge", "every": 3.6, "range": 430, "windup": 0.7, "dash_speed": 560, "dash_time": 0.5}, 
		"hex_imp": {"name": "Hex Imp", "sprite": "hex_imp", "scale": 3.2, "hp": 16, "speed": 95, "radius": 18, "xp": 3, "motion": "fly", 
			"ability": "shoot", "every": 2.6, "range": 560, "hold": 330, "shot_speed": 170, 
			"shot_color": Color(1, 0.35, 0.7)}, 
		"brood_mother": {"name": "Brood Mother", "sprite": "brood_mother", "scale": 3.6, "hp": 70, "speed": 62, "radius": 28, "xp": 5, 
			"ability": "split", "into": "imp", "count": 4}, 

		"magma_slime": {"name": "Magma Slime", "sprite": "magma_slime", "scale": 2.0, "hp": 22, "speed": 95, "radius": 22, "xp": 2, 
			"motion": "hop", "ability": "split", "into": "slimelet", "count": 3}, 
		"slimelet": {"name": "Slimelet", "sprite": "magma_slime", "scale": 1.1, "hp": 5, "speed": 110, "radius": 12, "xp": 1, "motion": "hop"}, 
		"salamander": {"name": "Fire Salamander", "sprite": "salamander", "scale": 2.0, "hp": 16, "speed": 150, "radius": 20, "xp": 2}, 
		"gargoyle": {"name": "Gargoyle", "sprite": "gargoyle", "scale": 2.0, "hp": 40, "speed": 90, "radius": 24, "xp": 3, "motion": "fly"}, 
		"cultist": {"name": "Cultist", "sprite": "cultist", "scale": 2.0, "hp": 20, "speed": 100, "radius": 18, "xp": 2}, 
		"skeleton": {"name": "Skeleton", "sprite": "skeleton", "scale": 2.0, "hp": 14, "speed": 110, "radius": 18, "xp": 1}, 
		"plague_bloat": {"name": "Plague Bloat", "sprite": "plague_bloat", "scale": 2.2, "hp": 60, "speed": 60, "radius": 28, "xp": 4}, 
		"wraith": {"name": "Wraith", "sprite": "wraith", "scale": 2.0, "hp": 18, "speed": 130, "radius": 18, "xp": 2, 
			"motion": "float", "alpha": 0.88}, 
		"ash_spider": {"name": "Ash Spider", "sprite": "ash_spider", "scale": 1.8, "hp": 6, "speed": 175, "radius": 14, "xp": 1, 
			"motion": "skitter"}, 

		"cerberus": {"name": "Hellhound", "sprite": "cerberus", "scale": 4.8, "hp": 1000, "speed": 95, "radius": 56, "motion": "gallop", 
			"xp": 80, "coins": 12, "boss": true, "hits": 2, "tint": Color(1, 0.88, 0.75), "head": [35, 0, 15, 13], 
			"ability": "charge", "every": 4.5, "range": 700, "windup": 0.8, "dash_speed": 1150, "dash_time": 0.45, "lead": 0.7}, 
		"archfiend": {"name": "The Archfiend", "sprite": "archfiend", "scale": 8.0, "hp": 1300, "speed": 75, "radius": 60, 
			"xp": 100, "coins": 15, "boss": true, "hits": 2, "head": [0, 0, 16, 9], 
			"ability": "shoot", "every": 2.8, "range": 800, "hold": 300, "shots": 5, "spread": 0.8, "shot_speed": 250}, 
		"imp_lord": {"name": "Lord of Imps", "sprite": "imp_lord", "scale": 7.0, "hp": 1500, "speed": 110, "radius": 50, 
			"xp": 120, "coins": 18, "boss": true, "hits": 2, "motion": "fly", "head": [0, 0, 16, 10], 
			"ability": "charge", "every": 3.2, "range": 700, "windup": 0.7, "dash_speed": 700, "dash_time": 0.6}, 
	}


	spawn_table = [
		{"enemy": "devil", "weight": 3, "from": 0}, 
		{"enemy": "imp", "weight": 2, "from": 0, "group": 3}, 
		{"enemy": "cerberus_pup", "weight": 1.5, "from": 65, "group": 2}, 
		{"enemy": "magma_slime", "weight": 1.3, "from": 130}, 
		{"enemy": "devil_knight", "weight": 2, "from": 195}, 
		{"enemy": "salamander", "weight": 1.4, "from": 260}, 
		{"enemy": "lost_soul", "weight": 2, "from": 325}, 
		{"enemy": "hellhound", "weight": 1.2, "from": 390}, 
		{"enemy": "cultist", "weight": 1.5, "from": 455}, 
		{"enemy": "hex_imp", "weight": 1.2, "from": 520}, 
		{"enemy": "gargoyle", "weight": 1.0, "from": 585}, 
		{"enemy": "hellbrute", "weight": 0.6, "from": 650}, 
		{"enemy": "brood_mother", "weight": 0.7, "from": 715}, 
	]

	swarms = [
		{"enemy": "imp", "from": 40, "every": 25, "count": [26, 38], "speed": 380, "xp": 2}, 
		{"enemy": "lost_soul", "from": 340, "every": 40, "count": [18, 26], "speed": 320, "xp": 2}, 
	]

	bosses = [
		{"at": 180, "boss": "cerberus", "radius": 500, "spacing": 24, "burn": 10, "burn_out": 20}, 
		{"at": 465, "boss": "archfiend", "radius": 500, "spacing": 24, "burn": 12, "burn_out": 24}, 
		{"at": 735, "boss": "imp_lord", "radius": 500, "spacing": 24, "burn": 12, "burn_out": 24}, 
	]

	props = [
		{"sprite": "coffin", "scale": 3.5, "hp": 15, "radius": 24, "heart_chance": 0.5}, 
		{"sprite": "bone_urn", "scale": 3.0, "hp": 20, "radius": 22, "heart_chance": 0.5}, 
	]

	pickups = {"coin": "soul", "heart": "chalice", "blessing": "blessing", "blessing_open": "blessing_open", 
		"vacuum": "attractor_orb", "purge": "rosary", "freeze": "cocytus_shard", "fever": "golden_calf", "luck": "horseshoe_nail"}
	pickup_names = {"heart": "Healing", "soul_pouch": "Soul Pouch", "soul_coffer": "Soul Coffer", "vacuum": "Attractor", 
		"purge": "Rosary", "freeze": "Shard of Cocytus", "fever": "Golden Calf", "luck": "Horseshoe Nail"}

	map = {

		"ground_dark": Color(0.065, 0.08, 0.1), 
		"ground_light": Color(0.115, 0.135, 0.165), 
		"ground_accent": Color(0.15, 0.1, 0.11), 
		"path": Color(0.36, 0.1, 0.05), 
		"path_edge": Color(0.13, 0.06, 0.06), 
		"path_core": Color(0.58, 0.22, 0.06), 
		"path_heat": Color(0.15, 0.08, 0.08), 

		"style": "plates", "seam": Color(0.03, 0.03, 0.045), "seam_glow": Color(0.6, 0.2, 0.05), 
	}
	map_obstacles = [
		{"sprite": "dead_tree", "scale": 3.0, "radius": 16, "weight": 3}, 
		{"sprite": "obsidian_spires", "scale": 3.5, "radius": 24, "weight": 2}, 
	]
	map_decor = [
		{"sprite": "lava_crack", "scale": 3.0, "weight": 3}, 
		{"sprite": "charred_grass", "scale": 3.0, "weight": 4}, 
		{"sprite": "skull", "scale": 3.0, "weight": 1}, 
		{"sprite": "bones", "scale": 3.0, "weight": 2}, 
		{"sprite": "ember", "scale": 3.0, "weight": 2}, 
	]

	sprites = {

		"dead_tree": [
			"....K.........K.....", 
			"...KnK...K...KnK....", 
			"...KnK..KnK..KnK..K.", 
			"K..KnK..KnK.KnK..KnK", 
			"nK.KnK..KnK.KnK.KnK.", 
			"KnKKnNK.KnKKnK.KnK..", 
			".KnKnNK.KNnnK.KnNK..", 
			"..KnnNK.KNnK.KnNK...", 
			"...KnNnKNnK.KnNK....", 
			"....KnNnNnKKnNK.....", 
			".....KnNNnnnNK......", 
			"......KnNNnNK.......", 
			".......KnNNK........", 
			".......KnNNK........", 
			".......KnMNK........", 
			".......KnNNK........", 
			".......KnNMK........", 
			".......KnNNK........", 
			"......KnnNNnK.......", 
			".....KnnNNNnnK......", 
			"....KnnK.KK.KnK.....", 
			"....KK.......KK.....", 
		], 
		"obsidian_spires": [
			"......K.........", 
			".....KvK........", 
			".....KvgK...K...", 
			"....KvvgK..KvK..", 
			"....KvggK..KvgK.", 
			"..K.KvgMgK.KvgK.", 
			".KvKKvggggKKvggK", 
			".KvgKvgMggKvvggK", 
			"KvvgKvggggKvgMgK", 
			"KvggKvgggggKvggK", 
			"KvgMgKvgggKvgggK", 
			"KvgggKvgMgKvgggK", 
			"KKKKKKKKKKKKKKKK", 
			".KKKKKKKKKKKKKK.", 
		], 
		"lava_crack": [
			"m...........", 
			"Mm..........", 
			".MYm....m...", 
			"..mYMMmMYm..", 
			"......mYMMm.", 
			".......m..Mm", 
			"...........m", 
		], 
		"charred_grass": [
			"K...K", 
			"K.K.K", 
			".KDK.", 
		], 
		"skull": [
			".KKK.", 
			"KXXXK", 
			"XEXEX", 
			"KXXXK", 
			".X.X.", 
		], 
		"bones": [
			"X.....X", 
			".XXXXX.", 
			"X.....X", 
		], 
		"ember": [
			"..O..", 
			".OYO.", 
			"OYWYO", 
			".OYO.", 
			"..O..", 
		], 
		"exorcist": [
			"....KKKKKKK.....", 
			"...KDDDDDDDK....", 
			"...KDSSSSSDK....", 
			"...KSESSSESK....", 
			"...KSSSSSSSK....", 
			"....KSSsSSK.....", 
			"..KKqqWWWqqKK...", 
			".KqqqqWWWqqqqK..", 
			".KqqqqqYqqqqqK..", 
			".KSKqqYYYqqKSK..", 
			"..KKqqqYqqqKK...", 
			"...KqqqYqqqK....", 
			"...KqqqqqqqK....", 
			"...KqqK.KqqK....", 
			"...KKK...KKK....", 
		], 
		"paladin": [
			"....KKKKKKK.....", 
			"...KwwwYwwwK....", 
			"..KwwwwYwwwwK...", 
			"..KwKKKKKKKwK...", 
			"..KwKSESESKwK...", 
			"..KwwwwwwwwwK...", 
			"...KwwwwwwwK....", 
			"..KKGGKKKGGKK...", 
			".KwwGWWYWWGwwK..", 
			".KwwKWYYYWKwwK..", 
			".KGKKWWYWWKKGK..", 
			"..KKKWWYWWKKK...", 
			"...KGGGGGGGK....", 
			"...KwwK.KwwK....", 
			"...KKK...KKK....", 
		], 
		"hunter": [
			"....KKKKKK......", 
			"...KDDDDDDK.....", 
			".KKDDDDDDDDKK...", 
			"KDDDDDDDDDDDDK..", 
			".KKKSSSSSSSKK...", 
			"...KSESSSESK....", 
			"...KSSSSSSSK....", 
			"..KKRRRRRRRKK...", 
			".KLLRRLLLLLLLK..", 
			".KLLLLLYLLLLLK..", 
			".KSKLLLLLLLKSK..", 
			"..KKLLLLLLLKK...", 
			"...KLLK.KLLK....", 
			"...KKK...KKK....", 
		], 
		"nun": [
			"....KKKKKKK.....", 
			"...KqqqqqqqK....", 
			"..KqqWWWWWqqK...", 
			"..KqWSSSSSWqK...", 
			"..KqWSESESWqK...", 
			"..KqWSSSSSWqK...", 
			"..KqqWWWWWqqK...", 
			"..KqqqWWWqqqK...", 
			".KqqqqqYqqqqqK..", 
			".KqqqqYYYqqqqK..", 
			".KSKqqqYqqqKSK..", 
			"..KKqqqYqqqKK...", 
			"..KqqqqqqqqqK...", 
			"..KqqqqqqqqqK...", 
			"...KKKKKKKKK....", 
		], 
		"fallen_angel": [
			".....KKKKK......", 
			"....KAAAAAK.....", 
			"...KAASSSAAK....", 
			"...KASESESAK....", 
			"...KASSSSSAK....", 
			"KK..KASsSAK..KK.", 
			"KWK.KKWWWKK.KWK.", 
			"KWWKWWWWWWWKWWK.", 
			"KWwWKWWYWWKWwWK.", 
			".KwWKWYYYWKWwK..", 
			".KWwKWWYWWKwWK..", 
			"..KKKWWYWWKKK...", 
			"...KWWWWWWWK....", 
			"...KSSK.KSSK....", 
			"...KKK...KKK....", 
		], 
		"obelisk": [
			".....KK.....", 
			"....KvgK....", 
			"...KvvgK....", 
			"...KvggK....", 
			"..KvvgMggK..", 
			"..KvgMMMgK..", 
			"..KvggMggK..", 
			"..KvgMgMgK..", 
			"..KvgggggK..", 
			"..KvgggggK..", 
			".KKKKKKKKKK.", 
			".KvvggggggK.", 
			"KMKKKKKKKKMK", 
			"KKKKKKKKKKKK", 
		], 
		"coffin": [
			"...KKKKKK...", 
			"..KNNNNNNK..", 
			".KNnnnnnnNK.", 
			"KNnnnnnnnnNK", 
			"KNnnnnYnnnNK", 
			"KNnnnYYYnnNK", 
			"KNnnnnYnnnNK", 
			"KNnnnnYnnnNK", 
			".KNnnnnnnNK.", 
			".KNnnnnnnNK.", 
			".KNnnnnnnNK.", 
			"..KNnnnnNK..", 
			"..KNnnnnNK..", 
			"...KKKKKK...", 
		], 
		"bone_urn": [
			"...KKKKKK...", 
			"..KYYYYYYK..", 
			"...KKKKKK...", 
			"..KvvvvvvK..", 
			".KvggggggvK.", 
			"KvggXXXXggvK", 
			"KvgXKXXKXgvK", 
			"KvggXXXXggvK", 
			"KvgggXXgggvK", 
			".KvggggggvK.", 
			"..KvvvvvvK..", 
			"..KKKKKKKK..", 
		], 
		"soul": [
			"...K....", 
			"..KQK...", 
			".KQuQK..", 
			".KQuuQK.", 
			"KQuWWuQK", 
			"KQuWWuQK", 
			".KQuuQK.", 
			"..KKKK..", 
		], 
		"chalice": [
			"KKKKKKKKKK", 
			"KYRRRRRRYK", 
			"KYRRWRRRYK", 
			".KYRRRRYK.", 
			"..KYYYYK..", 
			"...KYYK...", 
			"...KYYK...", 
			"...KYYK...", 
			"..KYYYYK..", 
			"..KKKKKK..", 
		], 

		"blessing": [
			"..KKKKKKKKKKKK..", 
			".KIIIIIYYIIIIIK.", 
			"KIiiiiiYYiiiiiiK", 
			"KIiiiiYYYYiiiiiK", 
			"KiiiiiiYYiiiiiiK", 
			"KggggggYYggggggK", 
			"KYYYYYYYYYYYYYYK", 
			"KKKKKYYMMYYKKKKK", 
			"KIiiiiYMMYiiiiIK", 
			"KiiiiiiYYiiiiiiK", 
			"KiMiiiiiiiiiiMiK", 
			"KggggggggggggggK", 
			"KKKKKKKKKKKKKKKK", 
		], 
		"blessing_open": [
			"..KKKKKKKKKKKK..", 
			".KIiiiiYYiiiiIK.", 
			".KiggggYYggggiK.", 
			".KiggggggggggiK.", 
			"KIiiiiiiiiiiiiIK", 
			"KggYgggWggYgggKK", 
			"KgYWYgYYYgYWYggK", 
			"KYYYYYYRYYYYYYYK", 
			"KYWYYYYYYYYYWYYK", 
			"KKKKKYYMMYYKKKKK", 
			"KIiiiiYMMYiiiiIK", 
			"KiiiiiiYYiiiiiiK", 
			"KiMiiiiiiiiiiMiK", 
			"KggggggggggggggK", 
			"KKKKKKKKKKKKKKKK", 
		], 
		"rosary": [
			"....KKKKKK....", 
			"..KKRRrRRRKK..", 
			"..KRRKKKKRRK..", 
			".KRrK....KrRK.", 
			".KRK......KRK.", 
			".KRrK....KrRK.", 
			"..KRRK..KRRK..", 
			"...KrRKKRrK...", 
			"....KRRRRK....", 
			".....KRrK.....", 
			".....KYYK.....", 
			"...KKKYWKKK...", 
			"..KYYYYWYYYK..", 
			"..KKKKYYKKKK..", 
			".....KYYK.....", 
			".....KYYK.....", 
			".....KYmK.....", 
			".....KKKK.....", 
		], 
		"attractor_orb": [
			"....KKKK....", 
			"..KKQQQQKK..", 
			".KQQuuQQQQK.", 
			".KQuWWuQQQK.", 
			"KQQuWuQQQQBK", 
			"KQQQuuQQQBBK", 
			"KQQQQQQQBBBK", 
			".KQQQQQBBBK.", 
			".KiKBBBBKiK.", 
			"..KiKKKKiK..", 
			"..KIK..KIK..", 
			"...KK..KK...", 
		], 


		"holy_seraphfire": [
			".......KK.......", 
			"......K55K......", 
			"......K55K......", 
			".....K5YY5K.....", 
			"KK...K5YY5K...KK", 
			"K5K.K5Y55Y5K.K5K", 
			"K55KK5Y55Y5KK55K", 
			".K55K5Y55Y5K55K.", 
			".K555KY55YK555K.", 
			"..K55KYYYYK55K..", 
			"...KK6YYYY6KK...", 
			"....K6YOOY6K....", 
			".....K6OO6K.....", 
			"......KOOK......", 
			".......KK.......", 
		], 
		"holy_absolution": [
			"........KK7K.KK5", 
			"........K7KKKK5K", 
			".......KK7KKK5KK", 
			".......K7KKK5KK.", 
			"......KK7KK5KK..", 
			"......K7KK5KKKKK", 
			".....KK7K5KKKK77", 
			"....KK7K5KKK77KK", 
			"...KKY75KK77KKK.", 
			"...KYY5K77KKK...", 
			"...KKYY7KKK.....", 
			"..KKLKKKK.......", 
			".KKLKK..........", 
			"KKLKK...........", 
			"KYKK............", 
			"KKK.............", 
		], 
		"holy_crown": [
			".K.....KK.....K.", 
			"K5K...K57K...K5K", 
			"K5YK..KYYK..KY5K", 
			"KYYK.KYYYYK.KYYK", 
			"KYYYKYYYYYYKYYYK", 
			"KYYYYYYYYYYYYYYK", 
			"KY6YY6YYYY6YY6YK", 
			"KY7YYYY77YYYY7YK", 
			"KYYYYY7557YYYYYK", 
			"K66666677666666K", 
			"KKKKKKKKKKKKKKKK", 
		], 
		"holy_choir": [
			".....KKKKKK.....", 
			"....KY6666YK....", 
			".....KKKKKK.....", 
			"......KKKK......", 
			".....K5WW5K.....", 
			"....K5WWWW5K....", 
			"....K5EWWE5K....", 
			"....K5WWWW5K....", 
			".KK.K5WEEW5K.KK.", 
			"K55KK55WW55KK55K", 
			"K555KK5555KK555K", 
			".K55K.K55K.K55K.", 
			"..K5K..K5K..K5K.", 
			"...KK...KK...KK.", 
		], 
		"holy_wrath": [
			"....KKKK........", 
			"..KK5555KKK.....", 
			".K555555555KK...", 
			"K55555555555wK..", 
			"Kw5555555555wwK.", 
			".KwwwwwwwwwwwK..", 
			"..KKKKYYKKKKK...", 
			".....KYYK.......", 
			"....KYYK........", 
			"...KY5YYYK......", 
			"....KKKYYK......", 
			".....KYYK.......", 
			"....KYYK........", 
			"....KYK.........", 
			"...KYK..........", 
			"...KK...........", 
		], 
		"holy_ezekiel": [
			".....KKKKKK.....", 
			"...KKYW88WYKK...", 
			"..KYYKKKKKKYYK..", 
			".KYKK.KKKK.KKYK.", 
			".KYK.K5555K.KYK.", 
			"KWK.K5KKKK5K.KWK", 
			"K8K.K5K77K5K.K8K", 
			"K8K.K5K77K5K.K8K", 
			"KWK.K5KKKK5K.KWK", 
			".KYK.K5555K.KYK.", 
			".KYKK.KKKK.KKYK.", 
			"..KYYKKKKKKYYK..", 
			"...KKYW88WYKK...", 
			".....KKKKKK.....", 
		], 
		"holy_judgment": [
			".......KK.......", 
			".KK...K55K...KK.", 
			"KWWK..K5YK..KWWK", 
			"KWW5KKKYYKKK5WWK", 
			"KWW55YYYYYY55WWK", 
			"KWW555YYYY555WWK", 
			"KWW55YYYYYY55WWK", 
			"KWW5KKKYYKKK5WWK", 
			"KWWK..K6YK..KWWK", 
			".KK...K6YK...KK.", 
			"......K6YK......", 
			"......K6YK......", 
			"......K6YK......", 
			"......K6YK......", 
			".....K6YY6K.....", 
			"......KKKK......", 
		], 
		"holy_baptism": [
			"......KKKK......", 
			"......KYYK......", 
			".....KKKKKK.....", 
			"......KwWK......", 
			"......KwWK......", 
			".....KK77KK.....", 
			"....K777777K....", 
			"...K77755777K...", 
			"...K75555557K...", 
			"...K77755777K...", 
			"...K87755778K...", 
			"...K88888888K...", 
			"....K888888K....", 
			".....KKKKKK.....", 
		], 
		"holy_salvation": [
			"......KKKK......", 
			".....KYYYYK.....", 
			".....KYKKYK.....", 
			".....KY66YK.....", 
			"......KK6K......", 
			"......KKKK......", 
			".....KYYYYK.....", 
			".....KYKKYK.....", 
			".....KY66YK.....", 
			"......KK6K......", 
			".......KK.......", 
			"......KY5K......", 
			"....KKKY5KKK....", 
			"....K55555YK....", 
			"....KKKY5KKK....", 
			"......KY5K......", 
			"......KY5K......", 
			".......KK.......", 
		], 
		"holy_cherub": [
			".....KKKKKK.....", 
			"....KY6666YK....", 
			".....KKKKKK.....", 
			".....KKKKKK.....", 
			"....KAAAAAAK....", 
			"KK..KSSSSSSK..KK", 
			"K5K.KSESSESK.K5K", 
			"K55KKSSSSSSKK55K", 
			".K55KsSRRSsK55K.", 
			"..K5KKSSSSKK5K..", 
			"...KK.KKKK.KK...", 
		], 
		"holy_solomon": [
			".......K.......", 
			"......KYK......", 
			".....KYYYK.....", 
			"KKKKKYY5YYKKKKK", 
			"KYYYY55555YYYYK", 
			".KYY5555555YYK.", 
			"..KY5555555YK..", 
			"...KY55W55YK...", 
			"..KY5555555YK..", 
			".KYY5555555YYK.", 
			"KYYYY55555YYYYK", 
			"KKKKKYY5YYKKKKK", 
			".....KYYYK.....", 
			"......KYK......", 
			".......K.......", 
		], 
		"holy_trumpet": [
			"............KKK.", 
			"...........K5YYK", 
			"..........K5YYYK", 
			"KK.KKKKKKK5YYYYK", 
			"K6KYYYYYYYYYYY6K", 
			"KK.KKKKKKK6YYYYK", 
			"....KWWWWKK6YYYK", 
			"....KWYWWK.K66YK", 
			"....KYYYWK..KKK.", 
			"....KWYWWK......", 
			"....KWWWWK......", 
			"....KW.KWK......", 
			"....KK..KK......", 
		], 
		"holy_aegis": [
			"...KKKKKKKKKK...", 
			"KK.KYYYYYYYYK.KK", 
			"K5KKY55YY55YKK5K", 
			"K55KYYYYYYYYK55K", 
			"K55KY55YY55YK55K", 
			".K5KY55YY55YK5K.", 
			".K55KY5YY5YK55K.", 
			"..KK.KYYYYK.KK..", 
			"......KYYK......", 
			".......KK.......", 
		], 
		"icon_fireball": [
			"..........KKKK..", 
			".........KRRRK..", 
			"......KKKRRORK..", 
			".....KRROOOORK..", 
			"....KROOYYYOORK.", 
			"...KROYYYYYYORK.", 
			"...KROYYYYYYORK.", 
			"..KROOYYYYYYORK.", 
			"..KROOYYYYYOORK.", 
			".KROOOOYYYOORK..", 
			".KROOOOOOOORK...", 
			"KRROOOOOORRK....", 
			"KRRROORRRKK.....", 
			"KRRRRRKKK.......", 
			".KKKKK..........", 
		], 
		"icon_dagger": [
			"..............KK", 
			".............KRK", 
			"............KRrK", 
			"...........KRrK.", 
			"..........KRrK..", 
			".........KRrK...", 
			"........KRrK....", 
			".......KRrK.....", 
			"......KRrK......", 
			"...KK.KRK.......", 
			"...KYKKK........", 
			"....KYYK........", 
			"...KLKYK........", 
			"..KLLK.KK.......", 
			".KLLK...........", 
			".KKK............", 
		], 
		"icon_brimstone": [
			"........K.......", 
			"......KKRK......", 
			".....KROOOK.....", 
			"...KKKOOYOOKKK..", 
			"..KOOMMMMMMKOOK.", 
			"..KYMOOOOOOMYOK.", 
			".KOMOYYYYYYOMOK.", 
			".KOOOYOYYOYOOOOK", 
			".KMOYOOYYOOYOMOK", 
			".KMOYKKKKKKYOMK.", 
			".KMOYK....KYOMK.", 
			"..KOOYK..KYOOK..", 
			"..KMOYYKKYYOMK..", 
			"...KMOOOOOOMK...", 
			"....KMMMMMMK....", 
			".....KKKKKK.....", 
		], 
		"icon_souls": [
			".......KK.......", 
			".....KKuuK......", 
			"....KQuWWuK.....", 
			"...KQQuWWuK.....", 
			"..KQQQQuuK..K...", 
			"..KQKKKKK..KQK..", 
			"...K.......KQQK.", 
			"...........KQQK.", 
			"..KKK.....KQQQK.", 
			".KuuuK....KuuuK.", 
			".KuWuuK..KuuWuK.", 
			".KuuuQKK..KuuuK.", 
			"..KQQQQQK..KKK..", 
			"...KKQQQK.......", 
			".....KKK........", 
			"................", 
		], 
		"icon_hellstorm": [
			"..........KKKK..", 
			".........KMMMK..", 
			"........KMMMK...", 
			".......KMMMK....", 
			"......KMMMK.....", 
			".....KMMMKKKK...", 
			"....KMMMMMMMK...", 
			"...KKKKKMMMK....", 
			"......KMMMK.....", 
			".....KMMMK......", 
			"....KMMK........", 
			"...KMMK.........", 
			"...KMK..........", 
			"..KMK...........", 
			"..KK............", 
		], 
		"icon_wheel": [
			".......KK.......", 
			"......KOOK......", 
			"....KKKKYYK..K..", 
			"..KKOYOOOOOKKOK.", 
			".KOOYOMKKKMOYOK.", 
			"..KYOMnK.KnMOYK.", 
			"..KOMnnnKnnnMOK.", 
			"..KOKKnnYnnKKOK.", 
			"..KOK.KYYYK.KOK.", 
			"..KOKKnnYnnKKOK.", 
			"..KOMnnnKnnnMOK.", 
			"...KOMnK.KnMOK..", 
			"....KOMKKKMOK...", 
			".....KOOOOOK....", 
			"......KKKKK.....", 
			"................", 
		], 
		"icon_exec_axe": [
			"......KKKKK.......", 
			"....KKWWWwwK......", 
			"...KWWwwwwGGK.....", 
			"..KWWwwwGGGGiK....", 
			"..KWwwwGGGGGiKKKK.", 
			".KWWwwGGGGGiiKNNK.", 
			".KWwwGGGGGiiKNNnK.", 
			".KWwwGGGGiiKNNnK..", 
			".KWwwGGGiiKNNnK...", 
			"..KWwGGiiKNNnK....", 
			"..KWwGiiKNNnK.....", 
			"...KKKKKNNnK......", 
			"......KNNnK.......", 
			".....KNNnK........", 
			"....KNNnK.........", 
			"...KNNnK..........", 
			"..KnNnK...........", 
			"..KKKK............", 
		], 
		"icon_rosary_beads": [
			"....KKKKKKK....", 
			"...KWKWKWKWK...", 
			"..KW.......WK..", 
			".KW.........WK.", 
			".KW.........WK.", 
			".KW.........WK.", 
			"..KW.......WK..", 
			"...KWKWKWKWK...", 
			"....KKKWKKK....", 
			"......KWK......", 
			"......KYK......", 
			".....KKYKK.....", 
			"....KYYYYYK....", 
			".....KKYKK.....", 
			"......KYK......", 
			"......KYK......", 
			"......KKK......", 
		], 
		"icon_hood": [
			".......KK......", 
			"......KvDK.....", 
			".....KvDDDK....", 
			"....KvDDDDDK...", 
			"...KvDDDDDDDK..", 
			"...KvDDDDDDDK..", 
			"..KvDDDDDDDDDK.", 
			"..KvKKKKKKKKDK.", 
			"..KvKRRKKRRKDK.", 
			"..KvKKKKKKKKDK.", 
			"..KvDDDDDDDDDK.", 
			".KvDDDDDDDDDDDK", 
			".KvDDDDDDDDDDDK", 
			"KvDDDDDDDDDDDDDK", 
			"KKKKKKKKKKKKKKKK", 
		], 
		"icon_lantern": [
			".....KKKKK.....", 
			"....KG...GK....", 
			"....KK...KK....", 
			"...KKKKKKKKK...", 
			"..KGGGGGGGGGK..", 
			"..KKKKKKKKKKK..", 
			"..KGKQQQQQKGK..", 
			"..KGKQQuQQKGK..", 
			"..KGKQuuuQKGK..", 
			"..KGKQuWuQKGK..", 
			"..KGKQQuQQKGK..", 
			"..KKKKKKKKKKK..", 
			"..KGGGGGGGGGK..", 
			"...KKKKKKKKK...", 
		], 
		"icon_feather": [
			"..........KKK.", 
			".........KWWWK", 
			"........KWWWWK", 
			".......KWWWWWK", 
			"......KWWwWWK.", 
			".....KWWwWWWK.", 
			"....KWWwWWWK..", 
			"...KWWwWWWK...", 
			"..KWWwWWWK....", 
			"..KWwWWWK.....", 
			".KWwWWKK......", 
			".KwWKK........", 
			"KYKK..........", 
			"KK............", 
		], 
		"icon_bell": [
			"......KKK......", 
			".....KKOKK.....", 
			"....KOOYOOK....", 
			"...KOOYOOOOK...", 
			"...KOYOOOOOK...", 
			"...KOYOOOOOK...", 
			"..KOOYOOOOOOK..", 
			"..KOYOOOOOOmK..", 
			"..KOYOOOOOOmK..", 
			".KOOOOOOOOOmmK.", 
			"KmmmmmmmmmmmmmK", 
			"KKKKKKKKKKKKKKK", 
			"......KGK......", 
			".......K.......", 
		], 
		"icon_candle": [
			"......KKK......", 
			".....KOYOK.....", 
			"....KOYWYOK....", 
			"....KOYWYOK....", 
			".....KOYOK.....", 
			"......KDK......", 
			".....KKKKK.....", 
			".....KWWwK.....", 
			".....KWWwK.....", 
			".....KWWwK.....", 
			".....KWWwK.....", 
			".....KWWwK.....", 
			"...KKKKKKKKK...", 
			"..KYYYYYYYYYK..", 
			"...KKKKKKKKK...", 
		], 
		"icon_horseshoe": [
			"..KKKK....KKKK..", 
			".KIIiK....KiIIK.", 
			".KIYiK....KiYIK.", 
			"KIIiK......KiIIK", 
			"KIYiK......KiYIK", 
			"KIIiK......KiIIK", 
			"KIIiiK....KiiIIK", 
			".KIYiiK..KiiYIK.", 
			".KIIIiiKKiiIIIK.", 
			"..KIIIiiiiIIIK..", 
			"...KKIIIIIIKK...", 
			".....KKKKKK.....", 
		], 
		"icon_skip": [
			"..............", 
			".KK....KK.....", 
			".KYK...KYK....", 
			"..KYK...KYK...", 
			"...KYK...KYK..", 
			"....KYK...KYK.", 
			"...KYK...KYK..", 
			"..KYK...KYK...", 
			".KYK...KYK....", 
			".KK....KK.....", 
			"..............", 
		], 
		"soul_pouch": [
			"....KuK.....", 
			"...KQuQK....", 
			"....KQK.....", 
			"...KYYYK....", 
			"..KnNNNnK...", 
			".KnNNNNNnK..", 
			".KNNNQNNNK..", 
			".KNNQuQNNK..", 
			".KnNNQNNnK..", 
			"..KnnnnnK...", 
			"...KKKKK....", 
		], 
		"soul_coffer": [
			"...KK....KK...", 
			"..KuQK..KQuK..", 
			".KQuQQKKQQuQK.", 
			"KKKKKKKKKKKKKK", 
			"KYNNNNYYNNNNYK", 
			"KYnnnnYYnnnnYK", 
			"KKKKKKKKKKKKKK", 
			"KYNNNKYYKNNNYK", 
			"KYNNNKmmKNNNYK", 
			"KYnnnnKKnnnnYK", 
			"KYNNNNNNNNNNYK", 
			"KYYnnnnnnnnYYK", 
			"KKKKKKKKKKKKKK", 
		], 
		"golden_calf": [
			"...........KK...", 
			"..........KYYK..", 
			"...KKKKKKKYYWK..", 
			"..KYYYYYYYYYYYK.", 
			".KYWYYYYYYYYYYYK", 
			".KYYYYYYYYYYYYmK", 
			".KmYYYYYYYYYYmK.", 
			"..KYmKKKKKKYmK..", 
			"..KYK.....KYK...", 
			"..KmK.....KmK...", 
			".KKKKKKKKKKKKK..", 
			".KmmmmmmmmmmmK..", 
			".KKKKKKKKKKKKK..", 
		], 
		"horseshoe_nail": [
			"KKKKKK..", 
			"KIIIIK..", 
			"KKIiKK..", 
			".KIiK...", 
			".KIiK...", 
			".KIiK...", 
			".KIiK...", 
			".KIiK...", 
			"..KIK...", 
			"..KiK...", 
			"...K....", 
		], 
		"cocytus_shard": [
			"......KK......", 
			".....K7uK.....", 
			"....K87uWK....", 
			"....K87uuK....", 
			"...K887uuWK...", 
			"...K887uuuK...", 
			"..K8887uuuWK..", 
			"..K8887uuuuK..", 
			"..K8887uuuuK..", 
			"...K887uuuK...", 
			"....K87uuK....", 
			".....K87uK....", 
			"......K7K.....", 
			"......K.......", 
		], 
		"icon_exile": [
			"..KKKKKKKKKK..", 
			"..KXXXXXXXXK..", 
			"..KRRXXXXRRK..", 
			"..KXRRXXRRXK..", 
			"..KXXRRRRXXK..", 
			"..KXXXRRXXXK..", 
			"..KXXRRRRXXK..", 
			"..KXRRXXRRXK..", 
			"..KRRXXXXRRK..", 
			"..KXXXXXXXXK..", 
			"..KXwwwwwwXK..", 
			"..KXXXXXXXXK..", 
			"..KKKKKKKKKK..", 
		], 
		"icon_avarice": [
			"......KK......", 
			".....KQQK.....", 
			"....KQuuQK....", 
			"....KQuWQK....", 
			"....KQuuQK....", 
			"..KK.KQQK.KK..", 
			".KQQK.KK.KQQK.", 
			"KQuuQK..KQuuQK", 
			"KQuWQK..KQuWQK", 
			"KQuuQKKKKQuuQK", 
			".KQQKYYYYKQQK.", 
			"..KKKYYYYKKK..", 
			"....KKKKKK....", 
		], 
		"icon_lava_flask": [
			"...KKKK...", 
			"...KGGK...", 
			"...KGGK...", 
			"..KKGGKK..", 
			".KGMMMMGK.", 
			"KGMMYMMMGK", 
			"KMMYMMMMMK", 
			"KMMMMMMMMK", 
			"KMMMMMMRMK", 
			".KMMMMRRK.", 
			"..KKKKKK..", 
		], 
		"icon_chain": [
			"......KKK...", 
			".....KGGGK..", 
			"....KGK.KGK.", 
			"....KGK..KGK", 
			".....KGK.KGK", 
			"......KK.KGK", 
			"........KGK.", 
			"KK.....KGK..", 
			"KGKKKKKGK...", 
			".KGGGGGK....", 
			"..KRRK......", 
			"..KrrK......", 
		], 
	}

	sprites.merge({
		"icon_familiar": [
			"..K......K..", 
			".KRK....KRK.", 
			".KRRKKKKRRK.", 
			"KKRRRRRRRRKK", 
			"KRWWRRRRWWRK", 
			"KRWEWRRWEWRK", 
			"KRRWRRRRWRRK", 
			".KRRRYYRRRK.", 
			".KKRRRRRRKK.", 
			"..KKKKKKKK..", 
		], 
		"icon_sigil": [
			"....KKKK....", 
			"..KKpppPKK..", 
			".KpPPKKPPpK.", 
			".KPKPPPPKPK.", 
			"KpPPKPPKPPpK", 
			"KpPPPKKPPPpK", 
			"KpPPPKKPPPpK", 
			"KpPPKPPKPPpK", 
			".KPKPPPPKPK.", 
			".KpPPKKPPpK.", 
			"..KKpppPKK..", 
			"....KKKK....", 
		], 
		"icon_shockwave": [
			"......KK......", 
			"....KKRRKK....", 
			"..KKRRKKRRKK..", 
			".KRRKKOOKKRRK.", 
			".KRKOOOOOOKRK.", 
			"KRRKOOYYOOKRRK", 
			"KRKOOYYYYOOKRK", 
			"KRKOOYYYYOOKRK", 
			"KRRKOOYYOOKRRK", 
			".KRKOOOOOOKRK.", 
			".KRRKKOOKKRRK.", 
			"..KKRRKKRRKK..", 
			"....KKRRKK....", 
			"......KK......", 
		], 
		"icon_bulwark": [
			".....KKKKK.....", 
			"...KKCCCCCKK...", 
			"..KCCbbbbbCCK..", 
			".KCFbbbbbbbbCK.", 
			".KCbbbbYbbbbCK.", 
			"KCbbbbYYYbbbbCK", 
			"KCbbbYYWYYbbbCK", 
			"KCbbbbYYYbbbbCK", 
			".KCbbbbYbbbbCK.", 
			".KCbbbbbbbbbCK.", 
			"..KCCbbbbbCCK..", 
			"...KKCCCCCKK...", 
			".....KKKKK.....", 
		], 

		"icon_thorns": [
			"....X....X.....", 
			"..KKLKKKKLKK...", 
			".KLLnLLnLLnLK..", 
			"XLnKKKKKKKKnLKX", 
			"KLK.......KKLK.", 
			"KnLK.....KLLnK.", 
			".KLnLKKKKLnLK..", 
			"X.KLLnLLnLLKK.X", 
			"...KKKXKKXKK...", 
			"......KRK......", 
			"......KRK......", 
			".......K.......", 
			"......KRK......", 
			"......KRK......", 
			".......K.......", 
		], 
		"icon_relic": [
			"......KYK......", 
			".....KYWYK.....", 
			"......KYK......", 
			"....KKKYKKK....", 
			"...KYYYYYYYK...", 
			"..KYmKKKKKmYK..", 
			"..KYKrrrrrKYK..", 
			"..KYKWKrKWKYK..", 
			"..KYKXWWWXKYK..", 
			"..KYKWKrKWKYK..", 
			"..KYKrrrrrKYK..", 
			"..KYmKKKKKmYK..", 
			"...KYYYYYYYK...", 
			"....KmYYYmK....", 
			"...KYYYYYYYK...", 
			"...KKKKKKKKK...", 
		], 
		"icon_gargoyle": [
			"..K.........K..", 
			".K1K.......K1K.", 
			".K21K.....K12K.", 
			"..K21KKKKK12K..", 
			"..K222222222K..", 
			".K21222222212K.", 
			".K2KRK222KRK2K.", 
			".K22KK222KK22K.", 
			".K2222K2K2222K.", 
			"..K22KWKWK22K..", 
			"..K2KKKKKKK2K..", 
			"...K2WKWKW2K...", 
			"....KKKKKKK....", 
		], 
		"icon_censer": [
			"....w.....w....", 
			"...w.w...w.....", 
			"....w..K..w.w..", 
			".......KYK.....", 
			"......KIK......", 
			".....KIKIK.....", 
			"....KI...IK....", 
			"...KI.www.IK...", 
			"..KKKKKKKKKKK..", 
			"..KYYYYYYYYYK..", 
			"..KYKOKYKOKYK..", 
			"..KYYYYYYYYYK..", 
			"...KmYYYYYmK...", 
			"....KmYYYmK....", 
			".....KKKKK.....", 
		], 
		"icon_fang": [
			"..KKKKKKKKKK...", 
			".KXXXXXXXXXXK..", 
			".KXWWXXXXXXXK..", 
			"..KXWXXXXXXK...", 
			"..KXWXXXXXXK...", 
			"...KXWXXXXK....", 
			"...KXWXXXK.....", 
			"....KXXXXK.....", 
			"....KXXXK......", 
			".....KXXK......", 
			".....KXRK......", 
			"......KRK......", 
			".......K.......", 
			"......KRK......", 
			"......KKK......", 
		], 
		"icon_dodge": [
			"K...K.......", 
			"KC..KC......", 
			"KCC.KCC.....", 
			"KCCCKCCC....", 
			".KCCCKCCC...", 
			"..KCCCKCCC..", 
			".KCCCKCCC...", 
			"KCCCKCCC....", 
			"KCC.KCC.....", 
			"KC..KC......", 
			"K...K.......", 
		], 
		"icon_bounty": [
			"...KKKKKK...", 
			"....KLLK....", 
			"...KYYYYK...", 
			"..KLLLLLLK..", 
			".KLLLYYLLLK.", 
			"KLLLYLLYLLLK", 
			"KLLLYYYLLLLK", 
			"KLLLLLYLLLLK", 
			"KLLLYYYLLLLK", 
			".KLLLLLLLLK.", 
			"..KKKKKKKK..", 
		], 
		"icon_blast": [
			".....K......", 
			"K...KOK...K.", 
			"KO..KOK..OK.", 
			".KO.KOK.OK..", 
			"..KOOYOOK...", 
			"KKOYYWYYOKK.", 
			"..KOOYOOK...", 
			".KO.KOK.OK..", 
			"KO..KOK..OK.", 
			"K...KOK...K.", 
			".....K......", 
		], 
		"icon_curse": [
			"K..........K", 
			"KP........PK", 
			".KPKKKKKKPK.", 
			".KPPPPPPPPK.", 
			"KPPWWPPWWPPK", 
			"KPWEEWWEEWPK", 
			"KPPWWPPWWPPK", 
			".KPPPKKPPPK.", 
			".KPKPKPKPPK.", 
			"..KKWKWKWKK.", 
			"...KKKKKKK..", 
		], 

		"icon_winds": [
			"..........KKKKK.", 
			"..........KWWWK.", 
			"KKKKKKKKKKKK..WK", 
			"KWWWWWWWWWWWWWK.", 
			"KKKKKKKKKKKKKKK.", 
			"...KKKKKKKKKKKKK", 
			"...KwwwwwwwwwwwK", 
			"...KKKKKKKKKKKKK", 
			"KKKKKKKKKK......", 
			"KWWWWWWWWWWK....", 
			"KKKKKKKKKKKWK...", 
			"........KWWK....", 
			"........KKK.....", 
		], 
		"holy_breath": [
			".......6.......", 
			"...6...6...6...", 
			"....6..6..6....", 
			"......KKK......", 
			"....KK555KK....", 
			"...K5555555KK..", 
			"..K555555555WK.", 
			".K5555555555WK.", 
			"K55555555555WWK", 
			"K5555555555WW7K", 
			".K77777777777K.", 
			"..KKKKKKKKKKK..", 
		], 
		"icon_scythe": [
			"....KKKKKKK.....", 
			"..KKWWWWWWWKK...", 
			".KWWwwwwwwwWNK..", 
			"KWwwKKKKKKKKNK..", 
			"KwwK.......KNK..", 
			"KwK........KNK..", 
			"KwK........KNK..", 
			".KK........KNK..", 
			"..........KNK...", 
			"..........KNK...", 
			"..........KNK...", 
			"..........KNK...", 
			".........KNK....", 
			".........KNK....", 
			".........KNK....", 
			".........KnK....", 
			".........KK.....", 
		], 
		"holy_death": [
			"....KYYYYK......", 
			"...KY....YK.....", 
			"....KYYYYK......", 
			"....KKKKKKK.....", 
			"..KKWWWWWWWKK...", 
			".KWW5555555WYK..", 
			"KW55KKKKKKKKYK..", 
			"K55K.......KYK..", 
			"K5K........KYK..", 
			"K5K........KYK..", 
			".KK........KYK..", 
			"..........KYK...", 
			"..........KYK...", 
			"..........KYK...", 
			"..........KYK...", 
			".........KYK....", 
			".........KYK....", 
			".........KYK....", 
			".........K6K....", 
			".........KK.....", 
		], 
		"icon_maw": [
			"....KKKKKKKK....", 
			"..KKppppppppKK..", 
			".KppKKKKKKKKppK.", 
			"KpKXXXXXXXXXXKpK", 
			"KpKgXggXggXggKpK", 
			"KpKggggggggggKpK", 
			"KpKgggrrrrgggKpK", 
			"KpKggXggXggXgKpK", 
			"KpKXXXXXXXXXXKpK", 
			".KeeKKKKKKKKeeK.", 
			"..KKeeeeeeeeKK..", 
			"....KKKKKKKK....", 
		], 
		"holy_gate": [
			".....KKKK.....", 
			"...KKYYYYKK...", 
			"..KYY5555YYK..", 
			".KY55555555YK.", 
			".KY55555555YK.", 
			"KY5555WW5555YK", 
			"KY555WWWW555YK", 
			"KY55WYWWYW55YK", 
			"KY55WYWWYW55YK", 
			"KY55WYWWYW55YK", 
			"KY55WYWWYW55YK", 
			"KY55WYWWYW55YK", 
			"K6YYYYYYYYYY6K", 
			"KKKKKKKKKKKKKK", 
		], 
		"icon_spear": [
			"...........KKK", 
			"..........KWWK", 
			".........KWWGK", 
			"........KWWGK.", 
			".......KKGGK..", 
			"......KRKKK...", 
			".....KNKRK....", 
			"....KNK.RK....", 
			"...KNK..KK....", 
			"..KNK.........", 
			".KNK..........", 
			"KNK...........", 
			"KK............", 
		], 
		"holy_lance": [
			"........5..KKK", 
			"..........K55K", 
			".........K55WK", 
			"......5.K55WK.", 
			".......KKWWK.5", 
			"......K7KKK...", 
			".....KYK7K....", 
			"....KYK.7K....", 
			"...KYK..KK....", 
			"..KYK.........", 
			".K6K..........", 
			"K6K...........", 
			"KK............", 
		], 
	})



	_build_monsters()
	_build_pact_art()
	_family("_imp", "imp", {"R": "p", "r": "e"})
	_family("_imp", "hex_imp", {"R": "x", "r": "y"})
	_family("_imp", "imp_lord", {"R": "Y", "r": "O", "Y": "R"})
	_family("_devil", "devil", {})
	_family("_devil", "devil_knight", {"R": "z", "r": "d"})
	_family("_hound", "cerberus", {"J": "f", "j": "c", "D": "2"})
	_family("_hound", "hellhound", {"J": "R", "j": "O", "D": "r"})
	_family("_soul", "lost_soul", {})
	_family("_brute", "hellbrute", {"R": "k", "r": "l"})
	_family("_brute", "brood_mother", {"R": "a", "r": "U"})
	_family("_brute", "archfiend", {"R": "p", "r": "e"})
	sprites["dead_tree"] = _recolor(sprites["dead_tree"], {"N": "1", "n": "2"})
	sprites["obsidian_spires"] = _recolor(sprites["obsidian_spires"], {"v": "3", "g": "4"})
	HellMonsters.build(self)
	_build_levels()
	HellArtV2.build(self)
	HellArtV3.build(self)
	if NEW_ART:
		_use_new_art()




func _build_pact_art() -> void :
	var face: = [
		".K..............", 
		"KXK.............", 
		"KXK.............", 
		"KXXK............", 
		"KXwK............", 
		".KXwK.....KKKKKK", 
		".KXXwK..KKRRRRRR", 
		"..KXXwKKRRRRRRRR", 
		"..KXXXwKRRRRRRRR", 
		"...KXXXRRRRRRRRR", 
		"....KKRKKKRRRRRR", 
		"..K.KRRRRKKKKRRR", 
		".KRKRRKYYYYKKRRR", 
		".KrRKRKYYYEYKRRR", 
		"..KrKRRKYYEKRRRR", 
		"..KrrKRRKKKRRRRR", 
		"...KKRrRRRRRRRRr", 
		"....KRrRRRRRRKrr", 
		"....KrRRRRRRRRRR", 
		"....KrKRRRRRRRRR", 
		"....KrKKRRRRRRRR", 
		"....KRRKKKKKKKKK", 
		".....KRKWWKWWKWW", 
		".....KRRKWEEEEEE", 
		"......KRRKEEEEEE", 
		"......KRRKWWKWWK", 
		".......KRRKKKKKK", 
		"........KKRRRRRR", 
		"..........KKrRRR", 
		"............KrRR", 
		"............KKrR", 
		".............KKr", 
		"..............KK", 
	]
	sprites["pact_devil"] = _mirrored(face)
	var mad: = face.duplicate()
	var mad_rows: = {
		10: "....KKRRRRRRRRRR", 
		11: "..K.KRKKRRRRRRRR", 
		12: ".KRKRRRRKKKRRRRR", 
		13: ".KrRKRKYYYEKKKRR", 
		14: "..KrKRRKYYEKRRRR", 
		19: "....KrRRRRRRRRRR", 
		20: "....KrRRRRRRRRRR", 
		21: "....KRRRRKKKKKKK", 
		22: ".....KRRKWKWKWKW", 
		23: ".....KRRKWKWKWKW", 
		24: "......KRKKKKKKKK", 
		25: "......KRRRRRRRRR", 
		26: ".......KRRRRRRRR", 
	}
	for i: int in mad_rows:
		mad[i] = mad_rows[i]
	sprites["pact_devil_mad"] = _mirrored(mad)

	var closed_eyes: = {
		12: ".KRKRRRRRRRKKRRR", 
		13: ".KrRKRKKKKKKKRRR", 
		14: "..KrKRRRRRRRRRRR", 
		15: "..KrrKRRRRRRRRRR", 
	}
	var half_lid: = {
		12: ".KRKRRKKKKKKKRRR", 
		13: ".KrRKRKrrrrrKRRR", 
		14: "..KrKRRKYYEKRRRR", 
		15: "..KrrKRRKKKRRRRR", 
	}
	var shut_mouth: = {
		21: "....KRRRRRRRRRRR", 
		22: ".....KRRRRRRRRRR", 
		23: ".....KRRKKKKKKKK", 
		24: "......KRRRRRRRRR", 
		25: "......KRRRRRRRRR", 
		26: ".......KRRRRRRRR", 
	}
	var teeth_shut: = {
		22: ".....KRKWWKWWKWW", 
		23: ".....KRRKWWKWWKW", 
		24: "......KRRKKKKKKK", 
		25: "......KRRRRRRRRR", 
		26: ".......KRRRRRRRR", 
	}
	var yawn_mouth: = {
		19: "....KrKRRRRKKKKK", 
		20: "....KrKRRRKWKEEE", 
		21: "....KRRKRKEEEEEE", 
		22: ".....KRKKEEEEEEE", 
		23: ".....KRRKEEEEEEE", 
		24: "......KRKEEEEyyy", 
		25: "......KRKEEyxxxx", 
		26: ".......KRKyxxxxx", 
		27: "........KKKKKKKK", 
	}
	sprites["pact_devil_blink"] = _mirrored(_face_with(face, [closed_eyes]))
	sprites["pact_devil_bored"] = _mirrored(_face_with(face, [half_lid, shut_mouth]))
	sprites["pact_devil_bored_blink"] = _mirrored(_face_with(face, [closed_eyes, shut_mouth]))
	sprites["pact_devil_talk"] = _mirrored(_face_with(face, [teeth_shut]))
	sprites["pact_devil_yawn"] = _mirrored(_face_with(face, [closed_eyes, yawn_mouth]))

	var look: = _mirrored(face)
	look[13] = _set_px(_set_px(look[13], 10, "Y"), 8, "E")
	look[14] = _set_px(_set_px(look[14], 10, "Y"), 8, "E")
	sprites["pact_devil_look"] = look

	var lick: = _mirrored(face)
	for c in range(18, 22):
		lick[23] = _set_px(lick[23], c, "x")
		lick[24] = _set_px(lick[24], c, "y" if c == 21 else "x")
	for row in [25, 26, 27]:
		lick[row] = _set_px(_set_px(lick[row], 20, "x"), 21, "y")
	lick[28] = _set_px(_set_px(lick[28], 20, "y"), 21, "K")
	sprites["pact_devil_lick"] = lick

	sprites["pact_watch"] = [
		"...K..K..K....", 
		"..KXKKXKKXK...", 
		"..KRKKRKKRKK..", 
		"..KRRKRRKRKXK.", 
		"..KRRRRRRRKRK.", 
		"..KRRRRRRRRRK.", 
		"..KrRRRRRRRK..", 
		"...KrRRRRRK...", 
		"..KYYYYYYYYK..", 
		".KYKWWWWWKYK..", 
		".KYKWWKWWKYK..", 
		".KYKWWKKWKYK..", 
		".KYKWWWWWKYK..", 
		"..KYYYYYYYYK..", 
		"...KrRRRRRK...", 
		"...KrRRRRRK...", 
		"...KrRRRRRK...", 
		"...KrRRRRRK...", 
		"...KrRRRRRK...", 
	]


	sprites["pact_claw"] = [
		".....KKKKKKKK........", 
		"....KRRRRRRRRKK......", 
		"...KRRRRRRRRRRRK.....", 
		"..KRRRRRRRRRRRRRK....", 
		".KRRRRRRRRRRRRRRRK...", 
		"KRRRRRRRRRRRRRRRRRK..", 
		"KRRRRKRRRKRRRKRRRkRK.", 
		"KRRkKRRkKRRkKRRkKkRRK", 
		"KkkkKkkkKkkkKkkkKKkRK", 
		"KkkrKkkrKkkrKkkrK.KkK", 
		"KrrrKrrrKrrrKrrrK.KrK", 
		"KKrKKKrKKKrKKKrKK.KEK", 
		".KEEK.KEEK.KEEK.KEEKE", 
		".KEwK.KEwK.KEwK.KEwKK", 
		".KEK..KEK..KEK..KEK..", 
		"KEK..KEK..KEK..KEK...", 
		"KK...KK...KK...KK....", 
	]
	sprites["pact_claw/2"] = [
		".....KKKKKKKK........", 
		"....KRRRRRRRRKK......", 
		"...KRRRRRRRRRRRK.....", 
		"..KRRRRRRRRRRRRRK....", 
		".KRRRRRRRRRRRRRRRK...", 
		"KRRRRRRRRRRRRRRRRRK..", 
		"KRRRRKRRRKRRRKRRRkRK.", 
		"KRRkKRRkKRRkKRRkKkRRK", 
		"KkkkKKKKKkkkKkkkKKkRK", 
		"KkkrK...KkkrKkkrK.KkK", 
		"KrrrK...KrrrKrrrK.KrK", 
		"KKrKK...KKrKKKrKK.KEK", 
		".KEE....EK.KEEK.KEEKE", 
		".KEw....wK.KEwK.KEwKK", 
		".KEK....K..KEK..KEK..", 
		"KEK.......KEK..KEK...", 
		"KK........KK...KK....", 
	]
	sprites["pact_claw/3"] = [
		".....KKKKKKKK........", 
		"....KRRRRRRRRKK......", 
		"...KRRRRRRRRRRRK.....", 
		"..KRRRRRRRRRRRRRK....", 
		".KRRRRRRRRRRRRRRRK...", 
		"KRRRRRRRRRRRRRRRRRK..", 
		"KRRRRKRRRKRRRKRRRkRK.", 
		"KRRkKRRkKRRkKRRkKkRRK", 
		"KkkkKkkkKKKKKkkkKKkRK", 
		"KkkrKkkrK...KkkrK.KkK", 
		"KrrrKrrrK...KrrrK.KrK", 
		"KKrKKKrKK...KKrKK.KEK", 
		".KEEK.KE....EEK.KEEKE", 
		".KEwK.KE....EwK.KEwKK", 
		".KEK..KE....EK..KEK..", 
		"KEK..KEK....K..KEK...", 
		"KK...KK........KK....", 
	]

	sprites["pact_lawyer"] = _mirrored([
		"......YYYY", 
		".....Y....", 
		"......YYYY", 
		"KK.....KKK", 
		"KWK...KAAA", 
		"KWWK.KAASS", 
		"KWWWKKASES", 
		".KWWWKKSSS", 
		".KWWwWKKSS", 
		"..KWWKTKKW", 
		"..KwWKTTWR", 
		"...KwKTTTR", 
		"....KKTTTR", 
		".....KTTtR", 
		".....KTTtK", 
		".....KTTTT", 
		".....KtTKK", 
		".....KtTK.", 
		".....KDDK.", 
		"......KK..", 
	])


func _mirrored(halves: Array) -> Array:
	var out: = []
	for row: String in halves:
		out.append(row + row.reverse())
	return out




func _build_monsters() -> void :
	sprites["_imp"] = [
		"................", 
		".....K....K.....", 
		"rK..KXK..KXK..Kr", 
		"rrK.KXRKKRXK.Krr", 
		"rrrKKRRRRRRKKrrr", 
		"rrrKRRRRRRRRKrrr", 
		".rrKRYYRRYYRKrr.", 
		"..rKRRRRRRRRKr..", 
		"...KRWKWKWKWRK..", 
		"....KRRRRRRK....", 
		"....KrRRRRrK.KK.", 
		"....KrrRRrrKKRK.", 
		".....KrK.KrK.K..", 
		".....KK...KK....", 
	]
	sprites["_imp/2"] = [
		"................", 
		".....K....K.....", 
		"....KXK..KXK....", 
		"....KXRKKRXK....", 
		"...KKRRRRRRKK...", 
		"..KKRRRRRRRRKK..", 
		".KrKRYYRRYYRKrK.", 
		"KrrKRRRRRRRRKrrK", 
		"rrrKRWKWKWKWRKrr", 
		"rr..KRRRRRRK..rr", 
		"r...KrRRRRrK.KKr", 
		"....KrrRRrrKKRK.", 
		".....KrK.KrK.K..", 
		".....KK...KK....", 
	]
	sprites["_devil"] = [
		"..K....K...G.G.G", 
		".KXK..KXK..G.G.G", 
		".KXRKKRXK..GGGGG", 
		"..KRRRRRK....G..", 
		".KRRRYYRRK...G..", 
		".KRRRRRRRK...G..", 
		"..KRWKWKWK...G..", 
		"...KRRRRK..KRG..", 
		"..KKrRRrKKKRRG..", 
		".KRKrRRrRRK..G..", 
		".KRKrrrrK....G..", 
		"..KKrRRrK....G..", 
		"...KrKKrK....G..", 
		"...KRK.KRK...G..", 
		"..KKK..KKK......", 
	]
	sprites["_devil/2"] = [
		"..K....K...G.G.G", 
		".KXK..KXK..G.G.G", 
		".KXRKKRXK..GGGGG", 
		"..KRRRRRK....G..", 
		".KRRRYYRRK...G..", 
		".KRRRRRRRK...G..", 
		"..KRWKWKWK...G..", 
		"...KRRRRK..KRG..", 
		"..KKrRRrKKKRRG..", 
		".KRKrRRrRRK..G..", 
		".KRKrrrrK....G..", 
		"..KKrRRrK....G..", 
		"...KrKKrK....G..", 
		"..KRK...KRK..G..", 
		".KKK.....KKK....", 
	]




	var body: = [
		".......................Y..Y....KK.......", 
		".....................Y.MYYMY..KjJK......", 
		".Y..................YMYMMMMMYKJjJJKKKK..", 
		"YMY................YMMMMMMMMMKJJJYYJJJK.", 
		"YMMY.....KKKKK....YMMMMMMMMMMJJJJJJJJJJK", 
		".YMMY...KjjjjjKKKKMMMMMMMJJJJJJJJJKWKWKK", 
		"..YMMMMKjJJJJJjjjjjMMMMMJJJJJJJKrrrrrr..", 
		"...YMYKJJJJJJJJJJJJJJJJJJJJJJJKJJWKWK...", 
		".....KJJJJJJJJJJJJJJJJJJJJJJJKKKKKKKK...", 
		".....KJJJJJJJJKKKKKKJJJJJJJJK...........", 
	]
	var flicker: = [
		"......................Y...Y.....KK......", 
		"Y....................YMY.YMY..KjJK......", 
		"YMY................YMMMMMMMMYKJjJJKKKK..", 
		"YMMY..............YMMMMMMMMMMKJJJYYJJJK.", 
		".YMMY....KKKKK....YMMMMMMMMMMJJJJJJJJJJK", 
	] + body.slice(5)
	var air: = "........................................"
	sprites["_hound"] = body + [
		"....KJJJJJJJJK......KJJJJJJJK...........", 
		"..KJJJJJJKDDK.......KDDKJJJJJJK.........", 
		"KJJJJK.KDDDK........KDDKKKKJJJJJK.......", 
		"KKKKK.KDDDK..........KDDK..KKJJJJJK.....", 
		".....KDDDK...........KDDDK...KKKJJJJK...", 
		".....KKKKK...........KKKKK......KKKKK...", 
	]
	sprites["_hound/2"] = [air] + flicker + [
		"....KJJJJJJJJK......KJJJJJJJK...........", 
		"..KDDKJJJJJJK......KDDKJJJJJK...........", 
		".KDDK..KJJJJJK....KDDKKJJJJK............", 
		"KDDDK...KKKJJJK..KDDK.KJJJK.............", 
		"KKKKK......KJJJKKDDK..KJJJK.............", 
		"...........KKKKKDDK...KJJJK.............", 
		"..............KDDDK...KJJJJK............", 
		"..............KKKKK...KKKKKK............", 
	]
	sprites["_hound/3"] = body + [
		"....KJJJJJJJJK......KJJJJJJJK...........", 
		"...KDKJJJJJJK......KJJJJJKDDK...........", 
		".....KDDKJJJJK....KJJJK.KDDK............", 
		".......KDDKJJJK..KJJJK.KDDK.............", 
		"........KDDKJJJK.KJJK.KDDK..............", 
		"........KKKKKKKK.KKKKKDDDK..............", 
		".....................KKKKK..............", 
	]
	sprites["_hound/4"] = [air] + flicker + [
		"....KJJJJJJJJK......KJJJJJJJK...........", 
		"...KDKJJJJJJK.......KDDKJJJJJJJK........", 
		"..KDDKKJJJJK..........KDDKKKKJJJJJK.....", 
		".KDDK.KJJJK............KDDK..KKKJJJJK...", 
		"KDDK...KJJJK............KDDDK...KKKKK...", 
		"KDDDK..KJJJK............KKKKK...........", 
		"KKKKK..KJJJJK...........................", 
		".......KKKKKK...........................", 
	]
	sprites["_soul"] = [
		"..O.....O.........", 
		".OYO...OYKKKKKKK..", 
		"OYWYO.OYKXXXXXXXK.", 
		"OYWYOOYKXXXXXXXXXK", 
		".OYWYYYKXXXXXXXXXK", 
		"OYWWYYKXXKKXXXKKXK", 
		"OYWWWYKXXKRKXXKRKK", 
		".OYWWYKXXKKXXXKKXK", 
		"..OYYYKXXXXXKXXXXK", 
		"...OOYKKXXXKKKXXK.", 
		"....OOKXKXKXKXKXK.", 
		".....OKKXKXKXKXK..", 
		"......KKKKKKKKK...", 
	]
	sprites["_soul/2"] = [
		".O......O.........", 
		"OYO....OYKKKKKKK..", 
		"OYWYO.OYKXXXXXXXK.", 
		".OYWYOOYKXXXXXXXXK", 
		"OYWWYYYKXXXXXXXXXK", 
		"OYWWYYKXXKKXXXKKXK", 
		".OYWWYKXXKRKXXKRKK", 
		"OYWWYYKXXKKXXXKKXK", 
		".OOYYYKXXXXXKXXXXK", 
		"..OOOYKKXXXKKKXXK.", 
		"...OO.KXKXKXKXKXK.", 
		"......KKXKXKXKXK..", 
		"......KKKKKKKKK...", 
	]
	sprites["_brute"] = [
		"..KK........KK..", 
		".KXK........KXK.", 
		".KXXK.KKKK.KXXK.", 
		"..KXXKrRRrKXXK..", 
		"...KKRRRRRRKK...", 
		"....KRYRRYRK....", 
		"....KRRRRRRK....", 
		"....KWKWWKWK....", 
		"..KKKrRRRRrKKK..", 
		".KRRRKrRRrKRRRK.", 
		"KRRRRRRrrRRRRRRK", 
		"KRRKRRRRRRRRKRRK", 
		"KRRKrRRRRRRrKRRK", 
		"KXXK.KrrrrK.KXXK", 
		"....KrRK.KRrK...", 
		"....KrrK.KrrK...", 
		"...KKKKK.KKKKK..", 
	]
	sprites["_brute/2"] = [
		"..KK........KK..", 
		".KXK........KXK.", 
		".KXXK.KKKK.KXXK.", 
		"..KXXKrRRrKXXK..", 
		"...KKRRRRRRKK...", 
		"....KRYRRYRK....", 
		"....KRRRRRRK....", 
		"....KWKWWKWK....", 
		"..KKKrRRRRrKKK..", 
		".KRRRKrRRrKRRRK.", 
		"KRRRRRRrrRRRRRRK", 
		"KRRKRRRRRRRRKRRK", 
		"KRRKrRRRRRRrKRRK", 
		"KXXK.KrrrrK.KXXK", 
		"...KrRK...KRrK..", 
		"...KrrK...KrrK..", 
		"..KKKKK...KKKKK.", 
	]


func _family(src: String, dst: String, swap: Dictionary) -> void :
	sprites[dst] = _recolor(sprites[src], swap)
	var n: = 2
	while sprites.has("%s/%d" % [src, n]):
		sprites["%s/%d" % [dst, n]] = _recolor(sprites["%s/%d" % [src, n]], swap)
		n += 1


func _recolor(rows: Array, swap: Dictionary) -> Array:
	var out: = []
	for row: String in rows:
		var line: = ""
		for ch in row:
			line += swap.get(ch, ch)
		out.append(line)
	return out






func _build_levels() -> void :
	var tree: Array = sprites["dead_tree"]
	var spires: Array = sprites["obsidian_spires"]
	sprites["gravestone"] = [
		"...KKKKKK...", 
		"..KwwwwwwK..", 
		".KwwwwGwwwK.", 
		".KwwwGGGwwK.", 
		".KwwwwGwwwK.", 
		".KwwwwGwwGK.", 
		".KwwwwGwwGK.", 
		".KwwwwwwwGK.", 
		".KwwwwwwGGK.", 
		"KKKKKKKKKKKK", 
	]
	sprites["ash_pile"] = [
		"...KKK...", 
		".KKwwwKK.", 
		"KwwGwwGwK", 
		"KKKKKKKKK", 
	]
	sprites["glow_mushroom"] = [
		"..CCC..", 
		".CCCCC.", 
		"CCBCBCC", 
		"..bKb..", 
		"..bKb..", 
	]
	sprites["bubbles"] = [
		".C.....", 
		"C.C..C.", 
		".C..C.C", 
		"....C..", 
	]
	sprites["blood_pool"] = [
		"..RRRR..", 
		".RRrRRR.", 
		"RRRRrRRR", 
		".RRRRR..", 
	]
	sprites["kelp_tree"] = _recolor(tree, {"1": "H", "2": "h", "M": "C"})
	sprites["coral_spires"] = _recolor(spires, {"3": "B", "4": "b", "M": "C"})
	sprites["black_tree"] = _recolor(tree, {"1": "G", "2": "i", "M": "R"})
	sprites["bone_spires"] = _recolor(spires, {"3": "X", "4": "w", "M": "R"})
	sprites["blood_ember"] = _recolor(sprites["ember"], {"O": "R", "Y": "r", "W": "O"})
	HellRealms.build(self)
	HellCocytus.build(self)
	HellArsenal.build(self)
	_realm_enemies()

	var arena: = {"radius": 500, "spacing": 24, "burn": 10, "burn_out": 20}
	var late: = {"burn": 12, "burn_out": 24}

	var fog: = {"type": "gloom", "banner": "THE FOG OF PURGATORY", "info": "Lost souls hide in the mist", 
		"color": Color(0.58, 0.62, 0.64), "alpha": 0.86, "inner": 170, "outer": 430}
	var dark: = {"type": "gloom", "banner": "THE LIGHT DIES", "info": "Something watches from the dark", 
		"color": Color(0.0, 0.0, 0.01), "alpha": 0.93, "inner": 150, "outer": 390}
	var purgatory_events: Array = events.duplicate(true)
	purgatory_events[0] = fog.merged({"at": 100, "time": 25})
	purgatory_events[3] = (purgatory_events[3] as Dictionary).merged({"banner": "THE GRAVES BURST", "info": "Step out of the red circles. They burn the dead too"}, true)
	var abyss_events: Array = events.duplicate(true)
	for e: Dictionary in abyss_events:
		if e["type"] == "eruption":
			e.merge({"banner": "THE STYX BOILS", "info": "Step out of the red circles. They scald the drowned too"}, true)
	var oblivion_events: Array = events.duplicate(true)
	oblivion_events[0] = dark.merged({"at": 100, "time": 20})
	oblivion_events[3] = dark.merged({"at": 600, "time": 25})
	var gale: = {"type": "gloom", "banner": "THE WINGS OF LUCIFER", "info": "His wingbeats freeze the lake. You can barely see", 
		"color": Color(0.82, 0.88, 0.95), "alpha": 0.85, "inner": 160, "outer": 420}
	var cocytus_events: Array = events.duplicate(true)
	cocytus_events[0] = gale.merged({"at": 100, "time": 25})
	cocytus_events[3] = (cocytus_events[3] as Dictionary).merged({"banner": "THE ICE CRACKS", "info": "Step out of the red circles. They break the frozen too"}, true)

	level_looks = [
		{
			"map": {
				"ground_dark": Color(0.13, 0.13, 0.14), "ground_light": Color(0.21, 0.205, 0.215), 
				"ground_accent": Color(0.27, 0.25, 0.22), 
				"path": Color(0.25, 0.24, 0.24), "path_edge": Color(0.08, 0.08, 0.09), 
				"path_core": Color(0.25, 0.24, 0.24), 

				"style": "ash", "grass": Color(0.3, 0.28, 0.21), "grass_dark": Color(0.17, 0.165, 0.14), 
				"pebble": Color(0.31, 0.31, 0.32), "cell_freq": 0.008, 
			}, 
			"terrain": {
				"river": {"kind": "", "freq": 0.0008, "width": 0.03, "octaves": 2}, 
				"plots": {
					"chance": 0.6, 
					"walls": [
						{"h": "wall_stone_h", "v": "wall_stone_v", "post": "wall_stone_post", "scale": 3.0, "thick": 10, "weight": 2}, 
						{"h": "fence_h", "v": "fence_v", "post": "fence_post", "scale": 3.0, "thick": 8, "weight": 1}, 
					], 
					"inside": [
						{"sprite": "gravestone", "scale": 3.0, "radius": 14, "weight": 3}, 
						{"sprite": "grave_cross", "scale": 3.0, "radius": 12, "weight": 3}, 
						{"sprite": "grave_angel", "scale": 3.0, "radius": 16, "weight": 1}, 
					], 
				}, 
			}, 
			"map_obstacles": [
				{"sprite": "dead_tree", "scale": 3.0, "radius": 16, "weight": 3}, 
				{"sprite": "gravestone", "scale": 3.5, "radius": 18, "weight": 1}, 
				{"sprite": "chapel_ruin", "scale": 3.5, "radius": 34, "weight": 0.6}, 
			], 
			"map_decor": [
				{"sprite": "ash_pile", "scale": 3.0, "weight": 3}, 
				{"sprite": "charred_grass", "scale": 3.0, "weight": 3}, 
				{"sprite": "votive_candles", "scale": 3.0, "weight": 2}, 
				{"sprite": "wilted_flowers", "scale": 3.0, "weight": 2}, 
				{"sprite": "skull", "scale": 3.0, "weight": 1}, 
				{"sprite": "bones", "scale": 3.0, "weight": 2}, 
			], 
			"ambient": {"color": Color(0.8, 0.8, 0.85)}, 
			"vignette": Color(0.04, 0.04, 0.06, 0.65), 
			"events": purgatory_events, 
			"spawn_table": [
				{"enemy": "penitent", "weight": 3, "from": 0}, 
				{"enemy": "crow", "weight": 2, "from": 0, "group": 3}, 
				{"enemy": "grave_rat", "weight": 1.5, "from": 65, "group": 2}, 
				{"enemy": "ash_spider", "weight": 1.3, "from": 130, "group": 3}, 
				{"enemy": "skeleton", "weight": 2, "from": 195}, 
				{"enemy": "flagellant", "weight": 2, "from": 260}, 
				{"enemy": "coffin_crawler", "weight": 1.3, "from": 325}, 
				{"enemy": "plague_bloat", "weight": 0.9, "from": 390}, 
				{"enemy": "plague_rat", "weight": 1.2, "from": 455}, 
				{"enemy": "wraith", "weight": 1.5, "from": 520}, 
				{"enemy": "lantern_ghost", "weight": 1.2, "from": 585}, 
				{"enemy": "gravedigger", "weight": 0.6, "from": 650}, 
			], 
			"swarms": [
				{"enemy": "crow", "from": 40, "every": 25, "count": [26, 36], "speed": 380, "xp": 2}, 
				{"enemy": "grave_rat", "from": 340, "every": 40, "count": [20, 28], "speed": 330, "xp": 2}, 
			], 
			"bosses": [
				arena.merged({"at": 180, "boss": "rat_king"}), 
				arena.merged({"at": 465, "boss": "the_sexton"}).merged(late), 
				arena.merged({"at": 735, "boss": "carrion_king"}).merged(late), 
			], 
			"champion": "gravedigger", 

			"goals": {"hero": {"dir": "up", "survivor": "witch", "minutes": 4.25}, "item": {"dir": "down", "item": "relic", "minutes": 4.25}}, 
		}, 
		{
			"map": map.merged({"bridge": Color(0.19, 0.19, 0.23), "bridge_edge": Color(0.09, 0.08, 0.1)}), 
			"terrain": {
				"river": {"kind": "lava", "freq": 0.0009, "width": 0.05, "octaves": 2, "bridges": true, "slow": 0.6, "scorch": 16.0, "burn": 0.3}, 
				"band": {"axis": "y", "half": 820.0}, 
			}, 

			"goals": {"hero": {"dir": "up", "survivor": "chorister", "minutes": 4.5}, "item": {"dir": "down", "item": "sodom", "minutes": 4.5}}, 
		}, 
		{
			"map": {
				"ground_dark": Color(0.085, 0.085, 0.075), "ground_light": Color(0.14, 0.135, 0.115), 
				"ground_accent": Color(0.09, 0.14, 0.09), 

				"style": "mud", "shore": Color(0.2, 0.19, 0.15), "shore_dark": Color(0.15, 0.14, 0.11), 
				"sheen": Color(0.17, 0.18, 0.17), 
				"path": Color(0.07, 0.2, 0.22), "path_edge": Color(0.05, 0.11, 0.12), 
				"path_core": Color(0.12, 0.34, 0.36), "path_heat": Color(0.06, 0.1, 0.1), 
				"pool": Color(0.035, 0.12, 0.17), "pool_edge": Color(0.1, 0.24, 0.26), "pool_deep": Color(0.025, 0.09, 0.14), 
				"pool_glint": Color(0.12, 0.25, 0.3), 
			}, 
			"terrain": {
				"river": {"kind": "current", "freq": 0.0009, "width": 0.05, "octaves": 2, "flow": 150.0}, 
				"band": {"axis": "x", "half": 820.0}, 
				"pools": {"kind": "deep", "freq": 0.0022, "above": 0.22, "octaves": 3, "slow": 0.6}, 
			}, 
			"map_obstacles": [
				{"sprite": "kelp_tree", "scale": 3.0, "radius": 16, "weight": 2}, 
				{"sprite": "sunken_bell", "scale": 3.5, "radius": 20, "weight": 2}, 
				{"sprite": "ferry_wreck", "scale": 3.0, "radius": 30, "weight": 1}, 
			], 
			"map_decor": [
				{"sprite": "styx_reeds", "scale": 3.0, "weight": 4}, 
				{"sprite": "drowned_hand", "scale": 3.0, "weight": 1}, 
				{"sprite": "bones", "scale": 3.0, "weight": 2}, 
				{"sprite": "skull", "scale": 3.0, "weight": 1}, 
				{"sprite": "lily_candle", "scale": 3.0, "weight": 4, "on": "pool"}, 
				{"sprite": "bubbles", "scale": 3.0, "weight": 2, "on": "pool"}, 
			], 
			"props": [
				{"sprite": "sunken_reliquary", "scale": 3.0, "hp": 15, "radius": 22, "heart_chance": 0.5}, 
				{"sprite": "bone_urn", "scale": 3.0, "hp": 20, "radius": 22, "heart_chance": 0.5}, 
			], 
			"ambient": {"color": Color(0.3, 0.85, 1)}, 
			"vignette": Color(0.0, 0.05, 0.08, 0.7), 
			"events": abyss_events, 
			"spawn_table": [
				{"enemy": "drowned_sinner", "weight": 3, "from": 0}, 
				{"enemy": "styx_eel", "weight": 2, "from": 0, "group": 3}, 
				{"enemy": "styx_crab", "weight": 1.5, "from": 65, "group": 2}, 
				{"enemy": "leech", "weight": 1.3, "from": 130, "group": 3}, 
				{"enemy": "drowned_monk", "weight": 2, "from": 195}, 
				{"enemy": "halo_jelly", "weight": 1.5, "from": 260}, 
				{"enemy": "bloated_drowned", "weight": 0.9, "from": 325}, 
				{"enemy": "lure_fiend", "weight": 1.2, "from": 390}, 
				{"enemy": "siren", "weight": 1.2, "from": 455}, 
				{"enemy": "bellshell", "weight": 0.6, "from": 520}, 
				{"enemy": "leviathan_spawn", "weight": 0.7, "from": 585}, 
			], 
			"swarms": [
				{"enemy": "styx_eel", "from": 40, "every": 25, "count": [26, 38], "speed": 380, "xp": 2}, 
				{"enemy": "halo_jelly", "from": 340, "every": 40, "count": [18, 26], "speed": 300, "xp": 2}, 
			], 
			"bosses": [
				arena.merged({"at": 180, "boss": "leviathan"}), 
				arena.merged({"at": 465, "boss": "ferryman"}).merged(late), 
				arena.merged({"at": 735, "boss": "siren_queen"}).merged(late), 
			], 
			"champion": "bellshell", 

			"goals": {"hero": {"dir": "right", "survivor": "ravenkeeper", "minutes": 4.5}, "item": {"dir": "left", "item": "bounty", "minutes": 4.5}}, 
		}, 
		{
			"map": {
				"ground_dark": Color(0.06, 0.05, 0.07), "ground_light": Color(0.12, 0.105, 0.13), 
				"ground_accent": Color(0.15, 0.04, 0.06), 

				"style": "tiles", "tile_a": Color(0.15, 0.14, 0.17), "tile_b": Color(0.17, 0.16, 0.19), 
				"tile_c": Color(0.135, 0.125, 0.155), "grout": Color(0.05, 0.04, 0.06), "vein": Color(0.25, 0.21, 0.28), 
				"rubble": Color(0.09, 0.08, 0.1), 
				"path": Color(0.26, 0.03, 0.06), "path_edge": Color(0.1, 0.02, 0.04), 
				"path_core": Color(0.4, 0.06, 0.09), "path_heat": Color(0.09, 0.03, 0.05), 
				"pool": Color(0.05, 0.02, 0.07), "pool_edge": Color(0.3, 0.17, 0.36), "pool_deep": Color(0.0, 0.0, 0.0), 
				"pool_glint": Color(0.16, 0.1, 0.22), 
			}, 
			"terrain": {
				"river": {"kind": "", "freq": 0.0009, "width": 0.025, "octaves": 2}, 
				"pools": {"kind": "void", "freq": 0.0019, "above": 0.2, "octaves": 3}, 
			}, 
			"gloom": {"color": Color(0.0, 0.0, 0.01), "alpha": 0.62, "inner": 290, "outer": 620}, 
			"map_obstacles": [
				{"sprite": "broken_pillar", "scale": 3.5, "radius": 16, "weight": 3}, 
				{"sprite": "bone_brazier", "scale": 3.0, "radius": 16, "weight": 1}, 
				{"sprite": "black_tree", "scale": 3.0, "radius": 16, "weight": 2}, 
			], 
			"map_decor": [
				{"sprite": "blood_pool", "scale": 3.0, "weight": 3}, 
				{"sprite": "blood_ember", "scale": 3.0, "weight": 2}, 
				{"sprite": "halo_shard", "scale": 3.0, "weight": 1}, 
				{"sprite": "skull", "scale": 3.0, "weight": 2}, 
				{"sprite": "bones", "scale": 3.0, "weight": 3}, 
				{"sprite": "void_chain", "scale": 3.0, "weight": 2, "on": "pool"}, 
			], 
			"props": [
				{"sprite": "bone_cage", "scale": 3.0, "hp": 20, "radius": 22, "heart_chance": 0.5}, 
				{"sprite": "bone_urn", "scale": 3.0, "hp": 20, "radius": 22, "heart_chance": 0.5}, 
			], 
			"ambient": {"color": Color(0.9, 0.3, 0.35)}, 
			"vignette": Color(0.0, 0.0, 0.0, 0.8), 
			"events": oblivion_events, 
			"spawn_table": [
				{"enemy": "faceless", "weight": 3, "from": 0}, 
				{"enemy": "stray_eye", "weight": 2, "from": 0, "group": 3}, 
				{"enemy": "bone_serpent", "weight": 1.5, "from": 65, "group": 2}, 
				{"enemy": "crawling_hand", "weight": 1.3, "from": 130, "group": 3}, 
				{"enemy": "faceless_deacon", "weight": 2, "from": 195}, 
				{"enemy": "mirror_shade", "weight": 1.5, "from": 260}, 
				{"enemy": "weeping_saint", "weight": 1.0, "from": 325}, 
				{"enemy": "great_serpent", "weight": 1.2, "from": 390}, 
				{"enemy": "ophan", "weight": 1.2, "from": 455}, 
				{"enemy": "hollow_angel", "weight": 0.6, "from": 520}, 
				{"enemy": "great_eye", "weight": 0.7, "from": 585}, 
			], 
			"swarms": [
				{"enemy": "stray_eye", "from": 40, "every": 22, "count": [30, 42], "speed": 400, "xp": 2}, 
				{"enemy": "crawling_hand", "from": 340, "every": 35, "count": [20, 28], "speed": 330, "xp": 2}, 
			], 
			"bosses": [
				arena.merged({"at": 180, "boss": "pale_horse"}), 
				arena.merged({"at": 465, "boss": "watcher"}).merged(late), 
				arena.merged({"at": 735, "boss": "fallen_seraph"}).merged(late), 
			], 
			"champion": "hollow_angel", 

			"goals": {"hero": {"dir": "left", "survivor": "undertaker", "minutes": 4.75}, "item": {"dir": "right", "item": "amount", "minutes": 4.75}}, 
		}, 
		{
			"map": {
				"ground_dark": Color(0.065, 0.085, 0.125), "ground_light": Color(0.1, 0.13, 0.19), 
				"ground_accent": Color(0.5, 0.56, 0.66), 
				"path": Color(0.36, 0.4, 0.48), "path_edge": Color(0.12, 0.15, 0.2), "path_core": Color(0.42, 0.46, 0.54), 

				"style": "frost", "snow": Color(0.48, 0.54, 0.64), "crack": Color(0.3, 0.4, 0.54), "cell_freq": 0.01, 
				"ice": Color(0.27, 0.41, 0.58), "ice_edge": Color(0.6, 0.76, 0.9), 
			}, 
			"terrain": {
				"river": {"kind": "", "freq": 0.0009, "width": 0.025, "octaves": 2}, 
				"pools": {"kind": "ice", "freq": 0.0017, "above": 0.15, "octaves": 3}, 
				"band": {"axis": "x", "half": 820.0}, 
			}, 


			"gloom": {"color": Color(0.8, 0.86, 0.94), "alpha": 0.5, "inner": 320, "outer": 660}, 
			"map_obstacles": [
				{"sprite": "frozen_sinner", "scale": 3.0, "radius": 18, "weight": 2}, 
				{"sprite": "ice_spire", "scale": 3.5, "radius": 16, "weight": 2}, 
				{"sprite": "frost_tree", "scale": 3.0, "radius": 16, "weight": 2}, 
			], 
			"map_decor": [
				{"sprite": "face_in_ice", "scale": 3.0, "weight": 2}, 
				{"sprite": "frost_crack", "scale": 3.0, "weight": 3}, 
				{"sprite": "snow_drift", "scale": 3.0, "weight": 3}, 
				{"sprite": "skull", "scale": 3.0, "weight": 1}, 
				{"sprite": "bones", "scale": 3.0, "weight": 1}, 
				{"sprite": "ice_chain", "scale": 3.0, "weight": 1}, 
			], 
			"props": [
				{"sprite": "ice_reliquary", "scale": 3.0, "hp": 20, "radius": 22, "heart_chance": 0.5}, 
				{"sprite": "frozen_urn", "scale": 3.0, "hp": 20, "radius": 22, "heart_chance": 0.5}, 
			], 
			"ambient": {"color": Color(0.85, 0.92, 1.0)}, 
			"vignette": Color(0.02, 0.04, 0.08, 0.72), 
			"events": cocytus_events, 
			"spawn_table": [
				{"enemy": "frozen_traitor", "weight": 3, "from": 0}, 
				{"enemy": "frostwing", "weight": 2, "from": 0, "group": 3}, 
				{"enemy": "ice_mite", "weight": 1.5, "from": 65, "group": 2}, 
				{"enemy": "blood_mite", "weight": 1.3, "from": 130, "group": 3}, 
				{"enemy": "traitor_knight", "weight": 2, "from": 195}, 
				{"enemy": "blizzard_wraith", "weight": 1.5, "from": 260}, 
				{"enemy": "slush", "weight": 1.3, "from": 325}, 
				{"enemy": "frost_gargoyle", "weight": 0.9, "from": 390}, 
				{"enemy": "ice_beetle", "weight": 1.2, "from": 455}, 
				{"enemy": "hoarfrost_wisp", "weight": 1.2, "from": 520}, 
				{"enemy": "chained_giant", "weight": 0.6, "from": 585}, 
			], 
			"swarms": [
				{"enemy": "frostwing", "from": 40, "every": 22, "count": [30, 42], "speed": 400, "xp": 2}, 
				{"enemy": "blood_mite", "from": 340, "every": 35, "count": [20, 28], "speed": 330, "xp": 2}, 
			], 
			"bosses": [
				arena.merged({"at": 180, "boss": "antaeus"}), 
				arena.merged({"at": 465, "boss": "ugolino"}).merged(late), 
				arena.merged({"at": 735, "boss": "lucifer"}).merged(late), 
			], 
			"champion": "chained_giant", 

			"goals": {"hero": {"dir": "left", "survivor": "crusader", "minutes": 5.0}, "item": {"dir": "right", "item": "duration", "minutes": 5.0}}, 
		}, 
	]




func _realm_enemies() -> void :


	var walker: = {"scale": 2.0, "hp": 20, "speed": 105, "radius": 20, "xp": 1}
	var flier: = {"scale": 2.0, "hp": 6, "speed": 165, "radius": 16, "xp": 1, "motion": "fly"}
	var runner: = {"scale": 1.8, "hp": 9, "speed": 180, "radius": 16, "xp": 1}
	var knight: = {"scale": 2.3, "hp": 28, "speed": 120, "radius": 22, "xp": 2}
	var tank: = {"scale": 2.4, "hp": 140, "speed": 68, "radius": 34, "xp": 8}
	var bloat: = {"scale": 2.8, "hp": 60, "speed": 60, "radius": 28, "xp": 4}
	var floater: = {"scale": 2.0, "hp": 18, "speed": 130, "radius": 18, "xp": 2, "motion": "float", "alpha": 0.9}
	var charger: = {"scale": 2.4, "hp": 24, "speed": 115, "radius": 22, "xp": 3, 
		"ability": "charge", "every": 3.6, "range": 430, "windup": 0.7, "dash_speed": 560, "dash_time": 0.5}
	var shooter: = {"scale": 2.0, "hp": 16, "speed": 95, "radius": 18, "xp": 3, "motion": "fly", 
		"ability": "shoot", "every": 2.6, "range": 560, "hold": 330, "shot_speed": 170}
	var splitter: = {"scale": 3.0, "hp": 70, "speed": 62, "radius": 28, "xp": 5, "ability": "split", "count": 4}
	var crawler: = {"scale": 1.8, "hp": 6, "speed": 175, "radius": 14, "xp": 1, "motion": "skitter"}

	var boss_charge: = {"hp": 1000, "speed": 95, "radius": 56, "xp": 80, "coins": 12, "boss": true, "hits": 2, 
		"ability": "charge", "every": 4.5, "range": 700, "windup": 0.8, "dash_speed": 1150, "dash_time": 0.45, "lead": 0.7}
	var boss_volley: = {"hp": 1300, "speed": 75, "radius": 60, "xp": 100, "coins": 15, "boss": true, "hits": 2, 
		"ability": "shoot", "every": 2.8, "range": 800, "hold": 300, "shots": 5, "spread": 0.8, "shot_speed": 250}
	var boss_flier: = {"hp": 1500, "speed": 110, "radius": 50, "xp": 120, "coins": 18, "boss": true, "hits": 2, "motion": "fly", 
		"ability": "charge", "every": 3.2, "range": 700, "windup": 0.7, "dash_speed": 700, "dash_time": 0.6}
	var list: = {

		"penitent": walker.merged({"name": "Penitent"}), 
		"crow": flier.merged({"name": "Carrion Crow"}), 
		"grave_rat": runner.merged({"name": "Grave Rat", "motion": "gallop"}), 
		"flagellant": knight.merged({"name": "Flagellant"}), 
		"coffin_crawler": {"name": "Coffin Crawler", "scale": 2.0, "hp": 20, "speed": 140, "radius": 20, "xp": 2, "motion": "skitter"}, 
		"plague_rat": charger.merged({"name": "Plague Rat", "motion": "gallop"}), 
		"lantern_ghost": shooter.merged({"name": "Lantern Ghost", "motion": "float", "alpha": 0.92, "shot_color": Color(1, 0.8, 0.35)}), 
		"gravedigger": tank.merged({"name": "Gravedigger"}), 
		"rat_king": boss_charge.merged({"name": "The Rat King", "scale": 4.6, "motion": "gallop", "head": [14, 0, 11, 10]}), 
		"the_sexton": boss_volley.merged({"name": "The Sexton", "sprite": "sexton", "scale": 4.4, "head": [2, 5, 13, 8], "shot_color": Color(0.55, 1.0, 0.25)}), 
		"carrion_king": boss_flier.merged({"name": "The Carrion King", "scale": 4.6, "head": [14, 0, 8, 10]}), 

		"drowned_sinner": walker.merged({"name": "Drowned Sinner"}), 
		"styx_eel": flier.merged({"name": "Styx Eel", "scale": 1.7}), 
		"styx_crab": runner.merged({"name": "Bone Crab", "motion": "skitter"}), 
		"leech": {"name": "Leech", "scale": 1.8, "hp": 7, "speed": 115, "radius": 14, "xp": 1, "motion": "hop"}, 
		"drowned_monk": knight.merged({"name": "Drowned Monk"}), 
		"halo_jelly": floater.merged({"name": "Halo Jelly"}), 
		"bloated_drowned": bloat.merged({"name": "Bloated Drowned"}), 
		"lure_fiend": charger.merged({"name": "Lure Fiend", "scale": 2.0, "motion": "fly"}), 
		"siren": shooter.merged({"name": "Siren", "motion": "float", "shot_color": Color(0.6, 1, 0.95)}), 
		"bellshell": tank.merged({"name": "Bellshell"}), 
		"leviathan_spawn": splitter.merged({"name": "Leviathan Spawn", "sprite": "leviathan_spawn", "motion": "fly", "into": "styx_eel"}), 
		"leviathan": boss_charge.merged({"name": "The Leviathan", "scale": 4.2, "motion": "float", "head": [17, 0, 18, 14]}), 
		"ferryman": boss_volley.merged({"name": "The Ferryman", "scale": 4.4, "head": [2, 0, 12, 10], "shot_color": Color(1, 0.82, 0.3)}), 
		"siren_queen": boss_flier.merged({"name": "The Siren Queen", "scale": 4.4, "head": [1, 0, 11, 11]}), 

		"faceless": walker.merged({"name": "The Faceless"}), 
		"stray_eye": flier.merged({"name": "Stray Eye", "scale": 1.9}), 
		"bone_serpent": runner.merged({"name": "Bone Serpent", "scale": 1.7}), 
		"crawling_hand": crawler.merged({"name": "Crawling Hand", "scale": 1.9}), 
		"faceless_deacon": {"name": "Faceless Deacon", "scale": 2.1, "hp": 20, "speed": 100, "radius": 18, "xp": 2}, 
		"mirror_shade": floater.merged({"name": "Your Shadow", "sprite": "@survivor", "tint": Color(0.42, 0.3, 0.62), "alpha": 0.85}), 
		"weeping_saint": {"name": "Weeping Saint", "scale": 2.2, "hp": 40, "speed": 85, "radius": 22, "xp": 3}, 
		"great_serpent": charger.merged({"name": "Great Serpent", "scale": 2.4}), 
		"ophan": shooter.merged({"name": "Ophan", "shot_color": Color(1, 0.85, 0.3)}), 
		"hollow_angel": tank.merged({"name": "Hollow Angel", "scale": 2.2}), 
		"great_eye": splitter.merged({"name": "The Great Eye", "motion": "fly", "into": "stray_eye"}), 
		"pale_horse": boss_charge.merged({"name": "The Pale Horse", "scale": 4.0, "motion": "gallop", "head": [20, 8, 11, 7]}), 
		"watcher": boss_volley.merged({"name": "The Watcher Above", "scale": 5.0, "motion": "float", "head": [0, 0, 20, 18], "shot_color": Color(1, 0.3, 0.25)}), 
		"fallen_seraph": boss_flier.merged({"name": "The Fallen Seraph", "scale": 4.2, "head": [9, 0, 11, 10]}), 

		"frozen_traitor": walker.merged({"name": "Frozen Traitor", "scale": 1.5}), 
		"frostwing": flier.merged({"name": "Frostwing", "scale": 1.4}), 
		"ice_mite": runner.merged({"name": "Ice Mite", "scale": 1.6, "motion": "skitter"}), 
		"blood_mite": crawler.merged({"name": "Blood Mite", "scale": 1.3}), 
		"traitor_knight": knight.merged({"name": "Traitor Knight", "scale": 1.65}), 
		"blizzard_wraith": floater.merged({"name": "Blizzard Wraith"}), 
		"slush": {"name": "Slush", "scale": 1.7, "hp": 22, "speed": 95, "radius": 22, "xp": 2, "motion": "hop", "ability": "split", "into": "slushlet", "count": 3}, 
		"slushlet": {"name": "Slushlet", "sprite": "slush", "scale": 1.1, "hp": 5, "speed": 110, "radius": 12, "xp": 1, "motion": "hop"}, 
		"frost_gargoyle": {"name": "Frost Gargoyle", "scale": 2.0, "hp": 40, "speed": 90, "radius": 24, "xp": 3, "motion": "fly"}, 
		"ice_beetle": charger.merged({"name": "Ice Beetle", "scale": 1.7, "motion": "skitter"}), 
		"hoarfrost_wisp": shooter.merged({"name": "Hoarfrost Wisp", "scale": 1.7, "motion": "float", "shot_color": Color(0.3, 0.65, 1)}), 
		"chained_giant": tank.merged({"name": "Chained Giant", "scale": 1.8}), 
		"antaeus": boss_charge.merged({"name": "Antaeus", "scale": 3.4, "motion": "walk", "head": [6, 0, 14, 7]}), 
		"ugolino": boss_volley.merged({"name": "Count Ugolino", "scale": 4.6, "head": [9, 0, 13, 7], "shot_color": Color(0.9, 0.86, 0.76)}), 
		"lucifer": boss_flier.merged({"name": "Lucifer", "scale": 4.0, "head": [8, 0, 30, 10]}), 
	}
	for id: String in list:
		var d: Dictionary = list[id]
		if not d.has("sprite"):
			d["sprite"] = id
		enemies[id] = d



func build_full_art() -> void :
	HellArtV3.build(self, true)

func _use_new_art() -> void :
	for id: String in enemies:
		var e: Dictionary = enemies[id]
		var old: = str(e.get("sprite", ""))
		if ART_V3 and HellArtV3.RESCALE.has(old):
			e["sprite"] = "v3_" + old
			e["scale"] = e["scale"] * HellArtV3.RESCALE[old]
			if HellArtV3.HEADS.has(old) and e.has("head"):
				e["head"] = HellArtV3.HEADS[old]
			continue
		var v2: = "v2_" + old
		if not sprites.has(v2):
			continue
		e["sprite"] = v2
		if sprites["_v2_devil"] == sprites[v2]:
			e["scale"] = e["scale"] * HellArtV2.SCALE_DEVIL
	for s: Dictionary in survivors:
		if sprites.has("v2_" + str(s["sprite"])):
			s["sprite"] = "v2_" + str(s["sprite"])
			s["scale"] = 2.0



func _face_with(face: Array, changes: Array) -> Array:
	var out: = face.duplicate()
	for change: Dictionary in changes:
		for row: int in change:
			out[row] = change[row]
	return out


func _set_px(row: String, col: int, ch: String) -> String:
	return row.substr(0, col) + ch + row.substr(col + 1)

func _variant(base: String, id: String, display: String, sprite: String, extra: = {}) -> void :
	var d: Dictionary = (enemies[base] as Dictionary).duplicate(true)
	d["name"] = display
	d["sprite"] = sprite
	d.merge(extra, true)
	enemies[id] = d
