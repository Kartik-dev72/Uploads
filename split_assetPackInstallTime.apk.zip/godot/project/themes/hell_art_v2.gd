class_name HellArtV2
extends RefCounted












const SCALE_DEVIL: = 2.0 / 3.0

static func build(t: GameTheme) -> void :
	_devil(t)
	_hound(t)
	_survivors(t)
	_more_survivors(t)
	_pets(t)
	var devils: = {
		"devil": Color(0.85, 0.18, 0.2), 
		"devil_knight": Color(0.55, 0.7, 0.95), 
		"ghoul": Color(0.52, 0.7, 0.42), 
		"drowned": Color(0.95, 0.55, 0.15), 
		"siren_knight": Color(1.0, 0.35, 0.7), 
		"revenant": Color(0.92, 0.9, 0.8), 
		"gilded_knight": Color(1.0, 0.85, 0.25), 
	}
	for id: String in devils:
		var pal: = ramp(devils[id]).merged(DEVIL_PARTS, true)
		if id == "gilded_knight":
			pal.merge({"Y": Color(1, 0.3, 0.2), "O": Color(0.7, 0.1, 0.1)}, true)
		_family(t, "_v2_devil", "v2_" + id, pal)
	var fire: = {"M": Color(1, 0.45, 0.1), "Y": Color(1, 0.85, 0.25), "W": Color(1, 0.97, 0.75)}
	var hounds: = {
		"cerberus": [Color(0.78, 0.72, 0.62), fire], 
		"hellhound": [Color(0.85, 0.2, 0.18), fire], 
		"abyss_hound": [Color(0.95, 0.55, 0.15), {"M": Color(0.4, 0.85, 1), "Y": Color(0.85, 1, 1), "W": Color(1, 1, 1)}], 
		"bone_hound": [Color(0.9, 0.88, 0.8), {"M": Color(0.85, 0.18, 0.2), "Y": Color(0.95, 0.55, 0.15), "W": Color(1, 0.85, 0.4)}], 
	}
	for id: String in hounds:
		var pal: = ramp(hounds[id][0]).merged(HOUND_PARTS, true).merged(hounds[id][1], true)
		_family(t, "_v2_hound", "v2_" + id, pal)



static func ramp(c: Color) -> Dictionary:
	return {
		"@": _shift(c, 0.12, 0.04, 0.85, 1.15, 0.08), 
		"R": c, 
		"r": _shift(c, 0.8, 0.04, 1.05, 0.68, 0.0), 
		"&": _shift(c, 0.8, 0.07, 0.95, 0.42, 0.0), 
		"K": _shift(c, 0.8, 0.08, 0.7, 0.16, 0.02), 
	}


static func _shift(c: Color, toward_hue: float, amount: float, sat: float, val: float, add: float) -> Color:
	var d: = wrapf(toward_hue - c.h, -0.5, 0.5)
	var h: = wrapf(c.h + clampf(d, - amount, amount), 0.0, 1.0)
	return Color.from_hsv(h, clampf(c.s * sat, 0, 1), clampf(c.v * val + add, 0, 1))

const DEVIL_PARTS: = {
	"X": Color(0.9, 0.86, 0.74), "+": Color(1, 0.98, 0.9), "w": Color(0.6, 0.55, 0.5), 
	"Y": Color(1, 0.9, 0.3), "O": Color(1, 0.5, 0.1), 
	"W": Color(1, 0.98, 0.92), "E": Color(0.18, 0.02, 0.05), 
	"G": Color(0.72, 0.74, 0.8), "n": Color(0.4, 0.24, 0.16), 
}

const HOUND_PARTS: = {
	"+": Color(1, 0.98, 0.92), "E": Color(0.18, 0.02, 0.05), 
}

static func _family(t: GameTheme, src: String, dst: String, pal: Dictionary) -> void :
	t.sprites[dst] = t.sprites[src]
	var n: = 2
	while t.sprites.has("%s/%d" % [src, n]):
		t.sprites["%s/%d" % [dst, n]] = t.sprites["%s/%d" % [src, n]]
		n += 1
	t.sprite_palettes[dst] = pal



static func _devil(t: GameTheme) -> void :
	var rows: = [
		"....K.........K......G.G.G", 
		"...K+K.......K+K.....G.G.G", 
		"...KX+K.....K+XK.....GGGGG", 
		"...KXwK.....KXwK.......n..", 
		"....KXwKKKKKKXwK.......n..", 
		"....KK@@@@RRRRRRK......n..", 
		"....K@@RRRRRRRRRRK.....n..", 
		"....K@RRRRRKKRRKRRK....n..", 
		"....K@RRRRKYYKRKYKK....n..", 
		"....K@RRRRKYOKRKOKRK...n..", 
		"....KRRRRRRKKRRRKRRK..Kn..", 
		".....KRRrRRRRRRRRRRK.K@nK.", 
		"..K..KrRKWKWKWKWKWK..KRnK.", 
		".K@K..KrKEEEEEEEEK...KrnK.", 
		"K@RRK.KrrKWKWKWKWK...K&n..", 
		"KKrKK..KKrrrrrrrKK..K&Kn..", 
		".KrK..KK@RRRRRRrKKKK&K.n..", 
		".KrK.K@@RRRRRRRRrr&&K..n..", 
		"..KrKK@RRRRRRRRRrrK....n..", 
		"...KKKRRRRRRRRRrr&K....n..", 
		"......KrRRRRRRr&&K.....n..", 
		"......KK&rrrrr&KK......n..", 
		"......K&rK..Kr&K.......n..", 
		"......K&&K..K&&K......n...", 
		".....KKKK...KKKK..........", 
	]
	t.sprites["_v2_devil"] = rows
	var step: = rows.duplicate()
	step[22] = ".....K&rK....Kr&K......n.."
	step[23] = "....K&&K......K&&K....n..."
	step[24] = "....KKKK......KKKK........"
	t.sprites["_v2_devil/2"] = step





static func _hound(t: GameTheme) -> void :
	var body: = [
		".Y........................Y....Y........K.........", 
		"YMY......................YMY..YMY......K@K........", 
		".YMMY..................YMMYYMMYMY.....K@RK........", 
		"..YMWY..........Y..Y.YYMMWMMWMMMY..KKK@RRRKKK.....", 
		"...YMWMY..KKKKKKYMKYMYMMWWMMWWMMY@@RRRRRRRRK......", 
		"....YMMY.K@@@@@@MMMMMMMMWWWMMMMM@@RRRRRY+RRRK.....", 
		".....YMMK@@RRRRRRRRRRRRMMMMMMMMM@RRRRRRYYRRRRRRK..", 
		".......K@RRRRRRRRRRRRRRRRMMMMMrRRRRRRRRRRRRRRRRRKK", 
		".......K@RRRRRRRRRRRRRRRRRRRRrrRRRRRRKK+K+K+K+K+K.", 
		".......KrRRRRRRRRRRRRRRRRRRRrrrRRRRRKEEEEEEEEEE...", 
		".......KrRRRRRRRRRRrrrrrrRRRRRRRRRRKK+K+K+KK......", 
		".......KrrRRRRRRrKKKKKKKKrrRRRRRRRrrKKKKKKKK......", 
	]
	var flicker: = [
		"Y..........................Y....Y.......K.........", 
		".YMY.....................YMY...YMY.....K@K........", 
		"YMMY...................YMMYMYMMYMY....K@RK........", 
		".YMWY..........Y..Y.Y.YMMMWMMWMMY..KKK@RRRKKK.....", 
		"..YMWMY...KKKKKYMYKYMYMMMWWMMWWMY@@RRRRRRRRK......", 
	] + body.slice(5)
	var air: = ".................................................."
	t.sprites["_v2_hound"] = body + [
		"........KrRRRRRrK.........KrRRRRRrK...............", 
		"......KrRRRRr&&K..........K&&KrRRRRK..............", 
		"....KrRRRrK&&&K............K&&KKrRRRK.............", 
		"...KrRRrK.K&&&K.............K&&K.KrRRRK...........", 
		"..KrRRK..K&&&K...............K&&K..KrRRK..........", 
		".KrRRK..K&&&K.................K&&K...KrRRK........", 
		"KRRRK..K&&&K...................K&&&K...KRRRRK.....", 
		"KKKK...KKKKK...................KKKKK...KKKKKK.....", 
	]
	t.sprites["_v2_hound/2"] = [air] + flicker + [
		"........KrRRRRRrK.........KrRRRRRrK...............", 
		"......K&&KrRRRRK..........KrRRRRK&&K..............", 
		"....K&&K.KrRRRK...........KrRRRK.K&&K.............", 
		"..K&&K..KrRRK.............KrRRK....K&&K...........", 
		".K&&K..KrRRK..............KrRRK.....K&&K..........", 
		"K&&K..KrRRK...............KrRRK......K&&&K........", 
		"KKK..KrRRK................KrRRRK.....KKKKK........", 
		".....KKKK.................KKKKKK..................", 
	]
	t.sprites["_v2_hound/3"] = body + [
		"........KrRRRRRrK.........KrRRRRRrK...............", 
		".........KrRRRRK&K......K&KrRRRRK.................", 
		"...........KrRRRK&&K..K&&KrRRRK...................", 
		".............KrRRK&&KK&&KrRRK.....................", 
		"..............KrRRKKK&KrRRK.......................", 
		"..............KKKKK.KKKKKK........................", 
		air, 
		air, 
	]
	t.sprites["_v2_hound/4"] = [air] + flicker + [
		"........KrRRRRRrK.........KrRRRRRrK...............", 
		"........K&&KrRRRK..........K&&KrRRRRK.............", 
		".......K&&K.KrRRK............K&&K.KrRRRK..........", 
		"......K&&K..KrRRK..............K&&K..KrRRRK.......", 
		".....K&&K...KrRRK...............K&&K...KrRRK......", 
		".....K&&K...KrRRK................K&&&K..KRRRRK....", 
		"....K&&&K..KRRRRK................KKKKK..KKKKKK....", 
		"....KKKKK..KKKKKK.................................", 
	]

static func _survivors(t: GameTheme) -> void :

	t.sprites["v2_exorcist"] = [
		"......KKKKKK..........", 
		".....KDDDDDDK.........", 
		"....KDDdddDDDK........", 
		"....KDdDDDDDDDK.......", 
		"...KDDDDDSSSSSSK......", 
		"...KDDDDSSSSSSSK......", 
		"...KDDDSSSESSSEK......", 
		"...KDDDSSSESSSEK......", 
		"...KDDsSSSSSSSsK......", 
		"....KDsSSSSssSK.......", 
		".....KKssssssK........", 
		"....KQQKWWWWKqqK......", 
		"...KQQQqqWWqqqq&K.....", 
		"..KQQQqqqqYqqqq&&K....", 
		"..KQQqqqqYYYqqq&&K....", 
		"..KQqKqqqqYqqqqK&K....", 
		"..KSSKqqqqYqqqqKSSK...", 
		"..KssKqqqqqqqq&KssK...", 
		"...KKKQqqqqqqq&KKK....", 
		"....KQQqqqqqqq&&K.....", 
		"....KQqqqqKqqq&&K.....", 
		"....KQqqq&KKqq&&K.....", 
		"....KDDDDK.KDDDDK.....", 
		"....KKKKKK.KKKKKK.....", 
	]
	t.sprite_palettes["v2_exorcist"] = {
		"K": Color(0.07, 0.05, 0.09), "D": Color(0.3, 0.2, 0.15), "d": Color(0.5, 0.36, 0.25), 
		"S": Color(0.98, 0.8, 0.64), "s": Color(0.8, 0.56, 0.46), "E": Color(0.1, 0.08, 0.14), 
		"Q": Color(0.38, 0.34, 0.46), "q": Color(0.19, 0.17, 0.23), "&": Color(0.1, 0.09, 0.13), 
		"W": Color(0.97, 0.97, 0.95), "Y": Color(1, 0.85, 0.25), 
	}


	t.sprites["v2_paladin"] = [
		"..........KK..........", 
		".........KPPK.........", 
		"........KPPpK.........", 
		".....KKKKKKKKKK.......", 
		"....KwWWWWWWWWwK......", 
		"...KwWWWWWWWWWWwK.....", 
		"...KwWwwwwwwwwwwK.....", 
		"...KwKKKKKKKKKKKK.....", 
		"...KwKKSEKKKKSEKK.....", 
		"...KwwKKKKKKKKKwK.....", 
		"....KGwwwwwwwwGK......", 
		"..KKKGGGKKKKGGGKKK....", 
		".KwWwGKWWWYWWWKGwWwK..", 
		".KwwGGKWWYYYWWKGGwwK..", 
		".KGGGKKWWWYWWWKKGGGK..", 
		"..KSSKKwWWYWWwKKSSK...", 
		"..KKKKKwWWYWWwKKKKK...", 
		"....KGGGGGYGGGGGK.....", 
		"....KwWWWWWWWWwwK.....", 
		"....KwWWWWYWWWwwK.....", 
		"....KGwwwKKwwwGGK.....", 
		"....KGGwK..KwGGK......", 
		"....KwGGK..KGGwK......", 
		"...KKKKKK..KKKKKK.....", 
	]
	t.sprite_palettes["v2_paladin"] = {
		"K": Color(0.07, 0.07, 0.11), "P": Color(0.92, 0.2, 0.22), "p": Color(0.55, 0.08, 0.12), 
		"W": Color(0.95, 0.96, 1), "w": Color(0.68, 0.72, 0.84), "G": Color(0.42, 0.45, 0.56), 
		"S": Color(1, 0.75, 0.3), "E": Color(1, 0.95, 0.7), "Y": Color(1, 0.82, 0.25), 
	}

	t.sprites["v2_hunter"] = [
		"........KKKKK.........", 
		".......KhHhhhK........", 
		".......KHhhhhK........", 
		"....KKKKYYYYYKKKK.....", 
		"..KKhhhhhhhhhhhhhKK...", 
		"...KKKDDDDDDDDKKK.....", 
		"....KDDDSSSSSSSK......", 
		"....KDDSSSESSSEK......", 
		"....KDDSSSESSSEK......", 
		"....KDDsSSSSSSsK......", 
		"....KDDKsSSssSK.......", 
		"...KDDKRRRRRRRRK......", 
		"..KDDKLRRRrrRRLLK.....", 
		"..KDKLLLLRrLLLLllK....", 
		"..KKLLLLLLLLYLLllK....", 
		"..KLLKLLLLLLLLlKlK....", 
		"..KSSKLLLLLLLLlKSSK...", 
		"..KKKKnnnnYnnnnKKKK...", 
		"....KLLLLLLLLLllK.....", 
		"...KLLLLLKLLLLlllK....", 
		"....KTTTK.KTTtK.......", 
		"....KtTTK.KTTtK.......", 
		"....KDDDK.KDDDDK......", 
		"...KKKKKK.KKKKKKK.....", 
	]
	t.sprite_palettes["v2_hunter"] = {
		"K": Color(0.09, 0.05, 0.05), "h": Color(0.26, 0.17, 0.13), "H": Color(0.45, 0.32, 0.23), 
		"Y": Color(1, 0.8, 0.3), "D": Color(0.18, 0.12, 0.13), "S": Color(0.98, 0.8, 0.64), 
		"s": Color(0.8, 0.56, 0.46), "E": Color(0.1, 0.08, 0.14), "R": Color(0.88, 0.16, 0.18), 
		"r": Color(0.55, 0.08, 0.12), "L": Color(0.58, 0.38, 0.21), "l": Color(0.36, 0.22, 0.13), 
		"n": Color(0.24, 0.15, 0.1), "T": Color(0.34, 0.32, 0.4), "t": Color(0.2, 0.19, 0.26), 
	}

	t.sprites["v2_nun"] = [
		"......KKKKKKK.........", 
		".....KqqqqqqqK........", 
		"....KqQQqqqqqqK.......", 
		"...KqQqqWWWWWWqK......", 
		"...KqQqWWSSSSSWK......", 
		"...KqqqWSSSSSSSK......", 
		"...KqqqWSSESSSEK......", 
		"...KqqqWSSESSSEK......", 
		"...KqqqWSsSSSSsK......", 
		"...KqqqWWSSssSWK......", 
		"...KqqqqWWWWWWWK......", 
		"..KqQqqqWWWWWWqqK.....", 
		"..KQQqqqqqWWqqq&K.....", 
		"..KQqqqqqqYqqqq&K.....", 
		"..KQqKqqqYYYqqK&K.....", 
		"..KQqKqqqqYqqqKSSK....", 
		"..KSSKqqqqYqqqKSSK....", 
		"..KssKqqqqqqq&KKYK....", 
		"...KKqQqqqqqq&&K.Y....", 
		"....KQqqqqqqq&&K.Y....", 
		"...KQQqqqqqqq&&&K.O...", 
		"...KQqqqqqqqq&&&K.....", 
		"..KQqqqqqqqqqq&&&K....", 
		"..KKKKKKKKKKKKKKKK....", 
	]
	t.sprite_palettes["v2_nun"] = {
		"K": Color(0.06, 0.05, 0.08), "Q": Color(0.36, 0.34, 0.44), "q": Color(0.18, 0.17, 0.22), 
		"&": Color(0.09, 0.08, 0.12), "W": Color(0.97, 0.97, 0.95), "S": Color(0.98, 0.8, 0.64), 
		"s": Color(0.8, 0.56, 0.46), "E": Color(0.1, 0.08, 0.14), "Y": Color(1, 0.85, 0.25), "O": Color(0.85, 0.5, 0.15), 
	}

	t.sprites["v2_fallen_angel"] = [
		".........KKKKKK.........", 
		"........KAAAAAAK........", 
		".......KAaAAAAAAK.......", 
		".......KaAAAASSSSK......", 
		"......KaAAASSSSSSK......", 
		"......KaAASSESSSEK......", 
		"......KaAASSESSSEK......", 
		"......KaAAsSSSSSsK......", 
		"K.....KaAAKsSssSK.....K.", 
		"VK....KaaK.KssK......KV.", 
		"VvK..KKWWWWWWWWKK...KvV.", 
		"VvvKKWWwWWWWWWWwWKKvvV..", 
		"VvVvKWWWWWWYWWWWwKvVvV..", 
		"VVvvKWWWWWYYYWWWwKvvVV..", 
		".VvvKSKWWWWYWWWKSKvvV...", 
		".VVvKsKWWWWYWWWKsKvVV...", 
		"..VVKKKWWWWYWWwKKKVV....", 
		"...VVKOYYYYYYYYOKVV.....", 
		".....KWWWWWWWWwwK.......", 
		".....KWWWWWWWwwwK.......", 
		"....KWWWWWWWWwwwwK......", 
		"....KWWWwWWWWwwwwK......", 
		"....KKSSKKKKKKSSKK......", 
		".....KKKK....KKKK.......", 
	]
	t.sprite_palettes["v2_fallen_angel"] = {
		"K": Color(0.07, 0.06, 0.11), "A": Color(0.88, 0.9, 0.97), "a": Color(0.58, 0.6, 0.72), 
		"S": Color(0.98, 0.84, 0.74), "s": Color(0.82, 0.62, 0.56), "E": Color(0.75, 0.1, 0.15), 
		"V": Color(0.24, 0.2, 0.32), "v": Color(0.44, 0.38, 0.55), 
		"W": Color(0.97, 0.97, 0.95), "w": Color(0.7, 0.72, 0.82), "Y": Color(1, 0.85, 0.25), "O": Color(0.8, 0.55, 0.15), 
	}




static func _pets(t: GameTheme) -> void :
	var imp_body: = [
		"...K&&rKK@WERRWERK&K....", 
		"....KK&K@RRRRRRRRRK&KK..", 
		"......KK@RKWKWKWRRKK....", 
		".......K@RRKKKKKRRK.....", 
		".......KrRRRRRRRRrK.....", 
		".K@K..KRKrRRRRRRrKRK....", 
		"..KrK..KK&rrrrrr&KK.....", 
		"...KrK...KK&&&&KK.......", 
		"....KrKKKK&K..K&K.......", 
		".....KK...KK..KK........", 
	]
	t.sprites["v2_familiar"] = [
		".K....................K.", 
		".KK..................KK.", 
		".K&K.......K..K.....K&K.", 
		".K&rK.....KXKKXK...Kr&K.", 
		"..K&rK...KK@RRRRK.Kr&K..", 
		"..K&rrK.K@@RRRRRRKrr&K..", 
		"...K&rrKK@WWRRWWRKr&K...", 
	] + imp_body
	t.sprites["v2_familiar/2"] = [
		"........................", 
		"........................", 
		"...........K..K.........", 
		"..........KXKKXK........", 
		".........KK@RRRRK.......", 
		"........K@@RRRRRRK......", 
		"....KKKKK@WWRRWWRKKKK...", 
		"..KK&rrKK@WERRWERK&rrKK.", 
		".K&&rrKK@RRRRRRRRRKrr&&K", 
		"K&&rK.KK@RKWKWKWRRKKK&&K", 
		"K&rK...K@RRKKKKKRRK.Kr&K", 
		"KK.....KrRRRRRRRRrK...KK", 
	] + imp_body.slice(5)
	t.sprite_palettes["v2_familiar"] = ramp(Color(1, 0.4, 0.25)).merged({
		"X": Color(0.95, 0.9, 0.78), "W": Color(1, 1, 0.95), "E": Color(0.1, 0.02, 0.04), 
	}, true)
	var cherub_body: = [
		"....KKKSSSppSSSKKK....", 
		".......KSSSSSSK.......", 
		"......KWWWWWWWWK......", 
		".....KSKWWWWWWKSK.....", 
		"......KKWWWWWWKK......", 
		".......KKKKKKKK.......", 
	]
	t.sprites["v2_cherub"] = [
		"........HHHHHH........", 
		".......H......H.......", 
		"........HHHHHH........", 
		".KK......KKKK......KK.", 
		"KWWK...KAAAAAAK...KWWK", 
		"KWwWK.KAaAAaAAAK.KWwWK", 
		".KWwWKKSSSSSSSSKKWwWK.", 
		"..KWwWKSESSSSESKWwWK..", 
		"...KWWKSsSSSSsSKWWK...", 
	] + cherub_body
	t.sprites["v2_cherub/2"] = [
		"........HHHHHH........", 
		".......H......H.......", 
		"........HHHHHH........", 
		".........KKKK.........", 
		".......KAAAAAAK.......", 
		"......KAaAAaAAAK......", 
		"......KSSSSSSSSK......", 
		".KK...KSESSSSESK...KK.", 
		"KWWK..KSsSSSSsSK..KWWK", 
		"KWwWKKKSSSppSSSKKKWwWK", 
		".KWWK..KSSSSSSK..KWWK.", 
		"..KK..KWWWWWWWWK..KK..", 
	] + cherub_body.slice(3)
	t.sprite_palettes["v2_cherub"] = {
		"K": Color(0.25, 0.16, 0.08), "H": Color(1, 0.88, 0.35), "A": Color(1, 0.84, 0.4), "a": Color(0.85, 0.6, 0.2), 
		"S": Color(1, 0.86, 0.74), "s": Color(1, 0.6, 0.6), "E": Color(0.15, 0.1, 0.2), "p": Color(0.85, 0.35, 0.4), 
		"W": Color(1, 1, 1), "w": Color(0.75, 0.82, 0.95), 
	}



static func _more_survivors(t: GameTheme) -> void :

	var plague_doctor: = [
		"......KKKKKK..........", 
		".....KQqqqqqK.........", 
		".....KqqqqqqK.........", 
		"..KKKKqqqqqqKKKK......", 
		".KQQQQQQQQQQQQqqK.....", 
		"..KKKKKKKKKKKKKK......", 
		"....KqqXXXXXXK........", 
		"....KqXXOOXXXXKK......", 
		"....KqXXOOXXXXXXKK....", 
		"....KqXXXXXXXXXXXXKK..", 
		"....KqxXXXXXxxxxxKK...", 
		"....KqqxxxxxKKKKK.....", 
		"...KQQqqKKKKqqq&K.....", 
		"..KQQqqqqqqqqqq&&K....", 
		"..KQqqqqqqqqqqq&&K....", 
		"..KQqKqqqqqqqqqK&K....", 
		"..KLLKqqqqqqqqqKLLK...", 
		"..KllKqqqqqqqq&KMMK...", 
		"...KKKQqqqqqqq&KYMK...", 
		"....KQQqqqqqqq&&KK....", 
		"....KQqqqqqqqq&&&K....", 
		"....KQqqq&KKqq&&&K....", 
		"....KDDDDK.KDDDDK.....", 
		"....KKKKKK.KKKKKK.....", 
	]
	var plague_doctor_pal: = {
		"K": Color(0.06, 0.05, 0.07), "q": Color(0.16, 0.15, 0.19), "Q": Color(0.33, 0.31, 0.4), "&": Color(0.08, 0.07, 0.1), "X": Color(0.9, 0.84, 0.7), "x": Color(0.65, 0.57, 0.45), "O": Color(1, 0.6, 0.15), "L": Color(0.5, 0.33, 0.2), "l": Color(0.32, 0.2, 0.12), "M": Color(1, 0.45, 0.1), "Y": Color(1, 0.85, 0.25), "D": Color(0.2, 0.15, 0.13), 
	}
	for key in ["v2_plague_doctor", "plague_doctor"]:
		t.sprites[key] = plague_doctor
		t.sprite_palettes[key] = plague_doctor_pal

	var executioner: = [
		".......KKKKKK.........", 
		"......KqqqqqqK........", 
		".....KqQqqqqqqK.......", 
		".....KQqqqqqqqK.......", 
		"....KQqqqqqqqqqK......", 
		"....KqqqqKKqqKKK......", 
		"....KqqqqKWqqKWK......", 
		"....KqqqqqqqqqqK......", 
		"....KqqqqqqqqqqK......", 
		"...KqqqqqqqqqqqqK.....", 
		"..KqqqSSSSSSSSqqqK....", 
		".KSSSSSSSSSSSSSSSsK...", 
		".KSSsSSSSssSSSSSssK...", 
		".KSSKSSSSSSSSSSKsSK...", 
		".KSSKsSSSssSSSsKSSK...", 
		".KssKSSSSSSSSSSKssK...", 
		".KKKKLLLLLYLLLLKKKK...", 
		"....KNNNNNNNNNnnK.....", 
		"....KNNNNNNNNnnnK.....", 
		"....KNNNnKKNNnnnK.....", 
		"....KNNnK..KNnnnK.....", 
		"....KDDDK..KDDDDK.....", 
		"...KKKKKK..KKKKKKK....", 
	]
	var executioner_pal: = {
		"K": Color(0.08, 0.04, 0.05), "q": Color(0.17, 0.12, 0.13), "Q": Color(0.35, 0.26, 0.27), "W": Color(1, 0.3, 0.25), "S": Color(0.92, 0.72, 0.58), "s": Color(0.7, 0.48, 0.4), "L": Color(0.4, 0.25, 0.15), "Y": Color(0.85, 0.7, 0.3), "N": Color(0.3, 0.22, 0.2), "n": Color(0.19, 0.14, 0.13), "D": Color(0.15, 0.1, 0.1), 
	}
	for key in ["v2_executioner", "executioner"]:
		t.sprites[key] = executioner
		t.sprite_palettes[key] = executioner_pal

	var witch: = [
		"..........KK..........", 
		".........KPpK.........", 
		"........KPPK..........", 
		".......KPPpK..........", 
		"......KPPPpK..........", 
		"......KPPPPpK.........", 
		"...KKKKYYYYYKKKK......", 
		"..KPPPPPPPPPPPPPpK....", 
		"...KKDDDDDDDDKKKK.....", 
		"....KDDDSSSSSSSK......", 
		"....KDDSSSESSSEK......", 
		"....KDDSSSSSSSSK......", 
		"....KDDDsSSRRSsK......", 
		"....KDDDKsSSSSK.......", 
		"...KDDDKPPPPPPPK......", 
		"..KDDDKPPpPPPPPppK....", 
		"..KDDKPPPPPYPPPppK....", 
		"..KDDKPPPPPPPPPpKSSK..", 
		"..KSSKPPPPPPPPPpKSSK..", 
		"...KKPPPPPPPPPPppKK...", 
		"...KPPPPPPPPPPPpppK...", 
		"..KPPPPPPPPPPPPppppK..", 
		"..KPpPPpPPpPPpPpppppK.", 
		"..KKKKKKKKKKKKKKKKKKK.", 
	]
	var witch_pal: = {
		"K": Color(0.06, 0.04, 0.08), "P": Color(0.4, 0.22, 0.52), "p": Color(0.23, 0.12, 0.31), "Y": Color(1, 0.8, 0.3), "D": Color(0.12, 0.16, 0.12), "S": Color(0.9, 0.88, 0.8), "s": Color(0.68, 0.66, 0.62), "E": Color(0.45, 1, 0.4), "R": Color(0.7, 0.1, 0.2), 
	}
	for key in ["v2_witch", "witch"]:
		t.sprites[key] = witch
		t.sprite_palettes[key] = witch_pal

	var crusader: = [
		".......KKKKKKK........", 
		"......KIIIIIIIK.......", 
		".....KIIIIIIIIIK......", 
		".....KGIIIIIIIGK......", 
		"...KAAKGGGGGGGGK......", 
		"...KAAKwwSSSSSSK......", 
		"..KAaAKwSSESSSEK......", 
		"..KAAaKwSSESSSEK......", 
		"..KaAK.KwSSSSSsK......", 
		"..KRRK.KwwsSSsK.......", 
		"...KK.KwwwwwwwK.......", 
		".....KWWWWWWWWWK......", 
		"...KwWWWWRWWWWWwK.....", 
		"..KwwWWWRRRWWWWwwK....", 
		"..KGGKWWWRWWWWWKGGK...", 
		"..KSSKWWWRWWWWWKSSK...", 
		"..KKKKGGGGGGGGGKKKK...", 
		"....KWWWWWWWWWwwK.....", 
		"....KWWWWWWWWwwwK.....", 
		"....KGGwwKKwwwGGK.....", 
		"....KGGGK..KGGGGK.....", 
		"...KKKKKK..KKKKKKK....", 
	]
	var crusader_pal: = {
		"K": Color(0.07, 0.07, 0.1), "W": Color(0.96, 0.95, 0.92), "w": Color(0.7, 0.7, 0.76), "G": Color(0.45, 0.48, 0.56), "I": Color(0.78, 0.8, 0.86), "A": Color(1, 0.82, 0.4), "a": Color(0.75, 0.55, 0.25), "S": Color(0.98, 0.8, 0.64), "s": Color(0.8, 0.56, 0.46), "E": Color(0.1, 0.08, 0.14), "R": Color(0.82, 0.12, 0.15), 
	}
	for key in ["v2_crusader", "crusader"]:
		t.sprites[key] = crusader
		t.sprite_palettes[key] = crusader_pal
