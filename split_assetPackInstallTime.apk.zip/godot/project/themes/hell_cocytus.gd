class_name HellCocytus
extends RefCounted










static func build(t: GameTheme) -> void :
	_cast(t)
	_bosses(t)
	_scenery(t)
	_paint(t)
	_survivor(t)
	_icons(t)



static func _survivor(t: GameTheme) -> void :
	var hermit: = [
		".......KKKKKK.........", 
		"......KFFFFFfK........", 
		".....KFFffffFfK.......", 
		".....KFfSSSSfFK.......", 
		".....KFSOSSOSfK.......", 
		".....KFSSSSSSfK.......", 
		".....KFWWWWWWfK.......", 
		"....KCKWWwWWWKCK......", 
		"...KCCKWWwwWWKCcK.....", 
		"..KCCCCKWwwWKCCccK....", 
		"..KCCCCCKWWKCCCccK....", 
		"..KCKCCCCKKCCCCKcK....", 
		"..KSKCCCCCCCCCCKSK.KK.", 
		"..KKKCCCCCCCCCCKKKKTTK", 
		"....KCCCCCCCCCcKKTUUTK", 
		"....KCCCCCCCCccK.KTTK.", 
		"....KCCCCCCCcccK..KK..", 
		"....KCCCCCCCcccK......", 
		"....KFFFFFFFFFfK......", 
		"....KCCCcKKCCccK......", 
		"....KDDDK..KDDDK......", 
		"....KKKKK..KKKKK......", 
	]
	var pal: = {"K": Color(0.06, 0.06, 0.09), "F": Color(0.74, 0.72, 0.68), "f": Color(0.5, 0.48, 0.46), 
		"S": Color(0.9, 0.76, 0.66), "O": Color(0.42, 0.82, 1), "W": Color(0.96, 0.96, 0.99), "w": Color(0.74, 0.78, 0.86), 
		"C": Color(0.26, 0.34, 0.54), "c": Color(0.15, 0.19, 0.33), "T": Color(0.6, 0.9, 1), "U": Color(0.95, 1, 1), 
		"D": Color(0.22, 0.17, 0.15)}
	for key in ["v2_frost_hermit", "frost_hermit"]:
		t.sprites[key] = hermit
		t.sprite_palettes[key] = pal



static func _icons(t: GameTheme) -> void :
	t.sprites["icon_tear"] = [
		"............KK", 
		"...........KWK", 
		"..........KWtK", 
		".........KWTtK", 
		"........KWTtK.", 
		".......KWTTtK.", 
		"......KWTTtK..", 
		".....KWTTtK...", 
		"....KWTTtK....", 
		"...KWTTtK.....", 
		"..KWTtK.......", 
		".KWTtK........", 
		"KWtK..........", 
		"KKK...........", 
	]
	t.sprite_palettes["icon_tear"] = {"K": Color(0.06, 0.1, 0.18), "W": Color(0.95, 1, 1), "T": Color(0.55, 0.86, 1), "t": Color(0.3, 0.55, 0.85)}
	t.sprites["holy_tears"] = [
		"..KKK.......KK", 
		".K666K.....K5K", 
		"..KKK.....K57K", 
		".........K557K", 
		"........K557K.", 
		".......K5577K.", 
		"......K5577K..", 
		".....K5577K...", 
		"....K5577K....", 
		"...K5577K.....", 
		"..K5578K......", 
		".K578K........", 
		"K58K..........", 
		"KKK...........", 
	]
	t.sprites["icon_frozen_hourglass"] = [
		"KKKKKKKKKKKK", 
		"KGGGGGGGGGgK", 
		".KWTTTTTTWK.", 
		"..KWTTTTWK..", 
		"...KWTTWK...", 
		"....KWTK....", 
		"....KWTK....", 
		"...KWWWWK...", 
		"..KWWTTWWK..", 
		".KWWTTTTWWK.", 
		"KGGGGGGGGGgK", 
		"KKKKKKKKKKKK", 
	]
	t.sprite_palettes["icon_frozen_hourglass"] = {"K": Color(0.06, 0.08, 0.13), "G": Color(0.6, 0.68, 0.8), "g": Color(0.38, 0.45, 0.58), 
		"W": Color(0.86, 0.96, 1), "T": Color(0.4, 0.76, 1)}

static func _paint(t: GameTheme) -> void :
	var ice: = {"I": Color(0.78, 0.94, 1), "i": Color(0.45, 0.7, 0.9), "W": Color(1, 1, 0.97)}
	var hair: = {"H": Color(0.22, 0.24, 0.32), "h": Color(0.12, 0.13, 0.19), "j": Color(0.4, 0.44, 0.55)}
	var chain: = {"G": Color(0.7, 0.72, 0.8), "g": Color(0.34, 0.36, 0.44)}
	var kinds: = {
		"frozen_traitor": ["_c_traitor", Color(0.55, 0.66, 0.78), ice.merged(hair, true).merged(chain, true).merged({"D": Color(0.45, 0.1, 0.13), "d": Color(0.3, 0.06, 0.09), "e": Color(0.17, 0.03, 0.06), "b": Color(0.62, 0.2, 0.22), "Y": Color(1, 0.72, 0.25), "E": Color(0.08, 0.03, 0.05)}, true)], 
		"traitor_knight": ["_c_traitor", Color(0.6, 0.6, 0.66), ice.merged({"H": Color(0.5, 0.52, 0.6), "h": Color(0.3, 0.32, 0.4), "j": Color(0.72, 0.74, 0.8)}, true).merged(chain, true).merged({"D": Color(0.24, 0.28, 0.4), "d": Color(0.15, 0.17, 0.26), "e": Color(0.08, 0.09, 0.15), "b": Color(0.4, 0.46, 0.62), "Y": Color(1, 0.28, 0.18), "E": Color(0.05, 0.02, 0.04)}, true)], 
		"frostwing": ["_c_frostwing", Color(0.5, 0.52, 0.62), ice.merged({"B": Color(0.82, 0.86, 0.92), "F": Color(0.32, 0.3, 0.42), "f": Color(0.2, 0.18, 0.28), "Y": Color(1, 0.25, 0.15), "E": Color(0.08, 0.02, 0.04)}, true)], 
		"ice_mite": ["_c_mite", Color(0.72, 0.78, 0.86), ice.merged({"Y": Color(1, 0.3, 0.2)}, true)], 
		"blood_mite": ["_c_mite", Color(0.62, 0.16, 0.2), ice.merged({"Y": Color(1, 0.85, 0.35)}, true)], 
		"ice_beetle": ["_c_beetle", Color(0.3, 0.42, 0.58), ice.merged({"Y": Color(1, 0.55, 0.15)}, true)], 
		"hoarfrost_wisp": ["_c_wisp", Color(0.85, 0.86, 0.82), ice.merged({"Y": Color(0.4, 0.85, 1), "M": Color(0.62, 0.74, 0.86), "m": Color(0.4, 0.5, 0.64)}, true)], 
		"chained_giant": ["_c_giant", Color(0.62, 0.56, 0.54), ice.merged(chain, true).merged({"D": Color(0.3, 0.22, 0.18), "d": Color(0.19, 0.14, 0.11), "Y": Color(1, 0.55, 0.15)}, true)], 
		"antaeus": ["_c_giant", Color(0.7, 0.48, 0.36), ice.merged({"G": Color(0.92, 0.75, 0.35), "g": Color(0.55, 0.4, 0.15), "D": Color(0.2, 0.24, 0.36), "d": Color(0.12, 0.14, 0.22), "Y": Color(0.5, 0.95, 1)}, true)], 
		"ugolino": ["_c_ugolino", Color(0.66, 0.7, 0.78), ice.merged({"G": Color(1, 0.8, 0.3), "H": Color(0.9, 0.92, 0.95), "S": Color(0.72, 0.76, 0.84), "X": Color(0.9, 0.86, 0.76), "E": Color(0.08, 0.05, 0.07), "D": Color(0.36, 0.1, 0.34), "d": Color(0.22, 0.05, 0.21), "e": Color(0.12, 0.02, 0.12), "Y": Color(1, 0.22, 0.18)}, true)], 
		"slush": ["_c_slush", Color(0.52, 0.6, 0.7), ice.merged({"X": Color(0.88, 0.85, 0.76), "E": Color(0.06, 0.04, 0.08), "Y": Color(1, 0.5, 0.2)}, true)], 
		"lucifer": ["_c_lucifer", Color(0.7, 0.12, 0.15), {"B": Color(0.16, 0.14, 0.2), "b": Color(0.32, 0.28, 0.38), "N": Color(0.08, 0.07, 0.1), "P": Color(0.88, 0.8, 0.5), "p": Color(1, 0.95, 0.72), "Q": Color(0.58, 0.5, 0.28), "Y": Color(1, 0.85, 0.3), "W": Color(1, 1, 0.95), "S": Color(0.95, 0.9, 0.8), "X": Color(0.76, 0.93, 1.0), "x": Color(0.45, 0.68, 0.9), "F": Color(0.66, 0.34, 0.44), "f": Color(0.44, 0.2, 0.3), "O": Color(0.9, 0.72, 0.7)}], 
	}
	for id: String in kinds:
		var k: Array = kinds[id]
		HellArtV2._family(t, k[0], id, HellArtV2.ramp(k[1]).merged(k[2], true))

	var bone: = {"X": Color(0.92, 0.9, 0.8), "w": Color(0.62, 0.58, 0.55), "W": Color(1, 1, 0.95)}
	var waves: = {
		"blizzard_wraith": ["_m_wraith", Color(0.8, 0.9, 1.0), {"E": Color(0.03, 0.04, 0.08), "Y": Color(1, 0.35, 0.25), "X": Color(0.92, 1, 1)}], 
		"frost_gargoyle": ["_m_gargoyle", Color(0.7, 0.8, 0.94), bone.merged({"X": Color(0.9, 0.98, 1), "w": Color(0.55, 0.7, 0.85), "Y": Color(1, 0.4, 0.2)}, true)], 
	}
	for id: String in waves:
		var k: Array = waves[id]
		HellArtV2._family(t, k[0], id, HellArtV2.ramp(k[1]).merged(k[2], true))

static func _cast(t: GameTheme) -> void :



	t.sprites["_c_traitor"] = [
		"..........KKKKK..............", 
		"........KKjHHHHKK............", 
		".......KjHHHHhHHhK...........", 
		"......KjHHhHHHHhhhK..........", 
		"......KHHhHHjHH@@KhK.........", 
		".....KjHhHHHHK@RRRKhK........", 
		".....KHHhHHHK@RRRRrKhK.......", 
		".....KHhHhHHK@RYYRrKhK.......", 
		"....KjHhHhHK@RRRRr&KhK.......", 
		"....KHhKhHhK@RRrrr&KhhK......", 
		"....KhK.KhK.K@REEr&K.KhK.....", 
		"....KK..KhK..KrEEr&K..KK.....", 
		"........KK...KKrr&KK.........", 
		".......KKIIKKK&r&KKIIK.......", 
		".....KKIWIII@@RRRRRIIIKK.....", 
		"....KIIIi@@RRRRRRRRRiIIiK....", 
		"...KIii@RRRRRRRRRRRRrriiK....", 
		"...Ki@RRK@RRRRRRRRRRK&r&iK...", 
		"...K@RRK@RRrrrrrrRRRrK&r&K...", 
		"..K@RRK.K@RRRRRRRRRRrK.K&rK..", 
		"..K@RK..K@RrrrrrrRRRrK.K&rK..", 
		"..K@RK..K@RRRRRRRRRrrK..K&rK.", 
		"..K@RK..KK@RRRRRRRrr&K..K&rK.", 
		"..K@RK...KbDDDDDDDDdeK..K&rK.", 
		"..K@RK...KbDDDDDDDDdeK..KRrK.", 
		"..KGGGK..KbDDdDDDDdDdeK.KGGGK", 
		"..KgGgK..KbDDdDDDDdDdeK.KgGgK", 
		"..K@RRK..KbDDdDDDDdDdeK.KrRrK", 
		"..KKRKRK.KbDDdDDDDdDdeKKRKRKK", 
		"...KRKRK.KbDDdDDdDDdDeK.KRKRK", 
		"....KGK..KDDKdDDKdDKdeK..KGK.", 
		"....KgK..K@RKKKK.K@RKK...KgK.", 
		"....KGK..K@RrK...K@RrK...KGK.", 
		"....KiK..K@RrK...K@RrK...KiK.", 
		".....K...K@RrK...KRrrK....K..", 
		"..........KRr&K..KRr&K.......", 
		"..........K@Rr&K.KRr&K.......", 
		"..........KKKKKK.KKKKKK......", 
	]
	t.sprites["_c_traitor/2"] = [
		"..........KKKKK..............", 
		"........KKjHHHHKK............", 
		".......KjHHHHhHHhK...........", 
		"......KjHHhHHHHhhhK..........", 
		"......KHHhHHjHH@@KhK.........", 
		".....KjHhHHHHK@RRRKhK........", 
		".....KHHhHHHK@RRRRrKhK.......", 
		".....KHhHhHHK@RYYRrKhK.......", 
		"....KjHhHhHK@RRRRr&KhK.......", 
		"....KHhKhHhK@RRrrr&KhhK......", 
		"....KhK.KhK.K@REEr&K.KhK.....", 
		"....KK..KhK..KrEEr&K..KK.....", 
		"........KK...KKrr&KK.........", 
		".......KKIIKKK&r&KKIIK.......", 
		".....KKIWIII@@RRRRRIIIKK.....", 
		"....KIIIi@@RRRRRRRRRiIIiK....", 
		"...KIii@RRRRRRRRRRRRrriiK....", 
		"...Ki@RRK@RRRRRRRRRRK&r&iK...", 
		"...K@RRK@RRrrrrrrRRRrK&r&K...", 
		"..K@RRK.K@RRRRRRRRRRrK.K&rK..", 
		"..K@RK..K@RrrrrrrRRRrK.K&rK..", 
		"..K@RK..K@RRRRRRRRRrrK..K&rK.", 
		"..K@RK..KK@RRRRRRRrr&K..K&rK.", 
		"..K@RK...KbDDDDDDDDdeK..K&rK.", 
		"..K@RK...KbDDDDDDDDdeK..KRrK.", 
		"..KGGGK..KbDDdDDDDdDdeK.KGGGK", 
		"..KgGgK..KbDDdDDDDdDdeK.KgGgK", 
		"..K@RRK..KbDDdDDDDdDdeK.KrRrK", 
		"..KKRKRK.KbDDdDDDDdDdeKKRKRKK", 
		"...KRKRK.KbDDdDDdDDdDeK.KRKRK", 
		"....KGK..KDDKdDDKdDKdeK..KGK.", 
		"....KgK...K@RKKK.K@RKK...KgK.", 
		"....KGK..K@RrK...K@RrK...KGK.", 
		"....KiK.K@RrK....K@RrK...KiK.", 
		".....K..KRrrK.....K@RrK...K..", 
		"........KRr&K.....KRr&K......", 
		".......KRRr&K.....KRr&K......", 
		".......KKKKKK.....KKKKKK.....", 
	]
	t.sprites["_c_giant"] = [
		"..........KKKKK...............", 
		"........KK@@RRrKK.............", 
		".......K@RRRRRrr&K............", 
		"......K@RKKRRKKrr&K...........", 
		"......K@RYYRRYYrr&K...........", 
		"......K@RRRRRRrr&&K...........", 
		".......K@RWKWKr&&K............", 
		"....KKKKGGGGGGGGGKKKKK........", 
		"..KK@@RgGGGGGGGGGgRRrrKK......", 
		".K@@RRRRKgggggggKRRRRrr&K.....", 
		"K@@RRRRRRRRRRRRRRRRRRRrr&K....", 
		"K@RRRRGGRRRRRRRRRRRRRRRr&K....", 
		"K@RRRK@GGRRrRRRRRRRRK@Rr&&K...", 
		"K@RRK.K@RGGRRrRRRRRRKK@Rr&K...", 
		"K@RRK.K@RRRGGRRrRRRRrK.K@r&K..", 
		"K@RRK.K@RRRRRGGRRRRrrK.K@r&K..", 
		"K@RRK.KK@RRRRRRGGRRrrK.KRr&K..", 
		"K@RRK..K@RRrRRRRRGGr&K.KRr&K..", 
		"KGGGGK.K@RRRrRRRRRRGr&K.KGGGGK", 
		"KgGGgK..KDDDDDDDDDDDdK..KgGGgK", 
		"K@RRrK..KDDdDDDDDDdDdK..K@RrrK", 
		"K@R@RrK.KDDdDDDDDDdDdK.K@R@RrK", 
		".K@KRKK.KDDKdDDDDdKDdK.KK@KRK.", 
		"..KK.K..KK..KDDDK..KK..K.KK...", 
		".........K@RRK...K@RRK........", 
		".........K@RRrK..K@RrK........", 
		".........K@RRrK..K@RrK........", 
		".........K@RRrK..KRrrK........", 
		"..........KRr&K..KRr&K........", 
		".........K@RRr&KK@Rr&K........", 
		".........KKKKKKKKKKKKK........", 
	]
	t.sprites["_c_giant/2"] = [
		"..........KKKKK...............", 
		"........KK@@RRrKK.............", 
		".......K@RRRRRrr&K............", 
		"......K@RKKRRKKrr&K...........", 
		"......K@RYYRRYYrr&K...........", 
		"......K@RRRRRRrr&&K...........", 
		".......K@RWKWKr&&K............", 
		"....KKKKGGGGGGGGGKKKKK........", 
		"..KK@@RgGGGGGGGGGgRRrrKK......", 
		".K@@RRRRKgggggggKRRRRrr&K.....", 
		"K@@RRRRRRRRRRRRRRRRRRRrr&K....", 
		"K@RRRRGGRRRRRRRRRRRRRRRr&K....", 
		"K@RRRK@GGRRrRRRRRRRRK@Rr&&K...", 
		"K@RRK.K@RGGRRrRRRRRRKK@Rr&K...", 
		"K@RRK.K@RRRGGRRrRRRRrK.K@r&K..", 
		"K@RRK.K@RRRRRGGRRRRrrK.K@r&K..", 
		"K@RRK.KK@RRRRRRGGRRrrK.KRr&K..", 
		"K@RRK..K@RRrRRRRRGGr&K.KRr&K..", 
		"KGGGGK.K@RRRrRRRRRRGr&K.KGGGGK", 
		"KgGGgK..KDDDDDDDDDDDdK..KgGGgK", 
		"K@RRrK..KDDdDDDDDDdDdK..K@RrrK", 
		"K@R@RrK.KDDdDDDDDDdDdK.K@R@RrK", 
		".K@KRKK.KDDKdDDDDdKDdK.KK@KRK.", 
		"..KK.K..KK..KDDDK..KK..K.KK...", 
		".........K@RRK...K@RRK........", 
		".........K@RRrK..K@RrK........", 
		"..........KRr&K..K@RrK........", 
		".........KKKKKK..KRrrK........", 
		".................KRr&K........", 
		"................K@Rr&K........", 
		"................KKKKKK........", 
	]
	t.sprites["_c_mite"] = [
		"....K..K..K..K.......", 
		"...KIK.KIKKIK.KIK....", 
		"..KIiKKIiKIiKKIiK....", 
		"..KIiRRIiRRIiRR@@K...", 
		"..KrRRRRRRRRRRRRR@K..", 
		".K&rrRRRRrRRRRrRRR@K.", 
		"K&&rrRRRRRRRRRRRRRR@K", 
		"K&&rrRRRRRRRRRRRRYYK.", 
		".K&&rrRRRRRRRrWRWRR@K", 
		"..KK&&rrrrrrrKKWK.WK.", 
		"...K.K.K..K.K..K.K...", 
		"..K.K..K..K..K..K.K..", 
	]
	t.sprites["_c_mite/2"] = [
		"....K..K..K..K.......", 
		"...KIK.KIKKIK.KIK....", 
		"..KIiKKIiKIiKKIiK....", 
		"..KIiRRIiRRIiRR@@K...", 
		"..KrRRRRRRRRRRRRR@K..", 
		".K&rrRRRRrRRRRrRRR@K.", 
		"K&&rrRRRRRRRRRRRRRR@K", 
		"K&&rrRRRRRRRRRRRRYYK.", 
		".K&&rrRRRRRRRrWRWRR@K", 
		"..KK&&rrrrrrrKKWK.WK.", 
		"....K.K.K..K.K..K.K..", 
		"...K..K.K..K..K..K.K.", 
	]
	t.sprites["_c_beetle"] = [
		"..................KK....", 
		".................KIIK...", 
		"................KIiK....", 
		".......KKKKKKKKKIiK.....", 
		".....KK@@IIRRRRRIIK.....", 
		"....K@@IIRRRRRRRrIK.....", 
		"...K@IIRRRRKRRRRrrKKK...", 
		"..K@IRRRRRRKRRRRrr@RRK..", 
		"..K@RRRRRRRKRRRrr@YRRrK.", 
		".K@RRRRRRRRKRRrr&@RRRWK.", 
		".K@RRRRRRRRKRrr&&RRRWK..", 
		".KRRRRRRRRRKrr&&rrrrK...", 
		".K&rrrrrrrrrrr&&KKKK....", 
		"..KKKKKKKKKKKKKK........", 
		"...K.K..K.K..K.K........", 
		"..K..K.K..K.K..K........", 
	]
	t.sprites["_c_beetle/2"] = [
		"..................KK....", 
		".................KIIK...", 
		"................KIiK....", 
		".......KKKKKKKKKIiK.....", 
		".....KK@@IIRRRRRIIK.....", 
		"....K@@IIRRRRRRRrIK.....", 
		"...K@IIRRRRKRRRRrrKKK...", 
		"..K@IRRRRRRKRRRRrr@RRK..", 
		"..K@RRRRRRRKRRRrr@YRRrK.", 
		".K@RRRRRRRRKRRrr&@RRRWK.", 
		".K@RRRRRRRRKRrr&&RRRWK..", 
		".KRRRRRRRRRKrr&&rrrrK...", 
		".K&rrrrrrrrrrr&&KKKK....", 
		"..KKKKKKKKKKKKKK........", 
		"....K.K..K.K..K.K.......", 
		"...K..K.K..K.K..K.......", 
	]
	t.sprites["_c_wisp"] = [
		".........KK.........", 
		".......KKIiK...K....", 
		"..K...KIIiK...KIK...", 
		"..KIK.KIiKKKKKIiK...", 
		"...KIiK@@RRRRKiK....", 
		"....KK@RRRRRRrKK....", 
		"...K@RKKRRRKKrr&K...", 
		"...K@KYYKRKYYKr&K...", 
		"...K@RRKKRKKRRr&K...", 
		"....K@RRRRRRRr&K....", 
		"....KK@RWKWKr&KK....", 
		"..KIK.K&rrrr&K.KIK..", 
		"..KiiK.KKKKKK.KiiK..", 
		"...KK..KiMMiK..KK...", 
		".......KMmmMK.......", 
		"........KmmK........", 
		".........KK.........", 
	]
	t.sprites["_c_wisp/2"] = [
		".........KK.........", 
		".......KKIiK...K....", 
		"..K...KIIiK...KIK...", 
		"..KIK.KIiKKKKKIiK...", 
		"...KIiK@@RRRRKiK....", 
		"....KK@RRRRRRrKK....", 
		"...K@RKKRRRKKrr&K...", 
		"...K@KYYKRKYYKr&K...", 
		"...K@RRKKRKKRRr&K...", 
		"....K@RRRRRRRr&K....", 
		"....KK@RWKWKr&KK....", 
		"..KIK.K&rrrr&K.KIK..", 
		"..KiiK.KKKKKK.KiiK..", 
		"...KK..KiMMiK..KK...", 
		"......KMmmMK........", 
		".......KmmK.........", 
		"........KK..........", 
	]
	t.sprites["_c_frostwing"] = [
		"KK..................................KK", 
		"KBK................................KBK", 
		"KfBK......K..............K........KBfK", 
		".KfBK....KBK............KBK......KBfK.", 
		".KffBK...KfBK..KK..KK..KBfK.....KBffK.", 
		"..KfFBK..KffBKK@K..K@KKBffK....KBFfK..", 
		"..KfFFBK.KfFFBK@RKKR@KBFFfK...KBFFfK..", 
		"...KfFFBKKfFFFK@RRRR@KFFFfK..KBFFfK...", 
		"...KfFfFBKfFfK@RRRRRRrKfFfK.KBFfFfK...", 
		"....KfFfFBKfK@RYRRRRYrrKfK.KBFfFfK....", 
		"....KfFfFFBKK@RRRRRRRrrKKKBFFfFfK.....", 
		".....KfFfFFBK@RRWEEWRr&KBFFfFfK.......", 
		".....KfFfFfFBK@RWEEWr&KBFfFfFfK.......", 
		"......KfKfFfFK@RRRRr&KFfFfKfK.........", 
		"......KiK.KfKfK@Rrr&KfKfK.KiK.........", 
		".......K..KiK.KK&&&KK.KiK..K..........", 
		"...........K..K&K.K&K..K..............", 
		"..............KiK.KiK.................", 
		"...............K...K..................", 
	]
	t.sprites["_c_frostwing/2"] = [
		"......................................", 
		"......................................", 
		"......................................", 
		"......................................", 
		"...........KK..........KK.............", 
		"...........K@K.KK..KK.K@K.............", 
		"...........K@RKK@K.K@KR@K.............", 
		"...........K@RRRR@KK@RRrK.............", 
		".......KKKKK@RRRRRRRRRrrKKKKK.........", 
		"....KKBBBBK@RYRRRRRRYrrKBBBBKK........", 
		"..KKBFFFFFK@RRRRRRRRRrrKFFFFFBKK......", 
		".KBFFfFfFfKK@RRWEEWRr&KKfFfFfFFBK.....", 
		"KBFfFfFfFfFK@RRWEEWr&KFfFfFfFfFFBK....", 
		"KfFfKfFfKfFfK@RRRRr&KfFfKfFfKfFfK.....", 
		"KfKK.KfK.KfKKK@Rrr&KKKfK.KfK.KKfK.....", 
		"KiK..KiK..KiK.KK&&KK.KiK..KiK..KiK....", 
		".K....K....K..K&K.K&K..K....K....K....", 
		"..............KiK.KiK.................", 
		"...............K...K..................", 
	]



	t.sprites["_c_slush"] = [
		".........KKKKK..........", 
		"......KKK@@IIRKKK.......", 
		"....KK@@IIIRRRRRrKK.....", 
		"...K@IIRRRRXRRRRRrrK....", 
		"..K@IRRRKKRRRRKKRRrrK...", 
		"..K@RRRKYYKRRKYYKRrrK...", 
		".K@IRRRRKKRRRRKKRRRrrK..", 
		".K@RRRKKKKKKKKKKKKRrr&K.", 
		"K@IRRKWEEEEEEEEEEWKRr&&K", 
		"K@RRRKEEWEEEEEEWEEKRr&&K", 
		"K@RRRRKWEEEEEEEEWKRRr&&K", 
		"KRRXRRRKKKKKKKKKKRRXrr&K", 
		"K&rrRRRRRRRXRRRRRRrrr&&K", 
		".KK&&rrrrrrrrrrrrrr&&KK.", 
		"...KKKKKKKKKKKKKKKKKK...", 
	]
	t.sprites["_c_slush/2"] = [
		".........KKKKK..........", 
		"......KKK@@IIRKKK.......", 
		"....KK@@IIIRRRRRrKK.....", 
		"...K@IIRRRRXRRRRRrrK....", 
		"..K@IRRRKKRRRRKKRRrrK...", 
		"..K@RRRKYYKRRKYYKRrrK...", 
		".K@IRRRRKKRRRRKKRRRrrK..", 
		".K@RRRKKKKKKKKKKKKRrr&K.", 
		"K@IRRKKWEEEEEEEEWKKRr&&K", 
		"K@RRRRKKWWWWWWWWKKRRr&&K", 
		"K@RRRRRKKKKKKKKKKRRRr&&K", 
		"KRRXRRRKKKKKKKKKKRRXrr&K", 
		"K&rrRRRRRRRXRRRRRRrrr&&K", 
		".KK&&rrrrrrrrrrrrrr&&KK.", 
		"...KKKKKKKKKKKKKKKKKK...", 
	]

static func _bosses(t: GameTheme) -> void :


	t.sprites["_c_ugolino"] = [
		"...........KGKGKGK..........", 
		"...........KGGGGGK..........", 
		"..........KHHHHHHHK.........", 
		".........KHK@RRRrKHK........", 
		".........KHK@YRYr&KHK.......", 
		".........KHK@RRRr&KHK.......", 
		".........KH.K@KKr&KH........", 
		".......KKSSKKXXXKKSSKK......", 
		"......KSSSSKXEXEXKSSSSK.....", 
		"......KSSKKXXXXXXXKKSSK.....", 
		".......KK.KKXWWWXKK.KK......", 
		".....KKDDDDKKKKKKKDDDDKK....", 
		"....KDDDDDK@RrRrRK&DDDDdK...", 
		"...KDDDDDDK@RRRRRrKDDDDddK..", 
		"...KDDDDDK@RrRrRr&KDDDDddK..", 
		"..KDDDDDDK@RRRRRr&KDDDDdddK.", 
		"..KDDDDDDKK&rrrr&KKDDDDdddK.", 
		"..KDDDDDDDK@RRRr&KDDDDDdddK.", 
		".KDDDDDDDDK@RRrr&KDDDDDddddK", 
		".KdDDDDDDDK@RrK&&KDDDDDdddeK", 
		".KddDDDDDK@RRK.K@RKDDDddeeK.", 
		"..KKdddddK@RrK.K@RrKdddeKK..", 
		"....KKKKKK@RrK.K@RrKKKKK....", 
		"..........KKKK.KKKK.........", 
	]
	t.sprites["_c_ugolino/2"] = [
		"...........KGKGKGK..........", 
		"...........KGGGGGK..........", 
		"..........KHHHHHHHK.........", 
		".........KHK@RRRrKHK........", 
		".........KHK@YRYr&KHK.......", 
		".........KHK@RRRr&KHK.......", 
		".........KH.K@KKr&KH........", 
		".......KKSSKKXXXKKSSKK......", 
		"......KSSSSKXEXEXKSSSSK.....", 
		"......KSSKKXXXXXXXKKSSK.....", 
		".......KK.KKXWWWXKK.KK......", 
		".....KKDDDDKKKKKKKDDDDKK....", 
		"....KDDDDDK@RrRrRK&DDDDdK...", 
		"...KDDDDDDK@RRRRRrKDDDDddK..", 
		"...KDDDDDK@RrRrRr&KDDDDddK..", 
		"..KDDDDDDK@RRRRRr&KDDDDdddK.", 
		"..KDDDDDDKK&rrrr&KKDDDDdddK.", 
		"..KDDDDDDDK@RRRr&KDDDDDdddK.", 
		".KDDDDDDDDK@RRrr&KDDDDDddddK", 
		".KdDDDDDDDK@RrK&&KDDDDDdddeK", 
		".KddDDDDDK@RRK..K@RKDDddeeK.", 
		"..KKdddddK@RrK..K@RrKddeKK..", 
		"....KKKKKK@RrK.K@RrKKKKK....", 
		"..........KKKK.KKKK.........", 
	]

	var mid: = [
		"............K....K............", 
		"..K....K...K@K..K@K...K....K..", 
		".KbK..KNK..K@RKKR@K..KpK..KQK.", 
		"KbBBBBBBNKK@RRRRRRrKKpPPPPPPQK", 
		"KbBKBBKBNKK@RKRRKRrKKpPKPPKPQK", 
		"KbYYBBYYNKK@YYRRYYrKKpYYPPYYQK", 
		"KbBBBBBBNKK@RRRRRRrKKpPPPPPPQK", 
		"KBBWKKWBNKKRRWKKWRrKKPPWKKWPQK", 
		".KBWWWWNK..KRWWWWrK..KPWWWWQK.", 
		"..KKKKKK....KKKKKK....KKKKKK..", 
		"....KKK@@RRRRRRRRRRRRrrKKK....", 
		"...K@@RRRRRRRRRRRRRRRRRrr&K...", 
		"..K@RRRRRKRRRRRRRRRRKRRRrr&K..", 
		"..K@RRRRK@RRrRRRRrRRrKRRrr&K..", 
		".K@RRRRK.K@RRRRRRRRRrK.KRRr&K.", 
		".K@RRRK..K@RRrRRRRrRrK..KRr&K.", 
		".KSSSK...K@RRRRRRRRRrK...KSSK.", 
		".KSSK....KK@RRRRRRRr&K....KSK.", 
		"..KK......K@RRRRRRr&K......KK.", 
		"........KKXXXXXXXXXXXXKK......", 
		"......KKXXxXXXXXXXXxXXXXKK....", 
		".....KXXxXXXXXxXXXXXXXxXXXK...", 
		".....KxxxxxxxxxxxxxxxxxxxxK...", 
		"......KKKKKKKKKKKKKKKKKKKK....", 
	]

	var up: = [
		"..............", "K.............", "KOK...........", "KOfK..........", "KOFfK.........", "KOFFfK....K...", 
		"KOFFFfK..KOK..", "KOFFFFfKKOfK..", "KOFFFFFfOFfK..", "KOFFFFFOFFfK..", "KOFFFFOFFFfKKK", "KOFFFOFFFFfOOK", 
		"KOFFOFFFFfOFfK", "KOFOFFFFfOFFfK", ".KOKFFFfOFFFfK", "..K.KFfOKFFffK", "....KfK.KFfKKK", ".....K...KK...", 
	]
	var down: = [
		"..............", "..............", "..............", "..............", "..............", "..............", 
		"..............", "KK............", "KOOK..........", "KOFfOKK.......", "KOFFFfOOKK....", "KOFFFFFFfOOKKK", 
		"KOFFFOFFFFFfOK", ".KOFOFFOFFFFfK", ".KOKFFOKFFOFfK", "..K.KFK.KFKfKK", ".....K...K.K..", "..............", 
	]
	t.sprites["_c_lucifer"] = _winged(mid, up)
	t.sprites["_c_lucifer/2"] = _winged(mid, down)





const OVERLAP: = 6

static func _winged(mid: Array, wing: Array) -> Array:
	var ww: = (wing[0] as String).length()
	var mw: = (mid[0] as String).length()
	var width: = ww * 2 + mw - OVERLAP * 2
	var rows: Array = []
	for i in mid.size():
		var w: String = wing[i] if i < wing.size() else ".".repeat(ww)
		var row: = (w + ".".repeat(width - ww)).to_utf8_buffer()
		var right: = w.reverse()
		for x in ww:
			if right[x] != ".":
				row[width - ww + x] = right.unicode_at(x)
		var m: String = mid[i]
		for x in mw:
			if m[x] != ".":
				row[ww - OVERLAP + x] = m.unicode_at(x)
		rows.append(row.get_string_from_utf8())
	return rows

static func _scenery(t: GameTheme) -> void :

	t.sprites["frozen_sinner"] = [
		".KKKKKKKKKK.", 
		"KIIIWIIIIIiK", 
		"KIIWIDDDIIiK", 
		"KIIIDEDEDIiK", 
		"KIIIIDDDIIiK", 
		"KIIDDDDDDDiK", 
		"KIDDIDDDIDDK", 
		"KIIIIDDDIIiK", 
		"KIIIIDDDIIiK", 
		"KIIIIDIDIIiK", 
		"KIIIIDIDIIiK", 
		"KiiiiiiiiiiK", 
		"KKKKKKKKKKKK", 
	]
	t.sprite_palettes["frozen_sinner"] = {"K": Color(0.08, 0.12, 0.2), "I": Color(0.55, 0.74, 0.9), "i": Color(0.35, 0.52, 0.72), 
		"W": Color(0.92, 0.98, 1), "D": Color(0.24, 0.29, 0.44), "E": Color(0.95, 0.25, 0.2)}

	t.sprites["ice_spire"] = [
		"....KK....", 
		"...KWiK...", 
		"...KWiK...", 
		"..KWIiK...", 
		"..KWIiiK..", 
		"..KWIIiK..", 
		".KWIIIiK..", 
		".KWIIIiiK.", 
		".KWIIIIiK.", 
		"KWIIIIIiiK", 
		"KWIIIIIIiK", 
		"KKKKKKKKKK", 
	]
	t.sprite_palettes["ice_spire"] = {"K": Color(0.08, 0.12, 0.2), "I": Color(0.6, 0.8, 0.95), "i": Color(0.38, 0.56, 0.78), "W": Color(0.92, 0.98, 1)}

	t.sprites["frost_tree"] = t.sprites["dead_tree"]
	t.sprite_palettes["frost_tree"] = {"K": Color(0.08, 0.11, 0.18), "1": Color(0.82, 0.9, 0.98), "2": Color(0.5, 0.6, 0.76), "M": Color(0.96, 1, 1)}

	t.sprites["face_in_ice"] = [
		"...iiii...", 
		"..iIIIIi..", 
		".iIEIIEIi.", 
		".iIIIIIIi.", 
		".iIIEEIIi.", 
		"..iIIIIi..", 
		"...iiii...", 
	]
	t.sprite_palettes["face_in_ice"] = {"I": Color(0.4, 0.5, 0.6), "i": Color(0.28, 0.36, 0.48), "E": Color(0.1, 0.13, 0.2)}
	t.sprites["frost_crack"] = [
		"W.....ww....", 
		".ww..w..w...", 
		"...ww....w..", 
		"....w.....ww", 
		"...........w", 
	]
	t.sprite_palettes["frost_crack"] = {"W": Color(0.72, 0.86, 1), "w": Color(0.46, 0.6, 0.8)}
	t.sprites["snow_drift"] = [
		"....WWWW....", 
		"..WWWWWWWW..", 
		".WWWwwWWWWW.", 
		"wwwwwwwwwwww", 
	]
	t.sprite_palettes["snow_drift"] = {"W": Color(0.86, 0.93, 1), "w": Color(0.62, 0.72, 0.86)}
	t.sprites["ice_chain"] = t.sprites["void_chain"]
	t.sprite_palettes["ice_chain"] = {"K": Color(0.06, 0.08, 0.13), "G": Color(0.52, 0.6, 0.72)}

	t.sprites["ice_reliquary"] = [
		"..KKKKKKKK..", 
		".KIIIIIIIiK.", 
		"KIIWIIIIIIiK", 
		"KIINNNNNNIiK", 
		"KIINYNNYNIiK", 
		"KIINNNNNNIiK", 
		"KIINNNNNNIiK", 
		"KIIIIIIIIIiK", 
		"KiiiiiiiiiiK", 
		"KKKKKKKKKKKK", 
	]
	t.sprite_palettes["ice_reliquary"] = {"K": Color(0.07, 0.1, 0.16), "I": Color(0.62, 0.82, 0.95), "i": Color(0.4, 0.58, 0.78), 
		"W": Color(0.95, 1, 1), "N": Color(0.55, 0.38, 0.24), "Y": Color(1, 0.85, 0.35)}
	t.sprites["frozen_urn"] = [
		"...KKKKK...", 
		"..KIWIIiK..", 
		"...KIIiK...", 
		"..KIIIIiK..", 
		".KIIQQIIiK.", 
		"KIIQuuQIIiK", 
		"KIIQQQQIIiK", 
		".KIIIIIIiK.", 
		"..KIIIIiK..", 
		"..KKKKKKK..", 
	]
	t.sprite_palettes["frozen_urn"] = {"K": Color(0.07, 0.1, 0.16), "I": Color(0.62, 0.82, 0.95), "i": Color(0.4, 0.58, 0.78), 
		"W": Color(0.95, 1, 1), "Q": Color(1, 0.55, 0.25), "u": Color(1, 0.9, 0.55)}
