class_name HellArsenal
extends RefCounted








static func build(t: GameTheme) -> void :
	_birds(t)
	_icons(t)
	_sodom_icons(t)
	_survivors(t)

static func _put(t: GameTheme, keys: Array, rows: Array, pal: Dictionary) -> void :
	var w: = 0
	for r: String in rows:
		w = maxi(w, r.length())
	var padded: Array = []
	for r: String in rows:
		padded.append(r + ".".repeat(w - r.length()))
	for key: String in keys:
		t.sprites[key] = padded
		t.sprite_palettes[key.get_slice("/", 0)] = pal



const RAVEN_UP: = [
	".........KYK.........", 
	"........KBEBK........", 
	"........KBBbK........", 
	".........KBK.........", 
	"KK......KBBBK......KK", 
	"KbK..KKKbBBBbKKK..KbK", 
	".KbKKbbBBBBBBBbbKKbK.", 
	".KBbbBBBBBBBBBBBbbBK.", 
	"..KBBBBBKBBBKBBBBBK..", 
	"...KKBKBKKBKKBKBKK...", 
	"....K.K.KBBBK.K.K....", 
	".........KBK.........", 
	"........KBBBK........", 
	".......KBKBKBK.......", 
	".......KK.K.KK.......", 
]
const RAVEN_DOWN: = [
	".........KYK.........", 
	"........KBEBK........", 
	"........KBBbK........", 
	".........KBK.........", 
	"......KKKBBBKKK......", 
	"....KKbbBBBBBbbKK....", 
	"...KbBBBBBBBBBBBbK...", 
	"..KbBBKKBBBBBKKBBbK..", 
	"..KBBK..KBBBK..KBBK..", 
	".KBBK...KBBBK...KBBK.", 
	".KBK....KBBBK....KBK.", 
	".KK......KBK......KK.", 
	"........KBBBK........", 
	".......KBKBKBK.......", 
	".......KK.K.KK.......", 
]

static func _birds(t: GameTheme) -> void :
	var raven: = {"K": Color(0.04, 0.04, 0.07), "B": Color(0.14, 0.14, 0.2), "b": Color(0.32, 0.34, 0.48), 
		"E": Color(1, 0.25, 0.2), "Y": Color(0.82, 0.78, 0.68)}
	var dove: = {"K": Color(0.55, 0.6, 0.75), "B": Color(0.97, 0.97, 1), "b": Color(0.8, 0.84, 0.95), 
		"E": Color(0.1, 0.1, 0.15), "Y": Color(1, 0.6, 0.45)}
	_put(t, ["raven"], RAVEN_UP, raven)
	_put(t, ["raven/2"], RAVEN_DOWN, raven)
	_put(t, ["dove"], RAVEN_UP, dove)
	_put(t, ["dove/2"], RAVEN_DOWN, dove)

static func _icons(t: GameTheme) -> void :

	var requiem: = [
		"......KKKKKKKK", 
		"......KVVVVVVK", 
		"......KVKKKKVK", 
		"......KVK..KVK", 
		"......KVK..KVK", 
		"...KKKKVK.KKVK", 
		"..KVVVVVKKVVVK", 
		"..KVVVVK.KVVVK", 
		"...KKKK...KKK.", 
		".KKKKKK.KKKKKK", 
		"KPPPPPPKPPPPPPK", 
		"KPllllPKPllllPK", 
		"KPPPPPPKPPPPPPK", 
		"KPllPPPKPPllllK", 
		"KRRRRRRRRRRRRRK", 
		".KKKKKKKKKKKKK.", 
	]
	var requiem_pal: = {"K": Color(0.07, 0.05, 0.08), "V": Color(0.78, 0.7, 0.95), "P": Color(0.9, 0.84, 0.7), 
		"l": Color(0.35, 0.28, 0.3), "R": Color(0.55, 0.1, 0.12)}
	_put(t, ["icon_requiem"], requiem, requiem_pal)

	var dies_irae: = [
		".....5.KK.5...", 
		"......KWWK....", 
		"...5..KWWK..5.", 
		"..KKKKKWWKKKKK", 
		"..KWWWWWWWWWWK", 
		"..KKKKKWWKKKKK", 
		"......KWWK....", 
		"..5...KWWK..5.", 
		"......KKKK....", 
		".KKKKKK.KKKKKK", 
		"KPPPPPPKPPPPPPK", 
		"KPYYYYPKPYYYYPK", 
		"KPPPPPPKPPPPPPK", 
		"KPYYPPPKPPYYYPK", 
		"K66666666666666K", 
		".KKKKKKKKKKKKKK.", 
	]
	var dies_pal: = {"K": Color(0.25, 0.18, 0.08), "W": Color(1, 0.98, 0.85), "5": Color(1, 0.95, 0.6), 
		"P": Color(1, 0.96, 0.85), "Y": Color(0.85, 0.65, 0.2), "6": Color(0.9, 0.68, 0.18)}
	_put(t, ["holy_dies_irae"], dies_irae, dies_pal)

	var ravens: Array = RAVEN_UP.duplicate()
	ravens[0] = "........WKYKW........"
	_put(t, ["icon_ravens"], ravens, {"K": Color(0.04, 0.04, 0.07), "B": Color(0.14, 0.14, 0.2), "b": Color(0.32, 0.34, 0.48), 
		"E": Color(1, 0.25, 0.2), "Y": Color(0.82, 0.78, 0.68), "W": Color(0.92, 0.88, 0.78)})

	var doves: Array = RAVEN_UP.duplicate()
	doves[0] = ".........KYKG........"
	doves.push_front(".......HHHHHHH.......")
	doves.push_front("......H.......H......")
	doves.push_front(".......HHHHHHH.......")
	_put(t, ["holy_doves"], doves, {"K": Color(0.55, 0.6, 0.75), "B": Color(0.97, 0.97, 1), "b": Color(0.8, 0.84, 0.95), 
		"E": Color(0.1, 0.1, 0.15), "Y": Color(1, 0.6, 0.45), "H": Color(1, 0.88, 0.35), "G": Color(0.45, 0.75, 0.3)})

	var nail: = ["KKKKK", "KIIiK", "KKKKK", ".KIK.", ".KIK.", ".KIK.", ".KIK.", ".KiK.", ".KiK.", ".KiK.", "..K.."]
	var nails: = _three(nail, [0, 2, 1])
	nails[12] = nails[12].substr(0, 7) + "R" + nails[12].substr(8)
	_put(t, ["icon_nails"], nails, {"K": Color(0.07, 0.06, 0.08), "I": Color(0.66, 0.64, 0.7), "i": Color(0.4, 0.38, 0.44), 
		"R": Color(0.85, 0.12, 0.12)})

	var holy_nails: = [
		"..5.KKKKKKKK..5..", 
		"...5KWWWWWYK.5...", 
		"....KyYYYYyK5....", 
		"KKKKKKKWyKKK...5.", 
		"KWyK..KWyK..5....", 
		"KWYKKKKWyKKKKKKKK", 
		"KWYWWWWWyWWWWWyyK", 
		"KWYyyyyWyyyyyyyKK", 
		"KWYKKKKWyKKKKKKK.", 
		"KWyK..KWyK.5...5.", 
		"KKKK..KWyK..5....", 
		"....5.KWyK...5...", 
		"...5..KWyK....5..", 
		"..5...KWyK.......", 
		".5..5.KyyK.5.....", 
		"......KyKK.......", 
		"......KKK........", 
	]
	_put(t, ["holy_cross_nails"], holy_nails, {"K": Color(0.3, 0.18, 0.05), "W": Color(1, 0.95, 0.7), "Y": Color(1, 0.82, 0.32), 
		"y": Color(0.78, 0.55, 0.16), "5": Color(1, 0.97, 0.75)})


static func _sodom_icons(t: GameTheme) -> void :
	_put(t, ["icon_sodom"], [
		"...........F..F..", 
		"..........FOF.FF.", 
		".......F.FOYOFOF.", 
		"......FOFOYYOOF..", 
		".....FOOOYYYOF...", 
		"....KKKKKOYOF....", 
		"...KrrrrRKOF.....", 
		"..KrRRrrrrK......", 
		".KrRRrrSrrrK.....", 
		".KrRrrSYSrrK.....", 
		".KrrrrrSrrrK.....", 
		".KrrSrrrrRrK.....", 
		".KrSYSrrrRrK.....", 
		"..KrSrrrrrK......", 
		"..KKrrrrrKK......", 
		"....KKKKK........", 
	], {"K": Color(0.06, 0.03, 0.03), "r": Color(0.3, 0.16, 0.1), "R": Color(0.48, 0.27, 0.15), 
		"S": Color(1, 0.72, 0.15), "Y": Color(1, 0.95, 0.5), "O": Color(1, 0.5, 0.1), "F": Color(0.85, 0.2, 0.05)})

	_put(t, ["holy_wormwood"], [
		"5..............gg", 
		"..............gG.", 
		"....5.......gGG..", 
		"...........gGY..5", 
		".........gGGY....", 
		"........gGYY.....", 
		"..5...YYYYY......", 
		".....YWWWYY......", 
		"....YWWWWWY..5...", 
		"..YYWWWWWWYY.....", 
		"....YWWWWWY......", 
		".....YWWWY.......", 
		"......YYY....5...", 
		"..5....Y.........", 
		"...........5.....", 
	], {"W": Color(1, 0.99, 0.9), "Y": Color(1, 0.84, 0.35), "G": Color(0.82, 0.86, 0.4), 
		"g": Color(0.55, 0.7, 0.3), "5": Color(1, 0.97, 0.75)})


static func _three(glyph: Array, drops: Array) -> Array:
	var h: = glyph.size() + 2
	var out: Array = []
	for y in h + 1:
		var row: = ""
		for k in 3:
			var gy: int = y - int(drops[k])
			row += glyph[gy] if gy >= 0 and gy < glyph.size() else ".".repeat(5)
		out.append(row)
	return out

static func _survivors(t: GameTheme) -> void :


	var flagellant: = [
		".......KKKKKK.........", 
		"......KSSSSSSK........", 
		".....KDSsSSSSDK.......", 
		".....KDSSSSSSDK.......", 
		".....KSKESSKESK.......", 
		".....KSSSSSSSsK.......", 
		".....KSSsSSsSsK.......", 
		"......KSSrrSsK........", 
		".......KSSSsK.........", 
		"....KKKSSSSSSKKK......", 
		"...KSSSRSSSSRSSsK.....", 
		"..KSSRSSSSSSSSRSsK....", 
		"..KSSSRSSSSSRSSSsK....", 
		"..KSKSSSRSSSSSSKsK....", 
		"..KSKNNNNNNNNNNKsKK...", 
		"..KSKYYYYYYYYYYKSKIK..", 
		"..KKKNNNNNNNNnnKKKIK..", 
		"....KNNNNNNNNnnK..KIK.", 
		"....KNNNNNNNnnnK..KIK.", 
		"....KNNNNNNNnnnK.KIRIK", 
		"....KNNNNnKKNnnK.KRKRK", 
		"....KDDDDK.KDDDK..K.K.", 
		"....KKKKKK.KKKKK......", 
	]
	var flagellant_pal: = {"K": Color(0.08, 0.05, 0.05), "S": Color(0.86, 0.68, 0.56), "s": Color(0.64, 0.46, 0.38), 
		"D": Color(0.25, 0.18, 0.14), "E": Color(0.12, 0.06, 0.06), "r": Color(0.5, 0.25, 0.22), "R": Color(0.75, 0.12, 0.12), 
		"N": Color(0.42, 0.3, 0.2), "n": Color(0.28, 0.19, 0.13), "Y": Color(0.75, 0.66, 0.42), "I": Color(0.5, 0.48, 0.55)}
	_put(t, ["v2_zealot", "zealot"], flagellant, flagellant_pal)


	var chorister: = [
		"........KKKKKK........", 
		".......KDDDDDDK.......", 
		"......KDDdDDDDDK......", 
		"......KDDSSSSDDK......", 
		"......KDSESSESDK......", 
		"......KDSSSSSSDK......", 
		"......KDSSrrSSDK......", 
		"......KDKSSSSKDK......", 
		".....KWWWKKKKWWWK.....", 
		"....KWwWwWwWwWwWK.....", 
		"....KWWWWWWWWWWWwK....", 
		"...KWWWWWWWWWWWWwK....", 
		"...KWWWKKKKKKKWWwK....", 
		"...KWWSRRRYRRRSwwK....", 
		"...KWWSRRYYYRRSwwK....", 
		"...KWWKRRRYRRRKwwK....", 
		"....KWWKKKKKKKWwK.....", 
		"....KCCCCCCCCCCccK....", 
		"....KCCCCCCCCCcccK....", 
		"....KCCCCcKKCCcccK....", 
		"....KDDDDK..KDDDDK....", 
		"....KKKKKK..KKKKKK....", 
	]
	var chorister_pal: = {"K": Color(0.07, 0.04, 0.05), "D": Color(0.2, 0.13, 0.11), "d": Color(0.36, 0.25, 0.2), 
		"S": Color(0.93, 0.8, 0.7), "E": Color(0.2, 0.3, 0.55), "r": Color(0.8, 0.45, 0.45), "W": Color(0.95, 0.94, 0.9), 
		"w": Color(0.72, 0.72, 0.74), "P": Color(0.92, 0.86, 0.7), "l": Color(0.35, 0.28, 0.3), "R": Color(0.55, 0.1, 0.12), 
		"C": Color(0.66, 0.1, 0.12), "c": Color(0.42, 0.06, 0.08), "Y": Color(1, 0.82, 0.3)}
	_put(t, ["v2_chorister", "chorister"], chorister, chorister_pal)


	var ravenkeeper: = [
		"...KK.....KKKKK.......", 
		"..KbEK...KqqqqqK......", 
		".KYBBK..KqQqqqqqK.....", 
		"..KBBBK.KqqSSSSqK.....", 
		"...KBBK.KqSESSESK.....", 
		"...KBBBKKqSSSSSSK.....", 
		"....KBBBKqSSssSqK.....", 
		"....KKBBKqqSSSSqK.....", 
		"....KFKKFFFFFFFFFK....", 
		"...KFfFFfFFfFFfFFK....", 
		"..KFFFfFFFfFFFfFFFK...", 
		"..KFfFFfFqqqqFfFFfK...", 
		"..KFFKqqqqqqqqqKFFK...", 
		"..KSSKqqQqqqqqqKSSK...", 
		"..KKKKqqQqqqqqqKKKK...", 
		"....KqqqQqqqqqq&K.....", 
		"....KqqqqQqqqq&&K.....", 
		"....KqqqqqQqqq&&K.....", 
		"...KqqqqqqqqQq&&&K....", 
		"...KqqqqqqqqqQ&&&K....", 
		"...KqqqqqKKqqqq&&K....", 
		"....KDDDK..KDDDDK.....", 
		"....KKKKK..KKKKKK.....", 
	]
	var ravenkeeper_pal: = {"K": Color(0.04, 0.04, 0.07), "q": Color(0.2, 0.2, 0.26), "Q": Color(0.36, 0.36, 0.46), 
		"&": Color(0.11, 0.11, 0.15), "S": Color(0.8, 0.78, 0.76), "E": Color(0.55, 0.85, 1), "s": Color(0.58, 0.56, 0.58), 
		"F": Color(0.13, 0.13, 0.19), "f": Color(0.3, 0.34, 0.5), "B": Color(0.14, 0.14, 0.2), "b": Color(0.32, 0.34, 0.48), 
		"Y": Color(0.82, 0.78, 0.68), "D": Color(0.16, 0.13, 0.12)}
	ravenkeeper_pal["E"] = Color(0.55, 0.85, 1)
	ravenkeeper[1] = "..KbRK...KqqqqqK......"
	ravenkeeper_pal["R"] = Color(1, 0.25, 0.2)
	_put(t, ["v2_ravenkeeper", "ravenkeeper"], ravenkeeper, ravenkeeper_pal)


	var undertaker: = [
		".......KKKKKK.........", 
		".......KqqqqK.........", 
		".......KqQqqK.........", 
		".......KqQqqK.........", 
		".......KqQqqK.........", 
		".......KRRRRK.........", 
		".....KKKKKKKKKK.......", 
		"......KGGGGGGK........", 
		"......KGEGGEGK........", 
		"......KGGGGGgK........", 
		"......KGgGGggK........", 
		".......KGgggK.........", 
		".....KKWWWWWWKK.......", 
		"....KqqqWVVWqqqK......", 
		"...KqQqqKVVKqqqqK.....", 
		"...KqKQqqVVqqqKqK.....", 
		"...KqKqQqVVqqqKqK.....", 
		"...KGKqqqVVqqqKGK.....", 
		"...KKKqqqqqqqq&KK.....", 
		".....KqqqqqqqqqK......", 
		".....KqqqqqqqqqK......", 
		".....KqqqqKKqq&K......", 
		".....KDDDDK.KDDK......", 
		".....KKKKKK.KKKK......", 
	]
	var undertaker_pal: = {"K": Color(0.04, 0.04, 0.05), "q": Color(0.13, 0.12, 0.15), "Q": Color(0.28, 0.27, 0.32), 
		"&": Color(0.07, 0.07, 0.09), "R": Color(0.5, 0.08, 0.1), "G": Color(0.72, 0.72, 0.68), "g": Color(0.5, 0.5, 0.48), 
		"E": Color(0.85, 0.95, 0.75), "W": Color(0.95, 0.94, 0.9), "V": Color(0.42, 0.42, 0.46), "D": Color(0.1, 0.08, 0.08)}
	_put(t, ["v2_undertaker", "undertaker"], undertaker, undertaker_pal)
