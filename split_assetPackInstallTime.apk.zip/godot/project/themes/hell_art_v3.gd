class_name HellArtV3
extends RefCounted













const RESCALE: = {
	"imp": 0.5, "imp_lord": 2.0 / 7.0, "cultist": 0.65, "hellbrute": 1.5 / 4.5, 
	"devil": 1.45 / 3.0, "devil_knight": 1.5 / 3.4, 
	"cerberus": 0.88, "hellhound": 0.9, "magma_slime": 0.725, "salamander": 0.7, 
	"lost_soul": 1.45 / 3.0, "hex_imp": 1.5 / 3.2, "gargoyle": 0.7, 
	"brood_mother": 1.45 / 3.6, "archfiend": 2.1 / 8.0, 

	"grave_rat": 1.4 / 1.8, "plague_rat": 1.9 / 2.4, "rat_king": 3.6 / 4.6, 
	"crow": 1.45 / 2.0, "carrion_king": 3.4 / 4.6, "ash_spider": 1.45 / 1.8, 
	"skeleton": 1.4 / 2.0, "penitent": 0.7, "flagellant": 1.45 / 2.3, "gravedigger": 1.5 / 2.4, 
	"coffin_crawler": 1.45 / 2.0, "plague_bloat": 1.5 / 2.2, "wraith": 1.45 / 2.0, "lantern_ghost": 1.45 / 2.0, 
	"sexton": 2.1 / 4.4, 

	"styx_eel": 1.45 / 1.7, "leviathan_spawn": 2.5 / 3.0, "leech": 1.45 / 1.8, "styx_crab": 1.45 / 1.8, 
	"halo_jelly": 1.45 / 2.0, "lure_fiend": 1.45 / 2.0, 
	"drowned_sinner": 1.45 / 2.0, "drowned_monk": 1.45 / 2.3, "bloated_drowned": 1.5 / 2.8, "siren": 1.45 / 2.0, 
	"siren_queen": 3.4 / 4.4, "bellshell": 1.5 / 2.4, "leviathan": 3.0 / 4.2, "ferryman": 2.3 / 4.4, 

	"stray_eye": 1.45 / 1.9, "great_eye": 2.3 / 3.0, "bone_serpent": 1.45 / 1.7, "great_serpent": 2.0 / 2.4, 
	"crawling_hand": 1.45 / 1.9, "ophan": 1.45 / 2.0, 
	"faceless": 1.45 / 2.0, "faceless_deacon": 1.45 / 2.1, "weeping_saint": 1.45 / 2.2, "hollow_angel": 1.55 / 2.2, 
	"pale_horse": 2.5 / 4.0, "watcher": 2.3 / 5.0, "fallen_seraph": 2.6 / 4.2, 

	"traitor_knight": 1.55 / 1.65, "blizzard_wraith": 1.45 / 2.0, "slush": 1.4 / 1.7, "frost_gargoyle": 1.4 / 2.0, 
	"hoarfrost_wisp": 1.2 / 1.7, "frostwing": 1.6 / 1.4, "ice_mite": 1.5 / 1.6, "blood_mite": 1.25 / 1.3, 
	"ice_beetle": 1.45 / 1.7, "frozen_traitor": 1.7 / 1.5, 
	"chained_giant": 1.5 / 1.8, "antaeus": 2.8 / 3.4, "ugolino": 2.4 / 4.6, "lucifer": 2.8 / 4.0, 
}

const HEADS: = {
	"imp_lord": [27, 4, 23, 17], "cerberus": [39, 1, 18, 13], "archfiend": [17, 3, 20, 16], 
	"rat_king": [23, 0, 11, 10], "sexton": [15, 0, 12, 12], "carrion_king": [18, 4, 12, 10], 
	"leviathan": [36, 0, 14, 14], "ferryman": [10, 1, 14, 11], "siren_queen": [11, 0, 9, 10], 
	"pale_horse": [39, 4, 13, 10], "watcher": [13, 12, 20, 17], "fallen_seraph": [26, 3, 9, 11], 
	"antaeus": [17, 0, 10, 13], "ugolino": [12, 0, 12, 11], "lucifer": [16, 0, 32, 14], 
}




static var _quick: = false

static func build(t: GameTheme, full: = false) -> void :
	_quick = not full and not t.bake_mode
	for id: String in RESCALE:
		t.native_art["v3_" + id] = true
	if _quick and _register_baked(t):
		return
	_build_all(t)



static func _register_baked(t: GameTheme) -> bool:
	for id: String in RESCALE:
		if not ResourceLoader.exists(t.art_cache_path("v3_" + id, 1)):
			return false
	for id: String in RESCALE:
		var key: = "v3_" + id
		t.sprites[key] = []
		for n in range(2, (2 if HOPPERS.has(id) else 4) + 1):
			t.sprites["%s/%d" % [key, n]] = []
	return true

const HOPPERS: = ["magma_slime", "slush", "leech"]

static func _build_all(t: GameTheme) -> void :
	_imp(t)
	_imp_lord(t)
	_cultist(t)
	_hellbrute(t)
	_devil(t)
	_devil_knight(t)
	_hounds(t)
	_magma_slime(t)
	_salamander(t)
	_lost_soul(t)
	_hex_imp(t)
	_gargoyle(t)
	_brood_mother(t)
	_archfiend(t)
	_rats(t)
	_crows(t)
	_ash_spider(t)
	_skeleton(t)
	_penitent(t)
	_flagellant(t)
	_gravedigger(t)
	_coffin_crawler(t)
	_plague_bloat(t)
	_wraith(t)
	_lantern_ghost(t)
	_sexton(t)
	_eels(t)
	_leech(t)
	_bone_crab(t)
	_halo_jelly(t)
	_lure_fiend(t)
	_drowned_sinner(t)
	_drowned_monk(t)
	_bloated_drowned(t)
	_sirens(t)
	_bellshell(t)
	_leviathan(t)
	_ferryman(t)
	_eyes(t)
	_serpents(t)
	_crawling_hand(t)
	_ophan(t)
	_faceless(t)
	_faceless_deacon(t)
	_weeping_saint(t)
	_hollow_angel(t)
	_pale_horse(t)
	_watcher(t)
	_fallen_seraph(t)
	_cocytus_reworks(t)
	_frostwing(t)
	_mites(t)
	_ice_beetle(t)
	_frozen_traitor(t)
	_giants(t)
	_ugolino(t)
	_lucifer(t)
	for id: String in LIFT:
		var pal: Dictionary = t.sprite_palettes["v3_" + id]
		for ch: String in pal:
			if not KEEP_DARK.has(ch):
				var c: Color = pal[ch]
				pal[ch] = Color.from_hsv(c.h, c.s * 0.94, c.v + (1.0 - c.v) * float(LIFT[id]), c.a)




const LIFT: = {
	"archfiend": 0.28, "imp_lord": 0.15, "cultist": 0.28, "hex_imp": 0.15, 
	"sexton": 0.25, "carrion_king": 0.18, "crow": 0.18, "gravedigger": 0.15, "coffin_crawler": 0.1, 
	"ferryman": 0.25, "leech": 0.25, "leviathan_spawn": 0.15, "lure_fiend": 0.12, 
	"faceless_deacon": 0.22, "faceless": 0.18, "great_serpent": 0.1, "fallen_seraph": 0.12, 
	"blood_mite": 0.15, "lucifer": 0.1, 
}
const KEEP_DARK: = ["K", "d", "E", "D"]


static func paint(w: int, h: int, spans: Array, base: Array = []) -> Array:
	var rows: Array = []
	for y in h:
		rows.append(base[y] if y < base.size() else ".".repeat(w))
	for s: Array in spans:
		var y: int = s[0]
		var x: int = s[1]
		var px: String = s[2]
		var row: String = rows[y]
		for i in px.length():
			if px[i] != "." and x + i >= 0 and x + i < w:
				row = row.substr(0, x + i) + px[i] + row.substr(x + i + 1)
		rows[y] = row
	return rows


static func outlined(rows: Array, k: = "K") -> Array:
	var w: int = 0
	for r: String in rows:
		w = maxi(w, r.length())
	var grid: Array = [".".repeat(w + 2)]
	for r: String in rows:
		grid.append("." + r.rpad(w, ".") + ".")
	grid.append(".".repeat(w + 2))
	var out: Array = []
	for y in grid.size():
		var line: = ""
		for x in w + 2:
			var ch: String = grid[y][x]
			if ch == ".":
				for d: Vector2i in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
					var nx: = x + d.x
					var ny: = y + d.y
					if nx >= 0 and ny >= 0 and nx < w + 2 and ny < grid.size():
						var n: String = grid[ny][nx]
						if n != "." and n != k:
							ch = k
							break
			line += ch
		out.append(line)
	return out



static func wing_beat(spans: Array, axis: int, k: float) -> Array:
	var out: Array = []
	for sp: Array in spans:
		out.append([axis + roundi((int(sp[0]) - axis) * k), sp[1], sp[2]])
	return out



static func swung(spans: Array, pivot: int, bottom: int, dx: int) -> Array:
	var out: Array = []
	for sp: Array in spans:
		var r: = int(sp[0])
		var off: = 0 if r <= pivot else roundi(dx * float(r - pivot) / float(bottom - pivot))
		out.append([r, int(sp[1]) + off, sp[2]])
	return out


static func frames_to(t: GameTheme, id: String, w: int, h: int, frames: Array) -> void :
	var baked: = _quick and ResourceLoader.exists(t.art_cache_path(id, 1))
	for i in frames.size():
		t.sprites[id if i == 0 else "%s/%d" % [id, i + 1]] = [] if baked else _drawn(w, h, frames[i])



static func _drawn(w: int, h: int, spans: Array) -> Array:
	const DOT: = 46
	const OUTLINE: = 75
	var cw: = w + 2
	var ch: = h + 2
	var buf: = PackedByteArray()
	buf.resize(cw * ch)
	buf.fill(DOT)
	for s: Array in spans:
		var y: int = int(s[0]) + 1
		if y < 1 or y > h:
			continue
		var x: int = int(s[1]) + 1
		var px: = (s[2] as String).to_ascii_buffer()
		var row: = y * cw
		for i in px.size():
			var xx: = x + i
			if px[i] != DOT and xx >= 1 and xx <= w:
				buf[row + xx] = px[i]
	var out: = buf.duplicate()
	for y in ch:
		for x in cw:
			var at: = y * cw + x
			if buf[at] != DOT:
				continue
			if (x > 0 and buf[at - 1] != DOT and buf[at - 1] != OUTLINE)\
			or (x < cw - 1 and buf[at + 1] != DOT and buf[at + 1] != OUTLINE)\
			or (y > 0 and buf[at - cw] != DOT and buf[at - cw] != OUTLINE)\
			or (y < ch - 1 and buf[at + cw] != DOT and buf[at + cw] != OUTLINE):
				out[at] = OUTLINE
	var rows: Array = []
	for y in ch:
		rows.append(out.slice(y * cw, (y + 1) * cw).get_string_from_ascii())
	return rows



static func seg(a: Vector2i, b: Vector2i, px: String) -> Array:
	var out: Array = []
	var n: = maxi(maxi(absi(b.x - a.x), absi(b.y - a.y)), 1)
	for i in n + 1:
		var f: = float(i) / n
		out.append([roundi(lerpf(a.y, b.y, f)), roundi(lerpf(a.x, b.x, f)) - px.length() / 2, px])
	return out


static func leg(joints: Array, thigh: String, shin: String, foot: String, foot_dy: = 1) -> Array:
	var out: = seg(joints[0], joints[1], thigh) + seg(joints[1], joints[2], shin)
	if joints.size() > 3:
		out += seg(joints[2], joints[3], shin.substr(0, 2))
	var end: Vector2i = joints[joints.size() - 1]
	out.append([end.y + foot_dy, end.x - 1, foot])
	return out


static func flame(x: int, row: int, h: int) -> Array:
	var out: Array = []
	for i in h:
		if i == h - 1:
			out.append([row - i, x, "F"])
		elif i == 0:
			out.append([row, x - 1, "FGF"])
		else:
			out.append([row - i, x - 1, "FWF" if i == 1 and h > 3 else "FGF"])
	return out


static func moved(joints: Array, d: Vector2i, all: = false) -> Array:
	var out: Array = []
	for i in joints.size():
		out.append(joints[i] + (d if all or i < joints.size() - 1 else Vector2i.ZERO))
	return out


static func flip_spans(spans: Array, axis: int) -> Array:
	var out: Array = []
	for s: Array in spans:
		out.append([2 * axis - int(s[0]), s[1], s[2]])
	return out


static func squashed_down(spans: Array, axis: int) -> Array:
	var out: Array = []
	for i in range(spans.size() - 1, -1, -1):
		var s: Array = spans[i]
		out.append([axis + (axis - int(s[0]) + 1) / 2, s[1] + (axis - int(s[0])) / 3, s[2]])
	return out




static func _imp(t: GameTheme) -> void :
	var wing: = [
		[1, 9, "b"], 
		[2, 8, "nmb"], 
		[3, 5, "nmmmmmb"], 
		[4, 4, "bbbbbbbbb"], 
		[5, 2, "bbmmmmmmmbb"], 
		[6, 4, "nmmmmmbmmb"], 
		[7, 5, "nmmmbmmmb"], 
		[8, 6, "nmbmmmmmb"], 
		[9, 7, "bmmmmmmmb"], 
		[10, 6, "bnmmmmmmmmb"], 
		[11, 9, "nnmmmmmmb"], 
		[12, 11, "nnmmmmmb"], 
		[13, 14, "nnnmmb"], 
	]
	var body: = [

		[1, 19, "H"], [2, 20, "h"], [3, 20, "Hh"], [4, 22, "Hh"], [5, 23, "Hh"], 
		[6, 24, "211"], 
		[7, 23, "221112"], 
		[8, 22, "32224443"], 
		[9, 22, "33225e522"], 
		[10, 23, "333333223"], 
		[11, 23, "43335555"], 
		[12, 24, "4443f4"], 
		[7, 19, "4"], [8, 20, "33"], [9, 21, "4"], 

		[13, 20, "223344"], 
		[14, 19, "22334"], [14, 24, "23"], 
		[15, 18, "223345"], [15, 24, "223"], 
		[16, 17, "2333445"], [16, 25, "223"], 
		[17, 17, "333445"], [17, 26, "322333"], [17, 32, "f"], 
		[18, 16, "334445"], [18, 31, "f"], 
		[19, 16, "433445"], 

		[20, 15, "554"], [21, 14, "545"], [22, 13, "545"], [23, 12, "545"], [24, 12, "f"], 
		[20, 18, "3334"], [21, 19, "3344"], [22, 18, "3445"], [23, 16, "3445"], [24, 15, "345"], [25, 15, "f.f"], 

		[19, 14, "44"], [20, 12, "44"], [21, 10, "44"], [22, 6, "4444"], [21, 5, "4"], [20, 4, "4"], [19, 4, "4"], 
		[18, 3, "444"], [17, 4, "4"], 
	]


	var tail: Array = body.slice(body.size() - 9)
	var front: Array = body.slice(0, body.size() - 9)
	var legs_tucked: = shifted(front, -1, 1, 22)
	frames_to(t, "v3_imp", 34, 27, [
		front + tail + wing, 
		front + shifted(tail, 1) + wing_beat(wing, 13, 0.3), 
		legs_tucked + shifted(tail, 1) + squashed_down(wing, 13), 
		front + tail + wing_beat(wing, 13, 0.3), 
	])
	t.sprite_palettes["v3_imp"] = {
		"1": Color(0.9, 0.55, 0.38), "2": Color(0.76, 0.35, 0.24), "3": Color(0.6, 0.22, 0.17), 
		"4": Color(0.42, 0.13, 0.14), "5": Color(0.26, 0.07, 0.1), "K": Color(0.08, 0.02, 0.04), 
		"m": Color(0.4, 0.16, 0.18), "n": Color(0.27, 0.09, 0.13), "b": Color(0.7, 0.45, 0.34), 
		"h": Color(0.78, 0.7, 0.58), "H": Color(0.5, 0.42, 0.36), 
		"e": Color(1.0, 0.72, 0.22), "f": Color(0.88, 0.82, 0.7), 
	}





static func _imp_lord(t: GameTheme) -> void :
	var far_wing: = [
		[0, 41, "B"], [1, 39, "BBNNN"], [2, 38, "BNNNNNN"], [3, 37, "BNNNNNNNN"], [4, 36, "BBBBBBBBBBB"], 
		[5, 35, "BNNNNNNNNN"], [6, 34, "BNNNNNNNN"], [7, 34, "BNNNNN"], [8, 33, "BNN"], [9, 33, "B"], [10, 32, "B"], 
	]
	var wing: = [
		[0, 13, "bb"], 
		[1, 10, "nmmmmbb"], 
		[2, 8, "nmmmmmmmmb"], 
		[3, 7, "nmmmmmbbbbbbb"], 
		[4, 6, "bbbbbbbmmmmmbmb"], 
		[5, 3, "bbbmmmmmmmmmmmbmmb"], 
		[6, 5, "nmmmmmmmmmmbmbmmb"], 
		[7, 5, "nmmm..mmmmbmmbmmmb"], 
		[8, 6, "nmmmmmmmbmmbmmmmmb"], 
		[9, 6, "nmmmmmmbmmmbmmmmmmb"], 
		[10, 7, "nmmmmbmmmbmmmmmmmmb"], 
		[11, 8, "nnmbmmmmbmmm.mmmmmb"], 
		[12, 9, "nbmmmmbmmmmmmmmmmmb"], 
		[13, 9, "bmm.mmbmmmmmmmmmmmm"], 
		[14, 8, "bnmmmmmbmmmmmmmmmm"], 
		[15, 7, "bnnmmmmbmmmmmmmmmm"], 
		[16, 10, "nmmmbmmm..mmmm"], 
		[17, 11, "nmmbmmmmmmmm"], 
		[18, 12, "nmbnmmmmmm"], 
		[19, 13, "nbnnmmmm"], 
		[20, 14, "b..nnn"], 
		[21, 14, "b"], 
	]
	var tail: = [
		[27, 19, "3344"], [28, 16, "2333444"], [29, 13, "3334444"], [30, 11, "334444"], [31, 9, "33444"], 
		[32, 7, "34444"], [33, 5, "344"], [32, 4, "4"], [31, 3, "4"], [30, 3, "4"], 
		[27, 3, "H"], [28, 2, "HhH"], [29, 3, "H"], 
	]
	var torso: = [
		[10, 30, "1122"], 
		[11, 28, "122221122"], 
		[12, 26, "12222222333"], 
		[13, 25, "122222233334"], 
		[14, 24, "12222233333444"], 
		[15, 24, "22222333334444"], 
		[16, 23, "222233333344455"], 
		[17, 23, "22333333444455"], 
		[18, 23, "23333334444555"], 
		[19, 23, "233333344445555"], 
		[20, 22, "23333344445555555"], 
		[21, 22, "233333444455555555"], 
		[22, 22, "3333334444555555555"], 
		[23, 22, "3333334444555555555"], 
		[24, 22, "3333344444555555555"], 
		[25, 22, "3333344444555555555"], 
		[26, 22, "433334444555555555"], 
		[27, 23, "43334444555555555"], 
		[28, 23, "4433444455555555"], 
		[29, 24, "44344445555555"], 
		[30, 24, "444444555555"], 
		[31, 25, "555555555"], 

		[20, 32, "uuvv"], [21, 31, "uuuuvv"], [22, 31, "xxxxxxxx"], [23, 30, "uuuuuuvvv"], 
		[24, 30, "uuuuuuvvvv"], [25, 30, "xxxxxxxxxx"], [26, 30, "uuuuuvvvv"], [27, 31, "uuuvvvv"], 
		[28, 31, "xxxxxxx"], [29, 32, "vvvv"], 
	]
	var head: = [
		[6, 30, "HHhh"], [7, 29, "H"], [8, 29, "H"], [7, 31, "HHHhhh"], [8, 32, "HHHHhhh"], [9, 35, "HHHhh"], 
		[6, 41, "h"], [7, 41, "h"], [5, 44, "h"], [6, 44, "h"], [7, 43, "h"], 
		[8, 39, "11122"], 
		[9, 40, "112222"], 
		[10, 37, "5122222223"], 
		[11, 37, "52224444443"], 
		[12, 37, "5225ee545e4"], 
		[13, 37, "523344433322"], 
		[14, 37, "543333332254"], 
		[15, 38, "4435fgggfg5"], 
		[16, 38, "5444f444f4"], 
		[17, 39, "54444445"], 
		[18, 40, "4.4.4"], [19, 42, "4"], 
		[9, 34, "3"], [10, 35, "34"], [11, 36, "3"], [12, 36, "y"], 
	]
	var arm: = [
		[14, 33, "1122"], [15, 33, "12223"], [16, 32, "5122235"], [17, 33, "5222334"], [18, 34, "522334"], 
		[19, 35, "522334"], [20, 36, "523344"], [21, 37, "523344"], [22, 37, "523334MM"], [23, 38, "52223ML"], 
		[24, 39, "5433ML"], [25, 40, "555LL"], 
		[21, 45, "33f"], [22, 45, "3334f"], [23, 45, "33344f"], [24, 45, "4344f"], [25, 45, "f4f"], 
		[26, 43, "M"], [27, 44, "L"], [28, 43, "M"], [29, 44, "L"], [30, 43, "M"], 
	]
	var far_leg: = [
		[30, 23, "5544"], [31, 23, "45544"], [32, 23, "45544"], [33, 24, "45554"], [34, 24, "55455"], 
		[35, 23, "5455"], [36, 23, "5455"], [37, 22, "54555"], [38, 22, "455555"], [39, 22, "4555555"], 
		[40, 23, "f.f.f"], 
	]
	var near_leg: = [
		[30, 28, "2333344"], [31, 29, "22333444"], [32, 30, "23333444"], [33, 31, "2333445"], [34, 31, "333445"], 
		[35, 30, "334455"], [36, 30, "334455"], [37, 30, "334455"], [38, 29, "33344455"], [39, 29, "333344444"], 
		[40, 31, "f.f.f.f"], 
	]


	var body: = torso + head + arm
	var beat: = [1.0, 0.35, -0.5, 0.35]
	var tail_dy: = [0, 1, 2, 1]
	var leg_dx: = [0, -1, -2, -1]
	var frames: Array = []
	for i in 4:
		frames.append(wing_beat(far_wing, 12, beat[i]) + wing_beat(wing, 13, beat[i]) + shifted(tail, tail_dy[i])
			+ body + swung(far_leg, 33, 40, leg_dx[i]) + swung(near_leg, 33, 40, leg_dx[i]) + arm)
	frames_to(t, "v3_imp_lord", 54, 42, frames)
	t.sprite_palettes["v3_imp_lord"] = {
		"1": Color(0.74, 0.43, 0.36), "2": Color(0.6, 0.29, 0.26), "3": Color(0.46, 0.19, 0.19), 
		"4": Color(0.32, 0.11, 0.14), "5": Color(0.2, 0.06, 0.1), "K": Color(0.07, 0.02, 0.04), 
		"u": Color(0.62, 0.42, 0.36), "v": Color(0.47, 0.3, 0.27), "x": Color(0.33, 0.16, 0.17), 
		"m": Color(0.33, 0.13, 0.15), "n": Color(0.22, 0.07, 0.1), "b": Color(0.64, 0.43, 0.35), 
		"N": Color(0.15, 0.05, 0.08), "B": Color(0.34, 0.19, 0.19), 
		"h": Color(0.84, 0.76, 0.62), "H": Color(0.52, 0.44, 0.38), 
		"e": Color(1.0, 0.82, 0.3), "g": Color(1.0, 0.5, 0.12), "f": Color(0.9, 0.84, 0.72), 
		"M": Color(0.64, 0.62, 0.6), "L": Color(0.36, 0.34, 0.37), "y": Color(0.86, 0.66, 0.25), 
	}


static func shifted(spans: Array, dy: int, dx: = 0, from_row: = -1) -> Array:
	var out: Array = []
	for sp: Array in spans:
		var moves: = int(sp[0]) >= from_row
		out.append([int(sp[0]) + (dy if moves else 0), int(sp[1]) + (dx if moves else 0), sp[2]])
	return out





static func _cultist(t: GameTheme) -> void :
	var robe: = [
		[1, 10, "2222"], 
		[2, 8, "22222233"], 
		[3, 7, "12222223333"], 
		[4, 6, "122222333334444"], 
		[5, 6, "12222333332ddd4"], 
		[6, 5, "122223333332ddd"], 
		[7, 5, "222233333332ded"], 
		[8, 5, "333333333342dds"], 
		[9, 6, "33333333342dss"], 
		[10, 6, "43333333442ss"], 
		[11, 7, "444333334444"], 
		[12, 5, "22333333334444"], 
		[13, 5, "123333333344445"], 
		[14, 4, "2332433324333455"], 
		[15, 4, "2332433324333455"], 
		[16, 4, "23324333243333455"], 
		[17, 3, "233324333243333455"], 
		[18, 3, "233324333243333455"], 
		[19, 3, "yyyyyyyyyyyyyyyYYY"], 
		[20, 3, "233324333243333455"], 
		[21, 3, "2333243332433243455"], 
		[22, 3, "2333243332433243455"], 
		[23, 2, "23333243332433243455"], 
		[24, 2, "23333243332433243455"], 
		[25, 2, "23333243332433243455"], 
		[26, 2, "233332433324332433455"], 
		[27, 2, "233332433324332433455"], 
		[28, 2, "233332433324332433455"], 
		[29, 2, "233332433324332433455"], 
		[30, 2, "444454444544454445555"], 
		[20, 9, "y"], [21, 9, "Y"], [22, 10, "y"], [23, 10, "Y"], 
	]
	var sleeve: = [
		[12, 12, "22223"], [13, 12, "122233"], [14, 13, "1222334"], [15, 14, "1222344"], 
		[16, 15, "1223344"], [17, 16, "222344"], [18, 17, "44555"], 
		[15, 13, "5"], [16, 14, "5"], [17, 15, "5"], [18, 16, "5"], 
		[17, 23, "Y"], [18, 22, "sss"], [19, 22, "sSs"], 
		[20, 23, "MM"], [21, 23, "ML"], [22, 24, "M"], [23, 24, "L"], 
	]


	var hem_a: = [31, 2, "5.55.555.55..55.5.55"]
	var hem_b: = [31, 2, "55.555.55..55.555.5."]
	var feet: = [
		[[31, 4, "SS"], [32, 3, "SSS"], [31, 19, "ss"], [32, 19, "ssss"]], 
		[[31, 9, "SS"], [31, 12, "ss"], [32, 12, "ssss"]], 
		[[31, 17, "SS"], [32, 17, "SSS"], [31, 6, "ss"], [32, 5, "ssss"]], 
		[[31, 11, "SS"], [32, 11, "SSS"], [31, 14, "ss"]], 
	]
	var hem_dx: = [1, 0, -1, 0]
	var hand_dx: = [-1, 0, 1, 0]
	var arm: Array = sleeve.slice(0, 11)
	var hand: Array = sleeve.slice(11)
	var frames: Array = []
	for i in 4:
		frames.append(swung(robe, 23, 30, hem_dx[i]) + shifted([hem_a if i % 2 == 0 else hem_b], 0, hem_dx[i]) + feet[i]
			+ arm + shifted(hand, 0, hand_dx[i]))
	frames_to(t, "v3_cultist", 28, 34, frames)
	t.sprite_palettes["v3_cultist"] = {
		"1": Color(0.74, 0.32, 0.27), "2": Color(0.58, 0.19, 0.19), "3": Color(0.43, 0.11, 0.13), 
		"4": Color(0.3, 0.06, 0.1), "5": Color(0.18, 0.03, 0.07), "K": Color(0.06, 0.01, 0.03), 
		"d": Color(0.04, 0.01, 0.03), "e": Color(1.0, 0.42, 0.2), 
		"s": Color(0.7, 0.66, 0.63), "S": Color(0.45, 0.41, 0.43), 
		"y": Color(0.62, 0.5, 0.32), "Y": Color(0.42, 0.32, 0.2), 
		"M": Color(0.8, 0.82, 0.85), "L": Color(0.46, 0.48, 0.54), 
	}






static func _hellbrute(t: GameTheme) -> void :
	var torso: = [
		[0, 23, "h"], [1, 23, "h"], [2, 23, "h"], [1, 19, "h"], [2, 19, "h"], [2, 27, "h"], [3, 27, "h"], 
		[3, 15, "h"], [4, 15, "h"], [4, 12, "h"], [5, 12, "h"], 
		[3, 18, "1111222"], 
		[4, 15, "1111122222222"], 
		[5, 13, "11112222222223333"], 
		[6, 12, "12222222222233333333"], 
		[7, 11, "1222222233333333333444"], 
		[8, 10, "122222333333333333344444"], 
		[9, 10, "222223333333333333444444"], 
		[10, 9, "2222333333333333334444445"], 
		[11, 9, "222333333333333344444455"], 
		[12, 9, "223333333333333444444555"], 
		[13, 9, "23333333333334444445555"], 
		[14, 10, "3333333333344444455555"], 
		[15, 10, "333333333344444455555"], 
		[16, 11, "33333333444444555555"], 
		[17, 12, "3333333444445555555"], 
		[18, 13, "333333444445555555"], 
		[19, 14, "3333344444555555"], 
		[20, 15, "333344444555555"], 
		[21, 15, "33344445555555"], 
		[22, 16, "3344445555555"], 
		[23, 16, "334444555555"], 
		[24, 16, "344444555555"], 
		[25, 16, "444445555555"], 
		[26, 15, "MLMLMLMLMLMLML"], 
		[27, 15, "44444555555555"], 
		[28, 15, "444445555555555"], 
		[29, 16, "4445555555555"], 

		[6, 15, "gg"], [7, 16, "gGg"], [8, 18, "gg"], [9, 19, "g"], 
		[5, 23, "g"], [6, 23, "gg"], [7, 24, "Gg"], [8, 25, "g"], 
		[13, 13, "gg"], [14, 14, "gg"], [15, 15, "g"], 
	]
	var head: = [
		[7, 31, "HH"], [6, 30, "HH"], [5, 30, "H"], [4, 31, "H"], 
		[8, 31, "11222"], 
		[9, 30, "51222223"], 
		[10, 30, "512222233"], 
		[11, 30, "5223355e33"], 
		[12, 30, "52333333322"], 
		[13, 31, "5333333345"], 
		[14, 31, "544ggggf55"], 
		[15, 31, "5444444f5"], 
		[16, 32, "5555555"], 
		[7, 34, "Hhh"], [6, 35, "Hhh"], [5, 36, "Hh"], [4, 37, "hh"], [3, 38, "hhh"], [4, 41, "h"], 
	]
	var arm: = [
		[8, 26, "11122"], [9, 24, "511112222"], [10, 24, "5112222233"], [11, 24, "5122222333"], 
		[12, 24, "5122223334"], [13, 25, "512223334"], [14, 26, "512233344"], [15, 26, "522333444"], 
		[16, 27, "52233344"], [17, 27, "522333445"], [18, 27, "522333445"], [19, 28, "52333445"], 
		[20, 28, "52333445"], [21, 28, "523334455"], [22, 29, "52333445"], [23, 29, "512333445"], 
		[24, 29, "5122333445"], [25, 30, "512233445"], [26, 30, "5122334455"], [27, 30, "5122334455"], 
		[28, 30, "51222334455"], [29, 30, "52223334455"], [30, 30, "52333344455"], [31, 29, "5222233344455"], 
		[32, 29, "52222333444555"], [33, 29, "52223333444555"], [34, 29, "52333334444555"], 
		[35, 30, "5333344445555"], [36, 30, "544444455555"], [37, 32, "f.f.f.f.f"], 
		[25, 33, "g"], [26, 33, "gg"], [27, 34, "Gg"], [28, 35, "g"], 
	]
	var far_arm: = [
		[13, 10, "4555"], [14, 9, "45555"], [15, 8, "455555"], [16, 8, "455555"], [17, 8, "455555"], 
		[18, 8, "455555"], [19, 8, "455555"], [20, 8, "455555"], [21, 8, "455555"], 
		[22, 7, "4555555"], [23, 7, "4555555"], [24, 7, "4555555"], [25, 7, "4555555"], [26, 7, "4555555"], 
		[27, 7, "4555555"], [28, 7, "4555555"], [29, 7, "4555555"], 
		[30, 5, "445555555"], [31, 5, "445555555"], [32, 5, "445555555"], [33, 6, "55555555"], 
		[34, 6, "f.f.f"], 
	]
	var leg: = [
		[29, 22, "23333444"], [30, 22, "223333444"], [31, 23, "22333444"], [32, 23, "223334445"], 
		[33, 24, "22334445"], [34, 24, "223334455"], [35, 25, "22334455"], [36, 25, "23334455"], 
		[37, 25, "33344555"], [38, 25, "3334455"], [39, 24, "23344555"], [40, 24, "2334455"], 
		[41, 24, "2334455"], [42, 23, "22334455"], [43, 23, "23334455"], [44, 22, "2233344555"], 
		[45, 21, "2333334444555"], [46, 21, "4444455555555"], [47, 26, "f.f.f.f"], 
		[33, 26, "gg"], [34, 27, "g"], 
	]
	var far_leg: = [
		[29, 14, "45555555"], [30, 13, "455555555"], [31, 13, "45555555"], [32, 13, "45555555"], 
		[33, 13, "45555555"], [34, 13, "45555555"], [35, 13, "45555555"], [36, 12, "45555555"], 
		[37, 12, "45555555"], [38, 13, "4555555"], [39, 13, "4555555"], [40, 13, "4555555"], 
		[41, 13, "4555555"], [42, 13, "4555555"], [43, 13, "4555555"], [44, 11, "4455555555"], 
		[45, 10, "44555555555"], [46, 10, "55555555555"], [47, 11, "f.f.f"], 
	]
	var cloth: = [
		[27, 18, "cccccCCC"], [28, 18, "cccccCCC"], [29, 19, "ccccCCC"], [30, 19, "ccccCC"], 
		[31, 20, "cc.cC"], [32, 20, "c..C"], 
	]



	var leg_dx: = [4, 0, -4, 0]
	var lift: = [0, 1, 0, -1]
	var arm_dx: = [-3, 0, 3, 0]
	var sink: = [1, 0, 1, 0]
	var frames: Array = []
	for i in 4:
		var near: = swung(leg, 29, 47, leg_dx[i])
		var far: = swung(far_leg, 29, 47, - leg_dx[i])
		if lift[i] == 1:
			far = shifted(far, -2, 1, 38)
		elif lift[i] == -1:
			near = shifted(near, -2, -1, 38)
		frames.append(shifted(swung(far_arm, 14, 34, - arm_dx[i]), sink[i]) + far + shifted(torso, sink[i])
			+ near + swung(cloth, 27, 32, - leg_dx[i] / 4) + shifted(swung(arm, 12, 37, arm_dx[i]), sink[i])
			+ shifted(head, sink[i]))
	frames_to(t, "v3_hellbrute", 46, 49, frames)
	t.sprite_palettes["v3_hellbrute"] = {
		"1": Color(0.64, 0.58, 0.56), "2": Color(0.49, 0.43, 0.44), "3": Color(0.37, 0.32, 0.35), 
		"4": Color(0.26, 0.22, 0.27), "5": Color(0.16, 0.13, 0.18), "K": Color(0.04, 0.03, 0.05), 
		"h": Color(0.8, 0.74, 0.64), "H": Color(0.5, 0.45, 0.42), 
		"g": Color(0.95, 0.42, 0.1), "G": Color(1.0, 0.8, 0.3), "e": Color(1.0, 0.85, 0.35), 
		"M": Color(0.55, 0.52, 0.5), "L": Color(0.32, 0.3, 0.32), 
		"c": Color(0.46, 0.33, 0.24), "C": Color(0.3, 0.2, 0.15), 
	}





static func _devil(t: GameTheme) -> void :
	var top: = [
		[1, 14, "h"], [2, 14, "Hh"], [3, 15, "Hh"], [4, 16, "Hh"], 
		[5, 13, "3"], [6, 14, "33"], [7, 15, "4"], 
		[5, 17, "12222"], 
		[6, 16, "12222223"], 
		[7, 16, "22235e433"], 
		[8, 16, "3333333222"], 
		[9, 17, "433333345"], 
		[10, 17, "43355554"], 
		[11, 18, "4444f4"], 
		[12, 19, "4444"], [12, 22, "b"], [13, 21, "bb"], [14, 21, "b"], 
		[12, 16, "444"], [13, 16, "4444"], 

		[13, 13, "1222233"], [14, 12, "122223344"], [15, 12, "124243445"], [16, 12, "22424445"], 
		[17, 12, "23424445"], [18, 13, "2333445"], [19, 13, "3333445"], [20, 13, "3334455"], 
		[21, 12, "uuuuuUUUx"], 

		[22, 16, "44"], [23, 16, "44"], 
	]
	var fork: = seg(Vector2i(12, 24), Vector2i(26, 17), "w") + seg(Vector2i(26, 14), Vector2i(26, 20), "L")\
	+ seg(Vector2i(27, 14), Vector2i(31, 14), "M") + seg(Vector2i(27, 17), Vector2i(32, 17), "M")\
	+ seg(Vector2i(27, 20), Vector2i(31, 20), "M")
	var arm: = [
		[14, 18, "222"], [15, 18, "2233"], [16, 19, "2334"], [17, 20, "334"], [18, 20, "322"], [19, 21, "33"], 
	]
	var tail: = [[22, 11, "4"], [23, 9, "44"], [23, 8, "4"], [22, 7, "4"], [21, 6, "4"], [20, 6, "4"], [19, 5, "444"], [18, 6, "4"]]

	var poses: = [
		[Vector2i(17, 22), Vector2i(20, 26), Vector2i(18, 29), Vector2i(21, 33)], 
		[Vector2i(17, 22), Vector2i(18, 26), Vector2i(15, 29), Vector2i(17, 33)], 
		[Vector2i(17, 22), Vector2i(16, 26), Vector2i(12, 29), Vector2i(11, 32)], 
		[Vector2i(17, 22), Vector2i(20, 25), Vector2i(17, 28), Vector2i(20, 31)], 
	]
	var far_of: = [2, 3, 0, 1]
	var frames: Array = []
	for i in 4:
		var near_p: Array = poses[i]
		var far_p: Array = []
		for j: Vector2i in poses[far_of[i]]:
			far_p.append(j + Vector2i(-3, 0))
		frames.append(shifted(tail, [0, 1, 0, -1][i]) + leg(far_p, "xUU", "Ux", "kkk") + top
			+ leg(near_p, "uuuU", "uU", "kkk") + fork + arm)
	frames_to(t, "v3_devil", 34, 36, frames)
	t.sprite_palettes["v3_devil"] = {
		"1": Color(0.86, 0.43, 0.32), "2": Color(0.71, 0.28, 0.22), "3": Color(0.56, 0.17, 0.16), 
		"4": Color(0.39, 0.1, 0.12), "5": Color(0.24, 0.05, 0.09), "K": Color(0.08, 0.02, 0.04), 
		"u": Color(0.38, 0.23, 0.19), "U": Color(0.26, 0.15, 0.14), "x": Color(0.16, 0.08, 0.09), 
		"k": Color(0.13, 0.11, 0.11), "h": Color(0.82, 0.75, 0.62), "H": Color(0.5, 0.43, 0.37), 
		"e": Color(1.0, 0.8, 0.3), "f": Color(0.9, 0.85, 0.75), "b": Color(0.18, 0.08, 0.08), 
		"w": Color(0.5, 0.35, 0.22), "M": Color(0.72, 0.74, 0.78), "L": Color(0.44, 0.46, 0.52), 
	}




static func _devil_knight(t: GameTheme, id: = "v3_devil_knight", extra: Array = []) -> void :
	var cape: = [
		[12, 13, "rRR"], [13, 11, "rrRRq"], [14, 11, "rRRRq"], [15, 10, "rrRRqq"], [16, 10, "rRRqRq"], 
		[17, 9, "rrRRqRq"], [18, 9, "rRRqRRq"], [19, 8, "rrRRqRqq"], [20, 8, "rRRqRRqq"], [21, 7, "rrRRqRRqq"], 
		[22, 7, "rRRqRRqqq"], [23, 6, "rrRqRRqqq"], [24, 6, "rRRqRqqq"], [25, 6, "RRqRRqq"], [26, 5, "RqqRqq"], 
		[27, 5, "q.Rq.q"], [28, 6, "q..q"], 
	]
	var body: = [
		[4, 19, "HH"], [3, 18, "H"], [2, 18, "H"], 
		[5, 19, "1122223"], 
		[6, 18, "122222333"], 
		[7, 18, "1222223333"], 
		[8, 18, "2223ggggg5"], 
		[9, 18, "223333g345"], 
		[10, 18, "3333333445"], 
		[11, 19, "333334455"], 
		[12, 20, "4445555"], 
		[5, 24, "Hh"], [4, 25, "Hh"], [3, 26, "hh"], [2, 27, "hhh"], [3, 30, "h"], 
		[12, 17, "1222223333"], [13, 16, "122222333334"], [14, 16, "222223333344"], [15, 16, "222333333445"], 
		[16, 16, "22333334445"], [17, 16, "23333344455"], [18, 16, "33333444555"], [19, 16, "3333444555"], 
		[20, 15, "wwwwwywwwwww"], 
	]
	var pauldron: = [
		[9, 15, "h"], [10, 15, "h"], [10, 18, "h"], [11, 18, "h"], 
		[11, 14, "112222"], [12, 13, "112222233"], [13, 13, "1222223333"], [14, 13, "2222333344"], 
		[15, 14, "333334445"], [16, 15, "4444555"], 
	]
	var tabard: = [
		[21, 15, "rrRRrrrRRqqq"], [22, 15, "rrRrrrrRRqqq"], [23, 15, "rRrrrrRRqqq"], [24, 16, "RrrrrRRqqq"], 
		[25, 16, "r.R.rR.q"], 
	]
	var arm: = [
		[16, 21, "233"], [17, 22, "334"], [18, 22, "334"], [19, 23, "344"], [20, 23, "344"], 
		[21, 23, "2334"], [22, 23, "3345"], 
		[19, 26, "4"], [20, 26, "4"], [21, 26, "4"], [22, 26, "4"], [23, 26, "4"], 
		[21, 27, "NN"], [22, 27, "MMMNN"], [23, 28, "LMMMMNN"], [24, 30, "LLMMMNN"], [25, 32, "LLMMN"], 
		[26, 34, "LMM"], [27, 35, "LM"], [28, 36, "M"], [24, 31, "."], [23, 33, "."], 
	]
	var poses: = [
		[Vector2i(21, 25), Vector2i(24, 31), Vector2i(24, 37), Vector2i(27, 37)], 
		[Vector2i(21, 25), Vector2i(22, 31), Vector2i(20, 37), Vector2i(23, 37)], 
		[Vector2i(21, 25), Vector2i(19, 31), Vector2i(15, 36), Vector2i(17, 37)], 
		[Vector2i(21, 25), Vector2i(24, 30), Vector2i(22, 35), Vector2i(25, 35)], 
	]
	var far_of: = [2, 3, 0, 1]
	var swing: = [1, 0, -1, 0]
	var frames: Array = []
	for i in 4:
		var far_p: Array = []
		for j: Vector2i in poses[far_of[i]]:
			far_p.append(j + Vector2i(-4, 0))
		frames.append(swung(cape, 14, 28, - swing[i]) + leg(far_p, "4455", "455", "5555") + body
			+ leg(poses[i], "2334", "123", "23344") + swung(tabard, 21, 25, swing[i]) + pauldron + arm)
	for fi in frames.size():
		frames[fi] = frames[fi] + extra
	frames_to(t, id, 38, 40, frames)
	t.sprite_palettes[id] = {
		"1": Color(0.62, 0.62, 0.68), "2": Color(0.45, 0.45, 0.52), "3": Color(0.32, 0.31, 0.38), 
		"4": Color(0.22, 0.21, 0.27), "5": Color(0.13, 0.12, 0.17), "K": Color(0.04, 0.03, 0.06), 
		"g": Color(1.0, 0.55, 0.15), "h": Color(0.82, 0.75, 0.62), "H": Color(0.5, 0.43, 0.37), 
		"r": Color(0.6, 0.14, 0.14), "R": Color(0.42, 0.08, 0.1), "q": Color(0.26, 0.04, 0.07), 
		"w": Color(0.36, 0.24, 0.17), "y": Color(0.82, 0.62, 0.26), 
		"M": Color(0.66, 0.68, 0.72), "L": Color(0.38, 0.39, 0.45), "N": Color(0.88, 0.89, 0.92), 
	}






static func _hounds(t: GameTheme) -> void :
	var body: = [
		[9, 4, "33"], [8, 2, "333"], [7, 0, "34"], [6, 0, "FG"], [5, 0, "F"], 
		[7, 9, "112222"], [8, 7, "1122222223"], [9, 6, "12222222333"], [10, 6, "22222223334"], 
		[11, 6, "22222233344"], [12, 6, "2222333344"], [13, 7, "333333445"], [14, 8, "3334455"], [15, 9, "44555"], 
		[8, 15, "22222222222223"], [9, 15, "222222222222333"], [10, 15, "33333333333334"], [11, 15, "3333333333444"], 
		[12, 15, "44444444444"], [13, 16, "55555"], 
		[7, 28, "1122222223"], [8, 26, "112222222233"], [9, 26, "1222222223333"], [10, 26, "2224224223334"], 
		[11, 26, "2234234233344"], [12, 26, "3343343334445"], [13, 25, "33333333344455"], [14, 27, "333333344455"], 
		[15, 29, "334444555"], [16, 31, "4455555"], [17, 32, "5555"], 
		[3, 38, "3"], [4, 38, "34"], [5, 39, "34"], 
		[4, 41, "12222"], [5, 40, "12222222"], [6, 37, "122222222233"], 
		[7, 38, "3322225e4222223"], [8, 38, "333333222222223"], [8, 53, "5"], 
		[9, 38, "4433333333333344"], [10, 38, "4444333333344f4f"], [11, 39, "44445EEEEEEEE"], 
		[12, 40, "4444444f44"], [13, 41, "55555555"], 
		[11, 36, "333"], [12, 36, "3444"], [13, 37, "4455"], 
	]
	var mane: = [
		[7, 27, "FF"], [6, 27, "FGF"], [5, 26, "FF"], [4, 25, "F"], 
		[6, 31, "FGGF"], [5, 30, "FGWF"], [4, 29, "FGF"], [3, 28, "FF"], [2, 27, "F"], 
		[6, 35, "FGGF"], [5, 34, "FWGF"], [4, 33, "FGF"], [3, 32, "FF"], [2, 31, "F"], 
		[5, 38, "FG"], [4, 37, "FG"], [3, 36, "F"], 
	]
	var mane2: = [
		[7, 26, "FF"], [6, 26, "FGF"], [5, 25, "FF"], [4, 24, "FF"], 
		[6, 31, "FGGF"], [5, 29, "FGWF"], [4, 28, "FGF"], [3, 27, "F"], 
		[6, 35, "FGGF"], [5, 33, "FWGF"], [4, 32, "FGF"], [3, 30, "FF"], [2, 29, "F"], 
		[5, 38, "FG"], [4, 36, "FG"], [3, 35, "F"], [2, 34, "F"], 
	]
	var sh: = Vector2i(34, 14)
	var hip: = Vector2i(11, 13)
	var front: = [
		[sh, Vector2i(39, 18), Vector2i(45, 20), Vector2i(49, 20)], 
		[sh, Vector2i(35, 19), Vector2i(34, 24), Vector2i(37, 25)], 
		[sh, Vector2i(31, 18), Vector2i(27, 21), Vector2i(25, 23)], 
		[sh, Vector2i(36, 18), Vector2i(40, 21), Vector2i(43, 22)], 
	]
	var hind: = [
		[hip, Vector2i(8, 18), Vector2i(3, 20), Vector2i(0, 22)], 
		[hip, Vector2i(12, 18), Vector2i(8, 21), Vector2i(6, 23)], 
		[hip, Vector2i(17, 17), Vector2i(16, 22), Vector2i(21, 24)], 
		[hip, Vector2i(14, 18), Vector2i(10, 22), Vector2i(12, 25)], 
	]
	var lift: = [0, 1, 1, 1]
	var frames: Array = []
	for i in 4:
		var d: = Vector2i(0, lift[i])
		var planted_front: = i == 1
		var planted_hind: = i == 3
		frames.append(
			leg(moved(front[i], d + Vector2i(-3, 0), not planted_front), "4455", "455", "455", 0)
			+ leg(moved(hind[i], d + Vector2i(3, 0), not planted_hind), "4455", "455", "455", 0)
			+ shifted(body + (mane if i % 2 == 0 else mane2), lift[i])
			+ leg(moved(front[i], d, not planted_front), "1233", "233", "334", 0)
			+ leg(moved(hind[i], d, not planted_hind), "12334", "233", "334", 0))
	for i in 4:
		frames[i] = shifted(frames[i], 0, 2)
	frames_to(t, "v3_cerberus", 58, 28, frames)
	frames_to(t, "v3_hellhound", 58, 28, frames)
	var fire: = {"F": Color(0.95, 0.4, 0.1), "G": Color(1.0, 0.72, 0.2), "W": Color(1.0, 0.95, 0.7), 
		"e": Color(1.0, 0.85, 0.3), "f": Color(0.92, 0.88, 0.78)}
	t.sprite_palettes["v3_cerberus"] = fire.merged({
		"1": Color(0.8, 0.76, 0.68), "2": Color(0.64, 0.59, 0.54), "3": Color(0.49, 0.44, 0.42), 
		"4": Color(0.35, 0.3, 0.31), "5": Color(0.22, 0.18, 0.2), "K": Color(0.07, 0.05, 0.06), 
		"E": Color(0.3, 0.05, 0.06), 
	}, true)
	t.sprite_palettes["v3_hellhound"] = fire.merged({
		"1": Color(0.62, 0.32, 0.26), "2": Color(0.47, 0.21, 0.19), "3": Color(0.34, 0.13, 0.13), 
		"4": Color(0.22, 0.08, 0.1), "5": Color(0.13, 0.04, 0.07), "K": Color(0.05, 0.01, 0.03), 
		"E": Color(0.9, 0.35, 0.08), 
	}, true)




static func _magma_slime(t: GameTheme, id: = "v3_magma_slime", extra: Array = []) -> void :
	var squash: = [
		[6, 11, "rrrrrrrr"], [7, 8, "r".repeat(14)], [8, 6, "r".repeat(18)], [9, 5, "r".repeat(20)], 
		[10, 4, "r".repeat(22)], [11, 3, "r".repeat(24)], [12, 2, "r".repeat(26)], [13, 2, "r".repeat(26)], 
		[14, 2, "r".repeat(26)], [15, 3, "R".repeat(24)], [16, 5, "R".repeat(20)], 
		[11, 6, "g".repeat(15)], [12, 5, "gggGGGGGGgggggggg"], [13, 5, "ggGGGWWGGGGggggggg"], [14, 7, "gggGGGGGggggg"], 
		[6, 11, "CCCcCCCc"], [7, 8, "CCCCcCCCcCCCcc"], [8, 6, "CCCCCcGCCCcCCCCccc"], [9, 5, "cCCCcgcCCcGccCCcccc"], 
		[10, 4, "cccgccccgcccccgcccc"], [11, 3, "cc"], [11, 25, "cc"], [12, 2, "c"], [12, 26, "cc"], 
		[9, 19, "hhhH"], [10, 19, "dhdH"], [11, 19, "hhhH"], [12, 20, "fHf"], 
	]
	var air: = [
		[1, 12, "rrrrrr"], [2, 10, "r".repeat(10)], [3, 9, "r".repeat(12)], [4, 8, "r".repeat(14)], 
		[5, 7, "r".repeat(16)], [6, 7, "r".repeat(16)], [7, 7, "r".repeat(16)], [8, 7, "r".repeat(16)], 
		[9, 7, "r".repeat(16)], [10, 7, "r".repeat(16)], [11, 7, "r".repeat(16)], [12, 7, "r".repeat(16)], 
		[13, 7, "r".repeat(16)], [14, 8, "r".repeat(14)], [15, 9, "R".repeat(12)], [16, 10, "R".repeat(10)], 
		[17, 11, "RRRRRRRR"], [18, 12, "RRRRR"], [19, 13, "RRR"], [20, 14, "R"], 
		[19, 9, "r"], [20, 9, "R"], [21, 19, "r"], [22, 19, "R"], 
		[8, 9, "gggggggggggg"], [9, 8, "ggGGGGGggggggg"], [10, 8, "gGGGWWGGGggggg"], [11, 8, "ggGGGGGgggggg"], 
		[12, 9, "gggggggggggg"], [13, 10, "gggggggg"], 
		[1, 12, "CCcCCC"], [2, 10, "CCCCcCCCcC"], [3, 9, "CCcCCGcCCCcc"], [4, 8, "cCCCcgcCCcCccc"], 
		[5, 7, "cccgccccgcccgccc"], [6, 7, "cc"], [6, 21, "cc"], [7, 7, "c"], [7, 22, "c"], 
		[6, 15, "hhhH"], [7, 15, "dhdH"], [8, 15, "hhhH"], [9, 16, "fHf"], 
	]
	frames_to(t, id, 30, 23, [shifted(squash, 5) + extra, air + extra])
	t.sprite_palettes[id] = {
		"r": Color(0.72, 0.2, 0.07), "R": Color(0.45, 0.1, 0.06), "g": Color(0.95, 0.42, 0.1), 
		"G": Color(1.0, 0.72, 0.25), "W": Color(1.0, 0.94, 0.68), 
		"c": Color(0.2, 0.14, 0.14), "C": Color(0.33, 0.25, 0.23), "K": Color(0.07, 0.03, 0.03), 
		"h": Color(0.86, 0.8, 0.68), "H": Color(0.56, 0.48, 0.42), "d": Color(0.15, 0.05, 0.03), 
		"f": Color(0.72, 0.66, 0.56), 
	}





static func _salamander(t: GameTheme) -> void :
	var body: = [
		[9, 8, "22222"], [10, 4, "233333333"], [11, 1, "4333333333"], [12, 0, "44"], [10, 7, "o"], [11, 4, "O"], 
		[8, 15, "1222222222222222222222222"], [9, 13, "122222222222222222222222222"], 
		[10, 12, "3333333333333333333333333333"], [11, 12, "3333333333333333333333333333"], 
		[12, 13, "bbbbbbbbbbbbbbbbbbbbbbbbbbb"], [13, 15, "4444444444444444444444"], 
		[9, 17, "oO"], [8, 22, "oo"], [10, 26, "oO"], [9, 31, "oo"], [10, 35, "O"], [11, 19, "o"], [11, 30, "oO"], [9, 37, "o"], 
		[8, 42, "12222"], [9, 40, "1222222222"], [10, 40, "22225e3333"], [11, 40, "3333333334"], 
		[12, 40, "455555544"], [13, 41, "4444444"], [9, 44, "o"], [8, 43, "o"], 
	]
	var heights: = [[3, 4, 2, 4, 3, 2], [4, 2, 4, 3, 2, 3], [2, 4, 3, 2, 4, 3], [3, 3, 4, 2, 3, 4]]
	var pose: = [
		[Vector2i.ZERO, Vector2i(3, 2), Vector2i(5, 4)], 
		[Vector2i.ZERO, Vector2i(1, 3), Vector2i(1, 4)], 
		[Vector2i.ZERO, Vector2i(-2, 3), Vector2i(-4, 4)], 
		[Vector2i.ZERO, Vector2i(2, 2), Vector2i(3, 3)], 
	]
	var roots: = {"nf": Vector2i(35, 12), "nh": Vector2i(17, 12), "ff": Vector2i(37, 11), "fh": Vector2i(19, 11)}
	var frames: Array = []
	for i in 4:
		var a: Array = pose[i]
		var b: Array = pose[(i + 2) % 4]
		var flames: Array = []
		for k in 6:
			flames += flame(16 + k * 4, 7, heights[i][k])
		var tail_dy: int = [0, 1, 0, -1][i]
		var spans: Array = []
		spans += leg([roots["ff"] + b[0], roots["ff"] + b[1], roots["ff"] + b[2]], "45", "45", "455", 0)
		spans += leg([roots["fh"] + a[0], roots["fh"] + a[1], roots["fh"] + a[2]], "45", "45", "455", 0)
		spans += flames + shifted(body.slice(0, 6), tail_dy) + body.slice(6)
		spans += leg([roots["nf"] + a[0], roots["nf"] + a[1], roots["nf"] + a[2]], "23", "23", "334", 0)
		spans += leg([roots["nh"] + b[0], roots["nh"] + b[1], roots["nh"] + b[2]], "23", "23", "334", 0)
		frames.append(spans)
	frames_to(t, "v3_salamander", 50, 18, frames)
	t.sprite_palettes["v3_salamander"] = {
		"1": Color(0.44, 0.38, 0.37), "2": Color(0.32, 0.27, 0.28), "3": Color(0.23, 0.19, 0.21), 
		"4": Color(0.14, 0.11, 0.14), "5": Color(0.08, 0.06, 0.09), "K": Color(0.03, 0.02, 0.04), 
		"b": Color(0.47, 0.21, 0.11), "o": Color(0.98, 0.66, 0.14), "O": Color(0.8, 0.42, 0.08), 
		"e": Color(1.0, 0.85, 0.3), "F": Color(0.95, 0.4, 0.1), "G": Color(1.0, 0.72, 0.2), "W": Color(1.0, 0.95, 0.7), 
	}



static func bat_wing() -> Array:
	return [
		[1, 9, "b"], [2, 8, "nmb"], [3, 5, "nmmmmmb"], [4, 4, "bbbbbbbbb"], [5, 2, "bbmmmmmmmbb"], 
		[6, 4, "nmmmmmbmmb"], [7, 5, "nmmmbmmmb"], [8, 6, "nmbmmmmmb"], [9, 7, "bmmmmmmmb"], 
		[10, 6, "bnmmmmmmmmb"], [11, 9, "nnmmmmmmb"], [12, 11, "nnmmmmmb"], [13, 14, "nnnmmb"], 
	]


static func wing_frames(wing: Array, axis: int) -> Array:
	return [wing, wing_beat(wing, axis, 0.3), squashed_down(wing, axis), wing_beat(wing, axis, 0.3)]




static func _lost_soul(t: GameTheme, id: = "v3_lost_soul", extra: Array = []) -> void :
	var skull: = [
		[4, 22, "12222222"], [5, 20, "112222222223"], [6, 19, "12222222222333"], [7, 18, "1222222222223334"], 
		[8, 18, "2222222222223334"], [9, 18, "22222222233333445"], [10, 18, "2222dddd22333dd45"], 
		[11, 18, "333ddedd23333de45"], [12, 19, "33dddd333333d445"], [13, 19, "334dd4333334445"], 
		[14, 20, "44443333d3445"], [15, 21, "4444333dd345"], [16, 22, "55fdfdfdfd5"], 
		[6, 24, "4"], [7, 25, "4"], [8, 25, "44"], [9, 27, "4"], 
	]
	var jaw_open: = [[17, 23, "ddddddddd"], [18, 24, "fdfdfdfd"], [19, 23, "344444445"], [20, 24, "5555555"]]
	var jaw_shut: = [[17, 24, "fdfdfdfd"], [18, 23, "344444445"], [19, 24, "5555555"]]
	var fire: = [
		[5, 16, "FGG"], [6, 14, "FGGWG"], [7, 12, "FFGWWG"], [8, 10, "FFGGWWG"], [9, 8, "FFGGGWWG"], 
		[10, 6, "FFFGGGWWG"], [11, 4, "FFFGGGGWWG"], [12, 6, "FFGGGGWWG"], [13, 8, "FFGGGWWG"], 
		[14, 10, "FGGGWG"], [15, 12, "FGGG"], [16, 14, "FGG"], [17, 17, "FG"], [18, 19, "F"], 
		[3, 18, "FF"], [4, 17, "FG"], [2, 20, "F"], 
	]
	var tongues: = [
		[[9, 3, "FF"], [8, 1, "FF"], [7, 0, "F"], [13, 2, "FF"], [14, 0, "F"], [4, 13, "F"], [3, 12, "F"], [17, 9, "F"], [18, 7, "F"]], 
		[[9, 2, "FF"], [8, 0, "F"], [12, 2, "FF"], [13, 0, "FF"], [4, 12, "FF"], [17, 10, "FF"], [18, 9, "F"], [19, 7, "F"]], 
		[[10, 2, "FF"], [9, 0, "FF"], [14, 3, "FF"], [15, 1, "F"], [3, 13, "F"], [2, 12, "F"], [18, 11, "F"]], 
		[[9, 3, "FF"], [8, 2, "F"], [7, 1, "F"], [12, 1, "FFF"], [4, 14, "F"], [3, 14, "F"], [17, 8, "FF"], [18, 6, "F"]], 
	]
	var frames: Array = []
	for i in 4:
		frames.append(shifted(fire, 0, -1 if i % 2 == 1 else 0) + tongues[i] + skull + (jaw_open if i < 2 else jaw_shut))
	for fi in frames.size():
		frames[fi] = frames[fi] + extra
	frames_to(t, id, 38, 22, frames)
	t.sprite_palettes[id] = {
		"1": Color(0.93, 0.89, 0.79), "2": Color(0.8, 0.74, 0.64), "3": Color(0.64, 0.57, 0.5), 
		"4": Color(0.46, 0.4, 0.37), "5": Color(0.3, 0.25, 0.26), "K": Color(0.08, 0.04, 0.04), 
		"d": Color(0.1, 0.03, 0.04), "e": Color(1.0, 0.55, 0.2), "f": Color(0.85, 0.8, 0.7), 
		"F": Color(0.95, 0.38, 0.1), "G": Color(1.0, 0.68, 0.2), "W": Color(1.0, 0.93, 0.66), 
	}




static func _hex_imp(t: GameTheme) -> void :
	var body: = [
		[5, 20, "HH"], [4, 19, "H"], [5, 18, "H"], [6, 18, "H"], [4, 25, "H"], [3, 26, "HH"], [4, 27, "H"], 
		[6, 19, "cc"], [7, 18, "ccc"], [8, 18, "ccc"], [9, 18, "cccc"], 
		[6, 21, "hhhh"], [7, 21, "hhhhhH"], [8, 21, "hdphhhH"], [9, 22, "hhhhhhH"], [10, 24, "HHHH"], 
		[10, 17, "ccccccc"], [11, 15, "bcccccccC"], [12, 14, "bccccccccC"], [13, 13, "bCcccccccCC"], 
		[14, 13, "CCcccccccCC"], [15, 12, "CCccccccccCC"], [16, 12, "CCcccccccCC"], [17, 12, "CCCccccCCC"], 
	]
	var tatters: = [
		[[18, 12, "CCCcccCCC"], [19, 12, "C.CCcCC.C"], [20, 13, "C..C.C"], [21, 14, "C...C"]], 
		[[18, 11, "CCCcccCCC"], [19, 10, "C.CCcCC.C"], [20, 10, "C..C.C"], [21, 10, "C...C"]], 
	]
	var arms: = [[12, 22, "ss"], [13, 23, "sss"], [14, 25, "s"], [16, 22, "ss"], [16, 24, "ss"], [17, 25, "s"], [14, 26, "f"], [16, 26, "f"]]
	var orb_big: = [[11, 29, "pp"], [12, 28, "pPPp"], [13, 27, "pPwwPp"], [14, 27, "pPwwPp"], [15, 27, "pPwwPp"], [16, 28, "pPPp"], [17, 29, "pp"]]
	var orb_small: = [[12, 29, "pp"], [13, 28, "pPPp"], [14, 28, "PwwP"], [15, 28, "pPPp"], [16, 29, "pp"]]
	var wings: = wing_frames(shifted(bat_wing(), -1, -2), 12)
	var frames: Array = []
	for i in 4:
		frames.append(wings[i] + body + tatters[i % 2] + arms + (orb_big if i % 2 == 0 else orb_small))
	frames_to(t, "v3_hex_imp", 34, 26, frames)
	t.sprite_palettes["v3_hex_imp"] = {
		"c": Color(0.3, 0.17, 0.32), "C": Color(0.19, 0.1, 0.22), "b": Color(0.48, 0.4, 0.46), "K": Color(0.06, 0.02, 0.07), 
		"h": Color(0.85, 0.8, 0.7), "H": Color(0.55, 0.48, 0.44), "d": Color(0.1, 0.04, 0.08), 
		"s": Color(0.55, 0.5, 0.56), "f": Color(0.85, 0.82, 0.78), 
		"p": Color(0.85, 0.2, 0.62), "P": Color(1.0, 0.45, 0.8), "w": Color(1.0, 0.88, 0.97), 
		"m": Color(0.26, 0.15, 0.28), "n": Color(0.17, 0.09, 0.19), 
	}




static func _gargoyle(t: GameTheme, id: = "v3_gargoyle", extra: Array = []) -> void :
	var body: = [
		[6, 27, "H"], [5, 26, "H"], [4, 26, "H"], [6, 31, "H"], [5, 32, "HH"], [4, 33, "H"], 
		[7, 27, "12223"], [8, 26, "1222223"], [9, 26, "2225e2233"], [10, 26, "3333332222"], 
		[11, 27, "44f5555f4"], [12, 28, "4444444"], 
		[10, 18, "12222222"], [11, 16, "1222222223"], [12, 15, "122222223333"], [13, 14, "1222223333344"], 
		[14, 14, "2222333333444"], [15, 14, "3333333344455"], [16, 15, "333334444555"], [17, 16, "4444455555"], 
		[13, 26, "233"], [14, 27, "234"], [15, 28, "33"], [16, 29, "f.f"], 
		[16, 13, "3334"], [17, 12, "33344"], [18, 13, "4444"], [19, 15, "4444"], [20, 17, "f.f.f"], 
		[16, 10, "44"], [17, 8, "44"], [18, 6, "44"], [19, 5, "4"], [20, 4, "444"], [19, 3, "4"], 
		[12, 19, "x"], [13, 20, "x"], [14, 20, "x"], [15, 21, "x"], [11, 17, "vv"], [12, 16, "v"], [7, 28, "v"], 
		[14, 17, "x"], [15, 16, "x"], 
	]
	var wings: = wing_frames(shifted(bat_wing(), -1, -1), 12)
	var frames: Array = []
	for i in 4:
		frames.append(wings[i] + shifted(body, [0, 0, -1, 0][i]))
	for fi in frames.size():
		frames[fi] = frames[fi] + extra
	frames_to(t, id, 38, 26, frames)
	t.sprite_palettes[id] = {
		"1": Color(0.72, 0.71, 0.66), "2": Color(0.58, 0.57, 0.53), "3": Color(0.45, 0.44, 0.42), 
		"4": Color(0.33, 0.32, 0.32), "5": Color(0.22, 0.21, 0.22), "K": Color(0.07, 0.07, 0.08), 
		"m": Color(0.42, 0.41, 0.4), "n": Color(0.31, 0.3, 0.31), "b": Color(0.62, 0.61, 0.57), 
		"v": Color(0.32, 0.4, 0.24), "x": Color(0.18, 0.17, 0.18), "e": Color(1.0, 0.38, 0.2), 
		"f": Color(0.82, 0.8, 0.74), "H": Color(0.42, 0.41, 0.4), 
	}



static func blob(cx: int, cy: int, rx: int, ry: int, ramp: String) -> Array:
	var out: Array = []
	for y in range(cy - ry, cy + ry + 1):
		var dy: = float(y - cy) / ry
		var hw: = roundi(rx * sqrt(maxf(0.0, 1.0 - dy * dy)))
		if hw <= 0:
			continue
		var row: = ""
		for x in range(cx - hw, cx + hw + 1):
			var dx: = float(x - cx) / rx
			var light: = clampf(0.5 + 0.45 * (dx * 0.6 + dy * 0.8), 0.0, 0.999)
			row += ramp[int(light * ramp.length())]
		out.append([y, cx - hw, row])
	return out





static func _brood_mother(t: GameTheme) -> void :
	var sac: = blob(18, 20, 14, 11, "UUuuvvV")
	sac += shifted([
		[11, 8, "rr"], [12, 10, "r"], [13, 11, "rr"], [14, 13, "r"], [12, 16, "rr"], [13, 18, "rr"], [14, 20, "r"], 
		[22, 3, "r"], [23, 4, "rr"], [24, 6, "rr"], [25, 8, "r"], [19, 21, "rr"], [20, 23, "rr"], [21, 25, "r"], 
		[26, 13, "rrr"], [27, 16, "rr"], [9, 14, "rr"], [10, 16, "r"], 
	], 0, 4) + shifted([
		[15, 5, "i.i"], [16, 5, "iiii"], [17, 4, "iieii"], [18, 4, "iiiii"], [19, 5, "iii"], [20, 6, "ii"], 
		[17, 15, "i.i"], [18, 15, "iiii"], [19, 14, "iieii"], [20, 14, "iiiii"], [21, 15, "iii"], [22, 16, "ii"], 
		[22, 7, "i.i"], [23, 7, "iiii"], [24, 6, "ieiii"], [25, 7, "iii"], 
	], 0, 4)
	var body: = [
		[1, 31, "HH"], [2, 32, "H"], [3, 33, "H"], 
		[4, 32, "1222"], [5, 31, "122223"], [6, 31, "22e2233"], [7, 32, "333334"], [8, 32, "45f54"], [9, 33, "444"], 
		[4, 29, "qq"], [5, 28, "qqq"], [6, 27, "qqqq"], [7, 27, "qqq"], [8, 26, "qqq"], [9, 26, "qq"], [10, 25, "q"], [11, 25, "q"], 
		[7, 30, "12"], [8, 28, "12233"], [9, 28, "1223344"], [10, 26, "2234344"], [11, 26, "2233445"], 
		[12, 25, "2333445"], [13, 25, "343445"], [14, 26, "3445"], [15, 27, "44"], 
	]
	var arm_poses: = [
		[Vector2i(31, 10), Vector2i(36, 19), Vector2i(40, 33)], 
		[Vector2i(31, 10), Vector2i(35, 20), Vector2i(37, 33)], 
		[Vector2i(31, 10), Vector2i(34, 20), Vector2i(33, 33)], 
		[Vector2i(31, 10), Vector2i(37, 18), Vector2i(40, 29)], 
	]
	var leg_poses: = [
		[Vector2i(18, 28), Vector2i(21, 31), Vector2i(19, 33)], 
		[Vector2i(18, 28), Vector2i(20, 31), Vector2i(17, 33)], 
		[Vector2i(18, 28), Vector2i(18, 31), Vector2i(14, 33)], 
		[Vector2i(18, 28), Vector2i(21, 30), Vector2i(20, 32)], 
	]
	var frames: Array = []
	for i in 4:
		var j: = (i + 2) % 4
		var far_arm: = []
		for v: Vector2i in arm_poses[j]:
			far_arm.append(v + Vector2i(-2, 0))
		var far_leg: = []
		for v: Vector2i in leg_poses[i]:
			far_leg.append(v + Vector2i(-8, 0))
		frames.append(leg(far_arm, "45", "45", "fff", 0) + leg(far_leg, "45", "45", "ff", 0)
			+ shifted(sac, [0, 1, 0, 1][i], [0, 0, -1, 0][i]) + leg(leg_poses[j], "34", "34", "ff", 0)
			+ body + leg(arm_poses[i], "23", "23", "fff", 0))
	frames_to(t, "v3_brood_mother", 42, 35, frames)
	t.sprite_palettes["v3_brood_mother"] = {
		"1": Color(0.62, 0.53, 0.57), "2": Color(0.48, 0.4, 0.45), "3": Color(0.36, 0.28, 0.34), 
		"4": Color(0.25, 0.18, 0.24), "5": Color(0.15, 0.1, 0.15), "K": Color(0.06, 0.03, 0.06), 
		"U": Color(0.8, 0.62, 0.57), "u": Color(0.67, 0.47, 0.45), "v": Color(0.5, 0.31, 0.33), "V": Color(0.33, 0.18, 0.22), 
		"r": Color(0.48, 0.12, 0.16), "i": Color(0.3, 0.11, 0.13), "q": Color(0.12, 0.08, 0.1), 
		"e": Color(1.0, 0.6, 0.25), "f": Color(0.85, 0.8, 0.72), "H": Color(0.55, 0.47, 0.42), 
	}



static func robe_row(y: int, l: int, r: int, folds: Array) -> Array:
	var row: = ""
	for x in range(l, r + 1):
		var ch: = "3"
		if x <= l + 1:
			ch = "2"
		elif x >= r - 1:
			ch = "5"
		elif x == r - 2:
			ch = "4"
		elif folds.has(x):
			ch = "4"
		elif folds.has(x + 1):
			ch = "2"
		row += ch
	return [y, l, row]






static func _archfiend(t: GameTheme) -> void :
	var staff: = seg(Vector2i(12, 8), Vector2i(12, 58), "wv") + [
		[3, 9, "hhhh"], [4, 8, "hdhdH"], [5, 8, "hhhhH"], [6, 9, "hHh"], [3, 7, "H"], [2, 6, "H"], [3, 14, "H"], [2, 15, "H"], 
	] + flame(11, 2, 3)
	var robe: Array = []
	for y in range(20, 58):
		var f: = float(y - 20) / 38.0
		var l: int = roundi(lerpf(18, 10, f * f)) if y >= 24 else [24, 21, 19, 18][y - 20]
		var r: int = roundi(lerpf(41, 47, f)) if y >= 24 else [37, 39, 40, 41][y - 20]
		var folds: = [roundi(lerpf(23, 17, f)), roundi(lerpf(29, 27, f)), roundi(lerpf(35, 37, f))]
		robe.append(robe_row(y, l, r, folds))
	robe += [[20, 24, "11112222222111"], [58, 10, "5.55.555..55.555.5.555..5.55.5555.5.5"]]
	var top: = [
		[19, 22, "h"], [18, 23, "h"], [17, 24, "h"], [19, 36, "h"], [18, 37, "h"], 
		[31, 17, "hHhHhHhHhHhHhHhHhHhHhHh"], [32, 17, "HjHjHjHjHjHjHjHjHjHjHjH"], 
		[33, 24, "hh"], [34, 23, "hddh"], [35, 23, "hhhh"], [36, 24, "jj"], 
		[16, 31, "jHj"], [17, 31, "HjH"], [18, 31, "jHj"], [19, 31, "HjH"], 
		[6, 31, "hhhh"], [7, 30, "hhhhhH"], [8, 29, "hhhhhhhH"], [9, 29, "hhdghhhhhH"], [10, 29, "hhddhhhhhhH"], 
		[11, 30, "hhhhhhhhhhH"], [12, 31, "HhhhhhhhhH"], [13, 32, "HHhhhhhdd"], [14, 33, "jHHHHHHH"], 
		[15, 34, "jfjfjfj"], [16, 34, "jHHHHHj"], [17, 35, "jjjj"], 
		[5, 34, "jj"], [4, 35, "jj"], [3, 36, "jjj"], [4, 38, "j"], 
		[5, 29, "HhjH"], [4, 27, "hHhjH"], [3, 25, "hhHjh"], [4, 23, "hHj"], [5, 22, "hjH"], [6, 22, "Hjj"], 
		[7, 22, "jHj"], [8, 23, "jHHj"], [9, 25, "jHj"], [10, 26, "jH"], 
		[5, 25, "jjjj"], [6, 25, "jHjj"], [7, 25, "jjHj"], [8, 27, "jj"], 
	]
	var arms: = seg(Vector2i(19, 23), Vector2i(15, 27), "445") + [[26, 12, "hhh"], [27, 12, "hhh"]]\
	+ seg(Vector2i(37, 23), Vector2i(44, 27), "2334") + [
		[26, 44, "3344"], [27, 44, "34455"], [28, 45, "455"], 
		[25, 47, "hh"], [26, 47, "hhhf"], [27, 48, "hhf"], [28, 48, "h.f"], [24, 49, "gG"], [23, 50, "g"], [25, 50, "Gg"], [22, 50, "g"], 
	]
	var feet: = [[[59, 24, "f.f"]], [], [[59, 32, "f.f"]], []]
	var frames: Array = []
	for i in 4:
		var sway: int = [1, 0, -1, 0][i]
		frames.append(staff + swung(robe, 40, 58, sway) + feet[i] + top + arms + (flame(50, 22, 3) if i % 2 == 0 else flame(50, 22, 4)))
	frames_to(t, "v3_archfiend", 56, 61, frames)
	t.sprite_palettes["v3_archfiend"] = {
		"1": Color(0.62, 0.22, 0.22), "2": Color(0.46, 0.13, 0.15), "3": Color(0.32, 0.07, 0.1), 
		"4": Color(0.21, 0.04, 0.07), "5": Color(0.12, 0.02, 0.05), "K": Color(0.04, 0.01, 0.02), 
		"h": Color(0.88, 0.83, 0.72), "H": Color(0.62, 0.55, 0.48), "j": Color(0.38, 0.32, 0.3), "d": Color(0.08, 0.03, 0.03), 
		"g": Color(1.0, 0.55, 0.15), "G": Color(1.0, 0.85, 0.4), "f": Color(0.85, 0.8, 0.72), 
		"w": Color(0.42, 0.3, 0.22), "v": Color(0.26, 0.18, 0.14), 
		"F": Color(0.95, 0.4, 0.1), "W": Color(1.0, 0.95, 0.7), 
	}







static func _rats(t: GameTheme) -> void :
	var body: = [
		[3, 13, "11222222"], [4, 10, "112222222233"], [5, 8, "12224222422333"], [6, 7, "122222222423333"], 
		[7, 6, "2224222223333344"], [8, 6, "2222223333334444"], [9, 6, "3333333334444455"], 
		[10, 7, "333344444555"], [11, 9, "44455555"], 
		[2, 21, "23"], [3, 21, "2s3"], [4, 21, "2333"], 
		[4, 23, "222"], [5, 22, "122223"], [6, 22, "2223e33"], [7, 22, "333333322s"], [8, 22, "4444433"], [8, 29, "f"], 
	]
	var tails: = [
		seg(Vector2i(6, 9), Vector2i(2, 11), "s") + seg(Vector2i(2, 11), Vector2i(0, 14), "S"), 
		seg(Vector2i(6, 9), Vector2i(2, 10), "s") + seg(Vector2i(2, 10), Vector2i(0, 12), "S"), 
		seg(Vector2i(6, 9), Vector2i(2, 9), "s") + seg(Vector2i(2, 9), Vector2i(0, 10), "S"), 
		seg(Vector2i(6, 9), Vector2i(2, 10), "s") + seg(Vector2i(2, 10), Vector2i(0, 13), "S"), 
	]
	var sh: = Vector2i(22, 9)
	var hip: = Vector2i(10, 9)
	var front: = [
		[sh, Vector2i(26, 12), Vector2i(29, 13)], [sh, Vector2i(23, 12), Vector2i(23, 15)], 
		[sh, Vector2i(20, 12), Vector2i(18, 14)], [sh, Vector2i(25, 11), Vector2i(27, 13)], 
	]
	var hind: = [
		[hip, Vector2i(7, 12), Vector2i(4, 14)], [hip, Vector2i(10, 12), Vector2i(8, 15)], 
		[hip, Vector2i(14, 12), Vector2i(16, 15)], [hip, Vector2i(11, 12), Vector2i(12, 15)], 
	]
	var lift: = [0, 1, 1, 1]
	var boils: = [[5, 11, "b"], [7, 15, "bB"], [6, 19, "s"], [8, 10, "ss"], [4, 16, "b"], [9, 13, "B"]]
	var crown: = [[1, 23, "h.h.h"], [2, 23, "hhhhh"], [3, 23, "y"]]
	var knot: = seg(Vector2i(4, 8), Vector2i(1, 5), "s") + seg(Vector2i(1, 5), Vector2i(0, 9), "S")\
	+ seg(Vector2i(5, 10), Vector2i(2, 15), "s") + [[4, 0, "23"], [5, 0, "e3"], [13, 2, "233"], [14, 2, "3e4"]]
	for kind: String in ["grave_rat", "plague_rat", "rat_king"]:
		var frames: Array = []
		for i in 4:
			var d: = Vector2i(0, lift[i])
			var extra: Array = boils if kind == "plague_rat" else (crown + knot if kind == "rat_king" else [])
			frames.append(shifted(leg(moved(front[i], d + Vector2i(-2, 0), i != 1), "34", "4", "SS", 0)
				+ leg(moved(hind[i], d + Vector2i(2, 0), i != 3), "45", "4", "SS", 0), 0, 2)
				+ shifted(shifted(tails[i], lift[i]) + shifted(body + extra, lift[i]), 0, 2)
				+ shifted(leg(moved(front[i], d, i != 1), "23", "3", "ss", 0) + leg(moved(hind[i], d, i != 3), "234", "3", "ss", 0), 0, 2))
		frames_to(t, "v3_" + kind, 34, 17, frames)
	var rat: = {"s": Color(0.82, 0.58, 0.58), "S": Color(0.58, 0.4, 0.42), "f": Color(0.92, 0.85, 0.6), "e": Color(1.0, 0.3, 0.25)}
	t.sprite_palettes["v3_grave_rat"] = rat.merged({
		"1": Color(0.62, 0.56, 0.51), "2": Color(0.48, 0.42, 0.39), "3": Color(0.36, 0.31, 0.3), 
		"4": Color(0.25, 0.21, 0.21), "5": Color(0.16, 0.13, 0.14), "K": Color(0.05, 0.04, 0.05), 
	}, true)
	t.sprite_palettes["v3_plague_rat"] = rat.merged({
		"1": Color(0.6, 0.64, 0.48), "2": Color(0.46, 0.5, 0.37), "3": Color(0.34, 0.38, 0.29), 
		"4": Color(0.23, 0.26, 0.21), "5": Color(0.14, 0.16, 0.14), "K": Color(0.04, 0.05, 0.04), 
		"b": Color(0.85, 0.8, 0.36), "B": Color(0.6, 0.55, 0.2), "e": Color(1.0, 0.85, 0.25), 
	}, true)
	t.sprite_palettes["v3_rat_king"] = rat.merged({
		"1": Color(0.66, 0.6, 0.55), "2": Color(0.52, 0.46, 0.43), "3": Color(0.39, 0.34, 0.33), 
		"4": Color(0.27, 0.23, 0.23), "5": Color(0.17, 0.14, 0.15), "K": Color(0.05, 0.04, 0.05), 
		"h": Color(0.88, 0.82, 0.7), "y": Color(0.85, 0.65, 0.25), 
	}, true)





static func _crows(t: GameTheme) -> void :
	var wing: = seg(Vector2i(11, 4), Vector2i(2, 1), "43") + seg(Vector2i(12, 4), Vector2i(4, 0), "34")\
	+ seg(Vector2i(12, 3), Vector2i(7, 0), "34") + seg(Vector2i(13, 3), Vector2i(10, 0), "23")\
	+ seg(Vector2i(16, 10), Vector2i(10, 5), "233") + seg(Vector2i(15, 11), Vector2i(8, 6), "334")\
	+ seg(Vector2i(14, 11), Vector2i(7, 7), "34") + seg(Vector2i(17, 10), Vector2i(13, 3), "12")
	var body: = [
		[10, 4, "3344"], [11, 2, "344444"], [12, 3, "34444"], [13, 4, "4444"], 
		[9, 10, "1222222"], [10, 8, "1222222223"], [11, 8, "22223333334"], [12, 9, "3333344445"], [13, 11, "4444455"], 
		[7, 20, "1222"], [8, 19, "12222e3"], [9, 18, "22222233"], [10, 18, "3333334"], [11, 19, "44445"], [12, 20, "4.4"], 
		[8, 25, "bb"], [9, 25, "bbbb"], [10, 25, "BBB"], [11, 27, "B"], 
		[14, 14, "f.f"], 
	]
	var king: = [[5, 20, "h.h.h"], [6, 20, "hhhhh"], [12, 17, "hdh"], [13, 16, "y"], [13, 19, "hdh"], [14, 18, "y"]]
	var wings: = wing_frames(wing, 11)
	for kind: String in ["crow", "carrion_king"]:
		var frames: Array = []
		for i in 4:
			frames.append(shifted(body + (king if kind == "carrion_king" else []), [0, 0, -1, 0][i]) + wings[i])
		frames_to(t, "v3_" + kind, 30, 22, frames)
	var crow: = {
		"1": Color(0.56, 0.57, 0.72), "2": Color(0.37, 0.37, 0.5), "3": Color(0.26, 0.25, 0.35), 
		"4": Color(0.17, 0.16, 0.24), "5": Color(0.1, 0.09, 0.15), "K": Color(0.02, 0.02, 0.04), 
		"b": Color(0.36, 0.35, 0.36), "B": Color(0.2, 0.19, 0.2), "e": Color(1.0, 0.25, 0.2), "f": Color(0.4, 0.34, 0.3), 
	}
	t.sprite_palettes["v3_crow"] = crow
	t.sprite_palettes["v3_carrion_king"] = crow.merged({
		"1": Color(0.52, 0.44, 0.62), "2": Color(0.33, 0.27, 0.4), "h": Color(0.88, 0.82, 0.7), "d": Color(0.08, 0.03, 0.04), 
		"y": Color(0.85, 0.65, 0.25), 
	}, true)




static func _ash_spider(t: GameTheme) -> void :
	var body: = blob(9, 6, 6, 4, "1223345") + blob(18, 7, 4, 2, "12334") + [
		[4, 6, "g"], [5, 7, "gg"], [6, 8, "g"], [6, 4, "g"], [7, 5, "gg"], [8, 6, "g"], [5, 10, "gG"], [6, 11, "g"], 
		[5, 20, "ee"], [6, 21, "e"], [8, 22, "f"], [9, 21, "f"], 
	]
	var roots: = [Vector2i(20, 8), Vector2i(19, 8), Vector2i(17, 8), Vector2i(15, 8)]
	var knees: = [Vector2i(25, 3), Vector2i(22, 1), Vector2i(13, 1), Vector2i(9, 3)]
	var feet: = [Vector2i(28, 13), Vector2i(23, 13), Vector2i(11, 13), Vector2i(4, 13)]
	var frames: Array = []
	for i in 4:
		var spans: Array = []
		for k in 4:
			var dx: = 2 if (k + i) % 2 == 0 else -2
			spans += seg(roots[k] + Vector2i(-1, -1), knees[k] + Vector2i(-2, 1), "4") + seg(knees[k] + Vector2i(-2, 1), feet[k] + Vector2i(-2 - dx, 0), "5")
		spans += body
		for k in 4:
			var dx: = 2 if (k + i) % 2 == 0 else -2
			var knee: Vector2i = knees[k] + Vector2i(dx / 2, 0)
			spans += seg(roots[k], knee, "2") + seg(knee, feet[k] + Vector2i(dx, 0), "3")
		frames.append(shifted(spans, 1, 1))
	frames_to(t, "v3_ash_spider", 31, 15, frames)
	t.sprite_palettes["v3_ash_spider"] = {
		"1": Color(0.66, 0.63, 0.6), "2": Color(0.52, 0.49, 0.47), "3": Color(0.39, 0.36, 0.35), 
		"4": Color(0.27, 0.25, 0.25), "5": Color(0.17, 0.15, 0.16), "K": Color(0.05, 0.04, 0.05), 
		"g": Color(0.95, 0.45, 0.12), "G": Color(1.0, 0.78, 0.35), "e": Color(1.0, 0.35, 0.2), "f": Color(0.82, 0.78, 0.7), 
	}



static func walk_poses(hip: Vector2i, l: int) -> Array:
	var k: = l / 2
	return [
		[hip, hip + Vector2i(3, k), hip + Vector2i(3, l), hip + Vector2i(5, l)], 
		[hip, hip + Vector2i(1, k), hip + Vector2i(-1, l), hip + Vector2i(2, l)], 
		[hip, hip + Vector2i(-2, k), hip + Vector2i(-5, l - 1), hip + Vector2i(-3, l)], 
		[hip, hip + Vector2i(3, k - 1), hip + Vector2i(1, l - 2), hip + Vector2i(3, l - 2)], 
	]


static func joints_dx(joints: Array, dx: int) -> Array:
	var out: Array = []
	for j: Vector2i in joints:
		out.append(j + Vector2i(dx, 0))
	return out




static func _skeleton(t: GameTheme) -> void :
	var body: = [
		[1, 10, "1222"], [2, 9, "122222"], [3, 9, "2223dd3"], [4, 9, "333dde3"], [5, 10, "3334d3"], 
		[6, 11, "3fdfd"], [7, 11, "44444"], [2, 11, "4"], 
		[8, 10, "4"], [9, 9, "22222"], [10, 8, "3222223"], [11, 8, "3"], [11, 14, "3"], [12, 8, "322222"], 
		[13, 8, "3"], [13, 13, "3"], [14, 8, "32222"], [15, 9, "3"], [16, 9, "3"], 
		[17, 8, "2333"], [18, 8, "3.33"], [17, 7, "cccccc"], [18, 7, "cc.cc"], [19, 8, "c..c"], 
	]
	var arm: = seg(Vector2i(12, 10), Vector2i(14, 14), "2") + seg(Vector2i(14, 14), Vector2i(18, 15), "2") + [[15, 18, "33"]]\
	+ seg(Vector2i(19, 14), Vector2i(23, 19), "M") + seg(Vector2i(19, 15), Vector2i(22, 19), "r") + [[13, 19, "L"], [14, 19, "L"], [16, 19, "L"]]
	var far_arm: = seg(Vector2i(10, 10), Vector2i(8, 14), "4") + seg(Vector2i(8, 14), Vector2i(7, 18), "4")
	var poses: = walk_poses(Vector2i(10, 18), 10)
	var frames: Array = []
	for i in 4:
		var sw: int = [-2, 0, 2, 0][i]
		frames.append(swung(far_arm, 10, 18, sw) + leg(joints_dx(poses[(i + 2) % 4], -2), "4", "4", "44")
			+ body + leg(poses[i], "23", "2", "223") + swung(arm, 10, 20, - sw))
	frames_to(t, "v3_skeleton", 25, 31, frames)
	t.sprite_palettes["v3_skeleton"] = {
		"1": Color(0.93, 0.9, 0.8), "2": Color(0.8, 0.75, 0.65), "3": Color(0.62, 0.56, 0.5), 
		"4": Color(0.44, 0.39, 0.37), "5": Color(0.28, 0.24, 0.25), "K": Color(0.07, 0.05, 0.06), 
		"d": Color(0.08, 0.04, 0.05), "e": Color(1.0, 0.35, 0.2), "f": Color(0.86, 0.82, 0.72), 
		"c": Color(0.35, 0.3, 0.26), "M": Color(0.6, 0.55, 0.5), "r": Color(0.55, 0.3, 0.18), "L": Color(0.35, 0.25, 0.2), 
	}




static func _penitent(t: GameTheme) -> void :
	var robe: = shifted([
		[1, 10, "2222"], [2, 8, "22222233"], [3, 7, "12222223333"], [4, 6, "122222333334444"], 
		[5, 6, "12222333332ddd4"], [6, 5, "122223333332ddd"], [7, 5, "222233333332ddd"], [8, 5, "333333333342ddd"], 
		[9, 6, "33333333342dss"], [10, 6, "43333333442ss"], [11, 7, "444333334444"], [12, 5, "22333333334444"], 
		[13, 5, "123333333344445"], [14, 4, "2332433324333455"], [15, 4, "2332433324333455"], 
		[16, 4, "23324333243333455"], [17, 3, "233324333243333455"], [18, 3, "233324333243333455"], 
		[19, 3, "yyyyyyyyyyyyyyyYYY"], [20, 3, "233324333243333455"], [21, 3, "2333243332433243455"], 
		[22, 3, "2333243332433243455"], [23, 2, "23333243332433243455"], [24, 2, "23333243332433243455"], 
		[25, 2, "23333243332433243455"], [26, 2, "233332433324332433455"], [27, 2, "233332433324332433455"], 
		[28, 2, "233332433324332433455"], [29, 2, "233332433324332433455"], [30, 2, "444454444544454445555"], 
		[20, 9, "y"], [21, 9, "Y"], [22, 10, "y"], [23, 10, "Y"], 
	], 2, 2)
	var cross: = seg(Vector2i(25, 18), Vector2i(2, 2), "WwV") + seg(Vector2i(1, 10), Vector2i(9, 0), "WwV")
	var arm: = shifted([[12, 12, "22223"], [13, 12, "122233"], [14, 13, "1222334"], [15, 14, "122234"], [16, 15, "2234"], 
		[14, 13, "5"], [15, 13, "5"]], 2, 2) + [[16, 21, "ss"], [17, 21, "sS"]]
	var feet: = [
		[[33, 6, "SS"], [34, 5, "SSS"], [33, 21, "ss"], [34, 21, "ssss"], [33, 23, "M"], [34, 1, "L.M.L"]], 
		[[33, 11, "SS"], [33, 14, "ss"], [34, 14, "ssss"], [33, 16, "M"], [34, 3, "L.M.L.M"]], 
		[[33, 19, "SS"], [34, 19, "SSS"], [33, 8, "ss"], [34, 7, "ssss"], [33, 10, "M"], [34, 0, "M.L"]], 
		[[33, 13, "SS"], [34, 13, "SSS"], [33, 16, "ss"], [33, 18, "M"], [34, 4, "L.M.L.M.L"]], 
	]
	var frames: Array = []
	for i in 4:
		var hem: int = [1, 0, -1, 0][i]
		frames.append(shifted(cross, [0, 1, 0, 1][i]) + swung(robe, 25, 32, hem)
			+ [[33, 4, "5.55.555.55..55.5.55" if i % 2 == 0 else "55.555.55..55.555.5."]] + feet[i] + arm)
	frames_to(t, "v3_penitent", 31, 36, frames)
	t.sprite_palettes["v3_penitent"] = {
		"1": Color(0.6, 0.53, 0.6), "2": Color(0.47, 0.4, 0.49), "3": Color(0.36, 0.3, 0.39), 
		"4": Color(0.26, 0.21, 0.29), "5": Color(0.16, 0.12, 0.19), "K": Color(0.05, 0.03, 0.06), 
		"d": Color(0.04, 0.02, 0.04), "s": Color(0.72, 0.64, 0.6), "S": Color(0.48, 0.42, 0.42), 
		"y": Color(0.62, 0.52, 0.36), "Y": Color(0.42, 0.34, 0.24), "w": Color(0.55, 0.4, 0.26), "v": Color(0.36, 0.25, 0.17), 
		"W": Color(0.7, 0.54, 0.36), "V": Color(0.3, 0.2, 0.14), 
		"M": Color(0.55, 0.55, 0.58), "L": Color(0.32, 0.32, 0.36), 
	}




static func _flagellant(t: GameTheme) -> void :
	var body: = [
		[1, 16, "Ccc"], [2, 15, "cccccC"], [3, 14, "ccccccC"], [4, 14, "cccccccC"], [5, 14, "cccdeCdeC"], 
		[6, 14, "ccccCcccC"], [7, 14, "CccccccC"], [8, 15, "CCcccCC"], [9, 16, "CCCC"], 
		[9, 12, "1122223"], [10, 10, "112222233"], [11, 10, "1222223334"], [12, 10, "2222233344"], [13, 10, "222333344"], 
		[14, 11, "22333344"], [15, 11, "23333444"], [16, 12, "3333444"], [17, 12, "3334445"], [18, 12, "3344455"], 
		[19, 12, "344455"], 
		[10, 11, "r"], [11, 12, "r"], [12, 13, "R"], [12, 10, "r"], [13, 11, "r"], [14, 12, "R"], 
		[14, 11, "r"], [15, 12, "r"], [16, 13, "R"], [16, 12, "r"], [17, 13, "r"], [13, 16, "4"], [15, 16, "4"], 
		[20, 11, "yyyyyyyy"], [21, 11, "uuuuuuUU"], [22, 11, "uuuuuUUU"], [23, 11, "uuuuUUU"], [24, 12, "u.uu.U"], 
	]
	var far_arm: = seg(Vector2i(16, 11), Vector2i(19, 16), "4") + seg(Vector2i(19, 16), Vector2i(21, 19), "4") + [[20, 21, "44"]]
	var arm: = seg(Vector2i(18, 11), Vector2i(22, 12), "23") + seg(Vector2i(22, 12), Vector2i(21, 6), "23") + [[5, 21, "22"]]\
	+ seg(Vector2i(21, 5), Vector2i(19, 2), "ww")
	var raised: = seg(Vector2i(19, 2), Vector2i(12, 0), "y") + seg(Vector2i(19, 2), Vector2i(10, 2), "Y") + seg(Vector2i(19, 2), Vector2i(11, 4), "y") + [[0, 11, "r"], [2, 9, "r"], [4, 10, "r"]]
	var strike: = seg(Vector2i(19, 2), Vector2i(11, 11), "y") + seg(Vector2i(19, 2), Vector2i(9, 9), "Y") + seg(Vector2i(19, 2), Vector2i(12, 13), "y") + [[11, 10, "r"], [9, 8, "r"], [13, 12, "r"]]
	var poses: = walk_poses(Vector2i(16, 23), 10)
	var frames: Array = []
	for i in 4:
		frames.append(far_arm + leg(joints_dx(poses[(i + 2) % 4], -3), "UU", "4", "44") + body
			+ leg(poses[i], "uuU", "23", "223") + arm + (raised if i % 2 == 0 else strike))
	frames_to(t, "v3_flagellant", 32, 35, frames)
	t.sprite_palettes["v3_flagellant"] = {
		"1": Color(0.88, 0.76, 0.66), "2": Color(0.76, 0.62, 0.53), "3": Color(0.6, 0.47, 0.42), 
		"4": Color(0.43, 0.32, 0.31), "5": Color(0.28, 0.2, 0.21), "K": Color(0.07, 0.03, 0.04), 
		"c": Color(0.52, 0.12, 0.13), "C": Color(0.33, 0.06, 0.08), "d": Color(0.06, 0.02, 0.02), "e": Color(1.0, 0.8, 0.5), 
		"r": Color(0.66, 0.1, 0.12), "R": Color(0.42, 0.05, 0.08), "y": Color(0.62, 0.52, 0.36), 
		"u": Color(0.42, 0.34, 0.27), "U": Color(0.28, 0.22, 0.18), "w": Color(0.5, 0.36, 0.24), 
	}





static func _gravedigger(t: GameTheme) -> void :
	var coat: Array = []
	for y in range(12, 28):
		var f: = float(y - 12) / 15.0
		coat.append(robe_row(y, roundi(lerpf(12, 9, f)), roundi(lerpf(28, 29, f)), [roundi(lerpf(16, 14, f)), roundi(lerpf(22, 21, f))]))
	coat += [[11, 14, "11222222222223"], [20, 11, "xx"], [21, 11, "xx"], [24, 20, "xxx"], [25, 20, "x"]]
	var back_flap: Array = []
	var front_flap: Array = []
	for y in range(28, 37):
		back_flap.append(robe_row(y, 9 - (y - 28) / 3, 15, [12]))
		front_flap.append(robe_row(y, 23, 29 + (y - 28) / 4, [26]))
	back_flap.append([37, 6, "5.55.5.55"])
	front_flap.append([37, 23, "55.5.55"])
	var head: = [
		[1, 17, "aaaaaa"], [2, 16, "aaaaaaaa"], [3, 16, "aAaaaaaA"], [4, 16, "AAAAAAAA"], 
		[5, 10, "aaaaaaaaaaaaaaaaaaaaa"], [6, 11, "AAAAAAAAAAAAAAAAAAA"], 
		[7, 19, "dddddddd"], [8, 19, "sSddeddS"], [9, 19, "ssSSssss"], [10, 20, "SsSssssS"], [11, 20, "SsSsSS"], [12, 21, "SSSS"], 
	]
	var shovel: = seg(Vector2i(30, 22), Vector2i(7, 4), "wv") + [
		[0, 3, "MM"], [1, 2, "MMML"], [2, 1, "MMMLL"], [3, 1, "MMLLL"], [4, 2, "MLLL"], [5, 3, "LL"], [2, 6, "r"], [3, 5, "r"], 
	]
	var arm: = seg(Vector2i(25, 13), Vector2i(29, 19), "12335") + [[19, 29, "jjj"], [20, 28, "jjjj"], [21, 29, "jj"]]
	var lantern: = [[26, 26, "L"], [27, 25, "MgM"], [28, 25, "MGM"], [29, 25, "MgM"], [30, 25, "LLL"]]
	var poses: = walk_poses(Vector2i(19, 27), 11)
	var frames: Array = []
	for i in 4:
		var sw: int = [1, 0, -1, 0][i]
		frames.append(shovel + leg(joints_dx(poses[(i + 2) % 4], -2), "UUU", "UU", "kkkk") + swung(back_flap, 28, 37, - sw)
			+ leg(poses[i], "uuuU", "uuU", "kkkkk") + coat + swung(front_flap, 28, 37, sw) + head
			+ shifted(lantern, 0, - sw) + arm)
		frames[i] = shifted(frames[i], 1, 1)
	frames_to(t, "v3_gravedigger", 36, 42, frames)
	t.sprite_palettes["v3_gravedigger"] = {
		"1": Color(0.55, 0.47, 0.38), "2": Color(0.43, 0.36, 0.29), "3": Color(0.32, 0.26, 0.22), 
		"4": Color(0.22, 0.18, 0.16), "5": Color(0.14, 0.11, 0.1), "K": Color(0.04, 0.03, 0.03), 
		"x": Color(0.38, 0.34, 0.28), "a": Color(0.3, 0.25, 0.22), "A": Color(0.19, 0.15, 0.14), 
		"d": Color(0.07, 0.05, 0.05), "e": Color(0.85, 0.95, 0.75), "s": Color(0.58, 0.63, 0.52), "S": Color(0.4, 0.44, 0.37), 
		"u": Color(0.3, 0.3, 0.32), "U": Color(0.2, 0.2, 0.22), "j": Color(0.36, 0.3, 0.24), 
		"w": Color(0.5, 0.38, 0.26), "v": Color(0.33, 0.24, 0.17), "M": Color(0.58, 0.57, 0.55), "L": Color(0.34, 0.33, 0.33), 
		"r": Color(0.5, 0.3, 0.18), "g": Color(1.0, 0.75, 0.3), "G": Color(1.0, 0.95, 0.7), "k": Color(0.12, 0.1, 0.09), 
	}




static func _coffin_crawler(t: GameTheme) -> void :
	var box: = [
		[3, 6, "11222222222222222233"], [4, 5, "1222222222222222223334"], [5, 5, "4444444444444"], [5, 18, "ddedded5"], 
		[6, 4, "2222222222222222222233"], [7, 4, "2333333333333333333334"], [8, 3, "23333333333333333333344"], 
		[9, 3, "33333333333333333333344"], [10, 3, "33333333333333333333445"], [11, 4, "4444444444444444444455"], 
		[12, 5, "55555555555555555555"], 
		[8, 6, "44"], [9, 12, "444"], [10, 22, "44"], [7, 15, "4"], 
	] + seg(Vector2i(9, 6), Vector2i(9, 11), "M") + seg(Vector2i(19, 6), Vector2i(19, 11), "M") + [[8, 9, "L"], [10, 19, "L"]]
	var roots: = [6, 10, 14, 17, 21, 24]
	var frames: Array = []
	for i in 4:
		var spans: Array = []
		for k in roots.size():
			var x: int = roots[k]
			var dx: = 2 if (k + i) % 2 == 0 else -2
			spans += seg(Vector2i(x, 12), Vector2i(x + dx / 2 + 1, 15), "h") + seg(Vector2i(x + dx / 2 + 1, 15), Vector2i(x + dx, 19), "H")
			spans.append([20, x + dx - 1, "h.h"])
		frames.append(spans + box)
	frames_to(t, "v3_coffin_crawler", 30, 21, frames)
	t.sprite_palettes["v3_coffin_crawler"] = {
		"1": Color(0.62, 0.48, 0.36), "2": Color(0.48, 0.36, 0.27), "3": Color(0.36, 0.26, 0.2), 
		"4": Color(0.25, 0.18, 0.14), "5": Color(0.15, 0.1, 0.09), "K": Color(0.05, 0.03, 0.03), 
		"d": Color(0.04, 0.02, 0.02), "e": Color(1.0, 0.85, 0.4), "M": Color(0.5, 0.5, 0.52), "L": Color(0.3, 0.3, 0.32), 
		"h": Color(0.86, 0.82, 0.72), "H": Color(0.62, 0.57, 0.5), 
	}




static func _plague_bloat(t: GameTheme) -> void :
	var body: = blob(16, 18, 12, 11, "1223334455") + [
		[12, 9, "b"], [13, 10, "bB"], [20, 12, "b"], [21, 13, "B"], [16, 22, "bb"], [17, 23, "B"], [23, 18, "b"], 
		[10, 14, "pp"], [11, 15, "p"], [24, 22, "pp"], [14, 26, "p"], [19, 17, "4"], [18, 18, "44"], 
		[3, 23, "1222"], [4, 22, "122223"], [5, 22, "2dd2d3"], [6, 22, "2e32e3"], [7, 22, "333333"], [8, 23, "3dd4"], [9, 23, "444"], 
		[9, 20, "33"], [10, 19, "334"], 
	]
	var arm: = seg(Vector2i(24, 11), Vector2i(27, 18), "23") + seg(Vector2i(27, 18), Vector2i(28, 23), "3") + [[24, 27, "333"]]
	var far_arm: = seg(Vector2i(9, 11), Vector2i(6, 18), "4") + seg(Vector2i(6, 18), Vector2i(6, 23), "4")
	var fumes: = [
		[[1, 10, "v"], [0, 12, "v"], [2, 14, "v"], [1, 18, "v"], [0, 20, "v"]], 
		[[0, 10, "v"], [1, 13, "v"], [0, 15, "v"], [2, 18, "v"]], 
		[[1, 11, "v"], [0, 13, "v"], [1, 16, "v"], [0, 19, "v"], [2, 21, "v"]], 
		[[0, 11, "v"], [2, 12, "v"], [1, 15, "v"], [0, 18, "v"]], 
	]
	var frames: Array = []
	for i in 4:
		var near: Array = walk_poses(Vector2i(19, 27), 5)[i]
		var far: Array = walk_poses(Vector2i(13, 27), 5)[(i + 2) % 4]
		frames.append(fumes[i] + far_arm + leg(far, "45", "4", "444") + shifted(body, [1, 0, 1, 0][i])
			+ leg(near, "234", "23", "3333") + shifted(arm, [1, 0, 1, 0][i]))
	frames_to(t, "v3_plague_bloat", 34, 34, frames)
	t.sprite_palettes["v3_plague_bloat"] = {
		"1": Color(0.72, 0.76, 0.62), "2": Color(0.58, 0.63, 0.5), "3": Color(0.45, 0.5, 0.4), 
		"4": Color(0.33, 0.36, 0.3), "5": Color(0.21, 0.23, 0.2), "K": Color(0.05, 0.06, 0.05), 
		"d": Color(0.08, 0.06, 0.06), "e": Color(0.95, 0.9, 0.5), "b": Color(0.88, 0.82, 0.38), "B": Color(0.62, 0.55, 0.22), 
		"p": Color(0.45, 0.3, 0.42), "v": Color(0.55, 0.8, 0.35), 
	}




static func _wraith(t: GameTheme, id: = "v3_wraith", extra: Array = []) -> void :
	var body: = [
		[2, 12, "1222"], [3, 10, "122222"], [4, 9, "12222223"], [5, 9, "22223dddd"], [6, 9, "2223dddde"], [7, 9, "2233ddddd"], 
		[8, 9, "23333ddd"], [9, 8, "22233344"], [10, 7, "2233333444"], [11, 6, "22333333444"], [12, 6, "2333333344455"], 
		[13, 6, "33333333444555"], [14, 6, "3333333444555"], [15, 5, "33333334445555"], [16, 5, "3333334445555"], 
		[17, 4, "433333444555"], [18, 3, "44333344455"], [19, 3, "4433344455"], [20, 2, "443344455"], [21, 2, "44444555"], 
	]
	var arm: = seg(Vector2i(15, 11), Vector2i(21, 13), "2334")
	var hands: = [
		[[11, 24, "h"], [12, 22, "hhhh"], [13, 22, "h.hh"], [14, 24, "h"], [12, 26, "h"]], 
		[[11, 25, "h"], [12, 22, "hhhh"], [13, 23, "hhh"], [14, 25, "h"], [12, 26, "h"]], 
	]
	var wisps: = [
		seg(Vector2i(5, 21), Vector2i(1, 27), "45") + seg(Vector2i(8, 21), Vector2i(5, 28), "5") + seg(Vector2i(11, 20), Vector2i(10, 27), "45") + seg(Vector2i(3, 19), Vector2i(0, 23), "5"), 
		seg(Vector2i(5, 21), Vector2i(2, 28), "45") + seg(Vector2i(8, 21), Vector2i(7, 28), "5") + seg(Vector2i(11, 20), Vector2i(12, 26), "45") + seg(Vector2i(3, 19), Vector2i(0, 21), "5"), 
		seg(Vector2i(5, 21), Vector2i(0, 26), "45") + seg(Vector2i(8, 21), Vector2i(4, 27), "5") + seg(Vector2i(11, 20), Vector2i(9, 28), "45") + seg(Vector2i(3, 19), Vector2i(1, 24), "5"), 
		seg(Vector2i(5, 21), Vector2i(1, 28), "45") + seg(Vector2i(8, 21), Vector2i(6, 27), "5") + seg(Vector2i(11, 20), Vector2i(11, 27), "45") + seg(Vector2i(3, 19), Vector2i(0, 22), "5"), 
	]
	var frames: Array = []
	for i in 4:
		frames.append(wisps[i] + body + arm + hands[i % 2])
	for fi in frames.size():
		frames[fi] = frames[fi] + extra
	frames_to(t, id, 28, 29, frames)
	t.sprite_palettes[id] = {
		"1": Color(0.6, 0.62, 0.74), "2": Color(0.45, 0.46, 0.6), "3": Color(0.32, 0.32, 0.46), "4": Color(0.21, 0.21, 0.32), 
		"5": Color(0.13, 0.12, 0.21), "K": Color(0.04, 0.03, 0.07), "d": Color(0.02, 0.02, 0.04), "e": Color(0.7, 0.95, 1.0), 
		"h": Color(0.8, 0.82, 0.86), 
	}




static func _lantern_ghost(t: GameTheme) -> void :
	var body: = [
		[3, 11, "1222"], [4, 10, "122222"], [5, 10, "22dd2d3"], [6, 10, "22dd2d3"], [7, 10, "3333333"], [8, 11, "33dd3"], 
		[9, 12, "4444"], [9, 9, "2233"], [10, 8, "22233333"], [11, 7, "2223333344"], [12, 7, "2233333444"], 
		[13, 7, "233333344"], [14, 7, "33333344"], [15, 6, "3333344"], [16, 6, "333344"], [17, 5, "33344"], [18, 5, "3344"], 
	]
	var tails: = [
		[[19, 4, "344"], [20, 3, "34"], [21, 2, "4"], [22, 1, "4"], [23, 1, "5"]], 
		[[19, 4, "344"], [20, 3, "44"], [21, 3, "4"], [22, 2, "5"]], 
		[[19, 4, "344"], [20, 4, "34"], [21, 3, "4"], [22, 3, "4"], [23, 2, "5"]], 
		[[19, 4, "344"], [20, 3, "44"], [21, 2, "4"], [22, 2, "5"]], 
	]
	var arm: = seg(Vector2i(14, 11), Vector2i(19, 13), "23") + [[13, 20, "1"], [14, 20, "L"]]
	var lamps: = [
		[[15, 19, "LLL"], [16, 19, "gWg"], [17, 19, "gGg"], [18, 19, "LLL"]], 
		[[15, 19, "LLL"], [16, 19, "gGg"], [17, 19, "gWg"], [18, 19, "LLL"]], 
	]
	var frames: Array = []
	for i in 4:
		frames.append(tails[i] + body + arm + lamps[i % 2])
	frames_to(t, "v3_lantern_ghost", 24, 25, frames)
	t.sprite_palettes["v3_lantern_ghost"] = {
		"1": Color(0.9, 0.96, 0.96), "2": Color(0.74, 0.86, 0.88), "3": Color(0.56, 0.7, 0.74), "4": Color(0.39, 0.52, 0.58), 
		"5": Color(0.25, 0.34, 0.4), "K": Color(0.05, 0.08, 0.1), "d": Color(0.06, 0.1, 0.12), 
		"L": Color(0.3, 0.28, 0.26), "g": Color(1.0, 0.75, 0.3), "G": Color(1.0, 0.88, 0.5), "W": Color(1.0, 0.98, 0.8), 
	}





static func _sexton(t: GameTheme) -> void :
	var robe: Array = []
	for y in range(13, 57):
		var f: = float(y - 13) / 43.0
		var l: int = roundi(lerpf(16, 8, f * f)) if y >= 16 else [21, 18, 17][y - 13]
		var r: int = roundi(lerpf(30, 36, f)) if y >= 16 else [28, 29, 30][y - 13]
		robe.append(robe_row(y, l, r, [roundi(lerpf(20, 14, f)), roundi(lerpf(25, 23, f)), roundi(lerpf(29, 31, f))]))
	robe += [[57, 8, "5.55.555.55..55.555.5.555..5"], [30, 16, "uuuuuuuuuuuuuu"], [31, 16, "M"], [32, 15, "MLM"], [33, 16, "M"], [34, 17, "L"]]
	var head: = [
		[3, 24, "ssss"], [4, 23, "ssssss"], [5, 22, "sssssssS"], [6, 22, "ssSdeSsSs"], [7, 22, "sssssSsss"], [8, 23, "sSssssS"], 
		[9, 23, "SSRRSS"], [10, 24, "SSSS"], [11, 25, "SS"], [12, 21, "cccccccc"], [13, 22, "cccccc"], 
	]
	var arm: = seg(Vector2i(27, 16), Vector2i(35, 13), "1234") + [[12, 35, "ss"], [13, 35, "sS"]]
	var bell: = [
		[14, 36, "ww"], [15, 35, "yyyy"], [16, 34, "yyyyyY"], [17, 34, "yyyyyY"], [18, 33, "yyoyyyYY"], [19, 33, "yyyyyYYY"], 
		[20, 32, "yyyyyyYYYY"], [21, 32, "YYYYYYYYYY"], [22, 36, "L"], 
	]
	var drips: = [[[23, 36, "g"], [25, 37, "g"]], [[24, 36, "g"], [27, 36, "g"]], [[23, 37, "g"], [26, 36, "g"]], [[25, 36, "g"], [28, 37, "g"]]]
	var feet: = [[[58, 14, "kkk"]], [], [[58, 25, "kkk"]], []]
	var frames: Array = []
	for i in 4:
		var sw: int = [1, 0, -1, 0][i]
		frames.append(swung(robe, 40, 57, sw) + feet[i] + head + arm + shifted(bell + drips[i], 0, [0, 1, 0, -1][i]))
	frames_to(t, "v3_sexton", 46, 59, frames)
	t.sprite_palettes["v3_sexton"] = {
		"1": Color(0.34, 0.32, 0.36), "2": Color(0.24, 0.22, 0.26), "3": Color(0.16, 0.15, 0.18), "4": Color(0.11, 0.1, 0.13), 
		"5": Color(0.07, 0.06, 0.09), "K": Color(0.02, 0.02, 0.03), "c": Color(0.85, 0.83, 0.78), 
		"s": Color(0.7, 0.68, 0.64), "S": Color(0.5, 0.48, 0.46), "d": Color(0.1, 0.08, 0.08), "e": Color(0.75, 1.0, 0.4), "R": Color(0.45, 0.3, 0.32), 
		"u": Color(0.4, 0.3, 0.22), "M": Color(0.62, 0.6, 0.55), "L": Color(0.36, 0.34, 0.32), "w": Color(0.45, 0.32, 0.22), 
		"y": Color(0.72, 0.52, 0.24), "Y": Color(0.48, 0.32, 0.14), "o": Color(0.95, 0.78, 0.45), "g": Color(0.55, 1.0, 0.25), 
		"k": Color(0.1, 0.09, 0.09), 
	}







static func _eels(t: GameTheme) -> void :
	for kind: String in ["styx_eel", "leviathan_spawn"]:
		var spawn: = kind == "leviathan_spawn"
		var frames: Array = []
		for i in 4:
			var spans: Array = []
			for x in 27:
				var f: = float(x) / 26.0
				var amp: = 2.4 * (1.0 - f * 0.8)
				var cy: = 6 + roundi(amp * sin(x * 0.42 - i * PI / 2.0))
				var half: = roundi(lerpf(0.6, 3.2, f))
				var col: = ""
				for k in range( - half, half + 1):
					col = "2" if k == - half else ("b" if k == half else ("4" if k > 0 else ("1" if k == - half + 1 and x % 3 == 0 else "3")))
					spans.append([cy + k, x, col])
				if x % 4 == 2 and half >= 1:
					spans.append([cy, x, "g"])
				if x >= 5 and x <= 24:
					spans.append([cy - half - 1, x, "h" if spawn and x % 4 == 0 else "n"])
					if spawn and x % 4 == 0:
						spans.append([cy - half - 2, x, "h"])
			spans += [
				[2, 26, "1222"], [3, 25, "1222223"], [4, 25, "222e22333"], [5, 25, "333333333"], [6, 26, "EEEEEEE"], 
				[7, 26, "EEEEEf"], [6, 32, "f"], [8, 26, "4f444"], [9, 26, "4444"], 
			]
			frames.append(shifted(spans, 1, 0))
		frames_to(t, "v3_" + kind, 34, 14, frames)
	t.sprite_palettes["v3_styx_eel"] = {
		"1": Color(0.42, 0.56, 0.56), "2": Color(0.3, 0.42, 0.43), "3": Color(0.21, 0.3, 0.32), "4": Color(0.14, 0.2, 0.22), 
		"K": Color(0.03, 0.05, 0.06), "b": Color(0.52, 0.56, 0.48), "g": Color(0.5, 1.0, 0.9), "n": Color(0.3, 0.5, 0.5), 
		"e": Color(0.85, 1.0, 0.95), "E": Color(0.12, 0.03, 0.05), "f": Color(0.9, 0.92, 0.85), 
	}
	t.sprite_palettes["v3_leviathan_spawn"] = {
		"1": Color(0.56, 0.3, 0.3), "2": Color(0.42, 0.18, 0.2), "3": Color(0.3, 0.11, 0.14), "4": Color(0.2, 0.07, 0.1), 
		"K": Color(0.05, 0.01, 0.03), "b": Color(0.6, 0.45, 0.38), "g": Color(1.0, 0.55, 0.25), "n": Color(0.45, 0.2, 0.22), 
		"h": Color(0.85, 0.8, 0.7), "e": Color(1.0, 0.8, 0.35), "E": Color(0.12, 0.02, 0.03), "f": Color(0.92, 0.88, 0.78), 
	}



static func _leech(t: GameTheme) -> void :
	var humped: = blob(10, 6, 8, 4, "2233445") + [[3, 6, "o"], [3, 10, "oo"], [4, 14, "o"], [7, 5, "o"], [6, 15, "o"]]
	var stretched: = blob(10, 7, 10, 2, "2233445") + [[5, 4, "oo"], [5, 9, "ooo"], [5, 15, "oo"], [8, 7, "o"]]
	for x in [5, 8, 11, 14]:
		humped += seg(Vector2i(x, 3), Vector2i(x, 9), "4")
	for x in [4, 7, 10, 13, 16]:
		stretched += seg(Vector2i(x, 6), Vector2i(x, 8), "4")
	humped += [[5, 18, "EE"], [6, 18, "Ef"], [7, 18, "fE"], [8, 2, "55"], [9, 2, "5"]]
	stretched += [[6, 20, "EE"], [7, 20, "fE"], [8, 20, "Ef"], [7, 0, "5"], [8, 0, "55"]]
	frames_to(t, "v3_leech", 22, 11, [shifted(humped, 1), stretched])
	t.sprite_palettes["v3_leech"] = {
		"2": Color(0.5, 0.28, 0.24), "3": Color(0.38, 0.19, 0.17), "4": Color(0.26, 0.12, 0.12), "5": Color(0.16, 0.07, 0.08), 
		"K": Color(0.05, 0.02, 0.02), "o": Color(0.8, 0.48, 0.2), "E": Color(0.12, 0.02, 0.03), "f": Color(0.9, 0.82, 0.7), 
	}



static func _bone_crab(t: GameTheme) -> void :
	var shell: = blob(12, 6, 8, 5, "1122334") + [
		[4, 15, "dd"], [5, 14, "ddd"], [6, 15, "dd"], [3, 16, "e"], [2, 17, "e"], [3, 17, "r"], 
		[8, 18, "d"], [10, 7, "fdfdfdfdf"], [3, 9, "4"], [4, 10, "4"], [5, 10, "44"], 
	]
	var claw: = seg(Vector2i(18, 11), Vector2i(22, 12), "rR") + [[9, 22, "rr"], [10, 21, "rrrR"], [11, 21, "rRRRr"], [12, 23, "..r"], [13, 22, "rrrR"]]
	var roots: = [7, 10, 13, 16]
	var frames: Array = []
	for i in 4:
		var spans: Array = []
		for k in 4:
			var dx: = 2 if (k + i) % 2 == 0 else -2
			spans += seg(Vector2i(roots[k] - 1, 10), Vector2i(roots[k] - 3 + dx / 2, 13), "R") + seg(Vector2i(roots[k] - 3 + dx / 2, 13), Vector2i(roots[k] - 4 + dx, 17), "R")
		spans += shell
		for k in 4:
			var dx: = -2 if (k + i) % 2 == 0 else 2
			spans += seg(Vector2i(roots[k], 11), Vector2i(roots[k] - 1 + dx / 2, 14), "r") + seg(Vector2i(roots[k] - 1 + dx / 2, 14), Vector2i(roots[k] - 2 + dx, 17), "r")
		frames.append(spans + shifted(claw, [0, 1, 0, -1][i]))
	frames_to(t, "v3_styx_crab", 26, 19, frames)
	t.sprite_palettes["v3_styx_crab"] = {
		"1": Color(0.92, 0.88, 0.78), "2": Color(0.8, 0.75, 0.65), "3": Color(0.63, 0.57, 0.5), "4": Color(0.45, 0.4, 0.37), 
		"K": Color(0.06, 0.04, 0.04), "d": Color(0.08, 0.04, 0.04), "e": Color(0.6, 1.0, 1.0), "f": Color(0.86, 0.82, 0.72), 
		"r": Color(0.72, 0.3, 0.18), "R": Color(0.46, 0.17, 0.12), 
	}




static func _halo_jelly(t: GameTheme) -> void :
	var frames: Array = []
	for i in 4:
		var squeeze: int = [0, 1, 2, 1][i]
		var bell: Array = []
		for sp: Array in blob(11, 10, 9 - squeeze, 7, "11223345"):
			if int(sp[0]) <= 10:
				bell.append(sp)
		bell += [[10, 2 + squeeze, "y".repeat(19 - squeeze * 2)], [7, 8, "pp"], [8, 7, "pppp"], [7, 13, "p"], [8, 12, "pp"], 
			[0, 7, "Yyyyyyyy"], [1, 6, "y"], [1, 15, "y"]]
		var spans: Array = []
		for k in 5:
			var x0: int = [5, 8, 11, 14, 17][k]
			var wob: = roundi(1.5 * sin(i * PI / 2.0 + k))
			spans += seg(Vector2i(x0 + squeeze / 2 * (1 if x0 < 11 else -1), 11), Vector2i(x0 + wob, 16), "3") + seg(Vector2i(x0 + wob, 16), Vector2i(x0 - wob, 22 - k % 2), "4")
		frames.append(shifted(spans + bell, 1))
	frames_to(t, "v3_halo_jelly", 22, 24, frames)
	t.sprite_palettes["v3_halo_jelly"] = {
		"1": Color(0.93, 0.84, 0.98), "2": Color(0.8, 0.64, 0.9), "3": Color(0.64, 0.47, 0.78), "4": Color(0.48, 0.32, 0.63), 
		"5": Color(0.34, 0.21, 0.47), "K": Color(0.1, 0.05, 0.15), "p": Color(0.45, 0.28, 0.58), 
		"y": Color(1.0, 0.85, 0.45), "Y": Color(1.0, 0.97, 0.8), 
	}




static func _lure_fiend(t: GameTheme) -> void :
	var body: = blob(16, 12, 11, 7, "1223344") + [
		[13, 23, "44444444"], [14, 23, "EEfEEEfE"], [15, 23, "EEfEEEEE"], [16, 23, "EEEEfEEE"], [17, 23, "5555f555"], [18, 24, "55555"], 
		[9, 22, "e"], [10, 21, "dd"], [11, 26, "4"], 
		[9, 9, "s"], [12, 12, "s"], [10, 15, "s"], [14, 10, "s"], [8, 17, "s"], 
	]
	var tails: = [
		[[7, 2, "nn"], [8, 1, "nnn"], [9, 1, "nn"], [12, 1, "nn"], [13, 0, "nnn"], [14, 1, "nn"], [10, 3, "n"], [11, 3, "n"]], 
		[[8, 2, "nn"], [9, 1, "nnn"], [10, 2, "nn"], [12, 2, "nn"], [13, 1, "nnn"], [14, 2, "n"], [11, 3, "n"]], 
	]
	var fins: = [
		[[15, 14, "nnn"], [16, 13, "nnnn"], [17, 12, "nnn"]], 
		[[16, 14, "nnnn"], [17, 13, "nnnn"]], 
		[[17, 14, "nn"], [18, 13, "nnnn"], [19, 12, "nnn"]], 
		[[16, 14, "nnnn"], [17, 13, "nnnn"]], 
	]
	var frames: Array = []
	for i in 4:
		var sway: int = [0, 1, 0, -1][i]
		var lure: = seg(Vector2i(20, 6), Vector2i(24, 1), "4") + seg(Vector2i(24, 1), Vector2i(28 + sway, 2), "4") + [[3, 27 + sway, "OOO"], [4, 27 + sway, "OoO"], [5, 28 + sway, "O"]]
		frames.append(tails[i % 2] + body + fins[i] + lure)
	frames_to(t, "v3_lure_fiend", 32, 20, frames)
	t.sprite_palettes["v3_lure_fiend"] = {
		"1": Color(0.56, 0.42, 0.5), "2": Color(0.43, 0.3, 0.39), "3": Color(0.32, 0.21, 0.3), "4": Color(0.22, 0.13, 0.21), 
		"5": Color(0.13, 0.07, 0.13), "K": Color(0.04, 0.02, 0.04), "s": Color(0.7, 0.62, 0.66), "n": Color(0.48, 0.34, 0.45), 
		"e": Color(0.85, 0.95, 0.9), "d": Color(0.1, 0.05, 0.08), "E": Color(0.08, 0.02, 0.05), "f": Color(0.9, 0.9, 0.84), 
		"O": Color(0.7, 1.0, 0.8), "o": Color(1.0, 1.0, 0.92), 
	}




static func _drowned_sinner(t: GameTheme) -> void :
	var body: = [
		[2, 10, "hhhh"], [3, 9, "hhhhhh"], [4, 9, "hhh1ss"], [5, 9, "hhs2es"], [6, 9, "hh2222"], [7, 10, "h3dd3"], [8, 10, "h333"], 
		[8, 9, "h"], [9, 9, "h"], [10, 9, "h"], 
		[9, 10, "cccccc"], [10, 7, "cccccccc"], [11, 7, "ccccccCC"], [12, 7, "cc3cccCC"], [13, 7, "ccccccCC"], [14, 8, "cccccCC"], 
		[15, 8, "cc3c3CC"], [16, 8, "c.CC.C"], [17, 8, "uuuuuuU"], [18, 8, "uuuuuUU"], [19, 8, "uuuuUU"], 
		[9, 11, "v"], [10, 11, "v"], [11, 12, "v"], [12, 12, "v"], [13, 13, "v"], [10, 8, "vv"], [11, 8, "v"], 
	]
	var far_arm: = seg(Vector2i(12, 10), Vector2i(18, 10), "4") + seg(Vector2i(18, 10), Vector2i(21, 10), "4") + [[9, 22, "4"]]
	var arm: = seg(Vector2i(13, 11), Vector2i(19, 12), "23") + seg(Vector2i(19, 12), Vector2i(22, 12), "2") + [[11, 23, "1"], [13, 23, "1"]]
	var drips: = [[[14, 21, "w"]], [[16, 21, "w"]], [[15, 22, "w"], [18, 21, "w"]], [[17, 22, "w"]]]
	var poses: = walk_poses(Vector2i(11, 19), 12)
	var frames: Array = []
	for i in 4:
		frames.append(far_arm + leg(joints_dx(poses[(i + 2) % 4], -2), "UU", "4", "44") + body + leg(poses[i], "uuU", "23", "223")
			+ shifted(arm, [0, 1, 0, 1][i]) + drips[i])
	frames_to(t, "v3_drowned_sinner", 25, 33, frames)
	t.sprite_palettes["v3_drowned_sinner"] = {
		"1": Color(0.76, 0.84, 0.84), "2": Color(0.6, 0.7, 0.72), "3": Color(0.45, 0.54, 0.58), "4": Color(0.32, 0.38, 0.44), 
		"5": Color(0.2, 0.24, 0.3), "K": Color(0.03, 0.05, 0.07), "s": Color(0.68, 0.77, 0.78), "e": Color(0.9, 1.0, 0.92), 
		"d": Color(0.06, 0.06, 0.08), "h": Color(0.08, 0.11, 0.12), "c": Color(0.38, 0.42, 0.38), "C": Color(0.26, 0.29, 0.27), 
		"u": Color(0.3, 0.3, 0.34), "U": Color(0.2, 0.2, 0.24), "v": Color(0.25, 0.42, 0.25), "w": Color(0.55, 0.85, 0.95), 
	}




static func _drowned_monk(t: GameTheme) -> void :
	var robe: Array = []
	for y in range(11, 37):
		var f: = float(y - 11) / 25.0
		robe.append(robe_row(y, roundi(lerpf(12, 7, f)), roundi(lerpf(21, 24, f)), [roundi(lerpf(15, 11, f)), roundi(lerpf(19, 18, f))]))
	robe += [[37, 7, "5.55.555.555.5.55"], [22, 9, "yyyyyyyyyyyyyy"], [9, 12, "2223"], [10, 11, "2223333"]]
	var head: = [
		[3, 15, "ssss"], [4, 14, "ssssss"], [5, 14, "sssSesS"], [6, 14, "ssSSsss"], [7, 15, "SdSSs"], [8, 15, "SSSt"], [9, 16, "tt"], 
	]
	var arm: = seg(Vector2i(19, 13), Vector2i(22, 19), "2334") + [[19, 21, "ss"], [20, 21, "sS"]]
	var chain_up: = seg(Vector2i(22, 21), Vector2i(21, 35), "M") + [[23, 22, "L"], [26, 22, "L"], [29, 21, "L"], [32, 21, "L"]]
	var anchor: = [
		[31, 3, "M"], [32, 3, "M"], [33, 3, "M"], [34, 3, "M"], [35, 3, "M"], [32, 1, "LML"], [36, 0, "MLLLM"], [35, 0, "M"], [35, 6, "M"], 
		[30, 2, "L.L"], [29, 3, "L"], 
	]
	var feet: = [[[38, 9, "SS"], [38, 20, "sss"]], [[38, 13, "SS"], [38, 16, "ss"]], [[38, 18, "SS"], [38, 11, "sss"]], [[38, 14, "SS"], [38, 17, "ss"]]]
	var frames: Array = []
	for i in 4:
		var sw: int = [1, 0, -1, 0][i]
		var drag: int = [0, 1, 2, 1][i]
		var ground: = seg(Vector2i(21, 36), Vector2i(6 + drag, 36), "M") + [[36, 9 + drag, "L"], [36, 13 + drag, "L"], [36, 17 + drag, "L"]]
		frames.append(shifted(anchor, 0, drag) + ground + swung(robe, 26, 37, sw) + feet[i] + head + arm + chain_up)
	frames_to(t, "v3_drowned_monk", 30, 39, frames)
	t.sprite_palettes["v3_drowned_monk"] = {
		"1": Color(0.48, 0.55, 0.66), "2": Color(0.36, 0.42, 0.54), "3": Color(0.26, 0.31, 0.42), "4": Color(0.18, 0.21, 0.3), 
		"5": Color(0.11, 0.13, 0.2), "K": Color(0.03, 0.04, 0.07), "s": Color(0.72, 0.8, 0.8), "S": Color(0.54, 0.62, 0.65), 
		"t": Color(0.38, 0.44, 0.5), "e": Color(0.5, 1.0, 0.85), "d": Color(0.07, 0.07, 0.1), "y": Color(0.5, 0.44, 0.32), 
		"M": Color(0.5, 0.42, 0.36), "L": Color(0.32, 0.26, 0.22), 
	}




static func _bloated_drowned(t: GameTheme) -> void :
	var body: = blob(16, 17, 9, 7, "ssSSttu") + blob(16, 28, 12, 10, "ssSSttu") + [
		[1, 17, "ssss"], [2, 16, "ssssss"], [3, 15, "sssssss"], [4, 15, "sssSesS"], [5, 15, "ssSSSSs"], [6, 16, "sSddSS"], [7, 16, "SSddS"], [8, 17, "SSSS"], 
		[1, 16, "h"], [2, 14, "hh"], [3, 14, "h"], [4, 14, "h"], [5, 14, "h"], [6, 14, "hh"], [7, 15, "h"], 
		[9, 15, "MMMMM"], [10, 20, "L"], [11, 21, "M"], [12, 21, "L"], 
		[14, 9, "xx"], [15, 8, "xxx"], [20, 22, "xx"], [21, 23, "x"], [28, 12, "xx"], [29, 11, "x"], [31, 20, "xx"], 
		[16, 19, "pp"], [24, 8, "pp"], [12, 13, "v"], [13, 13, "v"], [14, 12, "v"], [15, 12, "v"], [16, 13, "v"], 
		[11, 23, "v"], [12, 24, "v"], [13, 24, "v"], [14, 25, "v"], 
	]
	var arm: = seg(Vector2i(23, 13), Vector2i(28, 24), "ssSt") + seg(Vector2i(28, 24), Vector2i(29, 32), "sSt") + [[33, 27, "SSSt"], [34, 28, "S.S"]]
	var far_arm: = seg(Vector2i(9, 13), Vector2i(4, 24), "ttu") + seg(Vector2i(4, 24), Vector2i(4, 32), "tu") + [[33, 3, "tuu"]]
	var frames: Array = []
	for i in 4:
		var near: Array = walk_poses(Vector2i(19, 37), 7)[i]
		var far: Array = walk_poses(Vector2i(13, 37), 7)[(i + 2) % 4]
		var sw: int = [-1, 0, 1, 0][i]
		frames.append(swung(far_arm, 14, 34, - sw) + leg(far, "tuu", "tu", "uuu") + shifted(body, [1, 0, 1, 0][i])
			+ leg(near, "sSSt", "SSt", "SSSS") + swung(arm, 14, 34, sw))
	frames_to(t, "v3_bloated_drowned", 33, 46, frames)
	t.sprite_palettes["v3_bloated_drowned"] = {
		"s": Color(0.66, 0.74, 0.68), "S": Color(0.5, 0.58, 0.54), "t": Color(0.36, 0.43, 0.41), "u": Color(0.24, 0.29, 0.29), 
		"K": Color(0.03, 0.05, 0.05), "e": Color(0.92, 0.95, 0.9), "d": Color(0.08, 0.08, 0.08), "h": Color(0.08, 0.1, 0.1), 
		"M": Color(0.48, 0.4, 0.34), "L": Color(0.3, 0.24, 0.2), "x": Color(0.82, 0.8, 0.72), "p": Color(0.42, 0.36, 0.48), 
		"v": Color(0.28, 0.46, 0.26), 
	}





static func _sirens(t: GameTheme) -> void :
	var top: = [
		[2, 12, "ssss"], [3, 12, "sssss"], [4, 12, "sSsess"], [5, 13, "ssSs"], [6, 13, "sdds"], [7, 13, "sSs"], [8, 12, "SS"], 
		[9, 10, "ssssss"], [10, 9, "sssssSS"], [11, 9, "ssSsSSS"], [12, 10, "sSSSSS"], [13, 10, "SSSStt"], [14, 11, "Sttt"], 
	]
	var hairs: = [
		[[2, 8, "hhhh"], [3, 5, "hhhhhhh"], [4, 3, "hhhhhhhhh"], [5, 2, "hhhhhh"], [6, 1, "hhhh"], [7, 1, "hhh"], [8, 2, "hh"], [1, 11, "hhhh"], [2, 11, "h"]], 
		[[2, 8, "hhhh"], [3, 5, "hhhhhhh"], [4, 2, "hhhhhhhhhh"], [5, 1, "hhhhhhh"], [6, 0, "hhhh"], [7, 0, "hh"], [1, 11, "hhhh"], [2, 11, "h"]], 
	]
	var arms: = seg(Vector2i(13, 10), Vector2i(18, 9), "t") + seg(Vector2i(14, 11), Vector2i(19, 11), "sS") + seg(Vector2i(19, 11), Vector2i(22, 9), "s") + [[8, 23, "f"], [9, 23, "f"], [8, 19, "f"]]
	var tail: = [
		[15, 10, "gggGG"], [16, 9, "ggGGGq"], [17, 8, "gGgGqq"], [18, 8, "gGGqq"], [19, 7, "gGgq"], [20, 6, "gGqq"], [21, 5, "gGq"], [22, 4, "gq"], 
		[23, 1, "nnnn"], [24, 0, "nnnnn"], [25, 1, "n.nn"], 
	]
	var crown: = [[0, 12, "c.c.c"], [1, 12, "ccccc"], [9, 11, "w.w.w"]]
	for kind: String in ["siren", "siren_queen"]:
		var frames: Array = []
		for i in 4:
			var sway: int = [0, 1, 0, -1][i]
			frames.append(hairs[i % 2] + swung(tail, 17, 25, sway * 2) + top + arms + (crown if kind == "siren_queen" else []))
		frames_to(t, "v3_" + kind, 25, 26, frames)
	var siren: = {
		"s": Color(0.66, 0.74, 0.7), "S": Color(0.5, 0.58, 0.56), "t": Color(0.36, 0.42, 0.42), "K": Color(0.03, 0.05, 0.06), 
		"h": Color(0.1, 0.14, 0.15), "e": Color(0.75, 1.0, 0.95), "d": Color(0.05, 0.04, 0.05), "f": Color(0.86, 0.88, 0.82), 
		"g": Color(0.32, 0.56, 0.5), "G": Color(0.21, 0.41, 0.39), "q": Color(0.12, 0.26, 0.27), "n": Color(0.45, 0.7, 0.64), 
	}
	t.sprite_palettes["v3_siren"] = siren
	t.sprite_palettes["v3_siren_queen"] = siren.merged({
		"h": Color(0.3, 0.06, 0.1), "g": Color(0.42, 0.36, 0.6), "G": Color(0.3, 0.24, 0.46), "q": Color(0.18, 0.13, 0.3), 
		"n": Color(0.62, 0.52, 0.8), "c": Color(0.95, 0.5, 0.4), "w": Color(0.95, 0.93, 0.88), 
	}, true)



static func tube(points: Array, radius: Array) -> Array:
	var out: Array = []
	for i in points.size():
		var c: Vector2i = points[i]
		var r: int = radius[i]
		for dy in range( - r, r + 1):
			var hw: = roundi(sqrt(maxf(0.0, r * r - dy * dy)))
			var ch: = "2" if dy <= - r + 1 else ("b" if dy == r else ("4" if dy > 0 else "3"))
			out.append([c.y + dy, c.x - hw, ch.repeat(hw * 2 + 1)])
	return out





static func _bellshell(t: GameTheme) -> void :
	var bell: Array = [[1, 12, "YY"], [2, 11, "Y..Y"], [3, 11, "YYYY"]]
	for y in range(4, 23):
		var f: = float(y - 4) / 18.0
		var c: = 13 + roundi(f * 4.0)
		var hw: = roundi(5.0 + 3.0 * f + 4.5 * pow(f, 4.0))
		bell.append(robe_row(y, c - hw, c + hw, [c - hw / 2, c + hw / 3]))
	bell += [
		[22, 4, "11111111111111111111111111"], [23, 5, "4444dddddddddddddddd4444"], [24, 8, "ddddddddddddddddd"], 
		[6, 12, "vv"], [7, 11, "vvV"], [12, 9, "vVv"], [13, 9, "vV"], [16, 20, "vv"], [17, 19, "vVv"], [19, 9, "vv"], [20, 8, "V"], 
		[9, 16, "xx"], [10, 15, "x"], [15, 13, "xx"], [18, 22, "x"], [19, 23, "xx"], [21, 12, "x"], 
	]
	var crab: = [
		[21, 24, "r"], [20, 24, "e"], [21, 27, "r"], [20, 27, "e"], [24, 22, "rrrrr"], [25, 22, "RRRRR"], 
	] + seg(Vector2i(24, 25), Vector2i(29, 24), "rR") + [[22, 29, "rrr"], [23, 28, "rRRrr"], [24, 30, "..r"], [25, 29, "rrR"]]
	var roots: = [9, 13, 17, 21]
	var frames: Array = []
	for i in 4:
		var legs: Array = []
		for k in 4:
			var dx: = 2 if (k + i) % 2 == 0 else -2
			legs += seg(Vector2i(roots[k] - 1, 24), Vector2i(roots[k] - 3 + dx / 2, 28), "R") + seg(Vector2i(roots[k] - 3 + dx / 2, 28), Vector2i(roots[k] - 4 + dx, 33), "R")
		for k in 4:
			var dx: = -2 if (k + i) % 2 == 0 else 2
			legs += seg(Vector2i(roots[k] + 1, 25), Vector2i(roots[k] + dx / 2, 29), "r") + seg(Vector2i(roots[k] + dx / 2, 29), Vector2i(roots[k] - 1 + dx, 33), "r")
		frames.append(shifted(bell, [0, 1, 0, 1][i], [0, 0, 1, 0][i]) + legs + shifted(crab, [0, 1, 0, 1][i]))
	frames_to(t, "v3_bellshell", 33, 35, frames)
	t.sprite_palettes["v3_bellshell"] = {
		"1": Color(0.84, 0.68, 0.4), "2": Color(0.68, 0.52, 0.3), "3": Color(0.52, 0.38, 0.21), "4": Color(0.37, 0.26, 0.15), 
		"5": Color(0.23, 0.15, 0.09), "K": Color(0.06, 0.04, 0.02), "Y": Color(0.6, 0.45, 0.25), 
		"v": Color(0.4, 0.64, 0.54), "V": Color(0.27, 0.46, 0.39), "x": Color(0.86, 0.83, 0.75), "d": Color(0.07, 0.03, 0.02), 
		"r": Color(0.76, 0.33, 0.2), "R": Color(0.48, 0.18, 0.12), "e": Color(0.6, 1.0, 1.0), 
	}




static func _leviathan(t: GameTheme) -> void :
	var head: = [
		[2, 39, "h"], [3, 38, "hh"], [4, 37, "hh"], [3, 42, "h"], [4, 41, "h"], 
		[5, 38, "12222222"], [6, 37, "12222222223"], [7, 37, "2222e522333"], [8, 37, "3333333333322"], 
		[9, 38, "4444f444f4"], 
	]
	var jaws: = [
		[[10, 39, "EEEEEEEE"], [11, 39, "EEEfEEf"], [12, 38, "4444444444"], [13, 37, "55555555"]], 
		[[10, 39, "EEEEEE"], [11, 38, "444f44f444"], [12, 37, "55555555"]], 
	]
	var frames: Array = []
	for i in 4:
		var pts: Array = []
		var rad: Array = []
		for x in range(2, 30, 1):
			var f: = float(x - 2) / 27.0
			pts.append(Vector2i(x, 26 + roundi(3.0 * sin(x * 0.33 - i * PI / 2.0))))
			rad.append(roundi(lerpf(1.0, 4.0, f)))
		for k in 10:
			var f: = float(k) / 9.0
			pts.append(Vector2i(roundi(lerpf(30, 38, f)), roundi(lerpf(25, 11, f)) + (1 if i % 2 == 1 else 0)))
			rad.append(roundi(lerpf(4.0, 3.0, f)))
		var spans: = tube(pts, rad)
		for k in range(4, pts.size() - 2, 3):
			var pt: Vector2i = pts[k]
			spans.append([pt.y - int(rad[k]) - 1, pt.x, "h"])
			if int(rad[k]) >= 3:
				spans.append([pt.y - int(rad[k]) - 2, pt.x, "h"])
		spans += [[24, 12, "x"], [25, 13, "xx"], [27, 22, "x"], [26, 23, "x"], [20, 33, "xx"], [17, 35, "x"]]
		frames.append(spans + shifted(head + jaws[0 if i < 2 else 1], 1 if i % 2 == 1 else 0))
	frames_to(t, "v3_leviathan", 50, 32, frames)
	t.sprite_palettes["v3_leviathan"] = {
		"1": Color(0.46, 0.6, 0.6), "2": Color(0.32, 0.46, 0.48), "3": Color(0.22, 0.34, 0.37), "4": Color(0.15, 0.23, 0.27), 
		"5": Color(0.09, 0.14, 0.17), "K": Color(0.02, 0.04, 0.05), "b": Color(0.58, 0.6, 0.5), 
		"h": Color(0.85, 0.82, 0.72), "x": Color(0.8, 0.78, 0.7), "e": Color(1.0, 0.6, 0.2), 
		"E": Color(0.3, 0.05, 0.06), "f": Color(0.92, 0.9, 0.84), 
	}





static func _ferryman(t: GameTheme) -> void :
	var robe: Array = []
	for y in range(10, 46):
		var f: = float(y - 10) / 35.0
		robe.append(robe_row(y, roundi(lerpf(16, 8, f * f)), roundi(lerpf(30, 35, f)), [roundi(lerpf(20, 13, f)), roundi(lerpf(26, 23, f)), roundi(lerpf(29, 31, f))]))
	robe += [[46, 8, "5.55.555..55.555.5.555..5.5"]]
	var hood: = [
		[2, 19, "2222"], [3, 17, "22222222"], [4, 16, "1222222233"], [5, 16, "122222dddddd"], [6, 16, "22222ddhhhhd"], 
		[7, 16, "22223ddyhhhd"], [8, 16, "3333ddhhhhhh"], [9, 17, "333dhdhdhh"], [10, 18, "444dhhh"], 
	]
	var pole: = seg(Vector2i(8, 46), Vector2i(38, 1), "wv")
	var arms: = seg(Vector2i(22, 14), Vector2i(26, 21), "345") + [[21, 26, "hh"], [22, 26, "hh"]]\
	+ seg(Vector2i(27, 13), Vector2i(30, 17), "2334") + [[16, 31, "hh"], [17, 31, "hh"]]
	var feet: = [[[47, 12, "h.h"]], [], [[47, 24, "h.h"]], []]
	var frames: Array = []
	for i in 4:
		var sw: int = [1, 0, -1, 0][i]
		var lamp: = [[2, 37 + sw, "L"], [3, 37 + sw, "L"], [4, 36 + sw, "LLL"], [5, 36 + sw, "gGg"], [6, 36 + sw, "gWg"], [7, 36 + sw, "LLL"]]
		frames.append(swung(robe, 30, 46, sw) + feet[i] + pole + hood + arms + lamp)
	frames_to(t, "v3_ferryman", 44, 48, frames)
	t.sprite_palettes["v3_ferryman"] = {
		"1": Color(0.36, 0.34, 0.38), "2": Color(0.26, 0.24, 0.28), "3": Color(0.18, 0.16, 0.2), "4": Color(0.12, 0.11, 0.14), 
		"5": Color(0.07, 0.06, 0.09), "K": Color(0.02, 0.02, 0.03), "d": Color(0.02, 0.01, 0.02), 
		"h": Color(0.86, 0.82, 0.72), "y": Color(1.0, 0.8, 0.3), "w": Color(0.42, 0.32, 0.22), "v": Color(0.27, 0.2, 0.14), 
		"L": Color(0.3, 0.28, 0.26), "g": Color(1.0, 0.75, 0.3), "G": Color(1.0, 0.88, 0.5), "W": Color(1.0, 0.98, 0.8), 
	}







static func _eyes(t: GameTheme) -> void :
	var wings: = wing_frames(bat_wing(), 13)
	var ball: = blob(21, 15, 6, 6, "WwwwvvV") + [
		[13, 24, "iii"], [14, 23, "iiIii"], [15, 23, "iIddI"], [16, 23, "iiIii"], [17, 24, "iii"], [13, 23, "W"], 
		[12, 16, "r"], [13, 17, "rr"], [17, 16, "rr"], [18, 18, "r"], [11, 20, "r"], [19, 21, "r"], [10, 18, "r"], 
	]
	var buds: = [[11, 17, "wd"], [18, 15, "wd"], [20, 22, "dw"], [12, 26, "R"], [14, 16, "rr"], [16, 18, "R"]]
	var nerves: = [
		seg(Vector2i(15, 16), Vector2i(8, 18), "rR") + seg(Vector2i(8, 18), Vector2i(2, 16), "R") + [[15, 1, "R"], [17, 1, "R"]], 
		seg(Vector2i(15, 16), Vector2i(8, 17), "rR") + seg(Vector2i(8, 17), Vector2i(2, 19), "R") + [[20, 1, "R"]], 
		seg(Vector2i(15, 16), Vector2i(8, 16), "rR") + seg(Vector2i(8, 16), Vector2i(2, 18), "R") + [[19, 1, "R"], [17, 2, "R"]], 
		seg(Vector2i(15, 16), Vector2i(8, 17), "rR") + seg(Vector2i(8, 17), Vector2i(2, 17), "R") + [[16, 1, "R"]], 
	]
	for kind: String in ["stray_eye", "great_eye"]:
		var frames: Array = []
		for i in 4:
			frames.append(shifted(nerves[i] + ball + (buds if kind == "great_eye" else []), 4) + wings[i])
		frames_to(t, "v3_" + kind, 30, 27, frames)
	var eye: = {
		"W": Color(1.0, 0.97, 0.94), "w": Color(0.9, 0.84, 0.8), "v": Color(0.74, 0.6, 0.6), "V": Color(0.54, 0.4, 0.42), 
		"K": Color(0.06, 0.03, 0.05), "i": Color(0.88, 0.68, 0.16), "I": Color(0.6, 0.4, 0.08), "d": Color(0.04, 0.02, 0.03), 
		"r": Color(0.72, 0.15, 0.18), "R": Color(0.46, 0.08, 0.12), 
		"m": Color(0.32, 0.23, 0.3), "n": Color(0.21, 0.14, 0.21), "b": Color(0.52, 0.42, 0.45), 
	}
	t.sprite_palettes["v3_stray_eye"] = eye
	t.sprite_palettes["v3_great_eye"] = eye.merged({
		"w": Color(0.86, 0.74, 0.72), "v": Color(0.68, 0.5, 0.52), "i": Color(0.85, 0.2, 0.18), "I": Color(0.55, 0.1, 0.1), 
		"m": Color(0.36, 0.18, 0.22), "n": Color(0.24, 0.1, 0.15), 
	}, true)





static func _serpents(t: GameTheme) -> void :
	for kind: String in ["bone_serpent", "great_serpent"]:
		var bone: = kind == "bone_serpent"
		var frames: Array = []
		for i in 4:
			var spans: Array = []
			for x in 29:
				var f: = float(x) / 28.0
				var cy: = 7 + roundi(2.4 * (1.0 - f * 0.7) * sin(x * 0.4 - i * PI / 2.0))
				if bone:
					if x % 3 == 2:
						spans.append([cy, x, "H"])
					else:
						spans += [[cy - 1, x, "1" if x % 3 == 0 else "2"], [cy, x, "2"], [cy + 1, x, "3"]]
					if x % 6 == 0 and x > 3:
						spans += [[cy - 2, x, "H"], [cy + 2, x, "H"]]
				else:
					var half: = roundi(lerpf(0.6, 2.2, f))
					for k in range( - half, half + 1):
						var ch: = "2" if k == - half else ("b" if k == half else ("4" if k > 0 else "3"))
						if k == 0 and (x + i * 0) % 4 == 0:
							ch = "o"
						spans.append([cy + k, x, ch])
			if bone:
				spans += [[4, 29, "1222"], [5, 28, "122223"], [6, 28, "22de2233"], [7, 28, "333333322"], [8, 29, "dfddd"], [9, 29, "333f33"], [10, 30, "444"]]
			else:
				spans += [[2, 29, "h"], [3, 29, "hh"], [4, 29, "1222"], [5, 28, "1222223"], [6, 28, "22de22333"], [7, 28, "3333333322"], [8, 29, "dfdddf"], [9, 29, "3333f3"], [10, 30, "4444"]]
			frames.append(shifted(spans, 1, 0))
		frames_to(t, "v3_" + kind, 38, 13, frames)
	t.sprite_palettes["v3_bone_serpent"] = {
		"1": Color(0.93, 0.89, 0.79), "2": Color(0.8, 0.75, 0.65), "3": Color(0.6, 0.55, 0.49), "4": Color(0.42, 0.37, 0.35), 
		"H": Color(0.55, 0.5, 0.45), "K": Color(0.06, 0.04, 0.05), "d": Color(0.08, 0.03, 0.04), "e": Color(1.0, 0.3, 0.2), 
		"f": Color(0.92, 0.88, 0.8), 
	}
	t.sprite_palettes["v3_great_serpent"] = {
		"1": Color(0.5, 0.42, 0.58), "2": Color(0.38, 0.3, 0.46), "3": Color(0.27, 0.2, 0.34), "4": Color(0.18, 0.12, 0.23), 
		"b": Color(0.56, 0.48, 0.44), "o": Color(0.55, 0.42, 0.62), "K": Color(0.04, 0.02, 0.05), "d": Color(0.08, 0.02, 0.04), 
		"e": Color(1.0, 0.3, 0.2), "f": Color(0.92, 0.88, 0.8), "h": Color(0.85, 0.8, 0.7), 
	}




static func _crawling_hand(t: GameTheme) -> void :
	var back: = blob(11, 6, 7, 3, "11223344") + [[4, 7, "4"], [4, 10, "4"], [4, 13, "4"], [6, 2, "rR"], [7, 2, "rh"], [5, 3, "R"]]
	var knuckles: = [8, 11, 14, 17]
	var frames: Array = []
	for i in 4:
		var spans: Array = []
		for k in 4:
			var dx: = 2 if (k + i) % 2 == 0 else -2
			var x: int = knuckles[k]
			spans += seg(Vector2i(x, 7), Vector2i(x + 2 + dx / 2, 5), "2") + seg(Vector2i(x + 2 + dx / 2, 5), Vector2i(x + 3 + dx, 12), "3")
			spans.append([12, x + 3 + dx, "f"])
		var tdx: = 2 if i % 2 == 0 else -1
		spans += seg(Vector2i(13, 9), Vector2i(15 + tdx, 11), "3") + [[12, 15 + tdx, "f"]]
		frames.append(shifted(back, 0, 0) + spans)
	frames_to(t, "v3_crawling_hand", 25, 14, frames)
	t.sprite_palettes["v3_crawling_hand"] = {
		"1": Color(0.78, 0.74, 0.8), "2": Color(0.63, 0.58, 0.66), "3": Color(0.48, 0.43, 0.52), "4": Color(0.34, 0.3, 0.38), 
		"K": Color(0.05, 0.04, 0.06), "f": Color(0.1, 0.08, 0.1), "r": Color(0.62, 0.12, 0.15), "R": Color(0.4, 0.06, 0.1), 
		"h": Color(0.88, 0.84, 0.76), 
	}



static func _ophan(t: GameTheme) -> void :
	var c: = Vector2(13.5, 12.5)
	var frames: Array = []
	for i in 4:
		var spans: Array = []
		for a in 72:
			var ang: = TAU * a / 72.0
			for rr: float in [11.0, 10.0]:
				var p: = c + Vector2(cos(ang), sin(ang)) * rr
				spans.append([roundi(p.y), roundi(p.x), "y" if rr > 10.5 and sin(ang) < 0.2 else "Y"])
			var q: = c + Vector2(cos(ang) * 4.0, sin(ang) * 10.5)
			if cos(ang) < 0.0:
				spans.append([roundi(q.y), roundi(q.x), "Y"])
		for k in 6:
			var ang: = TAU * k / 6.0 + i * PI / 12.0
			var p: = c + Vector2(cos(ang), sin(ang)) * 10.5
			spans += [[roundi(p.y) - 1, roundi(p.x) - 1, "YwY"], [roundi(p.y), roundi(p.x) - 1, "wdw"], [roundi(p.y) + 1, roundi(p.x) - 1, "YwY"]]
		for k in 2:
			var ang: = PI * k + PI / 2.0 + i * PI / 6.0
			var q: = c + Vector2(cos(ang) * 4.0, sin(ang) * 10.5)
			spans += [[roundi(q.y), roundi(q.x) - 1, "wdw"]]
		spans += [[11, 12, "gGg"], [12, 12, "GWG"], [13, 12, "gGg"], [10, 13, "g"], [14, 13, "g"]]
		spans += [[0, 6 + i, "F"], [1, 5 + i, "FF"], [24, 18 - i, "FF"], [25, 19 - i, "F"]]
		frames.append(spans)
	frames_to(t, "v3_ophan", 28, 26, frames)
	t.sprite_palettes["v3_ophan"] = {
		"y": Color(0.95, 0.76, 0.35), "Y": Color(0.66, 0.46, 0.18), "K": Color(0.1, 0.05, 0.02), 
		"w": Color(1.0, 0.98, 0.92), "d": Color(0.1, 0.05, 0.1), "g": Color(1.0, 0.55, 0.15), "G": Color(1.0, 0.85, 0.4), 
		"W": Color(1.0, 1.0, 0.85), "F": Color(1.0, 0.6, 0.2), 
	}




static func _faceless(t: GameTheme) -> void :
	var body: = blob(13, 4, 3, 4, "sssSSt") + [
		[9, 12, "wSw"], [10, 10, "qcccccC"], [11, 9, "qcccccCC"], [12, 9, "qccwcCCC"], [13, 9, "qccwcCCC"], 
		[14, 9, "qcccccCC"], [15, 9, "qcccccCC"], [16, 9, "qccccCCC"], [17, 10, "cccccCC"], [18, 10, "cccccC"], [19, 10, "cccccC"], 
	]
	var arm: = seg(Vector2i(15, 11), Vector2i(17, 17), "cC") + seg(Vector2i(17, 17), Vector2i(18, 22), "cC")\
	+ [[23, 18, "ss"], [24, 18, "sS"], [25, 18, "S.S"], [26, 19, "S"]]
	var far_arm: = seg(Vector2i(11, 11), Vector2i(10, 17), "C") + seg(Vector2i(10, 17), Vector2i(10, 22), "C") + [[23, 10, "tt"], [24, 10, "t"], [25, 10, "t"]]
	var poses: = walk_poses(Vector2i(13, 20), 12)
	var frames: Array = []
	for i in 4:
		var sw: int = [-2, 0, 2, 0][i]
		frames.append(swung(far_arm, 11, 25, - sw) + leg(joints_dx(poses[(i + 2) % 4], -2), "CC", "C", "CCC") + body
			+ leg(poses[i], "cC", "cC", "CCCC") + swung(arm, 11, 26, sw))
	frames_to(t, "v3_faceless", 26, 34, frames)
	t.sprite_palettes["v3_faceless"] = {
		"s": Color(0.86, 0.84, 0.8), "S": Color(0.68, 0.66, 0.64), "t": Color(0.5, 0.48, 0.48), "w": Color(0.9, 0.9, 0.88), 
		"q": Color(0.34, 0.33, 0.38), "c": Color(0.22, 0.21, 0.26), "C": Color(0.13, 0.12, 0.16), "K": Color(0.03, 0.03, 0.04), 
	}




static func _faceless_deacon(t: GameTheme) -> void :
	var robe: Array = []
	for y in range(10, 34):
		var f: = float(y - 10) / 23.0
		robe.append(robe_row(y, roundi(lerpf(10, 6, f)), roundi(lerpf(18, 21, f)), [roundi(lerpf(13, 10, f)), roundi(lerpf(16, 16, f))]))
	robe += [[34, 6, "5.55.555.5.55.5"], [10, 13, "ww"], [11, 13, "ww"], [12, 14, "ww"], [13, 14, "ww"], [14, 14, "ww"], [15, 14, "ww"], 
		[16, 14, "ww"], [17, 14, "ww"], [18, 14, "ww"], [19, 14, "yy"]]
	var head: = blob(13, 5, 3, 4, "sssSSt")
	var arm: = seg(Vector2i(16, 12), Vector2i(19, 17), "2334") + [[17, 20, "ss"]]
	var feet: = [[[35, 8, "SS"], [35, 17, "SSS"]], [[35, 11, "SS"], [35, 14, "SS"]], [[35, 15, "SS"], [35, 9, "SSS"]], [[35, 12, "SS"], [35, 13, "SS"]]]
	var frames: Array = []
	for i in 4:
		var sw: int = [1, 0, -1, 0][i]
		var cx: int = 21 + sw * 2
		var censer: = seg(Vector2i(20, 18), Vector2i(cx, 24), "L") + [[25, cx - 1, "yyy"], [26, cx - 1, "yYy"], [27, cx, "Y"]]
		var smoke: = [[23 - i, cx + 1, "v"], [21 - i, cx + 2 + i % 2, "vv"], [19 - i, cx + 1, "v"]]
		frames.append(swung(robe, 22, 34, sw) + feet[i] + head + arm + censer + smoke)
	frames_to(t, "v3_faceless_deacon", 27, 36, frames)
	t.sprite_palettes["v3_faceless_deacon"] = {
		"1": Color(0.34, 0.31, 0.38), "2": Color(0.25, 0.22, 0.29), "3": Color(0.17, 0.15, 0.21), "4": Color(0.11, 0.1, 0.15), 
		"5": Color(0.07, 0.06, 0.1), "K": Color(0.02, 0.02, 0.03), "w": Color(0.88, 0.86, 0.82), "y": Color(0.8, 0.62, 0.3), 
		"Y": Color(0.52, 0.38, 0.16), "s": Color(0.86, 0.84, 0.8), "S": Color(0.68, 0.66, 0.64), "t": Color(0.5, 0.48, 0.48), 
		"L": Color(0.45, 0.4, 0.36), "v": Color(0.55, 0.62, 0.52), 
	}




static func _weeping_saint(t: GameTheme) -> void :
	var halo: Array = []
	for a in 40:
		var ang: = TAU * a / 40.0
		if a % 13 != 4:
			halo.append([roundi(5.0 + sin(ang) * 5.5), roundi(12.0 + cos(ang) * 5.5), "h"])
			halo.append([roundi(5.0 + sin(ang) * 4.6), roundi(12.0 + cos(ang) * 4.6), "H"])
	var robe: Array = []
	for y in range(10, 35):
		var f: = float(y - 10) / 24.0
		robe.append(robe_row(y, roundi(lerpf(9, 5, f)), roundi(lerpf(17, 19, f)), [roundi(lerpf(12, 9, f)), roundi(lerpf(15, 15, f))]))
	robe += [[34, 5, "455544554555445"], [16, 8, "x"], [17, 9, "x"], [18, 9, "x"], [24, 15, "x"], [25, 14, "x"], [29, 8, "xx"]]
	var head: = [
		[2, 12, "1222"], [3, 11, "122222"], [4, 11, "222d2d"], [5, 11, "22r2r3"], [6, 11, "2r23r3"], [7, 12, "3r3r"], [8, 12, "333"], 
		[8, 11, "2"], [9, 12, "33"], 
	]
	var hands: = seg(Vector2i(15, 12), Vector2i(17, 15), "23") + [[12, 17, "11"], [13, 17, "12"], [14, 18, "2"], [15, 17, "22"]]
	var feet: = [[[35, 7, "333"], [35, 15, "3333"]], [[35, 10, "333"], [35, 12, "333"]], [[35, 14, "333"], [35, 8, "3333"]], [[35, 11, "333"], [35, 12, "33"]]]
	var frames: Array = []
	for i in 4:
		frames.append(halo + swung(robe, 22, 34, [1, 0, -1, 0][i]) + feet[i] + head + hands)
	frames_to(t, "v3_weeping_saint", 25, 37, frames)
	t.sprite_palettes["v3_weeping_saint"] = {
		"1": Color(0.86, 0.85, 0.82), "2": Color(0.7, 0.69, 0.67), "3": Color(0.54, 0.53, 0.53), "4": Color(0.39, 0.38, 0.4), 
		"5": Color(0.26, 0.25, 0.28), "K": Color(0.05, 0.05, 0.06), "d": Color(0.3, 0.29, 0.3), "r": Color(0.7, 0.08, 0.1), 
		"h": Color(0.82, 0.8, 0.74), "H": Color(0.6, 0.58, 0.55), "x": Color(0.3, 0.29, 0.31), 
	}





static func _hollow_angel(t: GameTheme) -> void :
	var wing: = seg(Vector2i(18, 9), Vector2i(6, 3), "aaa") + seg(Vector2i(6, 4), Vector2i(2, 23), "aAB")\
	+ seg(Vector2i(10, 5), Vector2i(6, 27), "aAB") + seg(Vector2i(14, 6), Vector2i(10, 28), "aAB") + seg(Vector2i(17, 8), Vector2i(13, 24), "aAB")
	var far_wing: = seg(Vector2i(22, 9), Vector2i(31, 1), "AAB") + seg(Vector2i(31, 1), Vector2i(34, 14), "AB")\
	+ seg(Vector2i(29, 3), Vector2i(31, 17), "AB") + seg(Vector2i(26, 6), Vector2i(28, 15), "AB")
	var robe: Array = []
	for y in range(11, 36):
		var f: = float(y - 11) / 24.0
		robe.append(robe_row(y, roundi(lerpf(15, 11, f)), roundi(lerpf(25, 28, f)), [roundi(lerpf(18, 15, f)), roundi(lerpf(22, 22, f))]))
	robe += [[36, 11, "5.55.555.555.555.5"], [15, 20, "dd"], [16, 19, "dddd"], [17, 19, "ddWd"], [18, 20, "dd"]]
	var head: = [
		[1, 17, "yy.yy"], [2, 16, "y"], [2, 22, "y"], [3, 17, "y"], [3, 21, "y"], 
		[4, 19, "2222"], [5, 18, "22dddd"], [6, 18, "2ddddd"], [7, 18, "2ddWdd"], [8, 18, "3dddd"], [9, 19, "333"], [10, 19, "33"], 
	]
	var arm: = seg(Vector2i(24, 13), Vector2i(27, 20), "234") + [[21, 27, "ss"]] + seg(Vector2i(28, 21), Vector2i(31, 32), "M") + [[20, 27, "Y"], [21, 26, "Y"]]
	var feet: = [[[37, 13, "ss"], [37, 23, "sss"]], [[37, 16, "ss"], [37, 20, "ss"]], [[37, 21, "ss"], [37, 14, "sss"]], [[37, 18, "ss"], [37, 19, "ss"]]]
	var frames: Array = []
	for i in 4:
		var stir: int = [0, 1, 0, -1][i]
		frames.append(shifted(far_wing, stir) + swung(wing, 9, 28, stir) + swung(robe, 24, 36, [1, 0, -1, 0][i]) + feet[i] + head + arm)
	frames_to(t, "v3_hollow_angel", 36, 39, frames)
	t.sprite_palettes["v3_hollow_angel"] = {
		"1": Color(0.86, 0.85, 0.82), "2": Color(0.7, 0.69, 0.68), "3": Color(0.54, 0.53, 0.54), "4": Color(0.39, 0.38, 0.41), 
		"5": Color(0.26, 0.25, 0.29), "K": Color(0.04, 0.04, 0.06), "d": Color(0.01, 0.01, 0.02), "W": Color(0.95, 0.95, 1.0), 
		"y": Color(0.85, 0.72, 0.4), "Y": Color(0.5, 0.42, 0.3), "s": Color(0.8, 0.78, 0.76), "M": Color(0.7, 0.72, 0.76), 
		"a": Color(0.5, 0.48, 0.5), "A": Color(0.35, 0.33, 0.37), "B": Color(0.22, 0.21, 0.25), 
	}


static func recolored(spans: Array, swap: Dictionary) -> Array:
	var out: Array = []
	for sp: Array in spans:
		var px: = ""
		for ch in (sp[2] as String):
			px += swap.get(ch, ch)
		out.append([sp[0], sp[1], px])
	return out





static func _pale_horse(t: GameTheme) -> void :
	var neck: Array = []
	var nr: Array = []
	for k in 8:
		var f: = float(k) / 7.0
		neck.append(Vector2i(roundi(lerpf(35, 41, f)), roundi(lerpf(18, 9, f))))
		nr.append(roundi(lerpf(4.0, 2.0, f)))
	var horse: = blob(24, 20, 12, 5, "1223345") + blob(36, 20, 4, 5, "122334") + blob(14, 19, 5, 5, "122334") + tube(neck, nr) + [
		[5, 40, "1222"], [6, 39, "12222223"], [7, 39, "22de22233"], [8, 40, "222333333"], [9, 42, "333333332"], [10, 44, "334444"], [11, 46, "f44"], 
		[18, 21, "4"], [19, 21, "4"], [20, 21, "4"], [18, 24, "4"], [19, 24, "4"], [20, 24, "4"], [18, 27, "4"], [19, 27, "4"], [20, 27, "4"], [21, 30, "4"], 
	]
	var mane: = [[4, 35, "gG"], [5, 33, "ggGg"], [6, 32, "gGGg"], [7, 31, "ggGg"], [8, 30, "gGg"], [9, 30, "gg"], [10, 31, "g"], [3, 37, "g"], [4, 38, "g"]]
	var tails: = [
		seg(Vector2i(10, 17), Vector2i(1, 13), "gG") + seg(Vector2i(9, 18), Vector2i(0, 19), "g"), 
		seg(Vector2i(10, 17), Vector2i(1, 15), "gG") + seg(Vector2i(9, 18), Vector2i(0, 21), "g"), 
	]
	var rider: = recolored([
		[3, 24, "222"], [4, 23, "22222"], [5, 22, "22dhh"], [6, 22, "2dhdh"], [7, 22, "22hhd"], [8, 21, "2223"], 
		[9, 20, "1222333"], [10, 19, "12223333"], [11, 18, "122233334"], [12, 17, "2223333344"], [13, 16, "22333334445"], 
		[14, 15, "223333344455"], [15, 16, "33333444555"], [16, 17, "34444555"], [12, 13, "333"], [13, 11, "3344"], [14, 10, "344"], 
	] + seg(Vector2i(25, 11), Vector2i(29, 13), "23"), {"1": "c", "2": "c", "3": "C", "4": "q", "5": "q"}) + seg(Vector2i(31, 18), Vector2i(26, 0), "w") + seg(Vector2i(26, 0), Vector2i(36, 2), "MN") + [[3, 36, "M"], [4, 37, "M"], [5, 37, "L"]]
	var sh: = Vector2i(35, 23)
	var hip: = Vector2i(14, 23)
	var front: = [
		[sh, Vector2i(39, 29), Vector2i(44, 32), Vector2i(47, 32)], 
		[sh, Vector2i(36, 30), Vector2i(35, 36), Vector2i(37, 37)], 
		[sh, Vector2i(32, 29), Vector2i(28, 32), Vector2i(26, 34)], 
		[sh, Vector2i(38, 29), Vector2i(41, 33), Vector2i(43, 34)], 
	]
	var hind: = [
		[hip, Vector2i(10, 29), Vector2i(5, 32), Vector2i(2, 34)], 
		[hip, Vector2i(15, 29), Vector2i(11, 33), Vector2i(9, 36)], 
		[hip, Vector2i(19, 28), Vector2i(19, 33), Vector2i(23, 36)], 
		[hip, Vector2i(16, 29), Vector2i(12, 33), Vector2i(14, 37)], 
	]
	var lift: = [0, 1, 1, 1]
	var frames: Array = []
	for i in 4:
		var d: = Vector2i(0, lift[i])
		frames.append(
			leg(moved(front[i], d + Vector2i(-3, 0), i != 1), "445", "45", "kkk", 0)
			+ leg(moved(hind[i], d + Vector2i(3, 0), i != 3), "445", "45", "kkk", 0)
			+ shifted(tails[i % 2] + horse + mane + rider, lift[i])
			+ leg(moved(front[i], d, i != 1), "2334", "233", "kkk", 0)
			+ leg(moved(hind[i], d, i != 3), "12334", "233", "kkk", 0))
	frames_to(t, "v3_pale_horse", 50, 39, frames)
	t.sprite_palettes["v3_pale_horse"] = {
		"1": Color(0.88, 0.88, 0.82), "2": Color(0.74, 0.74, 0.7), "3": Color(0.58, 0.58, 0.56), "4": Color(0.42, 0.42, 0.43), 
		"5": Color(0.28, 0.28, 0.31), "K": Color(0.04, 0.04, 0.05), "b": Color(0.8, 0.8, 0.76), 
		"g": Color(0.5, 0.92, 0.55), "G": Color(0.85, 1.0, 0.85), "d": Color(0.06, 0.06, 0.06), "e": Color(0.6, 1.0, 0.6), 
		"h": Color(0.88, 0.84, 0.74), "f": Color(0.9, 0.88, 0.8), "k": Color(0.2, 0.2, 0.22), 
		"w": Color(0.42, 0.32, 0.22), "M": Color(0.72, 0.74, 0.78), "N": Color(0.9, 0.92, 0.95), "L": Color(0.45, 0.46, 0.5), 
		"c": Color(0.32, 0.3, 0.35), "C": Color(0.19, 0.18, 0.22), "q": Color(0.1, 0.09, 0.12), 
	}




static func _watcher(t: GameTheme) -> void :
	var c: = Vector2i(22, 20)
	var tips: = [
		[Vector2i(4, 2), Vector2i(9, 0), Vector2i(14, 1)], [Vector2i(30, 1), Vector2i(35, 0), Vector2i(40, 2)], 
		[Vector2i(0, 15), Vector2i(0, 21), Vector2i(1, 27)], [Vector2i(44, 15), Vector2i(44, 21), Vector2i(43, 27)], 
		[Vector2i(5, 39), Vector2i(10, 41), Vector2i(15, 40)], [Vector2i(29, 40), Vector2i(34, 41), Vector2i(39, 39)], 
	]
	var roots: = [Vector2i(16, 13), Vector2i(28, 13), Vector2i(13, 20), Vector2i(31, 20), Vector2i(16, 27), Vector2i(28, 27)]
	var frames: Array = []
	for i in 4:
		var stir: int = [0, 1, 0, -1][i]
		var spans: Array = []
		for w in 6:
			var out: = Vector2i(1 if roots[w].x > c.x else -1, 1 if roots[w].y > c.y else (-1 if roots[w].y < c.y else 0)) * stir
			var fan: Array = tips[w]
			for k in fan.size():
				spans += seg(roots[w], (fan[k] as Vector2i) + out, "aaAB")
				if k + 1 < fan.size():
					spans += seg(roots[w], ((fan[k] as Vector2i) + (fan[k + 1] as Vector2i)) / 2 + out, "aaAB")
			var mid: Vector2i = (roots[w] + (tips[w][1] as Vector2i) + out) / 2
			spans += [[mid.y, mid.x - 1, "wdw"]]
		spans += blob(c.x, c.y, 9, 7, "WwwwvvV") + [
			[13, 16, "llllllllllll"], [14, 15, "l"], [14, 28, "l"], [27, 16, "llllllllllll"], 
			[17, 23 + stir, "iii"], [18, 22 + stir, "iiiii"], [19, 22 + stir, "iidii"], [20, 22 + stir, "iidii"], [21, 22 + stir, "iidii"], 
			[22, 22 + stir, "iiiii"], [23, 23 + stir, "iii"], [18, 23 + stir, "W"], 
			[24, 18, "r"], [25, 18, "r"], [26, 19, "r"], [28, 19, "r"], [29, 19, "r"], [15, 18, "rr"], [24, 27, "r"], 
		]
		frames.append(spans)
	frames_to(t, "v3_watcher", 46, 43, frames)
	t.sprite_palettes["v3_watcher"] = {
		"W": Color(1.0, 0.97, 0.94), "w": Color(0.9, 0.85, 0.8), "v": Color(0.74, 0.62, 0.6), "V": Color(0.54, 0.42, 0.42), 
		"K": Color(0.06, 0.04, 0.04), "i": Color(0.85, 0.15, 0.15), "d": Color(0.04, 0.02, 0.02), "r": Color(0.7, 0.08, 0.1), 
		"l": Color(0.6, 0.45, 0.42), "a": Color(0.92, 0.88, 0.76), "A": Color(0.72, 0.66, 0.54), "B": Color(0.5, 0.44, 0.36), 
	}







static func _fallen_seraph(t: GameTheme) -> void :
	var wing: Array = seg(Vector2i(24, 15), Vector2i(13, 4), "aaA")
	for tip: Vector2i in [Vector2i(1, 0), Vector2i(0, 3), Vector2i(0, 6), Vector2i(1, 9), Vector2i(2, 12), Vector2i(4, 15)]:
		wing += seg(Vector2i(13, 4), tip, "aAB")
	for k in 7:
		var f: = float(k) / 6.0
		var a: = Vector2i(roundi(lerpf(22, 13, f)), roundi(lerpf(14, 5, f)))
		wing += seg(a, a + Vector2i(-6 + k / 3, 11 - k / 2), "aAB")
	var embers: = [[0, 1, "g"], [3, 0, "G"], [6, 0, "g"], [9, 1, "g"], [12, 2, "G"], [15, 4, "g"], [24, 15, "g"], [23, 17, "G"], [21, 19, "g"]]
	var far_wing: Array = []
	for sp: Array in wing:
		far_wing.append([int(sp[0]) - 3, int(sp[1]) + 5, (sp[2] as String).replace("a", "A").replace("A", "B")])
	var robe: Array = []
	for y in range(20, 31):
		var f: = float(y - 20) / 10.0
		robe.append(robe_row(y, roundi(lerpf(24, 21, f)), roundi(lerpf(31, 32, f)), [roundi(lerpf(27, 25, f)), roundi(lerpf(29, 29, f))]))
	robe.append([31, 21, "5.55.5.5.55"])
	var body: = [
		[3, 26, "y.yyy"], [4, 25, "y"], [4, 31, "y"], [5, 26, "yyy.y"], 
		[6, 25, "hhh"], [7, 23, "hhhh"], [8, 22, "hhhhh"], [9, 21, "hhhh"], [10, 21, "hhh"], [11, 22, "hh"], [12, 23, "h"], 
		[6, 28, "ssss"], [7, 27, "ssssss"], [8, 27, "sSsgsS"], [9, 28, "ssSSs"], [10, 28, "SSdS"], [11, 29, "SS"], [12, 28, "SS"], 
		[13, 25, "ssssss"], [14, 24, "sssssSS"], [15, 24, "ssSsSSS"], [16, 24, "sSsSsSS"], [17, 25, "SsSsSS"], [18, 25, "SSSSt"], 
		[19, 26, "SSSt"], 
	]
	var far_limbs: = seg(Vector2i(26, 14), Vector2i(31, 20), "t") + seg(Vector2i(31, 20), Vector2i(35, 21), "t")\
	+ seg(Vector2i(25, 30), Vector2i(22, 37), "tu") + seg(Vector2i(22, 37), Vector2i(19, 42), "t")
	var near_limbs: = seg(Vector2i(29, 14), Vector2i(34, 19), "sS") + seg(Vector2i(34, 19), Vector2i(39, 17), "s") + [[16, 40, "f"], [18, 40, "f"], [17, 41, "f"]]\
	+ seg(Vector2i(28, 30), Vector2i(27, 37), "sS") + seg(Vector2i(27, 37), Vector2i(25, 43), "S") + [[44, 24, "S"]]
	var beat: = [1.0, 0.4, -0.35, 0.4]
	var frames: Array = []
	for i in 4:
		var bob: int = [0, 0, -1, 0][i]
		frames.append(wing_beat(far_wing, 12, beat[i]) + shifted(far_limbs + robe + body, bob) + shifted(near_limbs, bob)
			+ wing_beat(wing + embers, 15, beat[i]))
	frames_to(t, "v3_fallen_seraph", 44, 46, frames)
	t.sprite_palettes["v3_fallen_seraph"] = {
		"1": Color(0.34, 0.27, 0.3), "2": Color(0.25, 0.19, 0.22), "3": Color(0.17, 0.12, 0.15), "4": Color(0.11, 0.08, 0.1), 
		"5": Color(0.07, 0.05, 0.06), "K": Color(0.03, 0.02, 0.03), "a": Color(0.4, 0.31, 0.33), "A": Color(0.26, 0.18, 0.2), 
		"B": Color(0.1, 0.07, 0.08), "g": Color(1.0, 0.45, 0.12), "G": Color(1.0, 0.8, 0.35), "y": Color(0.78, 0.64, 0.36), 
		"s": Color(0.68, 0.68, 0.74), "S": Color(0.5, 0.5, 0.57), "t": Color(0.36, 0.36, 0.42), "u": Color(0.26, 0.26, 0.32), 
		"h": Color(0.08, 0.06, 0.08), "d": Color(0.06, 0.04, 0.05), "f": Color(0.88, 0.86, 0.8), 
	}








static func _cocytus_reworks(t: GameTheme) -> void :
	_devil_knight(t, "v3_traitor_knight", [[13, 18, "W"], [14, 18, "I"], [24, 14, "I"], [25, 14, "I"], [26, 17, "I"], [27, 17, "I"], 
		[26, 21, "I"], [12, 23, "I"], [13, 23, "I"], [17, 26, "W"]])
	t.sprite_palettes["v3_traitor_knight"] = {
		"1": Color(0.78, 0.84, 0.9), "2": Color(0.58, 0.64, 0.72), "3": Color(0.42, 0.47, 0.56), "4": Color(0.29, 0.33, 0.41), 
		"5": Color(0.18, 0.2, 0.27), "K": Color(0.04, 0.05, 0.08), "g": Color(0.55, 0.85, 1.0), "h": Color(0.88, 0.96, 1.0), 
		"H": Color(0.6, 0.78, 0.92), "r": Color(0.3, 0.38, 0.52), "R": Color(0.2, 0.26, 0.38), "q": Color(0.12, 0.16, 0.26), 
		"w": Color(0.3, 0.26, 0.24), "y": Color(0.6, 0.62, 0.66), "M": Color(0.7, 0.78, 0.86), "L": Color(0.42, 0.48, 0.58), 
		"N": Color(0.92, 0.97, 1.0), "I": Color(0.75, 0.9, 1.0), "W": Color(0.95, 1.0, 1.0), 
	}
	var snow: = [[3, 22, "w"], [6, 25, "w"], [10, 1, "w"], [15, 22, "w"], [18, 24, "w"], [23, 14, "w"], [25, 20, "w"], [8, 3, "w"], [13, 0, "w"]]
	_wraith(t, "v3_blizzard_wraith", snow)
	t.sprite_palettes["v3_blizzard_wraith"] = {
		"1": Color(0.92, 0.96, 1.0), "2": Color(0.78, 0.85, 0.94), "3": Color(0.62, 0.7, 0.84), "4": Color(0.46, 0.53, 0.7), 
		"5": Color(0.32, 0.37, 0.54), "K": Color(0.06, 0.08, 0.14), "d": Color(0.03, 0.04, 0.08), "e": Color(1.0, 0.4, 0.3), 
		"h": Color(0.85, 0.9, 0.98), "w": Color(1.0, 1.0, 1.0), 
	}
	_magma_slime(t, "v3_slush", [[2, 13, "I"], [1, 14, "I"], [3, 19, "I"], [2, 20, "I"]])
	t.sprite_palettes["v3_slush"] = {
		"r": Color(0.58, 0.64, 0.7), "R": Color(0.38, 0.43, 0.5), "g": Color(0.72, 0.8, 0.86), "G": Color(0.86, 0.92, 0.96), 
		"W": Color(0.97, 1.0, 1.0), "c": Color(0.62, 0.8, 0.92), "C": Color(0.82, 0.93, 1.0), "K": Color(0.07, 0.09, 0.12), 
		"h": Color(0.7, 0.62, 0.62), "H": Color(0.5, 0.42, 0.44), "d": Color(0.2, 0.26, 0.34), "f": Color(0.55, 0.48, 0.5), 
		"I": Color(0.85, 0.95, 1.0), 
	}
	_gargoyle(t, "v3_frost_gargoyle", [[12, 29, "I"], [13, 29, "I"], [12, 33, "I"], [17, 14, "I"], [18, 14, "I"], [18, 17, "I"], [21, 6, "I"]])
	t.sprite_palettes["v3_frost_gargoyle"] = {
		"1": Color(0.86, 0.92, 0.98), "2": Color(0.7, 0.78, 0.88), "3": Color(0.54, 0.62, 0.75), "4": Color(0.4, 0.46, 0.6), 
		"5": Color(0.27, 0.31, 0.43), "K": Color(0.05, 0.07, 0.11), "m": Color(0.55, 0.64, 0.78), "n": Color(0.4, 0.48, 0.64), 
		"b": Color(0.85, 0.92, 1.0), "v": Color(0.75, 0.9, 1.0), "x": Color(0.3, 0.36, 0.5), "e": Color(1.0, 0.38, 0.2), 
		"f": Color(0.92, 0.95, 1.0), "H": Color(0.6, 0.7, 0.85), "I": Color(0.85, 0.96, 1.0), 
	}
	_lost_soul(t, "v3_hoarfrost_wisp", [[3, 23, "I"], [2, 24, "I"], [3, 27, "I"], [2, 28, "II"], [1, 29, "I"], [4, 30, "I"]])
	t.sprite_palettes["v3_hoarfrost_wisp"] = {
		"1": Color(0.95, 0.98, 1.0), "2": Color(0.82, 0.88, 0.94), "3": Color(0.66, 0.74, 0.84), "4": Color(0.48, 0.56, 0.68), 
		"5": Color(0.32, 0.38, 0.5), "K": Color(0.04, 0.06, 0.12), "d": Color(0.05, 0.08, 0.16), "e": Color(0.4, 0.8, 1.0), 
		"f": Color(0.86, 0.92, 0.98), "F": Color(0.25, 0.5, 0.95), "G": Color(0.55, 0.8, 1.0), "W": Color(0.92, 0.98, 1.0), 
		"I": Color(0.85, 0.96, 1.0), 
	}



static func _frostwing(t: GameTheme) -> void :
	var body: = blob(18, 14, 4, 3, "122334") + [
		[9, 22, "2"], [10, 22, "23"], [9, 24, "2"], [10, 24, "2"], [11, 22, "122"], [12, 21, "12223"], [13, 21, "22e23"], 
		[14, 22, "3f3f"], [17, 16, "f.f"], 
	]
	var wings: = wing_frames(bat_wing(), 13)
	var frames: Array = []
	for i in 4:
		frames.append(shifted(body, [0, 0, -1, 0][i]) + wings[i])
	frames_to(t, "v3_frostwing", 28, 21, frames)
	t.sprite_palettes["v3_frostwing"] = {
		"1": Color(0.9, 0.95, 1.0), "2": Color(0.74, 0.82, 0.92), "3": Color(0.56, 0.64, 0.78), "4": Color(0.4, 0.47, 0.62), 
		"K": Color(0.05, 0.07, 0.12), "m": Color(0.58, 0.7, 0.86), "n": Color(0.42, 0.54, 0.72), "b": Color(0.88, 0.95, 1.0), 
		"e": Color(1.0, 0.3, 0.25), "f": Color(0.95, 0.97, 1.0), 
	}




static func _mites(t: GameTheme) -> void :
	var body: = blob(10, 6, 7, 4, "1223345") + [[6, 17, "33"], [7, 17, "334"], [8, 18, "f"], [6, 19, "e"]]
	var spikes: = [[1, 6, "i"], [1, 10, "ii"], [2, 13, "i"], [1, 4, "i"], [0, 10, "i"]]
	var gloss: = [[3, 6, "ww"], [4, 5, "w"]]
	for kind: String in ["ice_mite", "blood_mite"]:
		var frames: Array = []
		for i in 4:
			var legs: Array = []
			for k in 3:
				var x: int = [6, 10, 13][k]
				var dx: = 2 if (k + i) % 2 == 0 else -2
				legs += seg(Vector2i(x - 1, 9), Vector2i(x - 2 + dx / 2, 11), "5") + [[12, x - 3 + dx, "5"]]
			for k in 3:
				var x: int = [6, 10, 13][k]
				var dx: = -2 if (k + i) % 2 == 0 else 2
				legs += seg(Vector2i(x, 9), Vector2i(x + dx / 2, 11), "4") + [[12, x - 1 + dx, "4"]]
			frames.append(shifted(legs + body + (spikes if kind == "ice_mite" else gloss), 1))
		frames_to(t, "v3_" + kind, 22, 14, frames)
	t.sprite_palettes["v3_ice_mite"] = {
		"1": Color(0.86, 0.93, 1.0), "2": Color(0.68, 0.78, 0.9), "3": Color(0.5, 0.6, 0.76), "4": Color(0.36, 0.43, 0.6), 
		"5": Color(0.24, 0.29, 0.43), "K": Color(0.04, 0.06, 0.1), "i": Color(0.92, 0.98, 1.0), "e": Color(1.0, 0.3, 0.25), "f": Color(0.9, 0.92, 0.95), 
	}
	t.sprite_palettes["v3_blood_mite"] = {
		"1": Color(0.85, 0.3, 0.3), "2": Color(0.68, 0.14, 0.18), "3": Color(0.5, 0.07, 0.12), "4": Color(0.34, 0.04, 0.08), 
		"5": Color(0.2, 0.02, 0.05), "K": Color(0.06, 0.01, 0.02), "w": Color(1.0, 0.7, 0.7), "e": Color(1.0, 0.85, 0.3), "f": Color(0.9, 0.85, 0.8), 
	}



static func _ice_beetle(t: GameTheme) -> void :
	var body: = blob(12, 8, 9, 5, "11223345") + blob(21, 10, 3, 2, "2334") + [
		[4, 8, "i"], [5, 9, "i"], [6, 10, "i"], [4, 13, "i"], [5, 13, "i"], [6, 14, "i"], [5, 4, "ii"], [8, 5, "4"], [9, 9, "4"], [10, 13, "4"], 
		[9, 22, "e"], [12, 23, "ff"], [13, 24, "f"], 
	] + seg(Vector2i(22, 8), Vector2i(25, 3), "ii") + [[2, 25, "W"]]
	var frames: Array = []
	for i in 4:
		var legs: Array = []
		for k in 3:
			var x: int = [7, 12, 17][k]
			var dx: = 2 if (k + i) % 2 == 0 else -2
			legs += seg(Vector2i(x - 1, 12), Vector2i(x - 3 + dx / 2, 14), "5") + seg(Vector2i(x - 3 + dx / 2, 14), Vector2i(x - 3 + dx, 17), "5")
		for k in 3:
			var x: int = [7, 12, 17][k]
			var dx: = -2 if (k + i) % 2 == 0 else 2
			legs += seg(Vector2i(x, 12), Vector2i(x + 1 + dx / 2, 14), "4") + seg(Vector2i(x + 1 + dx / 2, 14), Vector2i(x + 1 + dx, 17), "4")
		frames.append(legs + body)
	frames_to(t, "v3_ice_beetle", 26, 18, frames)
	t.sprite_palettes["v3_ice_beetle"] = {
		"1": Color(0.82, 0.92, 1.0), "2": Color(0.6, 0.76, 0.92), "3": Color(0.42, 0.58, 0.8), "4": Color(0.28, 0.4, 0.6), 
		"5": Color(0.17, 0.25, 0.42), "K": Color(0.03, 0.05, 0.1), "i": Color(0.92, 0.98, 1.0), "W": Color(1.0, 1.0, 1.0), 
		"e": Color(1.0, 0.35, 0.25), "f": Color(0.85, 0.9, 0.95), 
	}




static func _frozen_traitor(t: GameTheme) -> void :
	var body: = [
		[1, 9, "IIII"], [2, 8, "IWIIII"], [3, 8, "IIIIIIJ"], [4, 8, "IIIII"], [5, 8, "JIII"], [6, 9, "JJ"], 
		[4, 13, "ssss"], [5, 12, "sssSs"], [6, 12, "sSeSs"], [7, 12, "sSdSs"], [8, 13, "SSS"], [9, 15, "I"], [10, 15, "I"], 
		[9, 11, "ssssss"], [10, 10, "sssssSS"], [11, 10, "ssSsSSS"], [12, 10, "sSsSsSS"], [13, 11, "SsSsSS"], [14, 11, "SSSSt"], 
		[15, 10, "uuuuuU"], [16, 10, "uuuuUU"], [17, 11, "u.uU"], 
	]
	var arm: = [
		[10, 16, "JIIII"], [11, 15, "JIIWII"], [12, 15, "JIssII"], [13, 15, "JIIsII"], [14, 16, "JIIII"], [15, 17, "JJJ"], 
		[16, 18, "I"], [17, 18, "I"], [16, 20, "I"], 
	]
	var far_arm: = seg(Vector2i(11, 10), Vector2i(8, 15), "t") + seg(Vector2i(8, 15), Vector2i(7, 19), "t")
	var poses: = walk_poses(Vector2i(13, 17), 12)
	var frames: Array = []
	for i in 4:
		frames.append(swung(far_arm, 10, 19, [-1, 0, 1, 0][i]) + leg(joints_dx(poses[(i + 2) % 4], -2), "tt", "t", "tt") + body
			+ leg(poses[i], "sS", "sS", "SSS") + arm)
	frames_to(t, "v3_frozen_traitor", 26, 31, frames)
	t.sprite_palettes["v3_frozen_traitor"] = {
		"s": Color(0.74, 0.8, 0.86), "S": Color(0.56, 0.62, 0.72), "t": Color(0.4, 0.45, 0.56), "K": Color(0.04, 0.05, 0.09), 
		"e": Color(0.8, 0.95, 1.0), "d": Color(0.08, 0.08, 0.12), "u": Color(0.36, 0.34, 0.36), "U": Color(0.24, 0.22, 0.25), 
		"I": Color(0.72, 0.88, 0.98), "J": Color(0.5, 0.68, 0.84), "W": Color(0.97, 1.0, 1.0), 
	}





static func _giants(t: GameTheme) -> void :
	var torso: Array = []
	var edges: = {9: [14, 24], 10: [11, 26], 11: [10, 27], 12: [10, 27], 13: [10, 27], 14: [10, 27], 15: [10, 27], 16: [11, 26], 
		17: [12, 26], 18: [13, 25], 19: [13, 25], 20: [13, 25], 21: [14, 24], 22: [14, 24], 23: [14, 24]}
	for y: int in edges:
		var l: int = edges[y][0]
		var r: int = edges[y][1]
		var row: = ""
		for x in range(l, r + 1):
			var ch: = "3"
			if y <= 10 or x <= l + 1:
				ch = "1" if y <= 10 and x < 20 else "2"
			elif x >= r - 1:
				ch = "5" if x == r else "4"
			elif y == 15 and x >= 15 and x <= 24:
				ch = "4"
			elif (x == 19 and y >= 17) or ((y == 19 or y == 21) and x >= 16 and x <= 22):
				ch = "4"
			row += ch
		torso.append([y, l, row])
	var body: = torso + [
		[2, 25, "1222"], [3, 24, "1222223"], [4, 24, "22222233"], [5, 24, "2244443"], [6, 24, "224e223"], [7, 25, "222223"], 
		[8, 25, "hhhh33"], [9, 24, "hhhhhh"], [10, 24, "hhhhhh"], [11, 25, "hhhhh"], [12, 25, "hhhh"], [13, 26, "hhh"], [14, 27, "h"], 
		[23, 13, "uuuuuuuuuuuu"], [24, 13, "uuuuuuuuuuuU"], [25, 13, "uUuuuuuuUU"], [26, 13, "u.uUu.uU"], 
	]
	var arm: = seg(Vector2i(25, 11), Vector2i(29, 19), "12334") + seg(Vector2i(29, 19), Vector2i(31, 24), "2334") + [[25, 30, "3333"], [26, 31, "333"]]
	var far_arm: = seg(Vector2i(12, 11), Vector2i(9, 19), "445") + seg(Vector2i(9, 19), Vector2i(11, 25), "445")
	var chains: = seg(Vector2i(11, 12), Vector2i(25, 21), "M") + seg(Vector2i(12, 21), Vector2i(26, 13), "L") + [[24, 29, "MMMMM"], [25, 29, "M"], [25, 33, "M"]]
	var poses: = walk_poses(Vector2i(19, 27), 10)
	for kind: String in ["chained_giant", "antaeus"]:
		var chained: = kind == "chained_giant"
		var frames: Array = []
		for i in 4:
			var drag: int = [0, 1, 2, 1][i]
			var dragged: = seg(Vector2i(31, 27), Vector2i(29, 37), "L") + seg(Vector2i(29, 37), Vector2i(7 + drag, 37), "M")\
			+ [[34, 2 + drag, "IIIII"], [35, 1 + drag, "IWIIIJ"], [36, 1 + drag, "IIIIJJ"], [37, 2 + drag, "JJJJ"]]
			var sw: int = [-1, 0, 1, 0][i]
			frames.append((dragged if chained else []) + swung(far_arm, 11, 25, - sw) + leg(joints_dx(poses[(i + 2) % 4], -3), "445", "45", "455")
				+ leg(poses[i], "2334", "233", "3344") + shifted(body + (chains if chained else []), [1, 0, 1, 0][i]) + swung(arm, 11, 26, sw))
		frames_to(t, "v3_" + kind, 38, 39, frames)
	t.sprite_palettes["v3_chained_giant"] = {
		"1": Color(0.8, 0.84, 0.9), "2": Color(0.64, 0.69, 0.78), "3": Color(0.49, 0.54, 0.64), "4": Color(0.35, 0.39, 0.49), 
		"5": Color(0.23, 0.25, 0.34), "K": Color(0.04, 0.05, 0.08), "h": Color(0.88, 0.9, 0.94), "e": Color(0.6, 0.9, 1.0), 
		"u": Color(0.5, 0.48, 0.5), "U": Color(0.34, 0.32, 0.36), "M": Color(0.5, 0.5, 0.55), "L": Color(0.32, 0.32, 0.37), 
		"I": Color(0.72, 0.88, 0.98), "J": Color(0.5, 0.68, 0.84), "W": Color(0.97, 1.0, 1.0), 
	}
	t.sprite_palettes["v3_antaeus"] = {
		"1": Color(0.86, 0.66, 0.5), "2": Color(0.72, 0.52, 0.38), "3": Color(0.56, 0.38, 0.28), "4": Color(0.4, 0.26, 0.2), 
		"5": Color(0.26, 0.16, 0.13), "K": Color(0.06, 0.03, 0.02), "h": Color(0.36, 0.25, 0.18), "e": Color(1.0, 0.75, 0.3), 
		"u": Color(0.45, 0.32, 0.2), "U": Color(0.3, 0.2, 0.13), 
	}




static func _ugolino(t: GameTheme) -> void :
	var robe: Array = []
	for y in range(14, 45):
		var f: = float(y - 14) / 30.0
		robe.append(robe_row(y, roundi(lerpf(18, 10, f * f)), roundi(lerpf(30, 35, f)), [roundi(lerpf(22, 15, f)), roundi(lerpf(27, 25, f)), roundi(lerpf(29, 31, f))]))
	robe += [[45, 10, "5.55.555..55.555.5.555..5"]]
	var top: = [
		[4, 23, "y.y.y"], [5, 23, "yyyyy"], 
		[6, 24, "ssss"], [7, 23, "ssssss"], [8, 23, "sSdeSs"], [9, 23, "sSSsss"], [10, 24, "SddS"], 
		[11, 24, "hhhh"], [12, 25, "hhh"], [13, 26, "h"], [7, 21, "hh"], [8, 20, "hhh"], [9, 20, "hh"], [10, 21, "h"], [11, 21, "h"], 
		[12, 19, "ffffff"], [13, 18, "ffffffffff"], [14, 19, "ffffffff"], 
	]
	var arm: = seg(Vector2i(28, 15), Vector2i(31, 12), "2334") + [[11, 30, "ss"], [8, 30, "kkk"], [9, 29, "kddk"], [10, 29, "kkkk"], [11, 31, "k"]]
	var far_arm: = seg(Vector2i(20, 16), Vector2i(26, 22), "345") + [[22, 26, "ss"], [23, 26, "s.s"]]
	var feet: = [[[46, 13, "S.S"]], [], [[46, 25, "S.S"]], []]
	var frames: Array = []
	for i in 4:
		frames.append(swung(robe, 30, 45, [1, 0, -1, 0][i]) + feet[i] + far_arm + top + shifted(arm, [0, 1, 0, 1][i]))
	frames_to(t, "v3_ugolino", 40, 47, frames)
	t.sprite_palettes["v3_ugolino"] = {
		"1": Color(0.5, 0.36, 0.55), "2": Color(0.38, 0.25, 0.43), "3": Color(0.27, 0.17, 0.32), "4": Color(0.18, 0.11, 0.22), 
		"5": Color(0.11, 0.06, 0.14), "K": Color(0.03, 0.02, 0.04), "y": Color(0.55, 0.55, 0.6), "s": Color(0.74, 0.74, 0.78), 
		"S": Color(0.55, 0.55, 0.6), "d": Color(0.06, 0.05, 0.06), "e": Color(0.8, 0.95, 1.0), "h": Color(0.88, 0.92, 0.96), 
		"f": Color(0.82, 0.84, 0.88), "k": Color(0.88, 0.84, 0.74), 
	}


static func mirrored(spans: Array, axis: int) -> Array:
	var out: Array = []
	for sp: Array in spans:
		var px: String = sp[2]
		var rev: = ""
		for k in range(px.length() - 1, -1, -1):
			rev += px[k]
		out.append([sp[0], 2 * axis + 1 - int(sp[1]) - px.length() + 1, rev])
	return out





static func _lucifer(t: GameTheme) -> void :
	var wing: Array = seg(Vector2i(22, 14), Vector2i(12, 3), "bb")
	var tips: = [Vector2i(0, 2), Vector2i(0, 9), Vector2i(1, 16), Vector2i(5, 22), Vector2i(11, 25)]
	for k in tips.size() - 1:
		for m in 4:
			var tip: Vector2i = (tips[k] as Vector2i) + ((tips[k + 1] as Vector2i) - (tips[k] as Vector2i)) * m / 4
			wing += seg(Vector2i(12, 3), tip, "nm") + seg(Vector2i(20, 13), tip + Vector2i(2, 1), "m")
	for tip: Vector2i in tips:
		wing += seg(Vector2i(12, 3), tip, "b")
	var side: = [[4, 19, "yyyy"], [5, 18, "yyyyyY"], [6, 17, "yeyyYY"], [7, 17, "yyyyYY"], [8, 17, "yddyYY"], [9, 18, "yyYYY"], 
		[10, 19, "YYzz"], [11, 20, "zz"]] + seg(Vector2i(18, 4), Vector2i(16, 1), "H")
	var half: = [
		[1, 27, "12222"], [2, 26, "122222"], [3, 25, "1222222"], [4, 25, "2222222"], [5, 25, "2244444"], [6, 25, "224e444"], 
		[7, 25, "2222222"], [8, 26, "222224"], [9, 26, "22dddd"], [10, 27, "4f444"], [11, 27, "44444"], [12, 28, "4444"], 
	] + seg(Vector2i(26, 2), Vector2i(22, 0), "hH") + seg(Vector2i(22, 0), Vector2i(19, 1), "h")\
	+ seg(Vector2i(19, 15), Vector2i(14, 23), "2334") + seg(Vector2i(14, 23), Vector2i(15, 30), "233") + [[31, 13, "f.f.f"]]
	var chest: Array = []
	var hws: = {13: 6, 14: 12, 15: 13, 16: 13, 17: 13, 18: 13, 19: 13, 20: 13, 21: 13, 22: 12, 23: 11, 24: 10, 25: 9, 26: 9, 27: 9, 28: 9, 29: 9, 30: 9}
	for y: int in hws:
		var hw: int = hws[y]
		var row: = ""
		for x in range(31 - hw + 1, 32 + hw):
			var d: = absi(x * 2 - 63) / 2
			var ch: = "2" if d < hw / 3 else ("3" if d < hw - 2 else ("4" if d < hw - 1 else "5"))
			if y <= 14 and d < hw - 2:
				ch = "1"
			if (y == 18 and d < 10 and d > 0) or (d == 0 and y >= 14) or (y >= 22 and (d == 3)) or ((y == 24 or y == 27) and d < 4):
				ch = "4"
			row += ch
		chest.append([y, 31 - hw + 1, row])

	var lower: = [[30, 24, "uuuuuuuu"], [31, 24, "uUuuuuuu"], [32, 25, "uUuUuuu"], [33, 25, "u.uU.u"]]\
	+ seg(Vector2i(28, 31), Vector2i(25, 36), "2334") + seg(Vector2i(25, 36), Vector2i(26, 41), "x45") + [[42, 24, "kkk"], 
		[36, 23, "I"], [37, 23, "IW"], [38, 24, "I"], [39, 24, "I"]]
	var ice: = lower + mirrored(lower, 31)
	var beat: = [1.0, 0.4, -0.3, 0.4]
	var frames: Array = []
	for i in 4:
		var w: = wing_beat(wing, 14, beat[i])
		frames.append(w + mirrored(w, 31) + chest + half + mirrored(half, 31) + side + recolored(mirrored(side, 31), {"y": "q", "Y": "Q", "z": "Q", "e": "e"}) + ice)
	frames_to(t, "v3_lucifer", 64, 44, frames)
	t.sprite_palettes["v3_lucifer"] = {
		"1": Color(0.84, 0.32, 0.26), "2": Color(0.68, 0.19, 0.17), "3": Color(0.52, 0.11, 0.12), "4": Color(0.36, 0.06, 0.09), 
		"5": Color(0.22, 0.03, 0.05), "K": Color(0.05, 0.01, 0.02), "m": Color(0.32, 0.12, 0.16), "n": Color(0.21, 0.07, 0.1), 
		"b": Color(0.58, 0.32, 0.3), "I": Color(0.72, 0.88, 0.98), "J": Color(0.5, 0.68, 0.84), "W": Color(0.95, 1.0, 1.0), 
		"y": Color(0.88, 0.8, 0.5), "Y": Color(0.68, 0.58, 0.32), "z": Color(0.5, 0.4, 0.2), "q": Color(0.28, 0.25, 0.3), 
		"Q": Color(0.16, 0.14, 0.18), "h": Color(0.86, 0.8, 0.7), "H": Color(0.56, 0.5, 0.45), "e": Color(1.0, 0.85, 0.3), 
		"d": Color(0.08, 0.02, 0.03), "f": Color(0.92, 0.88, 0.8), 
		"u": Color(0.24, 0.14, 0.14), "U": Color(0.15, 0.08, 0.09), "x": Color(0.3, 0.16, 0.14), "k": Color(0.12, 0.09, 0.09), 
	}
