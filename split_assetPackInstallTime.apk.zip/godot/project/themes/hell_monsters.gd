class_name HellMonsters
extends RefCounted










static func build(t: GameTheme) -> void :
	_grids(t)
	var bone: = {"X": Color(0.92, 0.9, 0.8), "w": Color(0.62, 0.58, 0.55), "W": Color(1, 1, 0.95)}

	var kinds: = {

		"magma_slime": ["_m_slime", Color(1, 0.45, 0.1), {"Y": Color(1, 0.92, 0.45), "W": Color(1, 1, 0.9), "E": Color(0.2, 0.03, 0.02)}], 
		"salamander": ["_m_salamander", Color(0.85, 0.22, 0.14), {"M": Color(1, 0.45, 0.1), "Y": Color(1, 0.85, 0.25), "W": Color(1, 0.97, 0.75), "E": Color(0.1, 0.02, 0.02)}], 
		"gargoyle": ["_m_gargoyle", Color(0.58, 0.54, 0.64), bone.merged({"Y": Color(1, 0.45, 0.2)}, true)], 
		"cultist": ["_m_cultist", Color(0.72, 0.13, 0.16), {"E": Color(0.05, 0.02, 0.04), "Y": Color(1, 0.82, 0.3), "X": Color(0.92, 0.9, 0.8), "n": Color(0.4, 0.24, 0.16), "S": Color(0.82, 0.72, 0.62)}], 

		"skeleton": ["_m_skeleton", Color(0.92, 0.9, 0.8), bone.merged({"K": Color(0.12, 0.1, 0.12), "E": Color(0.05, 0.03, 0.05), "Y": Color(1, 0.35, 0.2), "G": Color(0.62, 0.58, 0.52), "n": Color(0.42, 0.26, 0.15)}, true)], 
		"plague_bloat": ["_m_bloat", Color(0.6, 0.76, 0.3), {"Y": Color(0.95, 0.85, 0.35), "O": Color(1, 0.6, 0.2), "E": Color(0.45, 0.02, 0.05), "w": Color(0.88, 0.82, 0.7)}], 
		"wraith": ["_m_wraith", Color(0.6, 0.55, 0.8), {"E": Color(0.03, 0.02, 0.06), "Y": Color(0.5, 1, 0.9), "X": Color(0.92, 0.92, 0.88)}], 
		"ash_spider": ["_m_spider", Color(0.6, 0.58, 0.66), {"Y": Color(0.55, 0.9, 1)}], 

		"abyss_jelly": ["_m_slime", Color(1, 0.42, 0.68), {"Y": Color(1, 0.85, 0.95), "W": Color(1, 1, 1), "E": Color(0.2, 0.02, 0.1)}], 
		"bloated_drowned": ["_m_bloat", Color(0.95, 0.55, 0.18), {"Y": Color(1, 0.6, 0.8), "O": Color(1, 0.35, 0.6), "E": Color(0.1, 0.02, 0.06), "w": Color(0.95, 0.9, 0.8)}], 
		"deep_shade": ["_m_wraith", Color(0.95, 0.45, 0.72), {"E": Color(0.04, 0.02, 0.05), "Y": Color(0.55, 1, 1), "X": Color(1, 0.9, 0.95)}], 
		"reef_crawler": ["_m_spider", Color(0.95, 0.5, 0.2), {"Y": Color(1, 0.55, 0.8)}], 
		"deep_cultist": ["_m_cultist", Color(0.85, 0.26, 0.55), {"E": Color(0.05, 0.02, 0.05), "Y": Color(0.6, 1, 1), "X": Color(1, 0.85, 0.7), "n": Color(0.45, 0.3, 0.2), "S": Color(0.9, 0.75, 0.7)}], 

		"bone_soldier": ["_m_skeleton", Color(0.92, 0.9, 0.8), bone.merged({"K": Color(0.1, 0.05, 0.06), "E": Color(0.04, 0.0, 0.02), "Y": Color(1, 0.12, 0.15), "G": Color(0.9, 0.72, 0.25), "n": Color(0.5, 0.08, 0.1)}, true)], 
		"bone_gargoyle": ["_m_gargoyle", Color(0.88, 0.85, 0.76), bone.merged({"X": Color(0.85, 0.15, 0.18), "w": Color(0.5, 0.06, 0.1), "Y": Color(1, 0.15, 0.15)}, true)], 
		"void_wraith": ["_m_wraith", Color(0.86, 0.86, 0.92), {"E": Color(0.02, 0.0, 0.02), "Y": Color(1, 0.12, 0.15), "X": Color(0.85, 0.15, 0.18)}], 
		"marrow_bloat": ["_m_bloat", Color(0.88, 0.85, 0.76), {"Y": Color(0.9, 0.2, 0.22), "O": Color(0.55, 0.04, 0.08), "E": Color(0.6, 0.02, 0.05), "w": Color(0.5, 0.06, 0.1)}], 
		"pale_cultist": ["_m_cultist", Color(0.9, 0.88, 0.8), {"E": Color(0.03, 0.0, 0.02), "Y": Color(1, 0.12, 0.15), "X": Color(0.95, 0.8, 0.3), "n": Color(0.5, 0.08, 0.1), "S": Color(0.8, 0.78, 0.72)}], 
		"bone_spider": ["_m_spider", Color(0.88, 0.85, 0.76), {"Y": Color(0.9, 0.12, 0.15)}], 
	}
	for id: String in kinds:
		var k: Array = kinds[id]
		var pal: = HellArtV2.ramp(k[1]).merged(k[2], true)
		HellArtV2._family(t, k[0], id, pal)

static func _grids(t: GameTheme) -> void :


	t.sprites["_m_slime"] = [
		"......................", 
		"......................", 
		"......................", 
		"......KKKKKKKKK.......", 
		"....KK@@@@RRRRRKK.....", 
		"...K@@YY@RRRRRRRRK....", 
		"..K@@YYY@RRRRRRRRRK...", 
		"..K@@Y@RRRRRWERRWERK..", 
		".K@@RRRRRRRREERREERRK.", 
		".K@RRRRRRRRRRRKKKKRRK.", 
		".KRRRRRRRRRRRRRRRRRrK.", 
		"K@RRRRRRRRRRRRRRRRrrrK", 
		"KrRRRRRRRRRRRRRRRrr&&K", 
		"K&rrrrRRRRRRRrrrr&&&&K", 
		".KK&&&&rrrrrr&&&&&KK..", 
		"...KKKKKKKKKKKKKKKK...", 
	]
	t.sprites["_m_slime/2"] = [
		".......KKKKKKK........", 
		"......K@@@RRRRK.......", 
		".....K@YY@RRRRRK......", 
		"....K@YYY@RRRRRRK.....", 
		"....K@Y@RRRRRWERWERK..", 
		"....K@RRRRRRREEREERK..", 
		"....K@RRRRRRRRKKKRRK..", 
		"....KRRRRRRRRRRRRRRK..", 
		"....K@RRRRRRRRRRRRrK..", 
		"....KrRRRRRRRRRRRrrK..", 
		".....KrrRRRRRRRrr&K...", 
		"......K&&rrrrr&&K.....", 
		".......KKKKKKKKK......", 
		"........K&K..K&K......", 
		"......................", 
		"......................", 
	]


	var lizard: = [
		"................Y....Y............", 
		"..............Y.MY..YMY...........", 
		".............YMYMMY.YMMMY..KKKK...", 
		"Y...........YMMMMMYMMMMMY.K@@RRK..", 
		"YMY....KKKKKKKMMMMMMMMMMK@RRRWERRK", 
		".YMMKKK@@@@@@@@@@@@@@@@@rRRRREERRK", 
		"..KK@@RRRRRRRRRRRRRRRRRRRRRRKKKKK.", 
		"...KrRRRRRRRRRRRRRRRRRRRRRRRRRRK..", 
		"....KrrrRRRRrrrrrrRRRRRrrrrrrrK...", 
		"....KK&&KKKKKKKKKKKK&&KKKKKKK.....", 
	]
	t.sprites["_m_salamander"] = lizard + [
		".....KrRK.....K&K.....KrRK..K&K...", 
		"....KrRK......K&&K...KrRK....K&&K.", 
		"...KKKK........KKK.KKKK......KKK..", 
	]
	t.sprites["_m_salamander/2"] = lizard + [
		".....K&K.....KrRK.....K&K..KrRK...", 
		"....K&&K.....KrRK....K&&K...KrRK..", 
		"...KKKK.....KKKK....KKKK...KKKK...", 
	]


	var garg_low: = [
		".........K@RRRRRrrK.......", 
		".........K@RRRRrr&K.......", 
		"..........KRRrr&&K..KK....", 
		"..........KrK.Kr&K.K&K....", 
		".........KrRK.KrRK.K&K....", 
		".........KKKK.KKKK..K&K...", 
		"....................KK....", 
	]
	t.sprites["_m_gargoyle"] = [
		".K......................K.", 
		".KK....................KK.", 
		".K&K......K....K......K&K.", 
		".K&rK....KXK..KXK....Kr&K.", 
		"..K&rK...KXwKKwXK...Kr&K..", 
		"..K&rrK..K@@RRRRK..KrR&K..", 
		"..K&rRrK.K@YRRYRK.KrRr&K..", 
		"...K&rRrKK@RKKKRKKrRr&K...", 
		"...K&rRRrK@RWWWRKrRRr&K...", 
		"....K&&rRK@RRRRRKRr&&K....", 
		".....KK&&K@@RRRRrK&&KK....", 
	] + garg_low
	t.sprites["_m_gargoyle/2"] = [
		"..........................", 
		"..........................", 
		"..........K....K..........", 
		".........KXK..KXK.........", 
		".........KXwKKwXK.........", 
		"......KKKK@@RRRRKKKK......", 
		"....KK&rrK@YRRYRKrr&KK....", 
		"...K&&rRrK@RKKKRKrRr&&K...", 
		"..K&&rRRrK@RWWWRKrRRr&&K..", 
		".K&&rRrK.K@RRRRRK.KrRr&&K.", 
		"K&&rRK...K@@RRRRrK..KrR&&K", 
		"K&rK.....K@RRRRRrrK...Kr&K", 
		"KK.......K@RRRRrr&K.....KK", 
	] + garg_low.slice(2)


	var robe: = [
		"........KKK....KKK..", 
		".......K@RRK..KXXXK.", 
		"......K@RRRRK.KXEXK.", 
		".....K@RRRRRRK.KXXK.", 
		".....K@RKKKKRK..KnK.", 
		"....K@RKEYEYEK..KnK.", 
		"....K@RKEEEEEK..KnK.", 
		"....K@RRKKKKRK..KnK.", 
		"...K@RRRRRRRRK.KSnK.", 
		"...K@RRRYRRRRRRKSnK.", 
		"..K@RRRRYRRRRRRRrnK.", 
		"..K@RRRYYYRRRRRrrnK.", 
		"..K@RRRRYRRRRRrrKnK.", 
		"..K@RRRRRRRRRrr&KnK.", 
		"..K@RRRRRRRRRrr&KnK.", 
		".K@RRRRRRRRRRr&&KnK.", 
		".K@RRRRRRRRRRr&&KnK.", 
		".KRRRRRRRRRRrr&&KnK.", 
	]
	t.sprites["_m_cultist"] = robe + [
		".KYYYYYYYYYYYYYYKnK.", 
		".KKKKKKKKKKKKKKKKnK.", 
		"................KnK.", 
		"................KKK.", 
	]
	var sway: = robe.duplicate()
	sway[5] = "....K@RKEEYEYK..KnK."
	t.sprites["_m_cultist/2"] = sway + [
		"..KYYYYYYYYYYYYYKnK.", 
		"..KKKKKKKKKKKKKKKnK.", 
		"................KnK.", 
		"................KKK.", 
	]


	var skull: = [
		".....KKKKK..........", 
		"....KXXXXXK.........", 
		"...KXXXXXXXK........", 
		"...KXXXXXXXXK.......", 
		"...KXXXEEXEEK.......", 
		"...KXXXEYXEYK.......", 
		"...KwXXXXKXXK..K....", 
		"....KwXWKWKWK.KGK...", 
		".....KKwwwwKK.KGK...", 
		"......KXKXK...KGK...", 
		"....KKXXKXXKK.KGK...", 
		"...KXKwXXXwKXKKGK...", 
		"...KXKXwXwXKXXKKKK..", 
		"...KK.KXXXK..KnK....", 
		"......KwXwK...KK....", 
		"......KXKXK.........", 
	]
	t.sprites["_m_skeleton"] = skull + [
		".....KXK.KXK........", 
		".....KXK.KXK........", 
		".....KXK.KXK........", 
		"....KXXK.KXXK.......", 
		"....KKKK.KKKK.......", 
	]
	t.sprites["_m_skeleton/2"] = skull + [
		".....KXK..KXK.......", 
		"....KXK...KXK.......", 
		"....KXK....KXK......", 
		"...KXXK....KXXK.....", 
		"...KKKK....KKKK.....", 
	]


	var sack: = [
		"........KKKKK...........", 
		".......K@RRRRK..........", 
		"......K@RRREREK.........", 
		"......K@RRRRRRK.........", 
		".....KK@RRKKKRRKK.......", 
		"...KK@@@RRRRRRRRRKK.....", 
		"..K@@@YY@RRRRRRRRRRK....", 
		".K@@@YOOY@RRRRRRRRRRK...", 
		".K@@@@YY@RRRRRRYYRRRrK..", 
		"K@@@RRRRRRRRRRYOOYRRRrK.", 
		"K@@RRRRRwKwKwRRRYYRRrrK.", 
		"K@RRRRRRRRRRRRRRRRRRrrK.", 
		"KRRRRRRRRRRRRRRRRRRrr&K.", 
		"KrRRRRRYYRRRRRRRRRrr&&K.", 
		".KrRRRYOOYRRRRRRRrr&&K..", 
		".KrrRRRYYRRRRRRrrr&&&K..", 
		"..K&rrrrRRRRRrrrr&&&K...", 
		"...KK&&&rrrrrr&&&&KK....", 
		".....KKKKKKKKKKKKKK.....", 
	]
	t.sprites["_m_bloat"] = sack + [
		".....K&rK....K&rK.......", 
		"....KKKKK...KKKKK.......", 
	]
	t.sprites["_m_bloat/2"] = sack + [
		"......K&rK..K&rK........", 
		".....KKKKK.KKKKK........", 
	]


	var ghost: = [
		"......KKKKK.........", 
		".....K@@RRRK........", 
		"....K@@RRRRRK.......", 
		"...K@@RRRRRRRK......", 
		"...K@RRKKKKKRK......", 
		"...K@RKEEEEEKK......", 
		"...K@RKEYEYEEK......", 
		"...K@RKEEEEEEK......", 
		"...K@RRKEEEEK.......", 
		"..K@RRRRKKKKRK......", 
		".K@RRRRRRRRRRRK.....", 
		"K@RRKRRRRRRRRrKKK...", 
		"K@RK.KRRRRRRRrK@RRRK", 
		"KRK..KRRRRRRRrrKKKXX", 
		"KK...KrRRRRRrrr&K.X.", 
		".....KrRRRRrrr&&K...", 
		".....KrrRRrrr&&&K...", 
		"......K&rrrr&&&K....", 
	]
	t.sprites["_m_wraith"] = ghost + [
		"......K&&r&&K&&K....", 
		".......K&KK&K.K.....", 
		"........K..K........", 
	]
	t.sprites["_m_wraith/2"] = ghost + [
		"......K&&&rK&&K.....", 
		"......K&K.K&K.K.....", 
		".......K...K........", 
	]


	var spider: = [
		".....KKKKKK.............", 
		"....K@@RRRRK............", 
		"...K@RRYRRRRK..KKKK.....", 
		"...K@RYYYRRRrKK@RRRK....", 
		"...K@RRYRRRrrKK@YRYK....", 
		"..KKKrRRRrrrKKKKRRRKK...", 
	]
	t.sprites["_m_spider"] = spider + [
		".K&K.KKrrrKKK&KKKKK&K...", 
		"K&K.K&K.KK.K&K.K&K..K&K.", 
		"KK.K&K..K&K.K&K..K&K..KK", 
		"...KK...KK...KK...KK....", 
	]
	t.sprites["_m_spider/2"] = spider + [
		"..K&K.KrrrKK&K.KKK&K....", 
		".K&K..K&KK&K..K&K..K&K..", 
		"K&K..K&K..K&K..KK...K&K.", 
		"KK...KK...KK.........KK.", 
	]
