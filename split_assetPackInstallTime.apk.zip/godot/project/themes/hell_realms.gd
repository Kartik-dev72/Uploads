class_name HellRealms
extends RefCounted



















static func build(t: GameTheme) -> void :
	_purgatory_art(t)
	_abyss_art(t)
	_oblivion_art(t)
	_scenery(t)
	_paint(t)


static func _paint(t: GameTheme) -> void :
	var bone: = {"X": Color(0.92, 0.9, 0.8), "w": Color(0.62, 0.58, 0.55), "W": Color(1, 1, 0.95)}
	var wood: = {"N": Color(0.62, 0.42, 0.22), "n": Color(0.4, 0.25, 0.14)}
	var kinds: = {

		"penitent": ["_r_penitent", Color(0.58, 0.32, 0.72), wood.merged({"S": Color(0.95, 0.85, 0.75), "Y": Color(1, 0.85, 0.3), "E": Color(0.06, 0.02, 0.06), "w": Color(0.85, 0.75, 0.5)}, true)], 
		"flagellant": ["_r_penitent", Color(0.82, 0.18, 0.22), wood.merged({"S": Color(0.95, 0.85, 0.75), "Y": Color(1, 0.95, 0.6), "E": Color(0.08, 0.02, 0.03), "w": Color(0.95, 0.85, 0.55)}, true)], 
		"crow": ["_r_crow", Color(0.42, 0.33, 0.56), {"Y": Color(1, 0.25, 0.2), "X": Color(0.92, 0.85, 0.6), "w": Color(0.6, 0.5, 0.35)}], 
		"carrion_king": ["_r_crow_king", Color(0.42, 0.33, 0.56), {"Y": Color(1, 0.25, 0.2), "X": Color(0.92, 0.85, 0.6), "w": Color(0.6, 0.5, 0.35), "G": Color(1, 0.82, 0.25), "g": Color(0.75, 0.5, 0.12)}], 
		"grave_rat": ["_r_rat", Color(0.66, 0.55, 0.48), {"Y": Color(1, 0.3, 0.25), "W": Color(1, 0.97, 0.88), "S": Color(0.95, 0.62, 0.62), "E": Color(0.1, 0.02, 0.02)}], 
		"plague_rat": ["_r_rat", Color(0.55, 0.72, 0.32), {"Y": Color(1, 0.85, 0.2), "W": Color(1, 0.97, 0.88), "S": Color(0.9, 0.55, 0.6), "E": Color(0.12, 0.02, 0.02)}], 
		"rat_king": ["_r_rat_king", Color(0.72, 0.62, 0.55), {"Y": Color(1, 0.3, 0.25), "W": Color(1, 0.97, 0.88), "S": Color(0.95, 0.62, 0.62), "E": Color(0.1, 0.02, 0.02), "G": Color(1, 0.82, 0.25), "g": Color(0.75, 0.5, 0.12)}], 
		"coffin_crawler": ["_r_coffin", Color(0.66, 0.42, 0.26), bone.merged({"Y": Color(1, 0.35, 0.3), "E": Color(0.06, 0.02, 0.03), "G": Color(0.85, 0.75, 0.45)}, true)], 
		"lantern_ghost": ["_r_lantern", Color(0.6, 0.85, 0.8), {"E": Color(0.05, 0.08, 0.1), "Y": Color(1, 0.85, 0.35), "O": Color(1, 0.55, 0.15), "G": Color(0.35, 0.33, 0.38), "W": Color(1, 1, 0.85)}], 
		"gravedigger": ["_r_digger", Color(0.5, 0.55, 0.38), bone.merged(wood, true).merged({"S": Color(0.8, 0.82, 0.7), "Y": Color(1, 0.75, 0.3), "E": Color(0.08, 0.06, 0.04), "G": Color(0.65, 0.68, 0.72), "D": Color(0.32, 0.24, 0.18)}, true)], 
		"sexton": ["_r_digger", Color(0.32, 0.3, 0.42), bone.merged(wood, true).merged({"S": Color(0.82, 0.8, 0.72), "Y": Color(1, 0.4, 0.25), "E": Color(0.06, 0.04, 0.06), "G": Color(0.7, 0.72, 0.78), "D": Color(0.22, 0.18, 0.2)}, true)], 

		"drowned_sinner": ["_r_drowned", Color(0.45, 0.72, 0.62), {"E": Color(0.05, 0.08, 0.08), "Y": Color(1, 0.95, 0.55), "G": Color(0.55, 0.58, 0.62), "g": Color(0.35, 0.37, 0.42), "h": Color(0.2, 0.45, 0.3), "W": Color(1, 1, 0.9)}], 
		"drowned_monk": ["_r_drowned", Color(0.3, 0.38, 0.62), {"E": Color(0.04, 0.05, 0.08), "Y": Color(0.5, 1, 0.9), "G": Color(0.85, 0.7, 0.35), "g": Color(0.6, 0.45, 0.2), "h": Color(0.25, 0.5, 0.35), "W": Color(1, 1, 0.9)}], 
		"bloated_drowned": ["_r_drowned", Color(0.62, 0.78, 0.55), {"E": Color(0.05, 0.08, 0.06), "Y": Color(1, 0.6, 0.3), "G": Color(0.55, 0.58, 0.62), "g": Color(0.35, 0.37, 0.42), "h": Color(0.3, 0.5, 0.25), "W": Color(1, 1, 0.9)}], 
		"styx_eel": ["_r_eel", Color(0.95, 0.55, 0.25), {"Y": Color(0.75, 1, 1), "W": Color(1, 1, 0.92), "E": Color(0.12, 0.03, 0.02), "M": Color(0.4, 0.85, 1)}], 
		"leviathan_spawn": ["_r_eel", Color(0.85, 0.3, 0.42), {"Y": Color(0.75, 1, 1), "W": Color(1, 1, 0.92), "E": Color(0.12, 0.02, 0.04), "M": Color(1, 0.75, 0.3)}], 
		"leviathan": ["_r_leviathan", Color(0.3, 0.55, 0.65), {"Y": Color(1, 0.9, 0.4), "W": Color(1, 1, 0.92), "E": Color(0.05, 0.03, 0.06), "M": Color(0.5, 1, 1), "X": Color(0.92, 0.9, 0.8)}], 
		"leech": ["_r_leech", Color(0.75, 0.25, 0.32), {"Y": Color(1, 0.75, 0.6), "E": Color(0.15, 0.02, 0.04), "W": Color(1, 0.95, 0.9)}], 
		"styx_crab": ["_r_crab", Color(0.95, 0.45, 0.22), bone.merged({"Y": Color(0.6, 1, 1), "E": Color(0.12, 0.03, 0.02)}, true)], 
		"bellshell": ["_r_bell", Color(0.9, 0.42, 0.3), {"G": Color(0.78, 0.66, 0.36), "g": Color(0.5, 0.4, 0.2), "c": Color(0.38, 0.62, 0.55), "Y": Color(0.6, 1, 1), "E": Color(0.1, 0.03, 0.02), "W": Color(1, 0.95, 0.8)}], 
		"halo_jelly": ["_r_jelly", Color(0.85, 0.5, 0.95), {"Y": Color(1, 0.92, 0.5), "W": Color(1, 1, 1), "E": Color(0.2, 0.05, 0.25)}], 
		"lure_fiend": ["_r_angler", Color(0.88, 0.32, 0.5), {"Y": Color(0.7, 1, 0.95), "W": Color(1, 1, 0.92), "E": Color(0.12, 0.02, 0.06), "O": Color(1, 0.85, 0.4)}], 
		"siren": ["_r_siren", Color(0.4, 0.82, 0.72), {"S": Color(0.98, 0.84, 0.78), "s": Color(0.82, 0.62, 0.6), "A": Color(1, 0.6, 0.25), "a": Color(0.75, 0.32, 0.12), "Y": Color(1, 1, 0.7), "E": Color(0.08, 0.03, 0.05), "W": Color(1, 1, 1)}], 
		"siren_queen": ["_r_siren_queen", Color(0.35, 0.75, 0.85), {"S": Color(0.98, 0.84, 0.78), "s": Color(0.82, 0.62, 0.6), "A": Color(0.95, 0.3, 0.45), "a": Color(0.6, 0.12, 0.25), "Y": Color(1, 1, 0.7), "E": Color(0.08, 0.03, 0.05), "W": Color(1, 1, 1), "G": Color(1, 0.82, 0.25), "g": Color(0.75, 0.5, 0.12)}], 
		"ferryman": ["_r_ferryman", Color(0.36, 0.34, 0.46), bone.merged(wood, true).merged({"E": Color(0.03, 0.02, 0.05), "Y": Color(0.5, 1, 0.9), "O": Color(1, 0.75, 0.3), "G": Color(1, 0.82, 0.3), "g": Color(0.7, 0.5, 0.15)}, true)], 

		"faceless": ["_r_faceless", Color(0.86, 0.84, 0.8), {"S": Color(0.95, 0.9, 0.86), "s": Color(0.72, 0.68, 0.66), "E": Color(0.55, 0.05, 0.08), "Y": Color(1, 0.2, 0.2)}], 
		"faceless_deacon": ["_r_faceless", Color(0.18, 0.16, 0.22), {"S": Color(0.95, 0.9, 0.86), "s": Color(0.72, 0.68, 0.66), "E": Color(0.55, 0.05, 0.08), "Y": Color(1, 0.82, 0.3)}], 
		"stray_eye": ["_r_eye", Color(0.95, 0.92, 0.88), {"V": Color(0.85, 0.15, 0.2), "v": Color(0.5, 0.05, 0.1), "E": Color(0.05, 0.02, 0.04), "Y": Color(1, 0.75, 0.3), "F": Color(0.95, 0.95, 1), "f": Color(0.65, 0.65, 0.75)}], 
		"great_eye": ["_r_eye", Color(0.98, 0.85, 0.82), {"V": Color(0.85, 0.15, 0.2), "v": Color(0.5, 0.05, 0.1), "E": Color(0.05, 0.02, 0.04), "Y": Color(0.4, 1, 0.9), "F": Color(1, 0.85, 0.5), "f": Color(0.75, 0.55, 0.25)}], 
		"crawling_hand": ["_r_hand", Color(0.9, 0.85, 0.78), {"E": Color(0.55, 0.05, 0.08), "X": Color(0.95, 0.92, 0.85), "Y": Color(1, 0.2, 0.2)}], 
		"bone_serpent": ["_r_serpent", Color(0.9, 0.88, 0.78), {"E": Color(0.08, 0.02, 0.03), "Y": Color(1, 0.18, 0.2), "W": Color(1, 1, 0.95), "V": Color(0.7, 0.1, 0.15)}], 
		"great_serpent": ["_r_serpent", Color(0.92, 0.75, 0.35), {"E": Color(0.08, 0.02, 0.03), "Y": Color(1, 0.18, 0.2), "W": Color(1, 1, 0.95), "V": Color(0.6, 0.05, 0.1)}], 
		"weeping_saint": ["_r_saint", Color(0.72, 0.72, 0.78), {"E": Color(0.08, 0.06, 0.1), "Y": Color(0.9, 0.05, 0.1), "G": Color(1, 0.85, 0.35), "g": Color(0.75, 0.55, 0.2)}], 
		"ophan": ["_r_ophan", Color(0.95, 0.75, 0.3), {"F": Color(0.98, 0.96, 0.9), "E": Color(0.05, 0.02, 0.04), "V": Color(0.85, 0.15, 0.2), "Y": Color(0.4, 0.95, 1)}], 
		"watcher": ["_r_ophan", Color(0.95, 0.9, 0.85), {"F": Color(1, 0.95, 0.8), "E": Color(0.05, 0.02, 0.04), "V": Color(0.95, 0.2, 0.15), "Y": Color(1, 0.25, 0.2)}], 
		"hollow_angel": ["_r_angel", Color(0.82, 0.8, 0.86), bone.merged({"E": Color(0.05, 0.02, 0.06), "Y": Color(1, 0.85, 0.3), "F": Color(0.62, 0.6, 0.66), "f": Color(0.4, 0.38, 0.45), "G": Color(1, 0.85, 0.3), "g": Color(0.7, 0.5, 0.15)}, true)], 
		"fallen_seraph": ["_r_angel", Color(0.3, 0.22, 0.32), bone.merged({"E": Color(0.05, 0.02, 0.06), "Y": Color(1, 0.35, 0.15), "F": Color(1, 0.55, 0.2), "f": Color(0.75, 0.25, 0.1), "G": Color(1, 0.85, 0.3), "g": Color(0.7, 0.5, 0.15)}, true)], 
		"pale_horse": ["_r_horse", Color(0.86, 0.9, 0.82), bone.merged({"E": Color(0.05, 0.03, 0.04), "Y": Color(0.5, 1, 0.6), "M": Color(0.55, 0.95, 0.65), "D": Color(0.25, 0.22, 0.28), "d": Color(0.15, 0.13, 0.18), "G": Color(0.7, 0.72, 0.78)}, true)], 
	}
	for id: String in kinds:
		var k: Array = kinds[id]
		HellArtV2._family(t, k[0], id, HellArtV2.ramp(k[1]).merged(k[2], true))



static func _purgatory_art(t: GameTheme) -> void :


	var robe: = [
		"...........K..........", 
		"..........K@K.........", 
		"..........K@RK........", 
		".KK......K@RRK........", 
		"KNnK.....K@RRRK.......", 
		"KNnK....K@RRRRK.......", 
		"KNnK....K@RRRRRK......", 
		"KKKKKK.K@RRRRRRK......", 
		"NNnNNnKK@RRRRRRRK.....", 
		"KKnKKKK@RRRRYRYRK.....", 
		".KnK..K@RRRRERERK.....", 
		".KnK.K@@RRRRRRRRRK....", 
		".KnKK@@RRRRRRRRRRrK...", 
		".KnSSK@RRRRRRRRRrrK...", 
		".KnK.K@RRRRRRRRRrrK...", 
		".KnK.K@RRRRRRRRRrrK...", 
		".KnK.KwwwwwwwwwwwwK...", 
		".KnK.K@RRRRwRRRRrrK...", 
		".KnKK@RRRRRwRRRRrr&K..", 
		".KnKK@RRRRRRRRRRrr&K..", 
		".KnKK@RRRRRRRRRRr&&&K.", 
		".KnKK&rrrrrrrrrrr&&&K.", 
		".KnK.KKKKKKKKKKKKKKK..", 
	]
	t.sprites["_r_penitent"] = robe + [
		".KnK...KSSK..KSSK.....", 
		".KKK..KKKK..KKKK......", 
	]
	t.sprites["_r_penitent/2"] = robe + [
		".KnK..KSSK....KSSK....", 
		".KKK.KKKK....KKKK.....", 
	]


	t.sprites["_r_crow"] = [
		"....KK................", 
		"...K@RK...............", 
		"...K@RrK..............", 
		"....K@RrK.............", 
		"....K@RRrK......KKK...", 
		".....K@RRrK....K@RRK..", 
		"KK....K@RRrKKKK@RRYRK.", 
		"K@KKKKK@RRRRRRRRRRRKXK", 
		"K@RRRRRRRRRRRRRRRRrKXw", 
		".KrRRRRRRRRRRRRRRrrKK.", 
		"K&rKrrRRRRRRRRRrr&K...", 
		"KK..KK&&rrrrrr&&KK....", 
		".....KK.KKKKKKK.......", 
		"......KwK...KwK.......", 
	]
	t.sprites["_r_crow/2"] = [
		"......................", 
		"......................", 
		"......................", 
		"................KKK...", 
		"...............K@RRK..", 
		"KK.............K@RYRK.", 
		"K@KKKKKKKKKKKKK@RRRRKK", 
		"K@RRRRRRRRRRRRRRRRRRKX", 
		".KrRRR@@RRRRRRRRRRrKXw", 
		"K&rKrR@RRRRRRRRRRrrKK.", 
		"KK..KR@RRrrRRRRrr&K...", 
		"....K@RRrKK&rrr&&K....", 
		"...K@RRrK.KKKKKKK.....", 
		"..K@RrK...KwK.KwK.....", 
		".K@rKK................", 
		".KKK..................", 
	]

	t.sprites["_r_crow_king"] = _crowned(t.sprites["_r_crow"], 14, 4, 1)
	t.sprites["_r_crow_king/2"] = _crowned(t.sprites["_r_crow/2"], 14, 3, 1)


	var rat: = [
		"...................KK....", 
		"..................KSSK...", 
		"..........KKKKKKKKSSK....", 
		"........KK@@@RRRRRRRKK...", 
		"......KK@@RRRRRRRRRRRYK..", 
		".....K@@RRRRRRRRRRRRRRRK.", 
		"....K@RRRRRRRRRRRRRRRRRRK", 
		"...K@RRRRRRRRRRRRRRREEEK.", 
		"..KrRRRRRRRRRRRRRRrKWKWK.", 
		"KSKrRRRRRRRRRRRRRrrKKKK..", 
		"KSKrrrRRRRRRRRrrr&&K.....", 
		".KSK&&&rrrrrrrr&&&K......", 
	]
	t.sprites["_r_rat"] = rat + [
		"..KSK.KSK.KKK..KSK.......", 
		"...KK.KSSK....KSSK.......", 
		"......KKKK....KKKK.......", 
	]
	t.sprites["_r_rat/2"] = rat + [
		"..KSK..KSK....KSK........", 
		"...KK.KSSK...KSSK........", 
		"......KKKK..KKKK.........", 
	]
	t.sprites["_r_rat_king"] = _crowned(t.sprites["_r_rat"], 12, 3, 1)
	t.sprites["_r_rat_king/2"] = _crowned(t.sprites["_r_rat/2"], 12, 3, 1)


	var coffin: = [
		".......KKKKKKKK.......", 
		"......K@@@@RRRRK......", 
		".....K@@RRRRRRRrK.....", 
		"....K@@RRRGRRRRrrK....", 
		"...K@@RRRRRRRRRrr&K...", 
		"...K@RRRKKKKKKKRr&K...", 
		"...K@RKEEXXXXXEEK&K...", 
		"...K@KEEXEYXEYXEEK&K..", 
		"...K@KEEXXXKXXXEEK&K..", 
		"...K@KEEEXWKWXEEEK&K..", 
		"...K@RKKEEEEEEEKKr&K..", 
		"...K@RRRRRRRRRRRRr&K..", 
		"...K@RRRRGRRRRRRrr&K..", 
		"....KRRRRRRRRRRrr&K...", 
		".....KKKKKKKKKKKKK....", 
	]
	t.sprites["_r_coffin"] = coffin + [
		"..KXK.KXK.KXK.KXK.KXK.", 
		".KXK..KXK..KXK..KXK.KK", 
		"KXK..KXK....KXK..KXK..", 
		"KK...KK......KK...KK..", 
	]
	t.sprites["_r_coffin/2"] = coffin + [
		"...KXK.KXK.KXK.KXK.KXK", 
		"..KXK..KXK.KXK..KXK.KX", 
		".KXK..KXK...KXK..KXK..", 
		".KK...KK.....KK...KK..", 
	]


	var ghost: = [
		".....KKKKK..........", 
		"....K@@RRRK.........", 
		"...K@@RRRRRK........", 
		"...K@RKKKKRRK.......", 
		"...K@KEEEEKRK.......", 
		"...K@KEYEYEKK.......", 
		"...K@KEEEEEK........", 
		"...K@RKKKKKRK.......", 
		"..K@RRRRRRRRRK.KK...", 
		".K@RRRRRRRRRRRKGGK..", 
		".K@RRRRRRRRRRRRKGK..", 
		".K@RRRRRRRRRRRK.KGK.", 
		".K@RRRRRRRRRRrK.KGGK", 
		".KRRRRRRRRRRrrK.KOYK", 
		".KrRRRRRRRRrr&K.KYOK", 
		"..KrRRRRRRrr&&K.KGGK", 
		"..KrrRRRRrr&&K...KK.", 
	]
	t.sprites["_r_lantern"] = ghost + [
		"...K&&r&&rK&&K......", 
		"....K&KK&K.K&K......", 
		".....K..K...K.......", 
	]
	t.sprites["_r_lantern/2"] = ghost + [
		"...K&&&r&&K&K.......", 
		"...K&K.K&K..K.......", 
		"....K...K...........", 
	]



	var digger: = [
		"................KKK.......", 
		"...............KGGGK......", 
		"..............KGGGGK......", 
		"..............KGGGK.......", 
		"...............KnK........", 
		"......KKKKKK...KnK........", 
		".....KDDDDDDK..KnK........", 
		"...KKDDDDDDDDKKKnK........", 
		"..KDDDDDDDDDDDDKnK........", 
		"...KKKKSSSSSKKKnK.........", 
		".....KSSEsSEsSKnK.........", 
		".....KSSSSSSSSKnK.........", 
		"....KKSXwXwXwSKnK.........", 
		"...K@@KSSSSSSKKnKKK.......", 
		"..K@@RRKKKKKK@RnRRRK......", 
		".K@@RRRRRRRRRRRnRRRrK.....", 
		".K@RRRRRRRRRRRRnRRRrrK....", 
		"K@RRRRSSKRRRRRRnRRRrrK....", 
		"K@RRRRSSKRRRRRRnRRRr&K....", 
		"K@RRRRRKKRRRRRRnRRrr&K....", 
		"K@RRRRRRRRRRRRRnRRr&&K....", 
		"KRRRRRRKYKRRRRRnRrr&&K....", 
		"KrRRRRRKYKRRRRRKrr&&&K....", 
		"KrrRRRRRKRRRRRRrr&&&K.....", 
		".K&rrrrrrrrrrrrr&&&&K.....", 
		"..KKKKKKKKKKKKKKKKKK......", 
	]
	t.sprites["_r_digger"] = digger + [
		"...KDDK.....KDDK..........", 
		"..KDDDK....KDDDK..........", 
		"..KKKKK....KKKKK..........", 
	]
	t.sprites["_r_digger/2"] = digger + [
		"....KDDK...KDDK...........", 
		"...KDDDK..KDDDK...........", 
		"...KKKKK..KKKKK...........", 
	]




static func _crowned(rows: Array, col: int, head_row: int, pad: int) -> Array:
	var crown: = [
		"K.K.K.K", 
		"KGKGKGK", 
		"KGGYGGK", 
		"KgggggK", 
	]
	var w: = 0
	for r: String in rows:
		w = maxi(w, r.length())
	w = maxi(w, col + 7)
	var out: = []
	for i in pad:
		out.append(".".repeat(w))
	for r: String in rows:
		out.append(r + ".".repeat(w - r.length()))
	var top: = head_row + pad - crown.size()
	for i in crown.size():
		var y: = top + i
		if y < 0:
			continue
		var line: String = out[y]
		for x in 7:
			var ch: String = crown[i][x]
			if ch != ".":
				line = line.substr(0, col + x) + ch + line.substr(col + x + 1)
		out[y] = line
	return out



static func _abyss_art(t: GameTheme) -> void :


	var body: = [
		".....KKKKKK.........", 
		"....KhhhhhhK........", 
		"...KhK@RRRRhK.......", 
		"...Kh@RRRRRRK.......", 
		"...K@RRRKRKRK.......", 
		"...K@RRRYRYRK.......", 
		"...K@RRRRRRRK.......", 
		"...K@RKWKWKRK.......", 
		"....K@REEEERK.......", 
		".....KKrrrrK........", 
		"...KK@@RRRRRKK......", 
		"..K@@RRRRRRRRRK.....", 
		".K@RKRRRRRRRRRRK....", 
		".K@K.KRRRRRRRRrK....", 
		".K@K.K@RRRRRRrrK....", 
		"KRRK.K@RRRRRRrrK....", 
		"KrK..K@RRRRRrr&K....", 
		".Kg..K@RRRRRrr&K....", 
		"..Kg.KRRRRRRr&&K....", 
		"...KgKrrrrrrr&&K....", 
		"..KGGKKKKKKKKKKK....", 
		".KGKGGK.............", 
		"KGK.KGGK............", 
	]
	t.sprites["_r_drowned"] = body + [
		".KK..K&rK..K&rK.....", 
		".....KKKK..KKKK.....", 
	]
	var step: = body.duplicate()
	step[20] = "..KGGKKKKKKKKKKK...."
	t.sprites["_r_drowned/2"] = step + [
		".KK...K&rK.K&rK.....", 
		"......KKKK.KKKK.....", 
	]


	t.sprites["_r_eel"] = [
		"..............................", 
		"..........KKKK..........KKKK..", 
		"........KK@@RRKK......KK@RRRK.", 
		".......K@RMMMMRRK....K@RRRYRK.", 
		"KK....K@RRRRRRRRRK..K@RRRRRWK.", 
		"KMK..K@RRRRrrRRRRKKK@RRRRKEEK.", 
		"KMMKK@RRRrrKKrrRRRRRRRRRrKWK..", 
		".KMMRRRrrKK..KKrrRRRRRRrrKK...", 
		"..KKrrrKK......KKrrrrrrKK.....", 
		"....KKK..........KKKKKK.......", 
	]
	t.sprites["_r_eel/2"] = [
		"....KKK..........KKKKKK.......", 
		"..KKrrrKK......KKrRRRRRKK.....", 
		".KMMRRRRRKK..KK@RRRRRRRRKKK...", 
		"KMMKK@RRRRRKK@RRRRMMMRRRRYRK..", 
		"KMK..K@RRRRRRRRRRRRRRRRRRRRWK.", 
		"KK....KrRRRRRRRRrrKKrRRRRKEEK.", 
		".......KrrRRRRrrK...KrRRRRWK..", 
		"........KKrrrrKK.....KKKKKK...", 
		"..........KKKK................", 
		"..............................", 
	]


	var lev: = [
		".................XK.XK.XK..........", 
		"................KXXKXXKXXK.........", 
		"..............KK@@@@@@RRRRKK.......", 
		"............KK@@RRRRRRRRRRRRKK.....", 
		"...........K@@RRRRRRRRRRRRRRRRK....", 
		"..........K@RRRRRRRRRRRRRKKRRRRK...", 
		".........K@RRRRRRRRRRRRRKYYKRRRRK..", 
		".........K@RRRRRRRRRRRRRKYEKRRRRRK.", 
		"........K@RRRRRRRRRRRRRRRKKRRRRRRRK", 
		"........K@RRRRRRRRRRRRRRRRRRRRRKKKK", 
		".......K@RRRRRRRRKKRRRRRRRRRRKWKWK.", 
		".......K@RRRRRRRK..KKRRRRRRRKEEEEK.", 
		"......K@RRRRRRRK.....KKKRRRKWKWKWK.", 
		"..XK..K@RRRRRRRK........KKKKKKKKK..", 
		".KXXK.K@RRMMRRRK...................", 
		"..KXXK@RRMMMMRRK...................", 
		"...KK@RRRRMMRRrK...................", 
		"....K@RRRRRRRrrK...................", 
		"...K@RRRRRRRrr&K...................", 
		"..K@RRRRRRRrr&&K...................", 
		".K@RRRRRRRrrr&K....................", 
		"K@RRRRRRrrr&&K.....................", 
		"K&rrrrrrr&&KK......................", 
		".KKKKKKKKKK........................", 
	]
	t.sprites["_r_leviathan"] = lev
	var lev2: = lev.duplicate()
	lev2[11] = ".......K@RRRRRRRK..KKRRRRRRRKWKWKK."
	lev2[12] = "......K@RRRRRRRK.....KKKRRRRKKKKK.."
	lev2[13] = "..XK..K@RRRRRRRK........KKKKK......"
	t.sprites["_r_leviathan/2"] = lev2


	t.sprites["_r_leech"] = [
		"................", 
		".....KKKKKK.....", 
		"...KK@@RRRRKK...", 
		"..K@@RRRRRRRRK..", 
		".K@RRrRRrRRRYRK.", 
		".K@RRrRRrRRRRREK", 
		".KrRRrRRrRRRRrEK", 
		"..K&rrrrrrrrr&K.", 
		"...KKKKKKKKKKK..", 
	]
	t.sprites["_r_leech/2"] = [
		"................", 
		"................", 
		"................", 
		"....KKKKKKKKKK..", 
		"..KK@@RR@RR@RYKK", 
		"KK@RRrRRrRRrRRRE", 
		"KrRRRrRRrRRrRRrE", 
		".KK&&rrrrrrrr&KK", 
		"...KKKKKKKKKKK..", 
	]


	var crab: = [
		"..KK..............KK..", 
		".K@RK....Y..Y....K@RK.", 
		"K@RRRK...K..K...K@RRRK", 
		"K@RKRRK..K..K..KRRKRrK", 
		"KRK.KRK.KKKKKK.KRK.KrK", 
		".KK.KRKK@@RRRRKKRK.KK.", 
		"....KRK@XXXXXXRKRK....", 
		".....KK@XEXXEXRKK.....", 
		".....K@RXXKKXXRrK.....", 
		".....K@RRXwwXRRrK.....", 
		"......KrRRRRRRr&K.....", 
		".......KKKKKKKKK......", 
	]
	t.sprites["_r_crab"] = crab + [
		"....KrK.K&K.K&K.KrK...", 
		"...KrK.K&K...K&K.KrK..", 
		"...KK..KK.....KK..KK..", 
	]
	t.sprites["_r_crab/2"] = crab + [
		".....KrK.K&KK&K.KrK...", 
		"....KrK..K&KK&K..KrK..", 
		"....KK...KK..KK...KK..", 
	]



	var bell: = [
		"...........KKK............", 
		"..........KgGgK...........", 
		"..........KKGKK...........", 
		"........KKGGGGGKK.........", 
		".......KGWGGGGGGgK........", 
		"......KGWGGGGGGGGgK.......", 
		"......KGGGGcGGGGGgK.......", 
		".....KGGGGGccGGGGggK......", 
		".....KGGGGGGGGGGGGgK......", 
		".....KGGGGGGGGGcGGgK......", 
		"....KGGGGGGGGGGccGggK.....", 
		"....KGGcGGGGGGGGGGggK.....", 
		"...KGGGccGGGGGGGGGGggK....", 
		"..KGGGGGGGGGGGGGGGGGggK...", 
		"..KKKKKKKKKKKKKKKKKKKKK...", 
		"...KEEEEEEEEEEEEEEEEEK....", 
		"...K@RK.Y..Y.KK@RRK.......", 
		"..K@RRRK.K..K.K@RRRRK.....", 
		"..KRKRRK.K..K..KRKRRK.....", 
		"...K.KK..KKKK...K.KK......", 
	]
	t.sprites["_r_bell"] = bell + [
		"....KrK.K&K..K&K.KrK......", 
		"...KK...KK....KK...KK.....", 
	]
	t.sprites["_r_bell/2"] = bell + [
		".....KrK.K&KK&K.KrK.......", 
		"....KK...KK..KK...KK......", 
	]


	var jelly: = [
		"....KKKKKKK.....", 
		"...KYYYYYYYK....", 
		"..KY.......YK...", 
		"...KYYY.YYYK....", 
		"....KKKKKKK.....", 
		"...KK@@@RRRKK...", 
		"..K@@WRRRRRRRK..", 
		".K@@WRRRRRRRRRK.", 
		".K@RRRERRRERRRK.", 
		"K@RRRRRRRRRRRrrK", 
		"K@RRRRRRRRRRRrrK", 
		"KrRRrRRrRRrRRr&K", 
		".KK&KK&KK&KK&KK.", 
	]
	t.sprites["_r_jelly"] = jelly + [
		"..KrK.KrK.KrK...", 
		"..KrK..KrK.KrK..", 
		"...KrK.KrK..KrK.", 
		"...KrK..K....KK.", 
		"....K...........", 
	]
	t.sprites["_r_jelly/2"] = jelly + [
		"...KrK.KrK.KrK..", 
		"..KrK.KrK.KrK...", 
		"..KrK..KrK.KrK..", 
		"...K...KrK..KK..", 
		"........K.......", 
	]


	var fish: = [
		"...........KKKKK..........", 
		"..........K.....K.........", 
		".........K.......KK.......", 
		"........K..........K.KOK..", 
		".......KKKKKKKK.....KOOOK.", 
		".....KK@@@RRRRRKK....KOK..", 
		"KK..K@@RRRRRRRRRRK........", 
		"K@KK@RRRRRRRRRRKKRK.......", 
		"K@R@RRRRRRRRRRKYYKRK......", 
		"KR@RRRRRRRRRRRRKKRRRK.....", 
		"KrKRRRRRRRRRRRRRRRRRRK....", 
		"KrKrRRRRRRRRRRRRRRRWKWK...", 
		"KK.KrRRRRRRRRRRRRRKEEEEK..", 
		"....KrrRRRRRRRRRRRWKWKWK..", 
		".....KKrrrrrrrrrrrKKKKKK..", 
		".......KKKKKKKKKKK........", 
	]
	t.sprites["_r_angler"] = fish
	var fish2: = fish.duplicate()
	fish2[6] = "....K@@RRRRRRRRRRK........"
	fish2[7] = "KK.K@RRRRRRRRRRKKRK......."
	fish2[8] = "K@KRRRRRRRRRRRKYYKRK......"
	fish2[9] = "K@R@RRRRRRRRRRRKKRRRK....."
	fish2[10] = "KR@RRRRRRRRRRRRRRRRRRK...."
	fish2[11] = "KKKrRRRRRRRRRRRRRRRWKWK..."
	fish2[12] = "...KrRRRRRRRRRRRRRKEEEEK.."
	t.sprites["_r_angler/2"] = fish2


	var siren: = [
		".....KKKKK..........", 
		"....KAAAAAK.........", 
		"...KAAASSSAK........", 
		"..KAAASSYSYK........", 
		"..KAaASSSSSK........", 
		"..KAaaSSSEsK........", 
		"..KAaaKSSSK.........", 
		"..KAa.KKSSK.........", 
		"..KAaKSSSSSSK.......", 
		"..KaKSSSsSSSSK......", 
		"...KKSSSsKKSSSK.....", 
		"....KSSSSK.KSsK.....", 
		"....K@RRRRK.KK......", 
		"....K@RWRRRK........", 
		"....K@RRRWRRK.......", 
		".....KRRRRRrrK......", 
		"......KrRRRrr&K.....", 
		".......KrrRr&&K..KK.", 
		"........KKrr&&KK@RK.", 
		"..........KKr&&RRK..", 
		"...........KKKKKK...", 
	]
	t.sprites["_r_siren"] = siren
	var sing: = siren.duplicate()
	sing[5] = "..KAaaSSSKKK........"
	sing[17] = ".......KrrRr&&K.KK.."
	sing[18] = "........KKrr&&KK@RK."
	sing[19] = "..........KKr&&&RRK."
	t.sprites["_r_siren/2"] = sing
	t.sprites["_r_siren_queen"] = _crowned(siren, 3, 0, 4)
	t.sprites["_r_siren_queen/2"] = _crowned(sing, 3, 0, 4)



	var ferry: = [
		"......KKKKK.........KK.", 
		".....K@@RRRK.......KNnK", 
		"....K@@RRRRRK......KNnK", 
		"...K@@RRRRRRRK.....KNnK", 
		"...K@RKKKKKKRK.....KNnK", 
		"...K@KEXXXXEKK.....KNnK", 
		"...K@KEYXYXEKK.....KNnK", 
		"...K@KEXXXXEK......KNnK", 
		"...K@RKXwXwKK....KKKNnK", 
		"..K@@RRKKKKRRK..KXXXNnK", 
		".K@@RRRRRRRRRRK.KXwKNnK", 
		".K@RRRRRRRRRRRRKKKKKNnK", 
		"K@RRRRRRRRRRRRRRRrrKNnK", 
		"K@RRRRRRRRRRRRRRrrKKNnK", 
		"K@RRRRRRRRRRRRRRrrK.KNK", 
		"K@RRRRRRRRRRRRRrr&K.KNK", 
		"K@RRRRRRRRRRRRRrr&K.KGK", 
		"KRRRRRRRRRRRRRrrr&K.KGK", 
		"KrRRRRRRRRRRRRrr&&KGOGK", 
		"KrRRRRRRRRRRRrrr&&KOYOK", 
		"K&rrRRRRRRRRrrr&&&K.KGK", 
		".K&&rrrrrrrrrrr&&K..KK.", 
		"..KKKKKKKKKKKKKKKK.....", 
		"...K&rK..K&rK..........", 
		"..KKKKK.KKKKK..........", 
	]
	t.sprites["_r_ferryman"] = ferry
	var ferry2: = ferry.duplicate()
	ferry2[23] = "....K&rK.K&rK.........."
	ferry2[24] = "...KKKKKKKKKK.........."
	t.sprites["_r_ferryman/2"] = ferry2



static func _oblivion_art(t: GameTheme) -> void :


	var robe: = [
		".......KKKKK..........", 
		"......KSSSSSK.........", 
		".....KSSSSSSSK........", 
		".....KSSSSSSSK........", 
		".....KSSSSSSSK........", 
		".....KSSSSEESK........", 
		".....KsSSSSSsK........", 
		"......KsSSSsK.........", 
		"....KK@KKKKK@KK.......", 
		"...K@@RRRRRRRRRK......", 
		"..K@RRRRRRRRRRRRK.....", 
		"..K@RRKRRRRRRRRRRKKK..", 
		"..K@RK.KRRRRRRRRKSSSSK", 
		"..K@K..K@RRRRRRRrKKKK.", 
		"..KSK..K@RRRRRRrrK....", 
		"..KSSK.K@RRRRRRrrK....", 
		"...KK..K@RRRRRRrrK....", 
		"......K@RRRRRRRrr&K...", 
		"......K@RRRRRRRrr&K...", 
		".....K@RRRRRRRRrr&&K..", 
		".....KRRRRRRRRrrr&&K..", 
		".....K&rrrrrrrrrr&&K..", 
		"......KKKKKKKKKKKKK...", 
	]
	t.sprites["_r_faceless"] = robe + [
		"........K&K..K&K......", 
		".......KKK....KKK.....", 
	]
	t.sprites["_r_faceless/2"] = robe + [
		".......K&K....K&K.....", 
		"......KKK......KKK....", 
	]


	t.sprites["_r_eye"] = [
		"KK......................KK", 
		"KFK....................KFK", 
		"KFFK..................KFFK", 
		".KFfFK..............KFfFK.", 
		".KFfFFK............KFFfFK.", 
		"..KFfFfFK.KKKKKK.KFfFfFK..", 
		"...KFfFfKK@@@RRRKKfFfFK...", 
		"....KFfK@@RRVRRRRrKfFK....", 
		".....KK@RRRRKKKRRVrKK.....", 
		"......K@RVRKYYYKRRrK......", 
		"......K@RRRKYEYKRRrK......", 
		"......K@RRRKYYYKRVrK......", 
		"......K@RRVRKKKRRRrK......", 
		".......KrRRRRVRRRr&K......", 
		"........KK&rrrrr&KK.......", 
		"..........KKKKKK..........", 
	]
	t.sprites["_r_eye/2"] = [
		"..........................", 
		"..........................", 
		"..........................", 
		"..........................", 
		"..........................", 
		"..........KKKKKK..........", 
		"........KK@@@RRRKK........", 
		"....KKKK@@RRVRRRRrKKKK....", 
		"..KKFFK@RRRRKKKRRVrKFFKK..", 
		".KFfFFK@RVRKYYYKRRrKFFfFK.", 
		"KFfFfKK@RRRKYEYKRRrKKfFfFK", 
		"KFfFK.K@RRRKYYYKRVrK.KFfFK", 
		"KFFK..K@RRVRKKKRRRrK..KFFK", 
		".KFK...KrRRRRVRRRr&K..KFK.", 
		".KK.....KK&rrrrr&KK....KK.", 
		"..........KKKKKK..........", 
	]


	var palm: = [
		"......KKKKKKK.....", 
		"....KK@@@@RRRKK...", 
		"KK.K@@RRRRRRRRRK..", 
		"KEKK@RRKRRKRRKRRK.", 
		"KXEK@RRRRRRRRRRRRK", 
		"KEKK@RRRRRRRRRRrrK", 
		"KK.KrRRRRRRRRRrr&K", 
		"...K&rrrrrrrrr&&KK", 
	]
	t.sprites["_r_hand"] = palm + [
		"...KrK.KrK.KrK.KrK", 
		"..KrK..KrK..KrK.KK", 
		"..KXK..KXK...KXK..", 
		"...K....K.....K...", 
	]
	t.sprites["_r_hand/2"] = palm + [
		"....KrK.KrK.KrK.KK", 
		"....KrK..KrK.KrK..", 
		"...KXK...KXK.KXK..", 
		"....K.....K...K...", 
	]


	t.sprites["_r_serpent"] = [
		"......................KKK.....", 
		"....................KK@RRK....", 
		"..KKK..............K@RRRKK.K..", 
		".K@RRK............K@RRKYYKRK..", 
		"K@RVRRK.....KKK...K@RRKEYKRRK.", 
		"K@RRVRRK...K@RRK..K@RRRKKRRRRK", 
		".KrRRVRRK.K@RVRRK.K@RRRRRRRKWK", 
		"..KrRRVRRK@RRRVRRKKrRRRRRRKWK.", 
		"...KrRRVRRRRrRRVRRRRrRRRKKKK..", 
		"....KrRRRRRrKKrRRVRRRrrKK.....", 
		".....KKrrrrKK..KKrrrrrKK......", 
		".......KKKK......KKKKK........", 
	]
	t.sprites["_r_serpent/2"] = [
		"......................KKK.....", 
		"....................KK@RRK....", 
		"...................K@RRRKK.K..", 
		"..................K@RRKYYKRK..", 
		".KKKK.............K@RRKEYKRRK.", 
		"K@RRRK......KKKK..K@RRRKKRRRRK", 
		"KrRVRRKK..KK@RRRK.K@RRRRRRRKWK", 
		".KrRRVRRKK@RRVRRRKKrRRRRRRKWK.", 
		"..KrRRRVRRRRRrVRRRRRrRRRKKKK..", 
		"...KKrRRRrrKKKrrRVRRRrrKK.....", 
		".....KKrrKK....KKrrrrrKK......", 
		".......KK........KKKKK........", 
	]


	var saint: = [
		"....KKKKKKK.......", 
		"...KGGgGGGGK......", 
		"..KGK.....KGK.....", 
		"..KGK.KKK.KgK.....", 
		"...KKK@RRKKK......", 
		"....K@RRRRK.......", 
		"....K@EREERK......", 
		"....K@RYRYRK......", 
		"....K@RYRYRK......", 
		".....K@RYRK.......", 
		"....KK@RRRKK......", 
		"...K@@RRRRRRK.....", 
		"..K@RRRK@KRRRK....", 
		"..K@RRK@RRKRRrK...", 
		"..K@RRRK@KRRRrK...", 
		"..K@RRRRKRRRRrK...", 
		"..K@RRRRRRRRRrK...", 
		"..K@RRRRRRRRrr&K..", 
		"..K@RRRRRRRRrr&K..", 
		".K@RRRRRRRRRrr&&K.", 
		".KRRRRRRRRRRrr&&K.", 
		".K&rrrrrrrrrrr&&K.", 
		"..KKKKKKKKKKKKKK..", 
	]
	t.sprites["_r_saint"] = saint + [
		"....K&rK..K&rK....", 
		"...KKKKK.KKKKK....", 
	]
	t.sprites["_r_saint/2"] = saint + [
		".....K&rK.K&rK....", 
		"....KKKKKKKKKK....", 
	]


	t.sprites["_r_ophan"] = [
		"......KKKKKKKK......", 
		"....KK@KFEFK@RKK....", 
		"...K@@RRKKKKRRRrK...", 
		"..K@RRKK....KKRrrK..", 
		".K@RKK..KKKK..KKrrK.", 
		".KFKK..K@RRrK..KKFK.", 
		"KFEFK.K@KKKKrK.KFEFK", 
		"KKFKK.K@KYYKrK.KKFKK", 
		"K@RK..K@KYYKrK..KrrK", 
		"K@RK..KrKKKKrK..KrrK", 
		"KKFKK..KrrrrK..KKFKK", 
		"KFEFK...KKKK...KFEFK", 
		".KFKK.........KKFK..", 
		".K@RKK......KKKrrK..", 
		"..K@RRKK..KKRRrrK...", 
		"...K@RRRKKKKRrrK....", 
		"....KKRRKFEFKrKK....", 
		"......KKKKKKKK......", 
	]
	t.sprites["_r_ophan/2"] = [
		"......KKKKKKKK......", 
		"....KK@RRRRR@RKK....", 
		"...K@@KFEFK@RRRrK...", 
		"..KFEFKK....KKFEFK..", 
		".K@KFKK.KKKK.KKFKrK.", 
		".K@RKK.K@RRrK..KKrK.", 
		"K@RRK.K@KKKKrK.KrrrK", 
		"K@RRK.K@KYYKrK.KrrrK", 
		"KKFKK.K@KYYKrK.KKFKK", 
		"KFEFK.KrKKKKrK.KFEFK", 
		".KFKK..KrrrrK..KKFK.", 
		"KK@RK...KKKK...KrrKK", 
		".K@RKK........KKrrK.", 
		".KFEFKK......KKFEFK.", 
		"..KFKRKK..KKRRKFKK..", 
		"...K@RRRKKKKRrrrK...", 
		"....KKRRRRRRRrKK....", 
		"......KKKKKKKK......", 
	]



	var angel: = [
		"...........KKKKKKK..........", 
		"..........KGGgKGGGK.........", 
		"..........KK.....KK.........", 
		"...........KKKKKKK..........", 
		"..........K@@RRRRRK.........", 
		"..KK......K@KEEEKRK......KK.", 
		".KFFK.....K@EYEYERK.....KFFK", 
		".KFfFK....K@KEEEKRK....KFfFK", 
		"KFfFfK.....K@RRRRK....KFfFfK", 
		"KFfFfFK...KK@RRRKKK..KFfFfFK", 
		"KFfFfFXK.K@@RRRRRRRK.XFfFfFK", 
		".KfFfFXXK@RRRRRRRRRRKXFfFfK.", 
		".KfFfKwXK@RRKRRRRKRRKXwKfFK.", 
		"..KfK.KK@RRK@RRRRK@RKK.KfK..", 
		"..KK...K@RK@RRRRRRK@RK..KK..", 
		"......K@RRK@RRRRRRKRRrK.....", 
		"......KSRK.K@RRRRrK.KSK.....", 
		"......KK...K@RRRRrK..KK.....", 
		"..........K@RRRRRrrK........", 
		"..........K@RRRRRrrK........", 
		".........K@RRRRRRrr&K.......", 
		".........KRRRRRRRrr&K.......", 
		".........K&rrrrrrrr&K.......", 
		"..........KKKKKKKKKK........", 
	]
	t.sprites["_r_angel"] = angel + [
		"...........K&K..K&K.........", 
		"..........KKK..KKK..........", 
	]
	var flap: = angel.duplicate()
	flap[5] = "..........K@KEEEKRK.........."
	flap[6] = "..KK......K@EYEYERK......KK.."
	flap[7] = ".KFFK.....K@KEEEKRK.....KFFK."
	t.sprites["_r_angel/2"] = flap + [
		"............K&K.K&K.........", 
		"...........KKK.KKK..........", 
	]



	var horse: = [
		"..........GGGGGGG.............", 
		"........GGG.....KK............", 
		"..........KKKK...KnK..........", 
		".........KXXXXK..KnK..........", 
		".........KXEXEK..KnK..........", 
		".........KXXXXK..KnK..........", 
		"........KDKwwKDK.KnK..........", 
		".......KDDDDDDDDKKnK..........", 
		"......KDDDDDDDDDDKXK......MMK..", 
		"......KDDDDDDDDDdKnK....MMRRRK.", 
		"......KDDDDDDDDDdKnK...MMRRRYRK", 
		"..MM..KdDDDDDDDDdKnK..MM@RRRRRK", 
		".MMRK.KKddDDDDDdKKnK.MMK@RRRRRK", 
		"MMRRRKK@@KKKKKKK@KKKMMK@RRRKERK", 
		"MRRKKK@@RRRRRRRRRRRRRRRRRRKKKKK", 
		"MRK.K@RRRRRRRRRRRRRRRRRRRK.....", 
		"MK..K@RRRRRRRRRRRRRRRRRRRK.....", 
		"M...K@RRRRRRRRRRRRRRRRRrrK.....", 
		"....KrRRRRRRRRRRRRRRRRrr&K.....", 
		".....KrrRRRRRRRRRRRRrrr&K......", 
		"......KKrrrrrrrrrrrrr&&K.......", 
		"......KrRK.KrRK..KrRK.KrRK.....", 
	]
	t.sprites["_r_horse"] = horse + [
		".....KrRK...KrRK..KrRK..KrRK...", 
		"....KrRK.....KrRK..KrRK..KrRK..", 
		"....KXXK.....KXXK..KXXK..KXXK..", 
	]
	t.sprites["_r_horse/2"] = horse + [
		"......KrRK.KrRK....KrRK.KrRK...", 
		"......KrRK.KrRK....KrRK.KrRK...", 
		"......KXXK.KXXK....KXXK.KXXK...", 
	]



static func _overlay(rows: Array, subs: Array, _unused: int) -> Array:
	var out: = rows.duplicate()
	for s: Array in subs:
		var y: int = s[0]
		if y >= out.size():
			continue
		var line: String = out[y]
		var add: String = s[1]
		while line.length() < add.length():
			line += "."
		for x in add.length():
			if add[x] != "." and line[x] == ".":
				line = line.substr(0, x) + add[x] + line.substr(x + 1)
		out[y] = line
	return out



static func _scenery(t: GameTheme) -> void :


	t.sprites["wall_stone_h"] = [
		"wwwwwwwwwwww", 
		"XXXXXXXXXXXX", 
		"wwwwwwwwwwww", 
		"GwwGwwwGwwGw", 
		"wwGwwwGwwwwG", 
		"KwwwGwwwwGwK", 
		"GGGGGGGGGGGG", 
		"KKKKKKKKKKKK", 
	]
	t.sprites["wall_stone_v"] = [
		"KwwXwK", 
		"KwXXwK", 
		"KwXwwK", 
		"KwXXwK", 
		"KGwXwK", 
		"KwwXwK", 
		"KwXwGK", 
		"KwXXwK", 
	]
	t.sprites["wall_stone_post"] = [
		"...KK...", 
		"..KXXK..", 
		"KKKXXKKK", 
		"KXXXXXXK", 
		"KKKXXKKK", 
		"..KXXK..", 
		"KKKKKKKK", 
		"KXXXXXXK", 
		"KwwwwwwK", 
		"KwGwwGwK", 
		"KwwwwwwK", 
		"KwwGwwwK", 
		"KGGGGGGK", 
		"KKKKKKKK", 
	]
	t.sprites["fence_h"] = [
		".Y...Y...Y..", 
		"KGK.KGK.KGK.", 
		".G...G...G..", 
		"KGKKKGKKKGKK", 
		".G...G...G..", 
		".G...G...G..", 
		"KGKKKGKKKGKK", 
		".G...G...G..", 
		".K...K...K..", 
	]
	t.sprites["fence_v"] = [
		"..KK..", 
		"..GG..", 
		"..GG..", 
		"..GG..", 
	]
	t.sprites["fence_post"] = [
		"..KK..", 
		".KGGK.", 
		"KGYYGK", 
		".KGGK.", 
		".KGGK.", 
		".KGGK.", 
		".KGGK.", 
		".KGGK.", 
		".KGGK.", 
		"KGGGGK", 
		"KKKKKK", 
	]
	t.sprite_palettes["wall_stone_h"] = _stone()
	t.sprite_palettes["wall_stone_v"] = _stone()
	t.sprite_palettes["wall_stone_post"] = _stone()
	var iron: = {"K": Color(0.06, 0.06, 0.08), "G": Color(0.24, 0.24, 0.28), "Y": Color(0.5, 0.48, 0.42)}
	t.sprite_palettes["fence_h"] = iron
	t.sprite_palettes["fence_v"] = iron
	t.sprite_palettes["fence_post"] = iron

	t.sprites["grave_cross"] = [
		"...KK...", 
		"..KNnK..", 
		"KKKNnKKK", 
		"KNNNNnnK", 
		"KKKNnKKK", 
		"..KNnK..", 
		"..KNnK..", 
		"..KNnK..", 
		".KKNnKK.", 
		"KwwwwwwK", 
		"KKKKKKKK", 
	]
	t.sprites["grave_angel"] = [
		"....KKKK....", 
		"...KXXXXK...", 
		".KKKXEXEKKK.", 
		"KXXKXXXXKXXK", 
		"KXwKKXXKKwXK", 
		"KXwK.XX.KwXK", 
		".KwKXXXXKwK.", 
		"..KKXXXXKK..", 
		"...KXXXwK...", 
		"...KXXXwK...", 
		"..KXXXXwwK..", 
		".KwwwwwwwwK.", 
		".KGGGGGGGGK.", 
		".KKKKKKKKKK.", 
	]
	t.sprites["chapel_ruin"] = [
		"..........KK..........", 
		".........KXXK.........", 
		"........KKXXKK........", 
		".......KwKXXKwK.......", 
		"......KwwKKKKwwK......", 
		".....KwwwwwwwwwwK.....", 
		"....KwwKKKKKKKKwwK....", 
		"...KwwK.KYYYYK.KwwK...", 
		"..KwwwK.KYEEYK.KwwwK..", 
		"..KwGwK.KYEEYK.KwGwK..", 
		"..KwwwK.KYEEYK.KwwwK..", 
		"..KwwGK.KEEEEK.KGwwK..", 
		"..KwwwK.KEEEEK.KwwwK..", 
		".KKwGwKKKEEEEKKKwGwKK.", 
		"KwwwwwwwwwwwwwwwwwwwwK", 
		"KGGGGGGGGGGGGGGGGGGGGK", 
		"KKKKKKKKKKKKKKKKKKKKKK", 
	]
	t.sprite_palettes["chapel_ruin"] = _stone().merged({"Y": Color(0.9, 0.7, 0.3), "E": Color(0.03, 0.03, 0.05)}, true)
	t.sprite_palettes["grave_angel"] = _stone().merged({"E": Color(0.2, 0.2, 0.24)}, true)
	t.sprites["votive_candles"] = [
		".Y...O..", 
		".O..KYK.", 
		"KWK.KWK.", 
		"KWK.KWKY", 
		"KWK.KWKO", 
		"KWKKKWKW", 
		"KKK.KKKW", 
	]
	t.sprites["wilted_flowers"] = [
		"..P..p..", 
		".PPPKpp.", 
		"..PK.K..", 
		"...KhK..", 
		"..hK.K..", 
		"..KhhK..", 
	]
	t.sprite_palettes["votive_candles"] = {"K": Color(0.15, 0.12, 0.1), "W": Color(0.92, 0.88, 0.75), "Y": Color(1, 0.92, 0.5), "O": Color(1, 0.55, 0.15)}
	t.sprite_palettes["wilted_flowers"] = {"K": Color(0.12, 0.12, 0.1), "P": Color(0.55, 0.4, 0.6), "p": Color(0.4, 0.3, 0.42), "h": Color(0.32, 0.35, 0.25)}


	t.sprites["ferry_wreck"] = [
		"..........KK..............", 
		"..........KnK.............", 
		"..........KnK.............", 
		"...........KnK............", 
		"KK.........KnK..........KK", 
		"KNK.........KnK........KNK", 
		"KNNKKKKKKKKKKKKKKKKKKKKNNK", 
		"KNNNNNNNNNNNNNNNNNNNNNNNnK", 
		".KnNNNNNNNNNNNNNNNNNNNNnK.", 
		".KnnnnnnKKnnnnnnnnnnnnnnK.", 
		"..KnnnnK..KnnnnnnnnnnnnK..", 
		"...KKKK....KKKKKKKKKKKK...", 
	]
	t.sprite_palettes["ferry_wreck"] = {"K": Color(0.06, 0.05, 0.05), "N": Color(0.4, 0.3, 0.22), "n": Color(0.26, 0.19, 0.14)}
	t.sprites["sunken_bell"] = [
		".....KKK.....", 
		"....KgGgK....", 
		"...KKGGGKK...", 
		"..KGWGGGGgK..", 
		"..KGWGGcGgK..", 
		".KGGGGGccggK.", 
		".KGGcGGGGGgK.", 
		"KGGGccGGGGggK", 
		"KKKKKKKKKKKKK", 
		"hhhKhhhhKhhhh", 
	]
	t.sprite_palettes["sunken_bell"] = {"K": Color(0.08, 0.07, 0.05), "G": Color(0.62, 0.52, 0.3), "g": Color(0.42, 0.33, 0.18), "c": Color(0.32, 0.55, 0.48), "W": Color(0.95, 0.88, 0.6), "h": Color(0.06, 0.12, 0.13)}
	t.sprites["styx_reeds"] = [
		".h....h.", 
		".h..h.h.", 
		"Hh..h.H.", 
		"H.h.HhH.", 
		"H.hHhH..", 
		".HhHH...", 
	]
	t.sprite_palettes["styx_reeds"] = {"H": Color(0.22, 0.38, 0.32), "h": Color(0.14, 0.26, 0.22)}
	t.sprites["lily_candle"] = [
		"....Y....", 
		"....O....", 
		"...KWK...", 
		".HHKWKHH.", 
		"HHhhhhhHH", 
		".HHHHhH..", 
	]
	t.sprite_palettes["lily_candle"] = {"K": Color(0.12, 0.1, 0.08), "W": Color(0.92, 0.88, 0.75), "Y": Color(1, 0.95, 0.6), "O": Color(1, 0.6, 0.2), 
		"H": Color(0.18, 0.4, 0.32), "h": Color(0.12, 0.28, 0.22)}
	t.sprites["drowned_hand"] = [
		".K.K.K..", 
		"KSKSKSK.", 
		"KSSSSSKK", 
		"KSSSSSKS", 
		".KSSSSSK", 
		"..KSSSK.", 
		"..KsSsK.", 
		"hhhhhhhh", 
	]
	t.sprite_palettes["drowned_hand"] = {"K": Color(0.08, 0.12, 0.1), "S": Color(0.55, 0.72, 0.62), "s": Color(0.35, 0.5, 0.42), "h": Color(0.06, 0.12, 0.12)}


	t.sprites["broken_pillar"] = [
		"..KKK.K...", 
		".KXXXKXK..", 
		".KXwXXXwK.", 
		".KXwXXXwK.", 
		".KXwXXXwK.", 
		".KXwXXXwK.", 
		".KXwXXXwK.", 
		".KXwXXXwK.", 
		".KXwXXXwK.", 
		".KXwXXXwK.", 
		"KKKKKKKKKK", 
		"KXXXXXXXXK", 
		"KwwwwwwwwK", 
		"KKKKKKKKKK", 
	]
	t.sprite_palettes["broken_pillar"] = {"K": Color(0.06, 0.05, 0.07), "X": Color(0.78, 0.76, 0.8), "w": Color(0.5, 0.48, 0.55)}
	t.sprites["bone_brazier"] = [
		"...Y.W.Y...", 
		"..YWYWYWY..", 
		"..YWWWWWY..", 
		"...YWWWY...", 
		"KKKKKKKKKKK", 
		"KXwXwXwXwXK", 
		".KXXXXXXXK.", 
		"..KKXXXKK..", 
		"....KXK....", 
		"...KXwXK...", 
		"..KXXXXXK..", 
		"..KKKKKKK..", 
	]
	t.sprite_palettes["bone_brazier"] = {"K": Color(0.06, 0.04, 0.06), "X": Color(0.9, 0.88, 0.8), "w": Color(0.55, 0.52, 0.5), 
		"Y": Color(0.45, 1, 0.75), "W": Color(0.9, 1, 0.95)}
	t.sprites["void_chain"] = [
		".KK.", 
		"KGGK", 
		"K..K", 
		"KGGK", 
		".KK.", 
		".GG.", 
		".KK.", 
		"KGGK", 
		"K..K", 
		"KGGK", 
		".KK.", 
	]
	t.sprite_palettes["void_chain"] = {"K": Color(0.05, 0.04, 0.06), "G": Color(0.35, 0.33, 0.38)}
	t.sprites["halo_shard"] = [
		"..YYY...", 
		".Y...YK.", 
		"Y.....K.", 
		"Y.......", 
		".K......", 
	]
	t.sprite_palettes["halo_shard"] = {"Y": Color(0.95, 0.8, 0.35), "K": Color(0.3, 0.22, 0.1)}

	t.sprites["sunken_reliquary"] = [
		"..KKKKKKKKK..", 
		".KGgGGGGGgGK.", 
		"KGGGGYGGGGGgK", 
		"KKKKKKKKKKKKK", 
		"KcNNNKYKNNNcK", 
		"KNNcNKKKNcNNK", 
		"KNNNNNNNNNNnK", 
		"KcNNNNNNNcNnK", 
		"KKKKKKKKKKKKK", 
	]
	t.sprite_palettes["sunken_reliquary"] = {"K": Color(0.08, 0.06, 0.05), "G": Color(0.8, 0.65, 0.3), "g": Color(0.55, 0.42, 0.18), 
		"Y": Color(1, 0.92, 0.5), "N": Color(0.45, 0.32, 0.22), "n": Color(0.3, 0.2, 0.14), "c": Color(0.75, 0.8, 0.72)}
	t.sprites["bone_cage"] = [
		"....KKK....", 
		"...KXXXK...", 
		"..KKXKXKK..", 
		".KX.X.X.XK.", 
		"KX..X.X..XK", 
		"KX.KEK.X.XK", 
		"KX.KYK.X.XK", 
		"KX..X.X..XK", 
		"KXXXXXXXXXK", 
		"KKKKKKKKKKK", 
	]
	t.sprite_palettes["bone_cage"] = {"K": Color(0.08, 0.05, 0.06), "X": Color(0.9, 0.86, 0.76), "E": Color(0.5, 0.05, 0.08), "Y": Color(1, 0.3, 0.25)}

static func _stone() -> Dictionary:
	return {"K": Color(0.07, 0.07, 0.08), "X": Color(0.62, 0.62, 0.64), "w": Color(0.44, 0.44, 0.47), "G": Color(0.3, 0.3, 0.33)}
