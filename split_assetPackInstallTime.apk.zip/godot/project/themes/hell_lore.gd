class_name HellLore
extends RefCounted






const MONSTERS: = {

	"Imp": "Hell's smallest servants, sent in clouds. One is a nuisance; a thousand is a weather report.", 
	"Little Devil": "Too young for horns that matter, old enough to bite. Every great fiend started as one of these.", 
	"Hellhound Pup": "Already hungry, already fast. Its mother is never far behind.", 
	"Devil Knight": "Sworn to a lord it has never met. Its armour was forged from the gates of a fallen city.", 
	"Lost Soul": "A sinner who forgot their own name. It drifts toward anything warm, hoping to remember.", 
	"Hellbrute": "Pure muscle given a grudge. It does not hurry; it does not need to.", 
	"Blazing Hound": "Its mane burns hotter the longer it hunts. When it lowers its head, step aside.", 
	"Hex Imp": "An imp that stole a page of a grimoire and learned exactly one curse. It uses it a lot.", 
	"Brood Mother": "Her belly writhes with the next generation. Killing her is merciful, briefly.", 
	"Magma Slime": "Molten rock that learned to want. Split it and the pieces want twice as much.", 
	"Slimelet": "A mouthful of angry lava with big ambitions.", 
	"Fire Salamander": "It basks in the lava rivers and leaves scorched footprints on the souls it crosses.", 
	"Gargoyle": "Carved to guard a cathedral, it heard the bells stop and came looking for who silenced them.", 
	"Cultist": "Traded their soul for a promise. The promise was this.", 
	"Skeleton": "Everything the worms left. It still remembers how to walk, and who wronged it.", 
	"Plague Bloat": "Swollen with every sickness ever prayed against. Keep your distance and hold your breath.", 
	"Wraith": "A shadow that outlived the body that cast it. It is cold, and it would like you to be too.", 
	"Ash Spider": "Spins its webs from cinders. Its bite tastes of a house fire.", 
	"Hellhound": "The gatekeeper's own dog, three times the size of its pups and ten times the temper.", 
	"The Archfiend": "A prince of the pit who keeps the old ledgers. Every soul down here is written in his hand.", 
	"Lord of Imps": "Crowned by the swarm because nobody else wanted the job. He flies at the head of a storm of wings.", 

	"Penitent": "It walks the cemetery paths reciting sins it can no longer name. The recital never ends.", 
	"Carrion Crow": "It watches every grave and remembers every name. It is not waiting for you to die. It is just early.", 
	"Grave Rat": "Fat on what the earth was given. It runs in packs and it is never full.", 
	"Flagellant": "Each lash was meant for their own back. Lately, they aim outward.", 
	"Coffin Crawler": "Something buried that refused to stay so. It skitters on fingers worn to the bone.", 
	"Plague Rat": "The grave rat's sickly cousin, carrying something worse than teeth.", 
	"Lantern Ghost": "It lights the way for the lost and leads every one of them astray.", 
	"Gravedigger": "He has dug a hole for every soul in Purgatory. He measured one for you this morning.", 
	"The Rat King": "A knot of rats grown into one hungry crown. It speaks with a hundred squeaking mouths.", 
	"The Sexton": "Keeper of the bell and the keys. When he rings for you, it is already too late.", 
	"The Carrion King": "The crows chose him to sit on the highest headstone. He has eaten every king before him.", 

	"Drowned Sinner": "Pulled under by the weight of their own greed. The river still has a grip on their ankles.", 
	"Styx Eel": "It swims through the dark water and the dark air alike. Neither notices the difference.", 
	"Bone Crab": "It wears a sinner's skull as a shell, and it is very proud of it.", 
	"Leech": "It drinks from the damned and is never satisfied. You are a new flavour.", 
	"Drowned Monk": "Took a vow of silence. The river made it permanent.", 
	"Halo Jelly": "It drifts with a ring of false light. Saints mistook it for a sign; the river kept them.", 
	"Bloated Drowned": "A body the river gave back, much bigger than it took.", 
	"Lure Fiend": "Its glowing bait looks like the way home. It has never been the way home.", 
	"Siren": "Her song promises rest. Her teeth deliver it.", 
	"Bellshell": "A giant snail wearing a drowned church bell. When it moves, the river tolls.", 
	"Leviathan Spawn": "A small piece of something very large. It is still growing.", 
	"The Leviathan": "The thing beneath the river. The river is only the part of it that shows.", 
	"The Ferryman": "He has taken every soul across. He has never once brought one back, and he does not mean to start.", 
	"The Siren Queen": "Every siren learned her song from this one. She sings it for you alone.", 

	"The Faceless": "Forgotten so completely that even its face gave up. It wanders the temple, looking for anyone who remembers.", 
	"Stray Eye": "An eye that wandered off from something enormous. It is still looking.", 
	"Bone Serpent": "A spine with ambitions. It coils through the marble like a forgotten prayer.", 
	"Crawling Hand": "It once reached for salvation. Now it reaches for ankles.", 
	"Faceless Deacon": "Preaches a sermon nobody can hear to a congregation nobody remembers.", 
	"Your Shadow": "The part of you that stayed behind every time you ran. It has caught up.", 
	"Weeping Saint": "A statue that wept for the world until the world forgot it. Now it weeps for itself.", 
	"Great Serpent": "The bone serpent's elder, long enough to circle the temple twice.", 
	"Ophan": "A wheel of wings and watching eyes, a guardian of a throne that no longer stands.", 
	"Hollow Angel": "Its grace drained out long ago. What is left still remembers how to strike.", 
	"The Great Eye": "The thing the stray eyes came from. It sees you, and it is not impressed.", 
	"The Pale Horse": "It carried the last rider out of the world. It came back for another.", 
	"The Watcher Above": "It has watched Oblivion since before there was anything to forget.", 
	"The Fallen Seraph": "Once the brightest choir in heaven. The fall cost it everything but its wings.", 

	"Frozen Traitor": "Betrayed a friend and froze where they stood. The ice only lets go of their hatred.", 
	"Frostwing": "A bat-thing born of the cold wind off Lucifer's wings.", 
	"Ice Mite": "Tiny, hard as frost and always in a crowd.", 
	"Blood Mite": "An ice mite that has fed. It is warmer now, and angrier.", 
	"Traitor Knight": "Sold the keep to the enemy for a purse of gold. The gold froze to his hand.", 
	"Blizzard Wraith": "The storm given a grudge and a shape. Its touch is the last cold you'll feel.", 
	"Slush": "Half-melted sin. Break it and it splits into smaller, angrier slush.", 
	"Slushlet": "A puddle with a temper.", 
	"Frost Gargoyle": "A gargoyle that perched too long on the frozen lake. Now the ice perches on it.", 
	"Ice Beetle": "It shells itself in the frozen tears of the damned and tunnels through the lake.", 
	"Hoarfrost Wisp": "A flicker of cold light that freezes whatever it brushes past.", 
	"Chained Giant": "One of the giants who stormed heaven, chained at the edge of the ice. The chains are loosening.", 
	"Antaeus": "The giant who sets travellers down on the ice of the ninth circle. He'd rather crush them.", 
	"Count Ugolino": "Frozen with his betrayer, gnawing forever. He has finally found something else to chew.", 
	"Lucifer": "The first to fall and the deepest down, frozen by the wind of his own wings. He weeps, and the tears freeze.", 
}


const ELITES: = {
	"swift": ["Swift", "A demon possessed by its own haste: faster than the rest, and harder to pin down."], 
	"brute": ["Brute", "Fed on its kin until it swelled: huge, slow and hard to put down."], 
	"volatile": ["Volatile", "Full to bursting with hellfire. When it dies, the fire comes out sideways."], 
	"champion": ["Champion", "Chosen by its realm's lord to hunt you. Slay it for a blessing."], 
}


const ELITE_STAND_INS: = {"swift": "hellhound", "brute": "hellbrute", "volatile": "imp", "champion": "gravedigger"}

const SURVIVORS: = {
	"exorcist": "A village priest who read the wrong book aloud. He has been reading the right ones ever since.", 
	"hunter": "She has hunted demons since the night one took her family. She is still not finished.", 
	"plague_doctor": "He treated the dying through every plague. Hell's sickness is simply the next one.", 
	"paladin": "His order fell to the last man. He decided that was enough.", 
	"executioner": "He carried out a thousand sentences. Now he means to carry out one more, on hell itself.", 
	"nun": "She prayed for the souls of the damned every night for forty years. Then she went to fetch them.", 
	"witch": "Burned once, she came back with a familiar and a grudge against the flames.", 
	"fallen_angel": "He fell for a reason he will not share. Heaven is closed to him; hell will have to do.", 
	"crusader": "She rode to the end of the world under a holy banner, and kept riding.", 
	"frost_hermit": "He lived alone at the edge of the ice for a hundred years, listening to Lucifer weep.", 
	"zealot": "He walked from town to town whipping his own back bloody for the world's sins. Hell seemed the next town.", 
	"chorister": "The youngest voice in the cathedral choir. When the demons came, she simply kept singing.", 
	"ravenkeeper": "He fed the ravens of the gallows field for thirty years. When he went below, they came with him.", 
	"undertaker": "He buried a whole city through the plague years. He has measured every one of them for a box.", 
}
