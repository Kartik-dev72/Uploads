class_name GameOverScreen
extends Control





const FADE_TIME: = 0.5
const SHOWN_SCORES: = 5
const MAX_NEWS: = 5

var _box: VBoxContainer
var _double_button: Button

func _ready() -> void :
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_to_group("game_over_screen")
	add_to_group("pause_screen")
	hide()

func open(summary: Dictionary, rank: int) -> void :
	get_tree().call_group("event_director", "silence")
	_clear()
	_build(summary, rank)
	_present()



func open_revive(summary: Dictionary, answer: Callable) -> void :
	_clear()
	var t: = Game.theme
	_add_dim()
	_start_box()
	_box.add_child(_label(t.death_title, 72, t.ui["hp"], 14))
	_box.add_child(_label("SCORE", 30, Color(1, 1, 1, 0.7)))
	_box.add_child(_label(HUD.format_score(summary["score"]), 96, t.ui["accent"], 16))
	_box.add_child(_label("Not yet. Rise again with half your HP and a moment of protection?", 28, Color(1, 1, 1, 0.85)))
	(_box.get_child(-1) as Label).autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_box.add_child(_button("Revive  (watch a short video)", t.ui["accent"], func() -> void :
		_lock_buttons()
		answer.call(true)))
	_box.add_child(_button("No thanks", Color(1, 1, 1, 0.6), func() -> void :
		_lock_buttons()
		answer.call(false)))
	_present()


func _lock_buttons() -> void :
	for b in _box.get_children():
		if b is Button:
			b.disabled = true

func _present() -> void :
	show()
	get_tree().process_frame.connect(_keep_on_screen, CONNECT_ONE_SHOT)
	get_tree().paused = true
	modulate.a = 0.0
	create_tween().tween_property(self, "modulate:a", 1.0, FADE_TIME)


func _keep_on_screen() -> void :
	if _box == null:
		return
	var top: = Game.safe_top() + 16.0
	var taunt: = get_tree().get_first_node_in_group("death_taunt") as DeathTaunt
	if taunt:
		top = taunt.header_bottom() + 8.0
	var view: = get_viewport_rect().size.y
	if _box.size.y > view - top - 16.0:
		_box.scale = Vector2.ONE * (view - top - 16.0) / _box.size.y
		_box.pivot_offset = Vector2(_box.size.x / 2.0, 0)
	_box.position.y = maxf(top, (view - _box.size.y * _box.scale.y) / 2.0)

func _clear() -> void :
	for c in get_children():
		remove_child(c)
		c.queue_free()



const SOUL_COLOR: = Color(0.72, 0.9, 1.0)
const SLAM_AT: = 0.55

func _slam(label: Label) -> void :
	label.modulate.a = 0.0
	var tw: = label.create_tween()
	tw.tween_interval(SLAM_AT)
	tw.tween_callback( func() -> void :
		label.pivot_offset = label.size / 2.0
		label.scale = Vector2.ONE * 3.2
		label.rotation = -0.12
		label.modulate.a = 0.0)
	tw.tween_property(label, "modulate:a", 1.0, 0.08)
	tw.parallel().tween_property(label, "scale", Vector2.ONE * 0.92, 0.16).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tw.parallel().tween_property(label, "rotation", 0.03, 0.16)
	tw.tween_callback( func() -> void :
		Game.sfx("thud")
		_dust(label)
		var jolt: = _box.create_tween()
		var y: = _box.position.y
		jolt.tween_property(_box, "position:y", y + 10.0, 0.05)
		jolt.tween_property(_box, "position:y", y, 0.18).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT))
	tw.tween_property(label, "scale", Vector2.ONE, 0.2).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.parallel().tween_property(label, "rotation", 0.0, 0.2)


func _dust(label: Label) -> void :
	var puff: = Control.new()
	puff.mouse_filter = Control.MOUSE_FILTER_IGNORE
	puff.top_level = true
	puff.position = label.global_position + Vector2(label.size.x / 2.0, label.size.y * 0.8)
	add_child(puff)
	var bits: Array = []
	for i in 16:
		var dir: = -1.0 if i % 2 == 0 else 1.0
		bits.append([Vector2(dir * randf_range(30, 230), randf_range(-14, 10)), randf_range(12, 26), randf_range(0.0, 0.15)])
	var t: = [0.0]
	puff.draw.connect( func() -> void :
		var k: float = t[0]
		for b: Array in bits:
			var e: = clampf((k - b[2]) / 0.6, 0.0, 1.0)
			if e <= 0.0 or e >= 1.0:
				continue
			var at: Vector2 = b[0] * (1.0 - pow(1.0 - e, 3.0)) + Vector2(0, -26.0 * e)
			var r: float = b[1] * (0.6 + 0.9 * e)
			puff.draw_circle(at, r, Color(0.7, 0.62, 0.55, 0.7 * (1.0 - e)))
			puff.draw_circle(at + Vector2( - r * 0.3, - r * 0.3), r * 0.55, Color(0.9, 0.84, 0.76, 0.45 * (1.0 - e))))
	var tw: = puff.create_tween()
	tw.tween_method( func(v: float) -> void :
		t[0] = v
		puff.queue_redraw(), 0.0, 0.8, 0.8)
	tw.tween_callback(puff.queue_free)




const BAR_DELAY: = 0.35
const BAR_FILL: = 1.3

func _survival_bar(secs: int, won: bool) -> Control:
	var t: = Game.theme
	var goal: = maxf(t.win_time, 1.0)
	var share: = clampf(secs / goal, 0.0, 1.0)
	var bar: = Control.new()
	bar.custom_minimum_size = Vector2(600, 96)
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var state: = {"k": 0.0, "flare": 0.0, "last_tick": -1}
	var boss_times: Array[float] = []
	for b: Dictionary in t.bosses:
		boss_times.append(float(b.get("at", 0.0)) / goal)
	var skull: = t.texture(t.taunt_sprite) if t.sprites.has(t.taunt_sprite) else null
	bar.draw.connect( func() -> void :
		var font: = ThemeDB.fallback_font
		var k: float = state["k"]
		var shown: = int(secs * k / maxf(share, 0.001)) if share > 0.0 else 0
		shown = mini(shown, secs)
		var head: = "%02d:%02d" % [shown / 60, shown % 60]
		var tail: = "  /  %02d:00" % (int(goal) / 60)
		var hw: = font.get_string_size(head, HORIZONTAL_ALIGNMENT_LEFT, -1, 40).x
		var tw: = font.get_string_size(tail, HORIZONTAL_ALIGNMENT_LEFT, -1, 28).x
		var x0: = 300.0 - (hw + tw) / 2.0
		bar.draw_string_outline(font, Vector2(x0, 36), head, HORIZONTAL_ALIGNMENT_LEFT, -1, 40, 8, Color.BLACK)
		bar.draw_string(font, Vector2(x0, 36), head, HORIZONTAL_ALIGNMENT_LEFT, -1, 40, Color.WHITE)
		bar.draw_string(font, Vector2(x0 + hw, 36), tail, HORIZONTAL_ALIGNMENT_LEFT, -1, 28, Color(1, 1, 1, 0.55))
		var r: = Rect2(20, 52, 560, 30)
		bar.draw_rect(r.grow(3), Color(0, 0, 0, 0.8))
		bar.draw_rect(r, Color(0.16, 0.05, 0.04))
		var fill: = r
		fill.size.x = r.size.x * k
		if fill.size.x > 0.5:
			var hot: Color = t.ui.get("holy", Color(1, 0.93, 0.55)) if won else t.ui["accent"]
			var cold: Color = t.ui["hp"].darkened(0.2)
			var steps: = 28
			for i in steps:
				var a: = float(i) / steps
				var seg: = Rect2(r.position.x + r.size.x * a, r.position.y, r.size.x / steps + 1.0, r.size.y)
				if seg.position.x >= fill.end.x:
					break
				seg.size.x = minf(seg.size.x, fill.end.x - seg.position.x)
				bar.draw_rect(seg, cold.lerp(hot, a))
			bar.draw_rect(Rect2(fill.position, Vector2(fill.size.x, 6)), Color(1, 1, 1, 0.25))
			bar.draw_rect(Rect2(fill.end.x - 3, r.position.y - 2, 3, r.size.y + 4), Color(1, 1, 1, 0.9))
		for at: float in boss_times:
			var x: = r.position.x + r.size.x * at
			var passed: = at <= k
			bar.draw_rect(Rect2(x - 1, r.position.y, 2, r.size.y), Color(0, 0, 0, 0.6))
			if skull:
				var sz: = skull.get_size() * (20.0 / maxf(skull.get_height(), 1.0))
				bar.draw_texture_rect(skull, Rect2(Vector2(x - sz.x / 2.0, r.end.y + 1), sz), false, 
					Color(1, 1, 1, 1.0) if passed else Color(0.4, 0.4, 0.4, 0.7))
		bar.draw_rect(r.grow(3), Color(t.ui["accent"], 0.7), false, 2.0)
		var pct: = "%d%%" % int(round(100.0 * share * minf(k / maxf(share, 0.001), 1.0)))
		var px: = clampf(fill.end.x, r.position.x + 30.0, r.end.x - 30.0)
		bar.draw_string_outline(font, Vector2(px - 40, r.position.y + 23), pct, HORIZONTAL_ALIGNMENT_CENTER, 80, 22, 6, Color.BLACK)
		bar.draw_string(font, Vector2(px - 40, r.position.y + 23), pct, HORIZONTAL_ALIGNMENT_CENTER, 80, 22, Color.WHITE)
		var flare: float = state["flare"]
		if flare > 0.0:
			bar.draw_rect(r.grow(3 + 10.0 * (1.0 - flare)), Color(1, 0.95, 0.6, flare), false, 4.0))
	var tw: = bar.create_tween()
	tw.tween_interval(BAR_DELAY)
	tw.tween_method( func(v: float) -> void :
		state["k"] = v
		var tick: = int(v * 20.0)
		if tick != state["last_tick"]:
			state["last_tick"] = tick
			Game.sfx("coin", 0.8 + v * 0.8)
		bar.queue_redraw(), 0.0, share, maxf(0.5, BAR_FILL * share)).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_callback( func() -> void :
		Game.sfx("level_up" if won else "select")
		if won:
			state["flare"] = 1.0)
	if won:
		tw.tween_method( func(v: float) -> void :
			state["flare"] = v
			bar.queue_redraw(), 1.0, 0.0, 0.6)
	return bar


func _count_up(label: Label, target: int) -> void :
	label.pivot_offset = Vector2(300, 48)
	var tw: = label.create_tween()
	tw.tween_method( func(v: float) -> void : label.text = HUD.format_score(int(v)), 0.0, float(target), 1.4).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	tw.tween_property(label, "scale", Vector2.ONE * 1.18, 0.1)
	tw.tween_property(label, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

func _add_dim() -> void :
	var dim: = ColorRect.new()
	var taunt: = get_tree().get_first_node_in_group("death_taunt")
	dim.color = Color(0, 0, 0, 0.0 if taunt else 0.75)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(dim)

func _start_box() -> void :
	_box = VBoxContainer.new()
	_box.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_box.custom_minimum_size = Vector2(600, 0)
	_box.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_box.grow_vertical = Control.GROW_DIRECTION_BOTH
	_box.add_theme_constant_override("separation", 12)
	add_child(_box)

func _build(summary: Dictionary, rank: int) -> void :
	var t: = Game.theme
	_add_dim()
	_start_box()
	var won: bool = summary.get("won", false)
	_box.add_child(_label("VICTORY!" if won else t.death_title, 72, t.ui.get("holy", Color(1, 0.93, 0.55)) if won else t.ui["hp"], 14))
	_box.add_child(_label("SCORE", 30, Color(1, 1, 1, 0.7)))
	var score: = _label("0", 84, t.ui["accent"], 16)
	_box.add_child(score)
	_count_up(score, summary["score"])
	if rank == 0:
		var best: = _label("NEW BEST!", 40, t.ui.get("holy", Color(1, 0.93, 0.55)), 10)
		_box.add_child(best)
		_pulse(best)
	elif rank > 0:
		_box.add_child(_label("#%d on your top scores" % (rank + 1), 30, Color.WHITE))
	var secs: = int(summary["time"])
	var souls: int = summary["coins"] + summary.get("bonus", 0)
	if Game.theme.difficulties.size() > 1:
		_box.add_child(_label(str(Game.tier_info(summary.get("tier", 0))["name"]), 28, Color(1, 1, 1, 0.65)))
	var offer_double: = souls > 0 and not Game.dev_mode and Ads.can_show()
	_box.add_child(_survival_bar(secs, won))
	_box.add_child(_label("Lv %d  ·  %d kills" % [summary["level"], summary["kills"]], 26, Color(1, 1, 1, 0.8)))
	if souls > 0:
		var earned: = _label("+%d %s" % [souls, t.currency], 56, SOUL_COLOR, 12)
		_box.add_child(earned)
		_slam(earned)
		if offer_double:
			_double_button = _button("DOUBLE YOUR %s  x2  (watch a video)" % t.currency.to_upper(), 
				t.ui.get("holy", Color(1, 0.93, 0.55)), func() -> void : _double_souls(earned, summary, souls))
			_double_button.add_theme_font_size_override("font_size", 28)
			_box.add_child(_double_button)
			_pulse(_double_button)

	var news: Array = Game.progress.news
	if not news.is_empty() and not Game.dev_mode:
		_box.add_child(_news_panel(news))
	_box.add_child(_top_scores(rank, 3 if offer_double or not news.is_empty() else SHOWN_SCORES))
	_box.add_child(_button("Play Again", t.ui["accent"], func() -> void :
		get_tree().paused = false
		LoadingCover.go(get_tree(), get_tree().reload_current_scene)))
	_box.add_child(_button("Main Menu", Color(1, 1, 1, 0.6), func() -> void :
		get_tree().paused = false
		get_tree().change_scene_to_file("res://menu.tscn")))



func _double_souls(earned: Label, summary: Dictionary, souls: int) -> void :
	_double_button.disabled = true
	Ads.show_rewarded( func(ok: bool) -> void :
		if not is_instance_valid(_double_button):
			return
		if not ok:
			_double_button.disabled = false
			return
		Game.coins += souls
		Game.track_souls(souls)
		Game.save_profile()
		summary["bonus"] = summary.get("bonus", 0) + souls
		Game.sfx("holy")
		var t: = Game.theme
		earned.pivot_offset = earned.size / 2.0
		var tw: = earned.create_tween()
		tw.tween_method( func(v: float) -> void : earned.text = "+%d %s" % [int(v), t.currency], float(souls), float(souls * 2), 1.2)\
		.set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
		tw.tween_property(earned, "scale", Vector2.ONE * 1.3, 0.12)
		tw.tween_property(earned, "scale", Vector2.ONE, 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		earned.add_theme_color_override("font_color", t.ui.get("holy", Color(1, 0.93, 0.55)))
		_double_button.text = "%s DOUBLED!" % t.currency.to_upper()
		_double_button.create_tween().tween_property(_double_button, "modulate:a", 0.6, 0.4))


func _news_panel(news: Array) -> Control:
	var panel: = PanelContainer.new()
	var holy: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
	panel.add_theme_stylebox_override("panel", _panel_style(holy))
	var col: = VBoxContainer.new()
	col.add_theme_constant_override("separation", 6)
	panel.add_child(col)
	col.add_theme_constant_override("separation", 10)
	col.add_child(_label("NEW THIS RUN", 30, holy))
	var order: = ["unlock", "fusion", "holy", "achievement", "quest"]
	var sorted: = news.duplicate()
	sorted.sort_custom( func(a: Dictionary, b: Dictionary) -> bool: return order.find(a["kind"]) < order.find(b["kind"]))
	for i in mini(sorted.size(), MAX_NEWS):
		var n: Dictionary = sorted[i]
		var row: = HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		var icon: = TextureRect.new()
		icon.texture = Game.theme.texture(n["icon"]) if n["icon"] != "" else null
		icon.custom_minimum_size = Vector2(48, 48)
		icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		row.add_child(icon)
		var texts: = VBoxContainer.new()
		texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		texts.add_theme_constant_override("separation", 2)
		var title: = _label(n["title"], 24, Color.WHITE if n["kind"] != "unlock" else holy)
		title.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
		texts.add_child(title)
		if n["text"] != "":
			var sub: = _label(n["text"], 18, Color(1, 1, 1, 0.6))
			sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
			sub.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			texts.add_child(sub)
		row.add_child(texts)
		col.add_child(row)
	if sorted.size() > MAX_NEWS:
		col.add_child(_label("+%d more" % (sorted.size() - MAX_NEWS), 20, Color(1, 1, 1, 0.6)))
	return panel

func _top_scores(rank: int, shown: = SHOWN_SCORES) -> Control:
	var panel: = PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _panel_style(Color(1, 1, 1, 0.25)))
	var col: = VBoxContainer.new()
	col.add_theme_constant_override("separation", 6)
	panel.add_child(col)
	col.add_child(_label("TOP SCORES", 30, Game.theme.ui["accent"]))
	for i in mini(Game.high_scores.size(), shown):
		var e: Dictionary = Game.high_scores[i]
		var color: Color = Game.theme.ui["accent"] if i == rank else Color.WHITE
		var row: = HBoxContainer.new()
		var secs: = int(e.get("time", 0))
		row.add_child(_cell("%d." % (i + 1), 56, color))
		row.add_child(_cell(HUD.format_score(e["score"]), 0, color, true))
		row.add_child(_cell("%02d:%02d" % [secs / 60, secs % 60], 110, color))
		row.add_child(_cell("Lv %d" % e.get("level", 1), 90, color))
		col.add_child(row)
	if Game.high_scores.is_empty():
		col.add_child(_label("No scores yet", 26, Color(1, 1, 1, 0.6)))
	return panel

func _cell(text: String, width: float, color: Color, expand: = false) -> Label:
	var l: = Label.new()
	l.text = text
	l.custom_minimum_size.x = width
	if expand:
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.add_theme_font_size_override("font_size", 28)
	l.add_theme_color_override("font_color", color)
	return l

func _label(text: String, font_size: int, color: Color, outline: = 0) -> Label:
	var l: = Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	if outline > 0:
		l.add_theme_color_override("font_outline_color", Color.BLACK)
		l.add_theme_constant_override("outline_size", outline)
	return l

func _pulse(node: Control) -> void :
	node.resized.connect( func() -> void : node.pivot_offset = node.size / 2.0)
	var tween: = node.create_tween().set_loops()
	tween.tween_property(node, "scale", Vector2.ONE * 1.12, 0.4).set_trans(Tween.TRANS_SINE)
	tween.tween_property(node, "scale", Vector2.ONE, 0.4).set_trans(Tween.TRANS_SINE)

func _button(text: String, border: Color, action: Callable) -> Button:
	var b: = Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 96)
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", 34)
	for state: String in ["normal", "hover", "pressed"]:
		var style: = _panel_style(border)
		if state == "pressed":
			style.bg_color = style.bg_color.lightened(0.15)
		b.add_theme_stylebox_override(state, style)
	b.pressed.connect( func() -> void :
		Game.sfx("click")
		action.call())
	return b

func _panel_style(border: Color) -> StyleBoxFlat:
	var style: = StyleBoxFlat.new()
	style.bg_color = Game.theme.ui["panel"]
	style.border_color = border
	style.set_border_width_all(3)
	style.set_corner_radius_all(12)
	style.set_content_margin_all(16)
	return style
