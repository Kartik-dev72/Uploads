class_name Bulwark
extends Weapon





const ID: = "bulwark"
const COOLDOWN_TEXT: = "recharges %d%% faster"
const BURST_RADIUS: = 190.0
const PUSH: = 700.0
const GUARD: = 0.35

const BASE: = {"damage": 25.0, "cooldown": 10.0, "count": 1, "area": 1.0}
const UPGRADES: = [
	{"cooldown": 0.85}, 
	{"damage": 10.0}, 
	{"area": 1.2}, 
	{"cooldown": 0.85}, 
	{"damage": 15.0}, 
	{"area": 1.2}, 
	{"cooldown": 0.85}, 
]


const HOLY: = {"damage": 25.0, "count": 1, "cooldown": 0.8}
const SMITES: = 6
const SMITE_SHOW: = 0.4

var damage: = 25.0
var cooldown: = 10.0
var count: = 1
var area: = 1.0
var charges: = 1
var _recharge: = 0.0
var _time: = 0.0
var _flash: = 0.0
var _guard: = 0.0
var _smites: Array[Dictionary] = []
var _sky: Node2D

func _on_level() -> void :
	Layers.put(self, Layers.PLAYER_EFFECTS)
	if _sky == null:
		_sky = Layers.canvas(self, Layers.SKY, _draw_smites, false)
	if charges < count and _recharge <= 0.0:
		_recharge = cooldown_of(cooldown)

func _ready() -> void :
	super ()
	charges = count

func _process(delta: float) -> void :
	_time += delta
	_flash = maxf(_flash - delta * 3.0, 0.0)
	_guard -= delta
	if not _smites.is_empty():
		for sm in _smites:
			sm["t"] += delta
		_smites = _smites.filter( func(sm: Dictionary) -> bool: return sm["t"] < SMITE_SHOW)
		_sky.queue_redraw()
	if charges < count:
		_recharge -= delta
		if _recharge <= 0.0:
			charges += 1
			_recharge = cooldown_of(cooldown)
			Game.sfx("reroll", 1.4)
	queue_redraw()


func absorb() -> bool:
	if _guard > 0.0:
		return true
	if charges <= 0:
		return false
	charges -= 1
	_guard = GUARD
	if _recharge <= 0.0:
		_recharge = cooldown_of(cooldown)
	_flash = 1.0
	var r: = area_of(BURST_RADIUS * area)
	for e: Enemy in Enemy.near(global_position, r):
		var d: = global_position.distance_to(e.global_position)
		if d < r + e.radius:
			e.take_damage(power(damage))
			e.knock(global_position.direction_to(e.global_position) * PUSH)
	RingFx.spawn(get_tree().current_scene, global_position, r, color)
	if holy:
		for e: Enemy in nearest_enemies_on_screen(SMITES):
			e.take_damage(power(damage))
			_smites.append({"at": e.global_position, "t": 0.0})
	Game.sfx("barrier")
	player.shake(6.0)
	FloatText.pop(player, "BARRIER!", global_position + Vector2(0, -80), color.lightened(0.4), 34, 0.9, 60.0, 1.6)
	return true


func _draw_smites() -> void :
	for sm in _smites:
		var at: = to_local(sm["at"])
		var k: float = 1.0 - sm["t"] / SMITE_SHOW
		PixelFx.rect(_sky, Rect2(at.x - 14.0 * k, at.y - 800.0, 28.0 * k, 800.0), Color(color, 0.35 * k))
		PixelFx.rect(_sky, Rect2(at.x - 4.0, at.y - 800.0, 8.0, 800.0), Color(1, 1, 1, 0.8 * k))
		PixelFx.disc(_sky, at, 30.0 * (1.5 - k), Color(1, 1, 1, 0.5 * k))


func _draw() -> void :
	var hot: = color.lightened(0.5)
	var r: = 54.0
	if holy and charges > 0:
		var beat: = sin(_time * 2.5) * 0.15
		for side: float in [-1.0, 1.0]:
			for f in 4:
				var base: = Vector2(side * (r - 6.0), -6.0 + f * 7.0)
				var tip: = base + Vector2(side * (34.0 - f * 6.0), -28.0 + f * 14.0 - beat * 30.0)
				PixelFx.poly(self, PackedVector2Array([base, tip, base + Vector2(side * 10.0, 8.0)]), Color(1, 1, 1, 0.75 - f * 0.12))
		PixelFx.rect(self, Rect2(-3, - r - 14, 6, 18), Color(color.lightened(0.3), 0.9))
		PixelFx.rect(self, Rect2(-8, - r - 9, 16, 5), Color(color.lightened(0.3), 0.9))
	if charges > 0:
		var pulse: = 0.5 + 0.5 * sin(_time * 3.0)
		PixelFx.disc(self, Vector2.ZERO, r, Color(color, 0.08 + 0.05 * pulse + 0.3 * _flash))
		PixelFx.arc(self, Vector2.ZERO, r, 0, TAU, Color(color, 0.35 + 0.2 * pulse), 2.0)
		for i in charges:
			var a: = _time * 1.4 + TAU * i / charges
			PixelFx.arc(self, Vector2.ZERO, r + 4.0, a, a + 1.4, Color(hot, 0.9), 5.0)
	elif _recharge > 0.0:
		var k: = 1.0 - _recharge / cooldown_of(cooldown)
		PixelFx.arc(self, Vector2.ZERO, r, - PI / 2.0, - PI / 2.0 + TAU * clampf(k, 0.0, 1.0), Color(color, 0.35), 3.0)
	if _flash > 0.0:
		PixelFx.arc(self, Vector2.ZERO, r + 60.0 * (1.0 - _flash), 0, TAU, Color(1, 1, 1, _flash), 6.0)
