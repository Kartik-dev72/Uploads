class_name MapChunk
extends Node2D











var _map: GameMap
var _coord: Vector2i
var _theme: GameTheme
var _decor: = Node2D.new()
var _solid: = Node2D.new()
var _ground: ImageTexture

func setup(map: GameMap, coord: Vector2i) -> void :
	_map = map
	_coord = coord
	_theme = Game.theme
	position = Vector2(coord * GameMap.CHUNK_SIZE)
	Layers.put(_decor, Layers.MAP_DETAIL)
	Layers.put(_solid, Layers.GROUND_OBJECTS)
	_decor.draw.connect(_draw_decor)
	_solid.draw.connect(_draw_obstacles)
	add_child(_decor)
	add_child(_solid)

func _draw() -> void :
	if _ground == null:
		draw_rect(Rect2(Vector2.ZERO, Vector2.ONE * GameMap.CHUNK_SIZE), _theme.map["ground_dark"])
		return
	draw_texture_rect(_ground, Rect2(Vector2.ZERO, Vector2.ONE * GameMap.CHUNK_SIZE), false)



func set_ground(img: Image) -> void :
	_ground = ImageTexture.create_from_image(img)
	queue_redraw()

func _draw_decor() -> void :
	var obstacles: = _map.obstacles_in(_coord)
	for o: Dictionary in obstacles:
		if o.has("b"):
			_wall_shadow(o)
		else:
			_shadow(o["pos"] - position, o["r"])
	var kinds: Array = _theme.map_decor
	if kinds.is_empty():
		return
	var rng: = RandomNumberGenerator.new()
	rng.seed = hash(Vector3i(_coord.x, _coord.y, _map.map_seed))
	for i in rng.randi_range(10, 18):
		var local: = Vector2(rng.randf(), rng.randf()) * GameMap.CHUNK_SIZE
		var kind: = GameMap.pick_weighted(kinds, rng)
		var flip: = rng.randf() < 0.5
		if not _fits(kind.get("on", "land"), _map.ground_at(position + local)) or _near_obstacle(position + local, obstacles):
			continue
		_sprite(_decor, kind["sprite"], kind["scale"], local, flip)


func _fits(on: String, g: int) -> bool:
	match on:
		"pool":
			return g == GameMap.Ground.DEEP or g == GameMap.Ground.VOID
		"any":
			return true
	return g == GameMap.Ground.LAND

func _near_obstacle(world: Vector2, obstacles: Array) -> bool:
	for o: Dictionary in obstacles:
		if GameMap.distance_to(o, world) < o["r"] + 40.0:
			return true
	return false


func _draw_obstacles() -> void :
	var list: = _map.obstacles_in(_coord).duplicate()
	list.sort_custom( func(a: Dictionary, b: Dictionary) -> bool: return _foot(a) < _foot(b))
	for o: Dictionary in list:
		if o.has("b"):
			_draw_wall(o)
			continue
		var tex: = _theme.rim_texture(o["sprite"], "obstacle_rim")
		var base: Vector2 = o["pos"] - position

		var size: = tex.get_size() * float(o["scale"])
		_solid.draw_texture_rect(tex, Rect2(base - Vector2(size.x / 2.0, size.y - o["r"] * 0.5), size), false)

func _foot(o: Dictionary) -> float:
	return maxf((o["pos"] as Vector2).y, (o.get("b", o["pos"]) as Vector2).y)



func _draw_wall(o: Dictionary) -> void :
	var style: Dictionary = o["wall"]
	var s: float = style.get("scale", 3.0)
	var a: Vector2 = o["pos"] - position
	var b: Vector2 = o["b"] - position
	var r: float = o["r"]
	var across: = absf(b.x - a.x) >= absf(b.y - a.y)
	var tex: = _theme.texture(style["h"] if across else style["v"])
	var size: = tex.get_size() * s
	if across:
		var x: = a.x
		while x < b.x - 1.0:
			var w: = minf(size.x, b.x - x)
			_solid.draw_texture_rect_region(tex, Rect2(Vector2(x, a.y + r * 0.5 - size.y), Vector2(w, size.y)), Rect2(Vector2.ZERO, Vector2(w / s, tex.get_size().y)))
			x += size.x
	else:
		var y: = a.y
		while y < b.y - 1.0:
			var h: = minf(size.y, b.y - y)
			_solid.draw_texture_rect_region(tex, Rect2(Vector2(a.x - size.x / 2.0, y - size.y * 0.5), Vector2(size.x, h)), Rect2(Vector2.ZERO, Vector2(tex.get_size().x, h / s)))
			y += size.y
	if style.has("post"):
		var post: = _theme.texture(style["post"])
		var ps: = post.get_size() * s
		for p: Vector2 in [a, b]:
			_solid.draw_texture_rect(post, Rect2(p - Vector2(ps.x / 2.0, ps.y - r * 0.6), ps), false)

func _wall_shadow(o: Dictionary) -> void :
	var a: Vector2 = o["pos"] - position
	var b: Vector2 = o["b"] - position
	var r: float = o["r"]
	_decor.draw_rect(Rect2(a - Vector2(r, - r * 0.2), (b - a) + Vector2(2.0 * r, r * 0.9)), Color(0, 0, 0, 0.3))

func _shadow(p: Vector2, r: float) -> void :
	_decor.draw_set_transform(p + Vector2(0, r * 0.35), 0.0, Vector2(1, 0.4))
	_decor.draw_circle(Vector2.ZERO, r * 1.4, Color(0, 0, 0, 0.3))
	_decor.draw_set_transform(Vector2.ZERO)

func _sprite(layer: CanvasItem, sprite: String, scale_: float, center: Vector2, flip: bool) -> void :
	var tex: = _theme.texture(sprite)

	layer.draw_set_transform(center, 0.0, Vector2( - scale_ if flip else scale_, scale_))
	layer.draw_texture(tex, - tex.get_size() / 2.0)
	layer.draw_set_transform(Vector2.ZERO)
