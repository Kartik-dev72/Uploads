class_name Grimoire
extends VBoxContainer









const CELL: = Vector2(96, 96)
const COLUMNS: = 6
const PAGE_WIDTH: = 600.0
const PARCHMENT: = Color(0.86, 0.78, 0.62)

var _page: CanvasLayer

func _ready() -> void :
	add_theme_constant_override("separation", 12)
	mouse_filter = Control.MOUSE_FILTER_PASS
	var t: = Game.theme
	var sections: = _sections()
	var found: = 0
	var total: = 0
	for sec: Array in sections:
		for e: Dictionary in sec[1]:
			total += 1
			found += 1 if e["found"] else 0
	add_child(_label("GRIMOIRE  %d / %d" % [found, total], 30, t.ui["accent"]))
	add_child(_label("Everything you have met in hell. Tap a page to read it.", 20, Color(1, 1, 1, 0.65)))
	for sec: Array in sections:
		var entries: Array = sec[1]
		var got: = entries.filter( func(e: Dictionary) -> bool: return e["found"]).size()
		add_child(_label("%s  %d / %d" % [sec[0], got, entries.size()], 24, t.ui["accent"]))
		var grid: = GridContainer.new()
		grid.columns = COLUMNS
		grid.add_theme_constant_override("h_separation", 10)
		grid.add_theme_constant_override("v_separation", 10)
		grid.mouse_filter = Control.MOUSE_FILTER_PASS
		add_child(grid)
		for e: Dictionary in entries:
			grid.add_child(_cell(e))



func _sections() -> Array:
	var t: = Game.theme
	var st: Dictionary = Game.progress.stats
	var out: Array = []
	var placed: = {}
	var boss_red: Color = t.ui["hp"]
	for i in t.difficulties.size():
		var realm: = str(t.difficulties[i].get("name", "Realm %d" % (i + 1)))
		var ids: Array = []
		for row: Dictionary in t.level_look(i, "spawn_table"):
			ids.append(row["enemy"])
		for row: Dictionary in t.level_look(i, "swarms"):
			ids.append(row["enemy"])
		var champ: = str(t.level_looks[i].get("champion", "")) if i < t.level_looks.size() else ""
		if champ == "":
			for ev: Dictionary in t.level_look(i, "events"):
				if ev.get("type", "") == "miniboss":
					champ = str(ev.get("enemy", ""))
		if champ != "":
			ids.append(champ)
		for row: Dictionary in t.level_look(i, "bosses"):
			ids.append(row["boss"])
		var more: Array = []
		for id: String in ids:
			more.append(id)
			var into: = str(t.enemies.get(id, {}).get("into", ""))
			if into != "":
				more.append(into)
		var entries: Array = []
		for id: String in more:
			var e: Dictionary = t.enemies.get(id, {})
			var name: = str(e.get("name", ""))
			if e.is_empty() or name == "" or placed.has(name) or e.get("motion", "") == "still":
				continue
			placed[name] = true
			entries.append(_monster(e, realm, id == champ, boss_red))
		if not entries.is_empty():
			out.append([realm.to_upper(), entries])

	for id: String in t.enemies:
		var e: Dictionary = t.enemies[id]
		var name: = str(e.get("name", ""))
		if name != "" and not placed.has(name) and e.get("motion", "") != "still" and not out.is_empty():
			placed[name] = true
			(out[0][1] as Array).append(_monster(e, "", false, boss_red))

	var elites: Array = []
	for kind: String in Enemy.ELITES:
		var stand: Dictionary = t.enemies.get(str(t.elite_stand_ins.get(kind, "")), t.enemies.values()[0])
		var lore: Array = t.elite_lore.get(kind, [kind.capitalize(), ""])
		var n: = int(st.get("elite_" + kind, 0))
		elites.append({"sprite": _sprite_of(stand), "name": "%s elite" % lore[0], "found": n > 0, "text": lore[1], 
			"lines": ["Slain: %s" % HUD.format_score(n)], "hint": "Not slain yet. Elites glow with their kind's color.", 
			"tint": t.elite_colors.get(kind, Color.WHITE), "frame": t.elite_colors.get(kind, Color.WHITE)})
	out.append(["ELITES", elites])

	var heroes: Array = []
	for s: Dictionary in t.survivors:
		var free: = Game.is_unlocked(s)
		var souls: = int(st.get("souls_" + str(s["id"]), 0))
		heroes.append({"sprite": s["sprite"], "name": "%s the %s" % [s["name"], s.get("title", "")], "found": free, 
			"text": str(t.survivor_lore.get(s["id"], s.get("perk", ""))), 
			"lines": [str(s.get("perk", "")), "Souls saved: %s" % HUD.format_score(souls)], 
			"hint": (str(s["secret"]) + "...") if s.has("secret") else ("\"%s...\"\n%s" % [str(s.get("riddle", "A lost soul waits in the dark")), Game.rescue_text(s)] if s.has("rescue") else "\"%s...\"\nFree this soul in the Survivors tab for %s %s" % [str(s.get("riddle", "A lost soul waits in the dark")), HUD.format_score(int(s.get("price", 0))), t.currency]), "frame": null})
	var all_souls: = 0
	for s: Dictionary in t.survivors:
		all_souls += int(st.get("souls_" + str(s["id"]), 0))
	out.append(["SURVIVORS  ·  %s souls saved in all" % HUD.format_score(all_souls), heroes])

	var weapons: Array = []
	var holies: Array = []
	for id: String in Game.WEAPONS:
		var w: = t.weapon(id)
		weapons.append({"sprite": w.get("icon", ""), "name": w.get("name", id), "found": st.get("wlvl_" + id, 0) > 0, 
			"text": w.get("description", ""), "lines": [], "hint": _unlock_hint(id), "frame": null})
		var pid: String = Game.EVOLUTIONS.get(id, "")
		holies.append({"sprite": w.get("holy_icon", w.get("icon", "")), "name": w.get("holy_name", id), "found": st.get("holy_" + id, 0) > 0, 
			"text": str(w.get("holy_tagline", "")) + ("\n" if w.get("holy_tagline", "") != "" else "") + str(w.get("holy_text", "")), 
			"lines": ["%s + %s" % [w.get("name", id), t.passive(pid).get("name", pid)]], 
			"hint": "A holy secret, not yet found", "frame": t.ui.get("holy", Color(1, 0.93, 0.55))})
	var passives: Array = []
	for id: String in Game.PASSIVES:
		var p: = t.passive(id)
		passives.append({"sprite": p.get("icon", ""), "name": p.get("name", id), "found": st.get("plvl_" + id, 0) > 0, 
			"text": Game.passive_text(id, 1, true) + ("\n" + Game.passive_about(id) if Game.passive_about(id) != "" else ""), 
			"lines": [], "hint": _unlock_hint(id), "frame": null})
	var pk: Dictionary = t.pickups
	var pickups: Array = []
	for row: Array in [
		[pk.get("coin", "coin"), t.currency.capitalize(), "Spend them in the shop", true], 
		[pk.get("heart", "heart"), t.pickup_name("heart"), "Restores HP", st.get("hearts", 0) > 0], 
		["soul_pouch", t.pickup_name("soul_pouch"), "%d %s" % [Pickup.POUCH, t.currency], st.get("soul_bags", 0) > 0], 
		["soul_coffer", t.pickup_name("soul_coffer"), "%d %s" % [Pickup.COFFER, t.currency], st.get("soul_bags", 0) > 0], 
		[pk.get("blessing", "blessing"), t.blessing_name.capitalize(), "Upgrades for what you own", st.get("chests", 0) > 0], 
		[pk.get("vacuum", "attractor_orb"), t.pickup_name("vacuum"), "Pulls in every XP gem on the map", st.get("vacuums", 0) > 0], 
		[pk.get("purge", "rosary"), t.pickup_name("purge"), "Destroys every demon on screen", st.get("purges", 0) > 0], 
		[pk.get("freeze", "ice_shard"), t.pickup_name("freeze"), "Freezes every demon for %d seconds" % int(Freeze.TIME), st.get("freezes", 0) > 0], 
		[pk.get("fever", "coin"), t.pickup_name("fever"), """Pulls in every soul, then kills drop extra souls for %d seconds; souls you pick up make it last
Best fever: %d %s""" %[int(SoulFever.TIME), int(st.get("fever_souls", 0)), t.currency], st.get("fevers", 0) > 0], 
		[pk.get("luck", "icon_star"), t.pickup_name("luck"), "+10% luck for the run", st.get("nails", 0) > 0], 
	]:
		pickups.append({"sprite": row[0], "name": row[1], "found": row[3], "text": row[2], "lines": [], "hint": "Not found yet", "frame": null})
	out.append(["WEAPONS", weapons])
	out.append(["HOLY WEAPONS", holies])
	out.append(["PASSIVES", passives])
	out.append(["PICKUPS", pickups])
	return out

func _monster(e: Dictionary, realm: String, champion: bool, boss_red: Color) -> Dictionary:
	var t: = Game.theme
	var name: = str(e.get("name", ""))
	var n: = int(Game.progress.stats.get("kill_" + name, 0))
	var boss: bool = e.get("boss", false)
	var role: = "Boss" if boss else ("Champion" if champion else "")
	var where: = ("%s of %s" % [role, realm]) if role != "" and realm != "" else ("Found in %s" % realm if realm != "" else "")

	var stats: = "Health %d  ·  Speed %d" % [int(e.get("hp", 0)), int(e.get("speed", 0))]
	return {"sprite": _sprite_of(e), "name": name, "found": n > 0, "text": str(t.lore.get(name, "")), 
		"lines": [where, stats, "Slain: %s" % HUD.format_score(n)].filter( func(l: String) -> bool: return l != ""), 
		"hint": "Not slain yet." + (" Lurks in %s." % realm if realm != "" else ""), 
		"frame": boss_red if boss else (t.elite_colors.get("champion", Color.WHITE) if champion else null)}


func _sprite_of(e: Dictionary) -> String:
	var s: = str(e.get("sprite", ""))
	return str(Game.survivor().get("sprite", "")) if s.begins_with("@") else s

func _unlock_hint(id: String) -> String:
	if Game.UNLOCKS.has(id) and not Game.progress.is_item_unlocked(id):
		return "Locked. " + Game.unlock_text(id)
	return "Not found yet"


func _cell(e: Dictionary) -> Control:
	var b: = Button.new()
	b.custom_minimum_size = CELL
	b.mouse_filter = Control.MOUSE_FILTER_PASS
	b.focus_mode = Control.FOCUS_NONE
	var frame: Variant = e.get("frame")
	if frame != null and e["found"]:
		for state: String in ["normal", "hover", "pressed"]:
			var sb: = StyleBoxFlat.new()
			sb.bg_color = Color(0.1, 0.05, 0.06, 0.9)
			sb.border_color = frame
			sb.set_border_width_all(3)
			sb.set_corner_radius_all(8)
			b.add_theme_stylebox_override(state, sb)
	if e["found"]:
		var icon: = TextureRect.new()
		icon.texture = Game.theme.texture(str(e["sprite"]))
		icon.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		icon.offset_left = 10
		icon.offset_top = 10
		icon.offset_right = -10
		icon.offset_bottom = -10
		icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
		if e.has("tint"):
			icon.modulate = (e["tint"] as Color).lerp(Color.WHITE, 0.35)
		b.add_child(icon)
	else:
		b.text = "?"
		b.add_theme_font_size_override("font_size", 44)
		b.add_theme_color_override("font_color", Color(1, 1, 1, 0.3))
	b.pressed.connect( func() -> void :
		Game.sfx("click")
		_open_page(e))
	return b


func _open_page(e: Dictionary) -> void :
	_close_page()
	var t: = Game.theme
	_page = CanvasLayer.new()
	_page.layer = 30
	add_child(_page)
	var dim: = ColorRect.new()
	dim.color = Color(0, 0, 0, 0.75)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.gui_input.connect( func(ev: InputEvent) -> void :
		if ev is InputEventMouseButton and ev.pressed:
			_close_page())
	_page.add_child(dim)
	var sheet: = PanelContainer.new()
	var sb: = StyleBoxFlat.new()
	sb.bg_color = Color(0.17, 0.1, 0.08)
	sb.border_color = t.ui["accent"]
	sb.set_border_width_all(4)
	sb.set_corner_radius_all(14)
	sb.set_content_margin_all(26)
	sb.shadow_color = Color(0, 0, 0, 0.6)
	sb.shadow_size = 18
	sheet.add_theme_stylebox_override("panel", sb)
	sheet.custom_minimum_size = Vector2(PAGE_WIDTH, 0)
	sheet.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var view: = get_viewport().get_visible_rect().size
	sheet.position = Vector2((view.x - PAGE_WIDTH) / 2.0, view.y * 0.16)
	_page.add_child(sheet)
	var col: = VBoxContainer.new()
	col.add_theme_constant_override("separation", 14)
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	sheet.add_child(col)
	var pic: = Control.new()
	pic.custom_minimum_size = Vector2(0, 240)
	pic.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_child(pic)
	var found: bool = e["found"]
	var tex: Texture2D = Game.theme.texture(str(e["sprite"])) if found else null
	var tint: Color = (e["tint"] as Color).lerp(Color.WHITE, 0.35) if e.has("tint") else Color.WHITE
	var glow: Color = e["frame"] if e.get("frame") != null else t.ui["accent"]
	pic.draw.connect( func() -> void :
		var c: = pic.size / 2.0
		pic.draw_circle(c, 110.0, Color(glow, 0.12))
		pic.draw_arc(c, 110.0, 0.0, TAU, 48, Color(glow, 0.5), 2.0)
		if tex:
			var fit: = minf(200.0 / tex.get_width(), 200.0 / tex.get_height())
			var sz: = tex.get_size() * fit
			pic.draw_texture_rect(tex, Rect2(c - sz / 2.0, sz), false, tint)
		else:
			var font: = ThemeDB.fallback_font
			var w: = font.get_string_size("?", HORIZONTAL_ALIGNMENT_LEFT, -1, 120).x
			pic.draw_string(font, c + Vector2( - w / 2.0, 42), "?", HORIZONTAL_ALIGNMENT_LEFT, -1, 120, Color(1, 1, 1, 0.35)))
	col.add_child(_label(str(e["name"]) if found else "???", 36, t.ui["accent"], true))
	if found:
		if str(e["text"]) != "":
			col.add_child(_label(str(e["text"]), 23, PARCHMENT, true))
		for line: String in e["lines"]:
			if line != "":
				col.add_child(_label(line, 21, Color(1, 1, 1, 0.75), true))
	else:
		col.add_child(_label(str(e["hint"]), 23, Color(1, 1, 1, 0.6), true))
	col.add_child(_label("Tap to close", 18, Color(1, 1, 1, 0.4), true))

func _close_page() -> void :
	close_page()


func close_page() -> bool:
	var was: = is_instance_valid(_page)
	if was:
		_page.queue_free()
	_page = null
	return was

func _label(text: String, font_size: int, color: Color, center: = false) -> Label:
	var label: = Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if center:
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	return label
