class_name Shrines
extends Node2D
















const CELL: = 4000.0
const JITTER: = 380.0
const CHANCE: = 0.8
const ACTIVE: = 1500.0
const CHECK_EVERY: = 0.5
const START_CLEAR: = 1600.0
const TRAILS: = 3
const TRAIL_STEPS: = 48
const TRAIL_STEP: = 38.0


const WEIGHTS: = [
	[Pickup.Kind.HEART, 0, 3.0], [Pickup.Kind.FREEZE, 0, 1.0], [Pickup.Kind.VACUUM, 0, 1.0], [Pickup.Kind.COIN, Pickup.COFFER, 1.0], 
	[Pickup.Kind.PURGE, 0, 0.5], [Pickup.Kind.FEVER, 0, 1.0], [Pickup.Kind.LUCK, 0, 0.5], 
]

static var resume_taken: Array = []

var map: GameMap
var _spots: = {}
var _timer: = 0.0
var _time: = 0.0
var _trail_canvas: Node2D
var _here: = Vector2i(1 << 20, 0)

func _ready() -> void :
	add_to_group("shrines")
	Layers.put(self, Layers.GROUND_OBJECTS)
	_trail_canvas = Layers.canvas(self, Layers.MAP_DETAIL, _draw_trails, false)
	for c: Vector2i in resume_taken:
		var spot: = _roll(c)
		if not spot.is_empty():
			spot["taken"] = true
			_spots[c] = spot
	resume_taken = []


func save_state() -> Array:
	var taken: Array = []
	for c: Vector2i in _spots:
		var spot: Dictionary = _spots[c]
		if not spot.is_empty() and spot["taken"]:
			taken.append(c)
	return taken

func _process(delta: float) -> void :
	_time += delta
	queue_redraw()
	_timer -= delta
	if _timer > 0.0:
		return
	_timer = CHECK_EVERY
	var player: = get_tree().get_first_node_in_group("player") as Node2D
	if player == null:
		return
	var at: = player.global_position
	var here: = Vector2i((at / CELL).floor())
	var changed: = here != _here
	_here = here
	for x in range(here.x - 1, here.x + 2):
		for y in range(here.y - 1, here.y + 2):
			var c: = Vector2i(x, y)
			if not _spots.has(c):
				_spots[c] = _roll(c)
				changed = true
	for c: Vector2i in _spots.keys():
		var spot: Dictionary = _spots[c]
		var loaded: bool = absi(c.x - here.x) <= 1 and absi(c.y - here.y) <= 1
		if spot.is_empty():
			if not loaded:
				_spots.erase(c)
			continue


		if spot["out"] and not is_instance_valid(spot["pickup"]):
			spot["pickup"] = null
			spot["out"] = false
			spot["taken"] = true
		var near: bool = (spot["pos"] as Vector2).distance_to(at) < ACTIVE
		if near and not spot["taken"] and not spot["out"]:
			var w: Array = spot["what"]
			var pick: = Pickup.spawn(get_tree().current_scene, w[0], spot["pos"], maxi(w[1], 1))
			pick.position = spot["pos"]
			spot["pickup"] = pick
			spot["out"] = true
		elif not near and spot["out"]:
			(spot["pickup"] as Node).queue_free()
			spot["pickup"] = null
			spot["out"] = false
		if not loaded and not spot["taken"]:
			_spots.erase(c)
			changed = true
	if changed:
		_trail_canvas.queue_redraw()


func _roll(c: Vector2i) -> Dictionary:
	var rng: = RandomNumberGenerator.new()
	rng.seed = hash(Vector3i(c.x, c.y, (map.map_seed if map else 0) + 7919))
	if rng.randf() >= CHANCE:
		return {}
	var middle: = (Vector2(c) + Vector2(0.5, 0.5)) * CELL
	var pos: = middle + Vector2(rng.randf_range( - JITTER, JITTER), rng.randf_range( - JITTER, JITTER))
	if pos.length() < START_CLEAR or (map and not map.in_band(pos, 150.0)):
		return {}
	pos = GameMap.reachable(pos)
	if map:
		pos = map.push_out(pos, 60.0)
	var total: = 0.0
	for w: Array in WEIGHTS:
		total += w[2]
	var roll: = rng.randf() * total
	var what: Array = WEIGHTS[0]
	for w: Array in WEIGHTS:
		roll -= w[2]
		if roll <= 0.0:
			what = w
			break
	var trails: Array = []
	var first: = rng.randf() * TAU
	for i in TRAILS:
		var heading: = first + TAU * i / TRAILS + rng.randf_range(-0.5, 0.5)
		var p: = pos + Vector2.RIGHT.rotated(heading) * 70.0
		var pts: = PackedVector2Array()
		for s in TRAIL_STEPS:
			heading += rng.randf_range(-0.28, 0.28)
			p += Vector2.RIGHT.rotated(heading) * TRAIL_STEP
			pts.append(p)
		trails.append(pts)
	return {"pos": pos, "what": what, "pickup": null, "out": false, "taken": false, "trails": trails}


func _shown(c: Vector2i) -> bool:
	return absi(c.x - _here.x) <= 1 and absi(c.y - _here.y) <= 1

func _draw_trails() -> void :
	for c: Vector2i in _spots:
		var spot: Dictionary = _spots[c]
		if spot.is_empty() or not _shown(c):
			continue
		for pts: PackedVector2Array in spot["trails"]:
			for i in pts.size():
				var fade: = 1.0 - float(i) / pts.size()
				var at: = pts[i] - global_position
				var h: = hash(Vector2i(roundi(at.x), roundi(at.y)))
				var off: = Vector2(float(h % 9) - 4.0, float((h / 9) % 7) - 3.0)
				PixelFx.rect(_trail_canvas, Rect2(at + off - Vector2(13, 6), Vector2(26, 12)), Color(0, 0, 0, 0.05 + 0.13 * fade))
				PixelFx.rect(_trail_canvas, Rect2(at - off * 0.5 - Vector2(8, 4), Vector2(16, 8)), Color(0, 0, 0, 0.04 + 0.08 * fade))
				if h % 3 == 0:
					var side: = Vector2( - off.y, off.x).normalized() * 18.0 * (1.0 if h % 2 == 0 else -1.0)
					PixelFx.rect(_trail_canvas, Rect2(at + side - Vector2(3, 2), Vector2(6, 4)), Color(0.75, 0.7, 0.65, 0.12 + 0.3 * fade))



func _draw() -> void :
	var holy: Color = Game.theme.ui.get("holy", Color(1, 0.93, 0.55))
	for c: Vector2i in _spots:
		var spot: Dictionary = _spots[c]
		if spot.is_empty() or not _shown(c):
			continue
		var at: Vector2 = spot["pos"] - global_position + Vector2(0, 14)
		var full: bool = not spot["taken"]
		var pulse: = 0.5 + 0.5 * sin(_time * 2.2 + at.x * 0.01)

		draw_arc(at + Vector2(0, -4), 74.0, 0.0, TAU, 48, Color(0, 0, 0, 0.35), 6.0)
		draw_arc(at + Vector2(0, -4), 74.0, 0.0, TAU, 48, Color(holy, (0.2 + 0.25 * pulse) if full else 0.08), 2.0)
		for k in 8:
			var a: = TAU * k / 8.0 + (_time * 0.15 if full else 0.0)
			PixelFx.rect(self, Rect2(at + Vector2(0, -4) + Vector2.RIGHT.rotated(a) * 74.0 - Vector2(3, 3), Vector2(6, 6)), 
				Color(holy, (0.35 + 0.4 * pulse) if full else 0.12))
		if full:
			PixelFx.rect(self, Rect2(at + Vector2(-16, -260), Vector2(32, 260)), Color(holy, 0.05 + 0.05 * pulse))
			PixelFx.rect(self, Rect2(at + Vector2(-7, -260), Vector2(14, 260)), Color(holy, 0.05 + 0.04 * pulse))

		PixelFx.rect(self, Rect2(at + Vector2(-40, 2), Vector2(80, 14)), Color(0.12, 0.1, 0.12))
		PixelFx.rect(self, Rect2(at + Vector2(-38, 4), Vector2(76, 10)), Color(0.34, 0.3, 0.32))
		PixelFx.rect(self, Rect2(at + Vector2(-30, -8), Vector2(60, 12)), Color(0.12, 0.1, 0.12))
		PixelFx.rect(self, Rect2(at + Vector2(-28, -6), Vector2(56, 10)), Color(0.46, 0.42, 0.44))
		PixelFx.rect(self, Rect2(at + Vector2(-28, -6), Vector2(56, 3)), Color(0.64, 0.6, 0.6))
		PixelFx.rect(self, Rect2(at + Vector2(-6, 6), Vector2(12, 4)), Color(holy, 0.5 if full else 0.15))
		for side: float in [-1.0, 1.0]:
			var candle: = at + Vector2(side * 24, -8)
			PixelFx.rect(self, Rect2(candle + Vector2(-3, -16), Vector2(6, 16)), Color(0.92, 0.88, 0.78))
			var flick: = sin(_time * 9.0 + side * 2.0)
			PixelFx.rect(self, Rect2(candle + Vector2(-2 + flick * 0.6, -22), Vector2(4, 6)), Color(1, 0.7, 0.25))
			PixelFx.rect(self, Rect2(candle + Vector2(-1, -25), Vector2(2, 3)), Color(1, 0.95, 0.7))
			draw_circle(candle + Vector2(0, -20), 12.0 + 2.0 * flick, Color(1, 0.7, 0.3, 0.1))
		if full:
			var relic: = at + Vector2(0, -30)
			for k in 3:
				draw_circle(relic, (26.0 + 12.0 * k) * (0.9 + 0.15 * pulse), Color(holy, 0.1 - 0.025 * k))
			draw_arc(relic, 40.0 + 6.0 * pulse, 0.0, TAU, 32, Color(holy, 0.35 * pulse), 2.0)
			for m in 6:
				var ph: = fmod(_time * 0.5 + m / 6.0, 1.0)
				var mote: = relic + Vector2(sin(m * 2.1 + _time) * 26.0, 10.0 - ph * 70.0)
				PixelFx.rect(self, Rect2(mote, Vector2(3, 3)), Color(holy, (1.0 - ph) * 0.8))
