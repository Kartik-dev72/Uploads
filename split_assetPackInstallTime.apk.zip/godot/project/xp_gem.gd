class_name XPGem
extends Node2D



















const MAX_GEMS: = 400



const HARD_MAX_GEMS: = 800
const GRID_CELL: = 128.0
static var _grid: = {}
static var _field: Node
const VACUUM_SPEED: = 1300.0
const VACUUM_ACCEL: = 1500.0




const KICK_SPEED: = 340.0
const TIERS: = [1, 3, 10]

@export var value: = 1
@export var max_speed: = 900.0
@export var acceleration: = 2900.0

const STREAK_TIME: = 0.35

static var _streak: = 0
static var _last_pickup: = 0
static var _slots: Array = []
static var _free_slots: Array[int] = []
static var _textures: = {}

var mergeable: = true
var magnetic: = true
var vacuumable: = true

var _player: Player
var _vel: = Vector2.ZERO
var _attracted: = false
var _flash: = 0.0
var _tier: = -1
var _slot: = -1
var _wants_slot: = false
var _cell: = Vector2i(1 << 30, 0)

static func drop(parent: Node, pos: Vector2, amount: int) -> void :
	pos = GameMap.reachable(pos)
	var leftover: = 0
	if _gem_count() + 1 > MAX_GEMS:
		leftover = _condense(parent.get_viewport(), MAX_GEMS - 1)
	if _gem_count() + 1 > HARD_MAX_GEMS:
		for i in range(_slots.size() - 1, -1, -1):
			var host: XPGem = _slots[i]
			if host != null and is_instance_valid(host) and host.is_inside_tree() and not host.is_queued_for_deletion():
				host.add_value(amount + leftover)
				return
	var gem: = XPGem.new()
	gem.value = amount + leftover
	gem.position = pos
	gem._wants_slot = true
	parent.add_child.call_deferred(gem)

static func _gem_count() -> int:
	return _slots.size() - _free_slots.size()

func _take_slot() -> void :
	if _free_slots.is_empty():
		_slot = _slots.size()
		_slots.append(self)
	else:
		_slot = _free_slots.pop_back()
		_slots[_slot] = self

func _release_slot() -> void :
	if _slot >= 0 and _slot < _slots.size() and _slots[_slot] == self:
		_slots[_slot] = null
		_free_slots.append(_slot)
	_slot = -1

func _enter_tree() -> void :
	if _wants_slot and _slot < 0:
		_take_slot()

func _exit_tree() -> void :
	_release_slot()
	_leave_grid()

func _join_grid() -> void :
	_cell = Vector2i((global_position / GRID_CELL).floor())
	if not _grid.has(_cell):
		_grid[_cell] = []
	_grid[_cell].append(self)
	set_process(_flash > 0.0)

func _leave_grid() -> void :
	if _grid.has(_cell):
		var list: Array = _grid[_cell]
		list.erase(self)
		if list.is_empty():
			_grid.erase(_cell)
	_cell = Vector2i(1 << 30, 0)
	set_process(true)

func _in_grid() -> bool:
	return _cell.x != 1 << 30


static func wake_near(player: Player) -> void :
	var r: = player.pickup_range
	var p: = player.global_position
	var lo: = Vector2i(((p - Vector2(r, r)) / GRID_CELL).floor())
	var hi: = Vector2i(((p + Vector2(r, r)) / GRID_CELL).floor())
	for cx in range(lo.x, hi.x + 1):
		for cy in range(lo.y, hi.y + 1):
			var cell: = Vector2i(cx, cy)
			if not _grid.has(cell):
				continue
			for g: XPGem in (_grid[cell] as Array).duplicate():
				if g.global_position.distance_squared_to(p) <= r * r:
					g._leave_grid()

class GemField extends Node:
	var player: Player
	func _process(_delta: float) -> void :
		if is_instance_valid(player):
			XPGem.wake_near(player)



static func _condense(viewport: Viewport, max_gems: int) -> int:
	var view: = viewport.get_canvas_transform().affine_inverse() * viewport.get_visible_rect()
	var keep: = maxi(max_gems, 1)
	var kept: = 0
	var host: XPGem = null
	var i: = _slots.size() - 1
	while i >= 0 and _gem_count() > keep:
		var g: XPGem = _slots[i]
		i -= 1
		if g == null or not is_instance_valid(g) or not g.is_inside_tree() or g.is_queued_for_deletion():
			continue
		if view.has_point(g.global_position):
			host = g
			break
		kept += g.value
		g._release_slot()
		g.queue_free()
	while host == null and i >= 0:
		var g: XPGem = _slots[i]
		i -= 1
		if g != null and is_instance_valid(g) and g.is_inside_tree() and not g.is_queued_for_deletion():
			host = g
	if host == null:
		return kept
	if kept > 0:
		host.add_value(kept)
	return 0



static func vacuum_all(tree: SceneTree, include_pickups: = false) -> void :
	for g: XPGem in tree.get_nodes_in_group("xp_vacuum"):
		g.pull()
	if include_pickups:
		for g: XPGem in tree.get_nodes_in_group("pullable_pickups"):
			g.pull()

func pull() -> void :
	_leave_grid()
	if not _attracted:
		_kick()
	_attracted = true
	max_speed = VACUUM_SPEED
	acceleration = VACUUM_ACCEL
	remove_from_group("xp_gems")

func add_value(amount: int) -> void :
	value += amount
	_flash = 0.25
	set_process(true)
	_update_tier()

static func tier_of(amount: int) -> int:
	var t: = 0
	for i in TIERS.size():
		if amount >= TIERS[i]:
			t = i
	return t

func _update_tier() -> void :
	if not mergeable:
		return
	var t: = tier_of(value)
	if t != _tier:
		_tier = t
		if t >= 2:
			Layers.put(self, Layers.PICKUPS + 1)
	queue_redraw()

func _ready() -> void :
	Layers.put(self, Layers.PICKUPS)
	_player = get_tree().get_first_node_in_group("player") as Player
	if vacuumable:
		add_to_group("xp_vacuum")
	if mergeable:
		add_to_group("xp_gems")
	_update_tier()
	if mergeable and magnetic and not _attracted and is_instance_valid(_player):
		if not is_instance_valid(_field):
			_field = GemField.new()
			_field.player = _player
			_field.process_priority = 5
			get_tree().current_scene.add_child(_field)
		_join_grid()

func _process(delta: float) -> void :
	if _flash > 0.0:
		_flash -= delta
		queue_redraw()
	elif _in_grid():
		set_process(false)
		return
	if _in_grid():
		return
	if not is_instance_valid(_player):
		return
	var to_player: = _player.global_position - global_position
	var dist: = to_player.length()
	if not magnetic:

		if dist < _player.radius + 22.0 and _can_collect():
			_take()
		return
	if not _attracted:
		if dist > _player.pickup_range:
			if mergeable and _flash <= 0.0:
				_join_grid()
			return
		_attracted = true
		remove_from_group("xp_gems")
		_kick()
	if dist < _player.radius:
		_take()
		return


	_vel = _vel.move_toward(to_player / dist * max_speed, acceleration * delta)
	var step: = _vel * delta
	if step.dot(to_player) > 0.0 and step.length() >= dist - _player.radius:
		_take()
	else:
		global_position += step



func _take() -> void :
	_release_slot()
	_collect()
	queue_free()


func _can_collect() -> bool:
	return true

func _kick() -> void :
	var away: = global_position - _player.global_position if is_instance_valid(_player) else Vector2.ZERO
	_vel = (away.normalized() if away.length_squared() > 1.0 else Vector2.UP) * KICK_SPEED


func _collect() -> void :
	_player.add_xp(value)
	if _tier >= 2:
		Game.sfx("xp_big")
		return
	var now: = Time.get_ticks_msec()
	_streak = mini(_streak + 1, 24) if now - _last_pickup < STREAK_TIME * 1000.0 else 0
	_last_pickup = now
	Game.sfx("xp", 1.0 + _streak * 0.03)

func _draw() -> void :
	var tex: = gem_texture(maxi(_tier, 0))
	draw_texture(tex, - tex.get_size() * 0.5)
	if _flash > 0.0:
		draw_circle(Vector2.ZERO, gem_size(maxi(_tier, 0)) * 1.9, Color(1, 1, 1, _flash * 1.6))

static func gem_size(tier: int) -> float:
	return 8.0 + tier * 3.0




static func gem_texture(tier: int) -> Texture2D:
	var color: = Game.theme.xp_tier_color(tier)
	var key: = "%d|%s" % [tier, color.to_html()]
	if _textures.has(key):
		return _textures[key]
	var s: = gem_size(tier)
	var glow: = tier >= 2
	var half: = ceili(s * 1.7 if glow else s + 3.0)
	var half_y: = ceili(maxf(s * 1.4 + 3.0, s * 1.7 if glow else 0.0))
	var img: = Image.create_empty(half * 2, half_y * 2, false, Image.FORMAT_RGBA8)
	var top: = Vector2(0, - s * 1.4)
	var bottom: = Vector2(0, s * 1.4)
	var mid: = Vector2(0, - s * 0.15)
	var layers: = [
		[PackedVector2Array([top + Vector2(0, -2), Vector2(s + 2, 0), bottom + Vector2(0, 2), Vector2( - s - 2, 0)]), color.darkened(0.7)], 
		[PackedVector2Array([top, mid, bottom, Vector2( - s, 0)]), color.lightened(0.25)], 
		[PackedVector2Array([top, Vector2(s, 0), bottom, mid]), color.darkened(0.2)], 
		[PackedVector2Array([top, Vector2(s * 0.45, - s * 0.5), mid, Vector2( - s * 0.45, - s * 0.5)]), color.lightened(0.6)], 
	]
	var glint: = Rect2( - s * 0.45, - s * 0.55, 2, 2)
	for y in half_y * 2:
		for x in half * 2:
			var p: = Vector2(x - half + 0.5, y - half_y + 0.5)
			var c: = Color(0, 0, 0, 0)
			if glow and p.length() < s * 1.7:
				c = Color(color, 0.16)
			for layer: Array in layers:
				if Geometry2D.is_point_in_polygon(p, layer[0]):
					c = layer[1]
			if glint.has_point(p):
				c = Color.WHITE
			img.set_pixel(x, y, c)
	var tex: = ImageTexture.create_from_image(img)
	_textures[key] = tex
	return tex
