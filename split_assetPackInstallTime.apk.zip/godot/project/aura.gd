class_name Aura
extends Weapon

const ID: = "aura"
const COOLDOWN_TEXT: = "burns %d%% more often"
const BASE_RADIUS: = 100.0
const PUSH: = 260.0
const BASE: = {"damage": 6.0, "cooldown": 0.5, "area": 1.0}
const UPGRADES: = [
	{"area": 1.15}, 
	{"damage": 3.0}, 
	{"cooldown": 0.85}, 
	{"area": 1.15}, 
	{"damage": 4.0}, 
	{"area": 1.15}, 
	{"damage": 5.0}, 
]




const HOLY: = {"damage": 6.0, "area": 1.35}
const HEART_CHANCE: = 0.03
const FED_CAP: = 100.0
const FED_DECAY: = 4.0

var damage: = 6.0
var cooldown: = 0.5
var area: = 1.0
var _timer: = 0.0
var _time: = 0.0
var _pulse: = 0.0
var _fed: = 0.0

func _on_level() -> void :
	Layers.put(self, Layers.AROUND_PLAYER)
	if holy and not player.healed.is_connected(_on_healed):
		player.healed.connect(_on_healed)

func _on_healed(amount: float) -> void :
	_fed = minf(_fed + amount, FED_CAP)

func radius() -> float:
	return area_of(BASE_RADIUS * area)

func _process(delta: float) -> void :
	_time += delta
	_pulse = maxf(_pulse - delta * 4.0, 0.0)
	queue_redraw()
	if _fed > 0.0:
		_fed = maxf(_fed - FED_DECAY * delta, 0.0)
	_timer -= delta
	if _timer > 0.0:
		return
	_timer = cooldown_of(cooldown)
	_pulse = 1.0
	var r: = radius()
	for e: Enemy in Enemy.near(global_position, r):
		var reach: = r + e.radius
		if global_position.distance_squared_to(e.global_position) < reach * reach:
			e.take_damage(power(damage) * (1.0 + _fed / 100.0), 0.0)
			if not e.is_dead():
				e.knock(global_position.direction_to(e.global_position) * PUSH)
			elif holy and randf() < HEART_CHANCE * player.luck:
				Pickup.little_heart(get_tree().current_scene, e.global_position)




func _draw() -> void :
	var r: = radius() * (1.0 + 0.04 * _pulse)
	var hot: = color.lightened(0.55)
	var dark: = color.darkened(0.55)

	PixelFx.arc(self, Vector2.ZERO, r * 0.86, 0, TAU, Color(dark, 0.22 + 0.06 * _pulse), r * 0.26)

	var rune_r: = r * 0.62
	var spin: = - _time * 0.6
	for i in 12:
		var a: = spin + TAU * i / 12.0
		PixelFx.arc(self, Vector2.ZERO, rune_r, a, a + TAU / 24.0, Color(color, 0.3), 2.0)
	for i in 6:
		var d: = Vector2.RIGHT.rotated(spin + TAU * (i + 0.25) / 6.0)
		var p: = d * rune_r
		var side: = d.orthogonal() * 3.0
		PixelFx.poly(self, PackedVector2Array([p + d * 6.0, p + side, p - d * 6.0, p - side]), Color(hot, 0.35))

	PixelFx.arc(self, Vector2.ZERO, r - 8.0, 0, TAU, Color(color, 0.18 + 0.12 * _pulse), 12.0)
	PixelFx.arc(self, Vector2.ZERO, r - 2.0, 0, TAU, Color(color, 0.85), 5.0)
	PixelFx.arc(self, Vector2.ZERO, r - 2.0, 0, TAU, Color(hot, 0.6 + 0.4 * _pulse), 2.0)


	var flames: = maxi(12, int(TAU * r / 22.0))
	var turn: = _time * 0.35
	var order: Array = range(flames)
	order.sort_custom( func(x: int, y: int) -> bool: return sin(turn + TAU * x / flames) < sin(turn + TAU * y / flames))
	for i: int in order:
		var at: = Vector2.RIGHT.rotated(turn + TAU * i / flames) * (r - 3.0)
		var grow: = (0.8 + 0.25 * sin(_time * 7.0 + i * 2.3)) * (1.0 + 0.35 * _pulse) * clampf(r / 110.0, 0.8, 1.3)
		draw_set_transform(PixelFx.snap(at), 0.0, Vector2.ONE * grow)
		PixelFx.draw_sprite(self, "flame", color, int(_time * 10.0 + i * 1.7), Color(1, 1, 1, 0.95), Vector2(0, -5))
	draw_set_transform(Vector2.ZERO)

	for i in 14:
		var life: = fmod(_time * 0.7 + i * 0.381, 1.0)
		var a: = i * 2.399
		var start: = Vector2.RIGHT.rotated(a) * r * (0.2 + 0.7 * fmod(i * 0.618, 1.0))
		var p: = start + Vector2(sin(_time * 3.0 + i) * 4.0, - life * 34.0)
		var s: = 4.0 if i % 3 == 0 else 3.0
		PixelFx.rect(self, Rect2(p - Vector2.ONE * s * 0.5, Vector2.ONE * s), Color(hot if i % 2 == 0 else color, (1.0 - life) * 0.9))
	if holy:
		var pulse: = 0.5 + 0.5 * sin(_time * 5.0)
		for i in 10:
			var a: = - _time * 0.5 + TAU * i / 10.0
			var d: = Vector2.RIGHT.rotated(a)
			var side: = d.orthogonal() * r * 0.09
			var tip: = d * r * (1.32 + 0.05 * sin(_time * 4.0 + i))
			PixelFx.poly(self, PackedVector2Array([d * r * 0.97 + side, tip, d * r * 0.97 - side]), Color(color, 0.9))
			PixelFx.poly(self, PackedVector2Array([d * r * 1.0 + side * 0.4, tip, d * r * 1.0 - side * 0.4]), Color(1, 1, 1, 0.85))
		if _fed > 0.0:
			var f: = _fed / FED_CAP
			PixelFx.arc(self, Vector2.ZERO, r * 0.75, 0, TAU, Color(1, 0.35, 0.3, 0.12 + 0.2 * f * pulse), r * 0.4 * f + 4.0)
		for i in 12:
			var a: = _time * 0.4 + TAU * i / 12.0
			var d: = Vector2.RIGHT.rotated(a)
			PixelFx.line(self, d * r * 0.3, d * r * 0.95, Color(1, 1, 1, 0.08 + 0.08 * pulse), 6.0)
		PixelFx.arc(self, Vector2.ZERO, r * (0.9 + 0.05 * pulse), 0, TAU, Color(1, 1, 1, 0.25 + 0.25 * pulse), 4)
		PixelFx.arc(self, Vector2.ZERO, r + 8.0, 0, TAU, Color(hot, 0.3 * pulse), 2)
