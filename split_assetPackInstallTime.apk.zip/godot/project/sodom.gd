class_name Sodom
extends Weapon








const ID: = "sodom"
const COOLDOWN_TEXT: = "hurls %d%% more often"
const SPEED: = 330.0
const SPREAD: = 0.12
const STAGGER: = 0.08
const BASE: = {"damage": 20.0, "cooldown": 2.8, "count": 3, "speed": 1.0, "area": 1.0}
const UPGRADES: = [
	{"damage": 10.0}, 
	{"damage": 10.0, "speed": 1.2}, 
	{"damage": 10.0}, 
	{"damage": 10.0, "speed": 1.2}, 
	{"damage": 10.0}, 
	{"damage": 10.0, "speed": 1.2}, 
	{"damage": 10.0}, 
]
const HOLY: = {"damage": 40.0, "area": 2.4}
const HOLY_STARS: = 2
const HOLY_SPEED: = 0.7

var damage: = 20.0
var cooldown: = 2.8
var count: = 3
var speed: = 1.0
var area: = 1.0
var _timer: = 1.0

var _aim: = Vector2.RIGHT
var _left: = 0
var _next: = 0
var _gap: = 0.0

func _process(delta: float) -> void :
	_timer -= delta
	if _left > 0:
		_gap -= delta
		if _gap <= 0.0:
			_throw()
		return
	if _timer > 0.0:
		return
	var targets: = enemies_on_screen()
	if targets.is_empty():
		return
	_timer = cooldown_of(cooldown)
	_aim = global_position.direction_to((targets.pick_random() as Enemy).global_position)
	_left = HOLY_STARS + player.extra_projectiles if holy else amount_of(count)
	_next = 0
	_throw()


func _throw() -> void :
	var step: = int((_next + 1) / 2.0) * (1 if _next % 2 == 1 else -1)
	var dir: = _aim.rotated(step * SPREAD * (1.6 if holy else 1.0))
	var p: = fire_projectile(global_position, dir, SPEED * speed * (HOLY_SPEED if holy else 1.0), damage, 
		100000 if holy else 1, Projectile.Style.METEOR, area)
	p.radius = 13.0
	p.lifetime = 4.0 if holy else 2.6
	Game.sfx("explode", randf_range(1.5, 1.7), -8.0 - 2.0 * _next)
	_next += 1
	_left -= 1
	_gap = STAGGER
